(function(){'use strict';
 function qrInit(){
  document.querySelectorAll('[data-ovm-qr]').forEach(function(node){
   if(node.dataset.qrReady==='1')return;
   const value=node.getAttribute('data-ovm-qr');
   if(!value)return;
   node.replaceChildren();
   if(typeof window.QRCode!=='function'){
    node.textContent='No se pudo cargar el código QR. Puedes presentar tu enlace privado.';
    node.classList.add('ovm-qr-error');
    return;
   }
   try{
    new window.QRCode(node,{text:value,width:168,height:168,correctLevel:window.QRCode.CorrectLevel.M});
    if(!node.querySelector('canvas,img'))throw new Error('No se dibujó el QR');
    node.dataset.qrReady='1';node.classList.remove('ovm-qr-error');
   }catch(e){node.replaceChildren();node.textContent='No se pudo generar el QR. Presenta el enlace o tu WhatsApp al negocio.';node.classList.add('ovm-qr-error');}
  });
 }
 function fallbackCopy(value){
  const el=document.createElement('textarea');el.value=value;el.setAttribute('readonly','');
  el.style.cssText='position:fixed;top:0;left:-10000px;opacity:0;';
  document.body.appendChild(el);el.focus();el.select();el.setSelectionRange(0,value.length);
  let ok=false;
  try{ok=document.execCommand('copy');}catch(e){}
  el.remove();return ok;
 }
 async function copyValue(value){
  if(navigator.clipboard&&window.isSecureContext){
   try{await navigator.clipboard.writeText(value);return true;}catch(e){}
  }
  return fallbackCopy(value);
 }
 document.addEventListener('click',async function(event){
  const btn=event.target.closest('[data-ovm-copy]');if(!btn)return;
  event.preventDefault();
  const value=btn.getAttribute('data-ovm-copy');if(!value)return;
  const original=btn.dataset.originalLabel||btn.textContent;
  btn.dataset.originalLabel=original;btn.disabled=true;
  const ok=await copyValue(value);
  if(ok){btn.textContent='✓ Enlace copiado';}
  else{btn.textContent='Selecciona y copia el enlace';window.prompt('Copia el enlace de la membresía:',value);}
  btn.disabled=false;
  window.setTimeout(function(){btn.textContent=original;},2400);
 });
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',qrInit);else qrInit();
})();
