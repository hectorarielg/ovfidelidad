document.addEventListener('click',function(e){
 const add=e.target.closest('#ovm-add-service');
 if(add){
   const list=document.getElementById('ovm-services-list');
   if(!list||list.children.length>=30)return;
   const row=document.createElement('div');
   row.className='ovm-service';
   row.innerHTML='<input name="service[]" maxlength="190" placeholder="Nombre del servicio" required><input name="quantity[]" type="number" min="1" max="100000" value="1" aria-label="Sesiones" required><button class="ovm-remove-service" type="button" aria-label="Quitar servicio">×</button>';
   list.appendChild(row);
   row.querySelector('input').focus();
 }
 const remove=e.target.closest('.ovm-remove-service');
 if(remove&&!remove.disabled){remove.closest('.ovm-service').remove();}
});

(function(){'use strict';
 const app=document.querySelector('.ovm-app');
 if(!app) return;
 const q=(s,root=app)=>root.querySelector(s);
 const make=(tag,val)=>{const n=document.createElement(tag); if(val!==undefined)n.textContent=String(val); return n;};

 async function ajax(body){
   const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body});
   const json=await response.json();
   if(!response.ok||!json.success) throw new Error(json.data?.message||'Error de consulta.');
   return json.data;
 }

 // Session method toggle and auto scroll to selected contract
 const methods=app.querySelectorAll('[data-ovm-method]'),camera=app.querySelector('#ovm-start-camera'),phone=app.querySelector('#ovm-client-lookup');
 methods.forEach(b=>b.addEventListener('click',()=>{methods.forEach(x=>x.classList.toggle('is-active',x===b));const qr=b.dataset.ovmMethod==='qr';if(camera)camera.hidden=!qr;if(phone){phone.placeholder=qr?'Pega el enlace o escanea el QR':'Ej. 3312345678';phone.focus();}}));
 const detail=q('#ovm-contract-detail'); if(detail && location.search.includes('contract_id=')){ setTimeout(()=>detail.scrollIntoView({behavior:'smooth',block:'start'}),120); }

 // Session modal: QR and WhatsApp share exactly the same lookup and server-side balance check.
 const lookupForm=q('#ovm-session-lookup-form'),modal=q('#ovm-session-modal');
 if(lookupForm&&modal&&window.OVM_AJAX){
   const field=q('#ovm-client-lookup'),feedback=q('#ovm-session-feedback'),dialog=q('.ovm-modal-dialog',modal),body=q('#ovm-modal-body',modal),msg=q('#ovm-modal-feedback',modal);
   let result=null,contract=null,lastFocus=null,busy=false;
   const uuid=()=>window.crypto&&crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('');
   function open(){lastFocus=document.activeElement;modal.hidden=false;document.body.classList.add('ovm-modal-open');msg.textContent='';dialog.focus();}
   function close(){if(busy)return;modal.hidden=true;document.body.classList.remove('ovm-modal-open');if(lastFocus&&lastFocus.focus)lastFocus.focus();}
   modal.addEventListener('click',e=>{if(e.target.closest('[data-ovm-close]'))close();});
   document.addEventListener('keydown',e=>{if(!modal.hidden&&e.key==='Escape'){e.preventDefault();close();}if(!modal.hidden&&e.key==='Tab'){
     const focusable=Array.from(modal.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled])')).filter(n=>n.offsetParent!==null);
     if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
   }});
   function line(className,content){const d=make('div');d.className=className;if(content)d.textContent=content;return d;}
   function renderSelection(){
     contract=null;msg.textContent='';body.replaceChildren();
     const customer=line('ovm-modal-customer');customer.append(make('strong',result.client.name),make('small',result.client.phone));body.append(customer);
     const heading=make('h3','Selecciona la membresía');body.append(heading);
     const available=result.contracts.filter(c=>c.valid&&c.services.some(s=>s.remaining>0));
     if(!available.length){body.append(line('ovm-modal-note','Este cliente no tiene sesiones vigentes disponibles.'));return;}
     available.forEach(c=>{const btn=make('button');btn.type='button';btn.className='ovm-contract-option';let remaining=c.services.reduce((a,s)=>a+s.remaining,0);btn.append(make('strong',c.name),make('small',`${remaining} sesiones disponibles · Vence ${c.expires}`));btn.addEventListener('click',()=>renderContract(c));body.append(btn);});
   }
   function renderContract(c){
     contract=c;msg.textContent='';body.replaceChildren();
     const back=make('button','← Cambiar membresía');back.type='button';back.className='ovm-modal-back';back.onclick=renderSelection;body.append(back);
     const heading=make('h3',c.name);body.append(heading);
     body.append(line('ovm-modal-note',result.client.name+' · Vence '+c.expires));
     const services=c.services.filter(s=>s.remaining>0);
     if(!services.length){body.append(line('ovm-modal-note','No hay sesiones disponibles.'));return;}
     const form=make('form');form.className='ovm-modal-form';
     const serviceLabel=make('label','Servicio realizado');const select=make('select');select.required=true;
     services.forEach(s=>{const opt=make('option',`${s.name} · ${s.remaining} disponibles`);opt.value=String(s.id);select.append(opt);});serviceLabel.append(select);form.append(serviceLabel);
     const qtyLabel=make('label','Sesiones a utilizar');const qty=make('input');qty.type='number';qty.min='1';qty.value='1';qty.required=true;qty.inputMode='numeric';qtyLabel.append(qty);form.append(qtyLabel);
     const noteLabel=make('label','Nota (opcional)');const note=make('textarea');note.rows=2;note.maxLength=255;note.placeholder='Referencia del servicio';noteLabel.append(note);form.append(noteLabel);
     const preview=line('ovm-modal-preview');form.append(preview);
     const button=make('button','Confirmar y descontar sesión');button.type='submit';button.className='ovm-btn ovm-confirm-use';form.append(button);
     const current=()=>services.find(s=>String(s.id)===select.value);
     const refresh=()=>{const s=current();qty.max=String(Math.min(100,s.remaining));const count=Number(qty.value)||0;preview.textContent=`Saldo posterior: ${s.remaining-Math.min(Math.max(count,0),s.remaining)} de ${s.total} sesiones`;};
     select.addEventListener('change',()=>{qty.value='1';refresh();});qty.addEventListener('input',refresh);refresh();
     form.addEventListener('submit',async e=>{
       e.preventDefault();if(busy)return;
       const s=current(),count=Number(qty.value);
       if(!Number.isInteger(count)||count<1||count>100||count>s.remaining){msg.textContent='Verifica la cantidad de sesiones.';return;}
       if(!window.confirm(`¿Registrar ${count} sesión(es) de ${s.name} para ${result.client.name}?`))return;
       busy=true;button.disabled=true;button.textContent='Registrando…';msg.textContent='';
       try{
         const data=await ajax(new URLSearchParams({action:'ovm_session_consume',nonce:OVM_AJAX.nonce,balance_id:String(s.id),qty:String(count),note:note.value,request_id:uuid()}));
         // Use only the server-verified balance. Never infer the previous balance from the service name.
         s.remaining=Number(data.remaining);
         body.replaceChildren();
         const ok=line('ovm-modal-done');
         const successIcon=line('ovm-success-icon','✓');
         const heading=line('ovm-success-title','Sesión registrada');
         const description=line('ovm-success-service',`Servicio: ${data.service}`);
         const summary=line('ovm-success-summary');
         const metric=(label,value,cls)=>{const item=line('ovm-success-stat '+(cls||''));item.append(make('small',label),make('strong',value));return item;};
         summary.append(metric('Antes',`${data.previous} sesiones`),metric('Descontadas',`−${data.used}`),metric('Ahora',`${data.remaining} sesiones`,'is-current'));
         ok.append(successIcon,heading,description,summary);
         body.append(ok);
         const again=make('button','Registrar otro servicio');again.className='ovm-btn';again.type='button';again.onclick=renderSelection;
         const done=make('button','Terminar');done.className='ovm-modal-secondary';done.type='button';done.onclick=close;body.append(again,done);feedback.textContent='Sesión registrada correctamente.';
       }catch(err){msg.textContent=err.message||'No se pudo registrar la sesión.';button.disabled=false;button.textContent='Confirmar y descontar sesión';}
       finally{busy=false;}
     });body.append(form);
   }
   async function searchClient(value){
     if(busy||!value.trim())return;
     feedback.textContent='Buscando cliente…';
     try{
       result=await ajax(new URLSearchParams({action:'ovm_session_lookup',nonce:OVM_AJAX.nonce,lookup:value.trim()}));
       feedback.textContent='Cliente encontrado: '+result.client.name;
       open();renderSelection();
       const available=result.contracts.filter(c=>c.valid&&c.services.some(s=>s.remaining>0));
       if(available.length===1)renderContract(available[0]);
     }catch(err){feedback.textContent=err.message||'No se encontró el cliente.';}
   }
   lookupForm.addEventListener('submit',e=>{e.preventDefault();searchClient(field.value);});
   const initialLookup=new URLSearchParams(window.location.search).get('lookup');if(initialLookup){field.value=initialLookup;searchClient(initialLookup);}
   // Called by QR scanner only after it detects a code.
   document.addEventListener('ovm:qr-found',e=>{field.value=e.detail.value;searchClient(e.detail.value);});
   const fromURL=new URLSearchParams(location.search);const initial=fromURL.get('lookup');if(initial){field.value=initial;searchClient(initial);}
 }

 // Shared AJAX analytics for Resumen and Reportes.
 const analytics=q('[data-ovm-analytics]');
 if(analytics&&window.OVM_AJAX){
   const period=q('.ovm-analytics-period',analytics),from=q('.ovm-analytics-from',analytics),to=q('.ovm-analytics-to',analytics),client=q('.ovm-analytics-client',analytics),clientInput=q('.ovm-analytics-client-search',analytics),clientResults=q('.ovm-analytics-client-results',analytics),clientClear=q('.ovm-analytics-client-clear',analytics),clientHelp=q('.ovm-analytics-client-help',analytics),allClients=q('.ovm-analytics-all-clients',analytics),scopeBadge=q('.ovm-analytics-scope',analytics),pkg=q('.ovm-analytics-package',analytics),status=q('.ovm-analytics-status',analytics),reset=q('.ovm-analytics-reset',analytics);
   const feedback=q('#ovm-report-feedback')||q('.ovm-analytics-feedback');
   const search=q('#ovm-report-search'),table=q('#ovm-report-results'),pages=q('#ovm-report-pagination'),exportBtn=q('#ovm-report-export');
   let controller=null,request=0,timer=0;
   const query=(page)=>{
     const values={action:'ovm_report_search',nonce:OVM_AJAX.nonce,period:period.value,from:from.value,to:to.value,client_id:client.value,package_id:pkg.value,filter:status?.value||'all',search:search?.value||'',page:String(page)};
     return new URLSearchParams(values);
   };
   function syncDates(){
     const custom=period.value==='custom';from.disabled=to.disabled=!custom;
     if(custom){const d=new Date();const today=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');if(!from.value)from.value=today.slice(0,8)+'01';if(!to.value)to.value=today;}
   }
   const fmtNumber=(n)=>new Intl.NumberFormat('es-MX',{maximumFractionDigits:0}).format(Number(n)||0);
   const fmtMoney=(n)=>new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(Number(n)||0);
   function chart(data){
     const root=q('.ovm-analytics-chart');if(!root)return;root.replaceChildren();
     const values=data.trend||[];
     if(!values.length){root.append(make('p','Sin actividad para los filtros seleccionados.'));return;}
     // Group into at most 16 columns so even large custom ranges stay readable on phones.
     let points=values;const groups=[];
     if(points.length>16){const bucket=Math.ceil(points.length/16);for(let i=0;i<points.length;i+=bucket){const part=points.slice(i,i+bucket);groups.push({date:part[0].date,sales:part.reduce((n,x)=>n+(+x.sales||0),0),sessions:part.reduce((n,x)=>n+(+x.sessions||0),0)});}points=groups;}
     const peak=Math.max(1,...points.flatMap(x=>[+x.sales||0,Math.max(0,+x.sessions||0)]));
     const caption=make('div');caption.className='ovm-chart-legend';caption.append(make('span','● Membresías registradas'),make('span','● Sesiones netas'));root.append(caption);
     const bars=make('div');bars.className='ovm-chart-bars';
     points.forEach(x=>{const col=make('div');col.className='ovm-chart-column';const pair=make('div');pair.className='ovm-chart-pair';
       const a=make('span');a.className='ovm-chart-sale';a.style.height=Math.max(2,Math.max(0,+x.sales||0)/peak*100)+'%';a.title=`${x.date}: ${x.sales} membresías`;
       const b=make('span');b.className='ovm-chart-session';b.style.height=Math.max(2,Math.max(0,+x.sessions||0)/peak*100)+'%';b.title=`${x.date}: ${x.sessions} sesiones netas`;
       pair.append(a,b);col.append(pair,make('small',x.date.slice(5)));bars.append(col);
     });root.append(bars);
   }
   function topChart(items,selector='.ovm-analytics-top'){const root=q(selector);if(!root)return;root.replaceChildren();
     if(!items?.length){root.append(make('p','Sin paquetes vendidos en este periodo.'));return;}
     const max=Math.max(1,...items.map(v=>+v.qty||0));items.forEach(v=>{const box=make('div');box.className='ovm-bar-row';const label=make('div');label.className='ovm-bar-label';label.append(make('span',v.name),make('strong',v.qty));const track=make('div');track.className='ovm-bar-track';const fill=make('span');fill.style.width=(v.qty/max*100)+'%';track.append(fill);box.append(label,track);root.append(box);});
   }
   function updateExport(){if(!exportBtn)return;const url=new URL(exportBtn.href,window.location.origin);const values=query(1);for(const [k,v] of values){if(k!=='action'&&k!=='page'&&k!=='nonce')url.searchParams.set(k,v);}exportBtn.href=url.toString();}
   async function load(page=1){
     if(period.value==='custom'&&(!from.value||!to.value)){feedback.textContent='Selecciona las dos fechas.';return;}
     if(controller)controller.abort();controller=new AbortController();const id=++request;
     feedback.textContent='Actualizando información…';updateExport();
     try{const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body:query(page),signal:controller.signal});const json=await response.json();if(id!==request)return;
       if(!response.ok||!json.success)throw new Error(json.data?.message||'No fue posible actualizar los datos.');
       const d=json.data;
       app.querySelectorAll('[data-ovm-metric]').forEach(el=>{const key=el.dataset.ovmMetric;el.textContent=key==='sales_value'?fmtMoney(d[key]):fmtNumber(d[key]);});
       chart(d);topChart(d.top);topChart(d.clients_top,'.ovm-analytics-client-rank');topChart(d.staff_top,'.ovm-analytics-staff-rank');
       if(table){table.replaceChildren();(d.items||[]).forEach(r=>{const tr=make('tr');tr.append(make('td',r.client),make('td',r.package),make('td',r.phone),make('td',r.price),make('td',r.created),make('td',r.expires),make('td',r.status));table.append(tr);});if(!(d.items||[]).length){const tr=make('tr');const cell=make('td','Sin registros en este periodo.');cell.colSpan=7;tr.append(cell);table.append(tr);}}
       if(pages)renderPagination(pages,d.page,d.pages,load);
       feedback.textContent=`Del ${d.dates.from} al ${d.dates.to} · ${d.total} membresías registradas. Saldos consultados al día de hoy.`;
     }catch(err){if(err.name!=='AbortError')feedback.textContent=err.message||'No se pudo actualizar.';}
   }
   // Keep the general / individual-client scope explicit and synchronized with AJAX and CSV.
   function syncClientScope(){
     const all=client.value==='0';
     if(allClients){allClients.classList.toggle('is-active',all);allClients.setAttribute('aria-pressed',String(all));}
     if(scopeBadge)scopeBadge.textContent=all?'Todos los clientes':'Cliente individual';
   }
   if(allClients)allClients.addEventListener('click',()=>{
     analytics.dispatchEvent(new Event('ovm:client-reset'));
     client.value='0';syncClientScope();load(1);
   });
   // AJAX client search. Never use free text as a client_id: explicit selection required.
   if(clientInput&&clientResults){
     let lookupTimer=0,lookupAbort=null,lookupSequence=0,activeIndex=-1;
     const closeResults=()=>{clientResults.hidden=true;clientInput.setAttribute('aria-expanded','false');clientInput.removeAttribute('aria-activedescendant');activeIndex=-1;};
     const clearItems=()=>{clientResults.replaceChildren();closeResults();};
     const selectClient=(item)=>{
       client.value=String(item.id);clientInput.value=item.name+' · '+item.phone;
       clientHelp.textContent='Cliente seleccionado: '+item.name;
       clientClear.hidden=false;syncClientScope();clearItems();load(1);
     };
     const showItems=(items)=>{
       clientResults.replaceChildren();activeIndex=-1;
       if(!items.length){const empty=make('div','No se encontraron clientes.');empty.className='ovm-analytics-client-empty';clientResults.append(empty);}
       else items.forEach((item,index)=>{
         const button=document.createElement('button');button.type='button';button.className='ovm-analytics-client-option';button.setAttribute('role','option');button.id='ovm-analytics-client-option-'+index;
         button.append(make('strong',item.name),make('small',item.phone));
         button.addEventListener('mousedown',event=>event.preventDefault());button.addEventListener('click',()=>selectClient(item));clientResults.append(button);
       });
       clientResults.hidden=false;clientInput.setAttribute('aria-expanded','true');
     };
     const findClients=async(text)=>{
       if(lookupAbort)lookupAbort.abort();lookupAbort=new AbortController();const seq=++lookupSequence;
       if(!text.trim()){clearItems();clientHelp.textContent='Escribe para buscar por nombre, WhatsApp o correo.';return;}
       clientHelp.textContent='Buscando clientes…';
       const body=new URLSearchParams({action:'ovm_report_clients',nonce:OVM_AJAX.nonce,search:text});
       try{const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body,signal:lookupAbort.signal});const json=await response.json();if(seq!==lookupSequence)return;
         if(!response.ok||!json.success)throw new Error(json.data?.message||'No se pudo buscar clientes.');
         showItems(json.data.items||[]);clientHelp.textContent=(json.data.items||[]).length+' coincidencias. Selecciona un cliente.';
       }catch(err){if(err.name!=='AbortError'){clearItems();clientHelp.textContent=err.message||'No se pudo buscar clientes.';}}
     };
     clientInput.addEventListener('input',()=>{
       clearTimeout(lookupTimer);if(lookupAbort)lookupAbort.abort();lookupSequence++;
       if(client.value!=='0'){client.value='0';clientClear.hidden=true;syncClientScope();load(1);}
       if(!clientInput.value.trim()){clearItems();clientHelp.textContent='Vista general: todos los clientes';return;}
       lookupTimer=setTimeout(()=>findClients(clientInput.value.trim()),240);
     });
     clientInput.addEventListener('keydown',event=>{
       if(event.key==='Escape'){closeResults();return;}
       const options=Array.from(clientResults.querySelectorAll('.ovm-analytics-client-option'));
       if(!options.length||clientResults.hidden)return;
       if(event.key==='ArrowDown'||event.key==='ArrowUp'){
         event.preventDefault();activeIndex=(activeIndex+(event.key==='ArrowDown'?1:-1)+options.length)%options.length;
         options.forEach((o,i)=>o.setAttribute('aria-selected',String(i===activeIndex)));
         clientInput.setAttribute('aria-activedescendant',options[activeIndex].id);options[activeIndex].scrollIntoView({block:'nearest'});
       }else if(event.key==='Enter'&&activeIndex>=0){event.preventDefault();options[activeIndex].click();}
     });
     clientClear.addEventListener('click',()=>{clearTimeout(lookupTimer);if(lookupAbort)lookupAbort.abort();lookupSequence++;client.value='0';clientInput.value='';clientClear.hidden=true;clientHelp.textContent='Vista general: todos los clientes';syncClientScope();clearItems();load(1);clientInput.focus();});
     document.addEventListener('pointerdown',event=>{if(!event.target.closest('.ovm-analytics-client-control'))closeResults();});
     analytics.addEventListener('ovm:client-reset',()=>{clearTimeout(lookupTimer);if(lookupAbort)lookupAbort.abort();lookupSequence++;clientInput.value='';clientClear.hidden=true;clientHelp.textContent='Vista general: todos los clientes';syncClientScope();clearItems();});
   }
   [period,client,pkg,status,from,to].filter(Boolean).forEach(field=>field.addEventListener('change',()=>{syncDates();load(1);}));
   if(search)search.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>load(1),280)});
   reset.addEventListener('click',()=>{analytics.dispatchEvent(new Event('ovm:client-reset'));period.value='month';client.value='0';pkg.value='0';if(status)status.value='all';from.value='';to.value='';if(search)search.value='';syncDates();syncClientScope();load(1);});
   syncDates();syncClientScope();load(1);
 }

 function renderPagination(container,page,pages,loadFn){
   container.replaceChildren();
   if(pages<=1) return;
   let prev=make('button','Anterior'), next=make('button','Siguiente'), label=make('span',`Página ${page} de ${pages}`);
   prev.type=next.type='button';
   prev.disabled=page<=1; next.disabled=page>=pages;
   prev.onclick=()=>loadFn(page-1); next.onclick=()=>loadFn(page+1);
   container.append(prev,label,next);
 }
})();

/* OV Membresías 1.3.5: accessible mobile navigation drawer. */
(function(){'use strict';
 const app=document.querySelector('.ovm-app');if(!app)return;
 const trigger=app.querySelector('#ovm-mobile-more-trigger');
 const menu=app.querySelector('#ovm-mobile-more-menu');
 const backdrop=app.querySelector('#ovm-mobile-more-backdrop');
 const closeButton=app.querySelector('#ovm-mobile-more-close');
 if(!trigger||!menu||!backdrop||!closeButton)return;
 let lastFocus=null;
 function closeMenu(restoreFocus=true){
   if(menu.hidden)return;
   menu.hidden=true;backdrop.hidden=true;
   trigger.setAttribute('aria-expanded','false');
   if(restoreFocus)trigger.focus({preventScroll:true});
 }
 function openMenu(){
   lastFocus=document.activeElement;
   menu.hidden=false;backdrop.hidden=false;
   trigger.setAttribute('aria-expanded','true');
   const first=menu.querySelector('a');
   (first||closeButton).focus({preventScroll:true});
 }
 trigger.addEventListener('click',()=>menu.hidden?openMenu():closeMenu());
 closeButton.addEventListener('click',()=>closeMenu());
 backdrop.addEventListener('click',()=>closeMenu());
 document.addEventListener('keydown',e=>{
   if(menu.hidden)return;
   if(e.key==='Escape'){e.preventDefault();closeMenu();return;}
   if(e.key==='Tab'){
     const focusable=[...menu.querySelectorAll('a,button')].filter(el=>!el.disabled);
     const first=focusable[0],last=focusable[focusable.length-1];
     if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
     else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
   }
 });
 document.addEventListener('click',e=>{
   if(!menu.hidden && e.target.closest('.ovm-mobile-nav a'))closeMenu(false);
 });
 const media=window.matchMedia('(min-width: 901px)');
 media.addEventListener?.('change',e=>{if(e.matches)closeMenu(false);});
})();

/* 1.3.6: server-side client lookup for membership assignment. */
(function(){'use strict';
 const app=document.querySelector('.ovm-app');
 const input=app?.querySelector('#ovm-assign-search');
 if(!input||!window.OVM_AJAX)return;
 const filter=app.querySelector('#ovm-assign-filter');
 const results=app.querySelector('#ovm-assign-results');
 const feedback=app.querySelector('#ovm-assign-feedback');
 const pages=app.querySelector('#ovm-assign-pagination');
 const selected=app.querySelector('#ovm-assign-selected');
 const selectedName=app.querySelector('#ovm-assign-selected-name');
 const selectedId=app.querySelector('#ovm-assign-client-id');
 const clear=app.querySelector('#ovm-assign-clear');
 const form=selectedId.closest('form');
 const submit=form.querySelector('button[type="submit"]');
 let timer,controller,serial=0;
 const node=(tag,value)=>{const el=document.createElement(tag);if(value!==undefined)el.textContent=String(value);return el;};
 function refreshSubmit(){submit.disabled=!Number(selectedId.value);}
 function choose(c){
   selectedId.value=String(c.id);
   selectedName.textContent=c.name+' · '+c.phone;
   selected.hidden=false;
   results.replaceChildren();
   pages.replaceChildren();
   feedback.textContent='Cliente seleccionado. Ahora elige el paquete y confirma la asignación.';
   refreshSubmit();
 }
 function setEmpty(){selectedId.value='0';selected.hidden=true;selectedName.textContent='';refreshSubmit();}
 async function load(page=1){
   controller?.abort(); controller=new AbortController();const request=++serial;
   feedback.textContent='Buscando clientes…';
   const payload=new URLSearchParams({action:'ovm_assign_search',nonce:OVM_AJAX.nonce,search:input.value.trim(),filter:filter.value,page:String(page)});
   try{
     const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body:payload,signal:controller.signal});
     const data=await response.json();
     if(request!==serial)return;
     if(!response.ok||!data.success)throw Error(data.data?.message||'No se pudo realizar la búsqueda.');
     results.replaceChildren();pages.replaceChildren();
     feedback.textContent=data.data.total?`${data.data.total} cliente(s) encontrado(s). Selecciona uno.`:'No encontramos clientes con estos datos.';
     for(const c of data.data.items){
       const button=node('button');button.type='button';button.className='ovm-assign-result';
       const details=node('span'); details.className='ovm-assign-result-details';
       details.append(node('strong',c.name),node('small',c.phone));
       const mark=node('span',c.active?'Membresía activa':'Seleccionar');mark.className='ovm-assign-result-status';
       button.append(details,mark);button.addEventListener('click',()=>choose(c));results.append(button);
     }
     if(data.data.pages>1){
       const prev=node('button','Anterior'),next=node('button','Siguiente'),label=node('span',`Página ${data.data.page} de ${data.data.pages}`);
       prev.type=next.type='button';prev.disabled=data.data.page<=1;next.disabled=data.data.page>=data.data.pages;
       prev.onclick=()=>load(data.data.page-1);next.onclick=()=>load(data.data.page+1);
       pages.append(prev,label,next);
     }
   }catch(error){if(error.name!=='AbortError')feedback.textContent=error.message||'Error al consultar clientes.';}
 }
 input.addEventListener('input',()=>{setEmpty();clearTimeout(timer);timer=setTimeout(()=>load(1),280);});
 filter.addEventListener('change',()=>{setEmpty();load(1);});
 clear?.addEventListener('click',()=>{setEmpty();input.focus();load(1);});
 form.addEventListener('submit',event=>{
   if(!Number(selectedId.value)){event.preventDefault();feedback.textContent='Selecciona primero un cliente de los resultados.';input.focus();}
 });
 refreshSubmit();
 if(!Number(selectedId.value))load(1);
 else{feedback.textContent='Cliente preseleccionado. Puedes cambiarlo usando la búsqueda.';}
})();

/* 1.3.8: align the theme-generated duplicate page heading on small screens. */
(function(){'use strict';
  const app=document.querySelector('.ovm-app');if(!app)return;
  document.querySelectorAll('h1,h2').forEach(heading=>{
    if(app.contains(heading))return;
    if(heading.textContent.trim().replace(/\s+/g,' ').toLocaleLowerCase('es')==='membresías y paquetes'){
      heading.classList.add('ovm-theme-page-title');
    }
  });
})();


/* 1.5.4: collapse duplicate theme title wrappers to remove blank top area on mobile. */
(function(){'use strict';
  const app=document.querySelector('.ovm-app'); if(!app) return;
  document.querySelectorAll('.ovm-theme-page-title').forEach(heading=>{
    const wrap=heading.closest('.et_pb_module, .et_pb_text, .entry-header, .wp-block-group, .wp-block-post-title, .et_pb_title_container');
    if(wrap) wrap.classList.add('ovm-theme-page-title-wrap');
  });
})();

/* Membership handoff after manual package sale. */
document.addEventListener('click',function(event){
 const button=event.target.closest('.ovm-app [data-ovm-copy]');
 if(!button)return;
 const url=button.dataset.ovmCopy;
 const previous=button.textContent;
 if(navigator.clipboard?.writeText){navigator.clipboard.writeText(url).then(()=>{button.textContent='Enlace copiado ✓';setTimeout(()=>button.textContent=previous,2000)}).catch(()=>window.prompt('Copia el enlace de la tarjeta:',url));}
 else window.prompt('Copia el enlace de la tarjeta:',url);
});


/* 1.5.10: place desktop account popup directly ABOVE avatar, inside sidebar width.
   Fixed positioning avoids shifting the profile or pushing the sidebar contents. */
(function(){'use strict';
 const desktop=document.querySelector('.ovm-sidebar-account .ovf-shared-account');
 const mobile=document.querySelector('.ovm-mobile-account .ovf-shared-account');
 if(!desktop)return;
 const sidebar=desktop.closest('.ovm-tabs');
 const anchor=desktop.querySelector('summary');
 const options=desktop.querySelector('.ovf-shared-account-options');
 const media=window.matchMedia('(min-width:901px)');
 let raf=0;
 function place(){
   if(!desktop.open||!media.matches||!sidebar||!anchor||!options)return;
   const sr=sidebar.getBoundingClientRect(),ar=anchor.getBoundingClientRect();
   // Keep the popup completely within the navigation column and the viewport.
   const left=Math.max(12,Math.min(sr.left+12,window.innerWidth-164));
   const width=Math.max(150,Math.min(sr.width-24,window.innerWidth-left-12));
   const spaceAbove=Math.max(100,ar.top-20);
   const bottom=Math.max(12,window.innerHeight-ar.top+9);
   desktop.style.setProperty('--ovm-popup-left',left+'px');
   desktop.style.setProperty('--ovm-popup-width',width+'px');
   desktop.style.setProperty('--ovm-popup-bottom',bottom+'px');
   desktop.style.setProperty('--ovm-popup-height',Math.min(spaceAbove,420)+'px');
 }
 function schedule(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{raf=0;place();});}
 desktop.addEventListener('toggle',()=>{
   if(desktop.open){if(mobile)mobile.open=false;schedule();}
 });
 if(mobile)mobile.addEventListener('toggle',()=>{if(mobile.open)desktop.open=false;});
 window.addEventListener('resize',schedule,{passive:true});
 window.addEventListener('scroll',schedule,{passive:true,capture:true});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&desktop.open){desktop.open=false;anchor?.focus();}});
 document.addEventListener('pointerdown',e=>{if(desktop.open&&!desktop.contains(e.target))desktop.open=false;});
})();



/* 1.5.12: render the same account summary anatomy as OV Fidelidad.
   Use textContent for user-supplied display names and email addresses. */
(function(){'use strict';
  const iconClass=(a)=>{
    const t=(a.textContent||'').toLowerCase();
    if(t.includes('perfil')) return 'is-profile';
    if(t.includes('equipo')) return 'is-team';
    if(t.includes('fidelidad')||t.includes('escritorio')) return 'is-home';
    if(t.includes('cerrar')) return 'is-logout';
    return 'is-generic';
  };
  document.querySelectorAll('.ovm-app .ovf-shared-account').forEach(menu=>{
    const summary=menu.querySelector('summary');
    const options=menu.querySelector('.ovf-shared-account-options');
    if(!summary||!options)return;
    if(!options.querySelector('.ovm-account-popup-head')){
      const name=summary.querySelector('.ovf-shared-identity strong')?.textContent?.trim()||'';
      const role=summary.querySelector('.ovf-shared-identity small')?.textContent?.trim()||'';
      const emailNode=options.querySelector('.ovf-shared-email');
      const email=emailNode?.textContent?.trim()||'';
      const head=document.createElement('div');head.className='ovm-account-popup-head';
      const dot=document.createElement('span');dot.className='ovm-account-dot';dot.setAttribute('aria-hidden','true');
      const info=document.createElement('div');info.className='ovm-account-popup-info';
      const display=document.createElement('b');display.textContent=name;
      info.append(display);
      if(role){const r=document.createElement('small');r.textContent=role;info.append(r);}
      if(email){const e=document.createElement('em');e.textContent=email;info.append(e);}
      head.append(dot,info);options.insertBefore(head,options.firstChild);
      if(emailNode)emailNode.hidden=true;
    }
    options.querySelectorAll('a').forEach(a=>a.classList.add(iconClass(a)));
  });
})();
