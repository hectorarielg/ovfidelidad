(function(){'use strict';
 const root=document.querySelector('.ovm-crm-v2');if(!root||!window.OVM_AJAX)return;
 const $=(selector,parent=document)=>parent.querySelector(selector);
 const search=$('#ovm-crm-search'),filter=$('#ovm-crm-filter'),tbody=$('#ovm-crm-results'),cards=$('#ovm-crm-cards'),pages=$('#ovm-crm-pagination'),feedback=$('#ovm-crm-feedback'),total=$('#ovm-crm-total'),kpis=$('#ovm-crm-kpis');
 const drawer=$('#ovm-crm-drawer'),panel=$('.ovm-crm-drawer-panel',drawer),drawerBody=$('#ovm-crm-drawer-body'),drawerTitle=$('#ovm-crm-drawer-title',drawer);
 const el=(tag,value,cls)=>{const n=document.createElement(tag);if(value!==undefined)n.textContent=String(value);if(cls)n.className=cls;return n};
 const line=(tag,cls,text)=>el(tag,text,cls);
 const moneyDate=s=>s?new Intl.DateTimeFormat('es-MX',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(s+'T12:00:00')):'—';
 const urlSafe=s=>typeof s==='string'&&/^https:\/\/(wa\.me|api\.whatsapp\.com)\//.test(s);
 const link=(label,href,cls='')=>{const a=el('a',label,cls);a.href=href||'#';if(urlSafe(href)){a.target='_blank';a.rel='noopener noreferrer';}return a;};
 const button=(label,cb,cls='')=>{const b=el('button',label,cls);b.type='button';b.addEventListener('click',cb);return b;};
 const pill=(text,positive)=>line('span','ovm-crm-pill'+(positive?' is-active':''),text);
 let lastFocus=null,request=null,timer=null,req=0,pageNow=1,drawerBusy=false;
 function closeDrawer(){if(drawerBusy)return;drawer.hidden=true;document.body.classList.remove('ovm-crm-open');if(lastFocus&&lastFocus.focus)lastFocus.focus();}
 drawer.addEventListener('click',e=>{if(e.target.closest('[data-ovm-crm-close]'))closeDrawer()});
 document.addEventListener('keydown',e=>{
  if(drawer.hidden)return;
  if(e.key==='Escape'){e.preventDefault();closeDrawer();return;}
  if(e.key==='Tab'){
   const arr=[...drawer.querySelectorAll('a[href],button:not([disabled]),input:not([disabled])')].filter(x=>x.getClientRects().length);
   if(!arr.length)return;const first=arr[0],last=arr[arr.length-1];
   if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
   else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }
 });
 function kpiUpdate(metrics){
   const numbers=[metrics.clients,metrics.active,metrics.remaining,metrics.expiring];
   [...kpis.querySelectorAll('strong')].forEach((n,i)=>n.textContent=Number(numbers[i]||0).toLocaleString('es-MX'));
 }
 function actions(c){
  const wrap=line('div','ovm-crm-actions');
  wrap.append(button('Ver detalle',()=>openDrawer(c.id),'ovm-crm-action is-main'));
  if(c.whatsapp){wrap.append(link('WhatsApp',c.whatsapp,'ovm-crm-action is-wa'));}
  if(c.card)wrap.append(link('Tarjeta',c.card,'ovm-crm-action'));
  wrap.append(link('Asignar',c.assign,'ovm-crm-action'));
  return wrap;
 }
 function desktopActions(c){
  const wrap=line('div','ovm-crm-desktop-actions');
  wrap.append(button('Ver detalle',()=>openDrawer(c.id),'ovm-crm-action is-main'));
  const extra=line('details','ovm-crm-action-menu');
  const trigger=line('summary','ovm-crm-action-more','Más opciones');
  trigger.setAttribute('aria-label','Más acciones para '+c.name);
  extra.append(trigger);
  const menu=line('div','ovm-crm-action-popover');
  if(c.whatsapp)menu.append(link('WhatsApp',c.whatsapp,'ovm-crm-menu-link is-wa'));
  if(c.card)menu.append(link('Ver tarjeta',c.card,'ovm-crm-menu-link'));
  menu.append(link('Asignar membresía',c.assign,'ovm-crm-menu-link'));
  extra.append(menu);wrap.append(extra);
  return wrap;
 }
 function appendRow(c){
  const tr=el('tr');tr.className='ovm-crm-client-row';
  let td=el('td');td.className='ovm-crm-client-cell';
  const person=line('div','ovm-crm-person');
  const avatar=el('span',(c.name||'?').trim()[0].toUpperCase(),'ovm-crm-avatar');
  const info=line('div','ovm-crm-person-info');
  const fullName=line('strong','ovm-crm-client-name',c.name);
  const phone=line('small','ovm-crm-client-phone',c.phone);
  const email=line('small','ovm-crm-client-email',c.email||'Sin correo');
  email.title=c.email||'Sin correo';
  info.append(fullName,phone,email);person.append(avatar,info);td.append(person);tr.append(td);
  td=el('td');td.className='ovm-crm-membership-cell';
  const membership=line('div','ovm-crm-memberships');
  if(c.plans)membership.append(line('strong','ovm-crm-membership-name',c.plans));
  membership.append(pill(c.active?`${c.active} ${c.active===1?'activa':'activas'}`:c.contracts?`${c.contracts} ${c.contracts===1?'histórica':'históricas'}`:'Sin paquetes',!!c.active));
  td.append(membership);tr.append(td);
  td=el('td');td.className='ovm-crm-sessions-cell';
  const session=line('div','ovm-crm-sessions');
  const available=line('div','ovm-crm-sessions-available');available.append(line('strong','',String(c.remaining)),line('small','','disponibles'));
  const used=line('small','ovm-crm-sessions-used',String(c.used)+' usadas');
  session.append(available,used);
  const usedCount=Number(c.used)||0,remainingCount=Number(c.remaining)||0;
  const count=usedCount+remainingCount;
  if(count>0){const meter=line('div','ovm-crm-row-meter');const fill=el('span');fill.style.width=(Math.max(0,Math.min(100,remainingCount/count*100)))+'%';meter.append(fill);session.append(meter);}
  td.append(session);tr.append(td);
  td=el('td');td.className='ovm-crm-expiry-cell';td.append(line('span','ovm-crm-expiry-date',moneyDate(c.expires)));tr.append(td);
  td=el('td');td.className='ovm-crm-row-actions-cell';td.append(desktopActions(c));tr.append(td);
  tbody.append(tr);
 }
 function appendCard(c){
  const card=line('article','ovm-crm-client-card');const head=line('div','ovm-crm-client-head');const identity=line('div','ovm-crm-person');identity.append(el('span',(c.name||'?')[0].toUpperCase(),'ovm-crm-avatar'));const labels=line('div','ovm-crm-person-info');labels.append(line('strong','',c.name),line('small','',c.phone));identity.append(labels);head.append(identity,pill(c.active?`${c.active} ${c.active===1?'activa':'activas'}`:c.contracts?'Históricas':'Sin paquetes',!!c.active));card.append(head);
  if(c.plans)card.append(line('p','ovm-crm-plan-name',c.plans));
  const metrics=line('div','ovm-crm-client-metrics');[['Usadas',c.used],['Disponibles',c.remaining],['Vence',moneyDate(c.expires)]].forEach(pair=>{const box=line('div','');box.append(line('small','',pair[0]),line('strong','',pair[1]));metrics.append(box)});card.append(metrics,actions(c));cards.append(card);
 }
 function paging(p,n){pages.replaceChildren();if(n<=1)return;
   const prev=button('Anterior',()=>load(p-1));prev.disabled=p<=1;
   const next=button('Siguiente',()=>load(p+1));next.disabled=p>=n;
   pages.append(prev,el('span',`Página ${p} de ${n}`),next);
 }
 async function load(p=1){
  if(request)request.abort();request=new AbortController();const current=++req;
  feedback.textContent='Actualizando clientes…';
  try{
   const params=new URLSearchParams({action:'ovm_crm_search',nonce:OVM_AJAX.nonce,search:search.value,filter:filter.value,page:String(p)});
   const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body:params,signal:request.signal});const json=await response.json();
   if(current!==req)return;if(!response.ok||!json.success)throw new Error(json.data?.message||'Error consultando los clientes.');
   const data=json.data;pageNow=data.page;if(floating)floating.host.open=false;tbody.replaceChildren();cards.replaceChildren();
   data.items.forEach(c=>{appendRow(c);appendCard(c)});
   total.textContent=`${data.total} clientes`;
   feedback.textContent=data.total?`${data.total} coincidencias. Resultados actualizados.`:'No hay clientes que coincidan con estos filtros.';
   if(!data.total){const tr=el('tr');const td=el('td','Sin resultados. Prueba otra búsqueda.');td.colSpan=5;tr.append(td);tbody.append(tr);cards.append(line('p','ovm-crm-empty','No encontramos clientes con estos filtros.'));}
   kpiUpdate(data.metrics);paging(data.page,data.pages);
  }catch(err){if(err.name!=='AbortError')feedback.textContent=err.message||'No fue posible cargar el CRM.';}
 }
 // Floating secondary-actions layer stays visible outside horizontally scrollable tables.
 let floating=null;
 const restoreMenu=()=>{
   if(!floating)return;
   const {host,panel:popup}=floating;
   popup.classList.remove('ovm-crm-menu-floating');popup.removeAttribute('style');
   host.append(popup);floating=null;
 };
 function positionMenu(){
   if(!floating)return;
   const {host,panel:popup}=floating;
   const rect=host.querySelector('summary').getBoundingClientRect();
   const width=188;
   const left=Math.max(10,Math.min(window.innerWidth-width-10,rect.right-width));
   popup.style.left=left+'px';
   popup.style.top=(window.innerHeight-rect.bottom<175?Math.max(8,rect.top-156):rect.bottom+7)+'px';
 }
 root.addEventListener('toggle',e=>{
   const menu=e.target;
   if(!(menu instanceof HTMLDetailsElement)||!menu.matches('.ovm-crm-action-menu'))return;
   if(!menu.open){if(floating?.host===menu)restoreMenu();return;}
   root.querySelectorAll('.ovm-crm-action-menu[open]').forEach(other=>{if(other!==menu)other.open=false;});
   restoreMenu();
   const popup=menu.querySelector('.ovm-crm-action-popover');
   if(!popup)return;
   document.body.append(popup);
   popup.classList.add('ovm-crm-menu-floating');floating={host:menu,panel:popup};positionMenu();
 },true);
 document.addEventListener('pointerdown',e=>{
   root.querySelectorAll('.ovm-crm-action-menu[open]').forEach(menu=>{
     if(!menu.contains(e.target)&&!(floating?.host===menu&&floating.panel.contains(e.target)))menu.open=false;
   });
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape')root.querySelectorAll('.ovm-crm-action-menu[open]').forEach(menu=>menu.open=false);});
 window.addEventListener('resize',()=>{if(floating)positionMenu()},{passive:true});
 window.addEventListener('scroll',()=>{if(floating)floating.host.open=false},{capture:true,passive:true});
 search.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>load(1),250)});
 filter.addEventListener('change',()=>load(1));

 async function openDrawer(id){
   if(drawerBusy)return;
   lastFocus=document.activeElement;drawer.hidden=false;document.body.classList.add('ovm-crm-open');drawerTitle.textContent='Detalle del cliente';drawerBody.replaceChildren(line('p','ovm-crm-muted','Cargando información…'));panel.focus();drawerBusy=true;
   try{
    const params=new URLSearchParams({action:'ovm_crm_detail',nonce:OVM_AJAX.nonce,contact_id:String(id)});
    const response=await fetch(OVM_AJAX.url,{method:'POST',credentials:'same-origin',body:params});const json=await response.json();
    if(!response.ok||!json.success)throw new Error(json.data?.message||'No se pudo cargar la ficha.');
    showDetail(json.data);
   }catch(err){drawerBody.replaceChildren(line('p','ovm-crm-error',err.message||'Error al consultar el detalle.'));}
   finally{drawerBusy=false;}
 }
 function showDetail(data){
   drawerTitle.textContent=data.client.name;drawerBody.replaceChildren();const c=data.client;
   const contact=line('section','ovm-crm-detail-contact');const line1=line('div','ovm-crm-detail-identity');line1.append(el('span',(c.name||'?')[0].toUpperCase(),'ovm-crm-avatar'),line('strong','',c.name));contact.append(line1);
   const fields=line('div','ovm-crm-detail-fields');[['WhatsApp',c.phone],['Correo',c.email],['Cumpleaños',moneyDate(c.birthday)],['Marketing',c.marketing?'Autorizado':'No autorizado'],['Cliente desde',moneyDate((c.registered||'').slice(0,10))]].forEach(([label,value])=>{const f=line('div','');f.append(line('small','',label),line('strong','',value||'—'));fields.append(f)});contact.append(fields);
   const ctas=line('div','ovm-crm-detail-cta');if(c.whatsapp)ctas.append(link('Abrir WhatsApp',c.whatsapp,'ovm-crm-action is-wa'));if(c.followups&&c.followups.length){
    const templates=line('div','ovm-crm-templates');templates.append(line('strong','','Mensajes preparados'));
    c.followups.forEach(item=>templates.append(link(item.label,item.url,'ovm-crm-action')));
    contact.append(templates);
   }if(data.card)ctas.append(link('Ver tarjeta digital',data.card,'ovm-crm-action'));ctas.append(link('Asignar membresía',data.assign,'ovm-crm-action is-main'));
   const register=link('Registrar uso',data.register,'ovm-crm-action');ctas.append(register);contact.append(ctas);
   if(!c.marketing)contact.append(line('p','ovm-crm-consent-note','Este contacto no autorizó promociones. Utiliza WhatsApp solo para atención o comunicaciones permitidas.'));
   drawerBody.append(contact);
   const h=line('div','ovm-crm-detail-heading');h.append(line('h3','',`Membresías (${data.contracts.length})`));drawerBody.append(h);
   if(!data.contracts.length)drawerBody.append(line('p','ovm-crm-empty','Este cliente todavía no tiene membresías.'));
   data.contracts.forEach(plan=>{
      const article=line('article','ovm-crm-plan');const title=line('div','ovm-crm-plan-top');const ti=line('div','');ti.append(line('strong','',plan.name),line('small','',`${moneyDate(plan.starts)} al ${moneyDate(plan.expires)}`));title.append(ti,pill(plan.valid?'Vigente':plan.status==='cancelled'?'Cancelada':'No vigente',plan.valid));article.append(title);
      const stats=line('div','ovm-crm-plan-stats');[['Usadas',plan.used],['Disponibles',plan.remaining],['Total',plan.total]].forEach(([k,v])=>{const b=line('div','');b.append(line('small','',k),line('strong','',v));stats.append(b)});article.append(stats);
      const percent=plan.total?Math.min(100,Math.round(plan.remaining/plan.total*100)):0;const meter=line('div','ovm-crm-meter');const bar=el('span');bar.style.width=percent+'%';meter.append(bar);article.append(meter);
      plan.services.forEach(service=>article.append(line('div','ovm-crm-service',`${service.name} · ${service.remaining} de ${service.total} restantes`)));
      drawerBody.append(article);
   });
   drawerBody.append(line('h3','ovm-crm-detail-heading','Historial de movimientos'));
   const history=line('div','ovm-crm-history');if(!data.history.length)history.append(line('p','ovm-crm-empty','Aún no hay movimientos registrados.'));
   data.history.forEach(entry=>{const row=line('div','ovm-crm-history-row');const info=line('div','');info.append(line('strong','',entry.package+' · '+entry.service),line('small','',`${entry.date} · ${entry.kind==='reverse'?'Corrección':'Consumo'} · Empleado #${entry.staff}`));if(entry.note)info.append(line('small','',entry.note));row.append(info,pill(entry.kind==='reverse'?'+'+Math.abs(entry.quantity):'−'+entry.quantity,entry.kind==='reverse'));history.append(row)});drawerBody.append(history);
 }
 load();
})();
