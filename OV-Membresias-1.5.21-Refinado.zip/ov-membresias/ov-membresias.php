<?php
/**
 * Plugin Name: OV Membresías y Paquetes
 * Description: Complemento de OV Fidelidad: paquetes prepagados, clientes, consumos, CRM y saldos.
 * Version: 1.5.21
 * Requires PHP: 7.4
 * Text Domain: ov-membresias
 */
if (!defined('ABSPATH')) exit;
define('OVM_VERSION','1.5.21');
define('OVM_FILE',__FILE__);
function ovm_ready(){return function_exists('ovf_business_id') && function_exists('ovf_tables') && function_exists('ovf_v02_staff_cap');}
function ovm_tables(){global $wpdb;return ['packages'=>$wpdb->prefix.'ovm_packages','items'=>$wpdb->prefix.'ovm_package_items','contacts'=>$wpdb->prefix.'ovm_contacts','contracts'=>$wpdb->prefix.'ovm_contracts','balances'=>$wpdb->prefix.'ovm_balances','uses'=>$wpdb->prefix.'ovm_uses'];}
function ovm_schema(){global $wpdb;$t=ovm_tables();$c=$wpdb->get_charset_collate();require_once ABSPATH.'wp-admin/includes/upgrade.php';
 dbDelta("CREATE TABLE {$t['packages']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,name varchar(190) NOT NULL,price decimal(12,2) NOT NULL DEFAULT 0,valid_days int unsigned NOT NULL DEFAULT 365,status varchar(20) NOT NULL DEFAULT 'active',created_at datetime NOT NULL,PRIMARY KEY  (id),KEY business_id (business_id)) $c;");
 dbDelta("CREATE TABLE {$t['items']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,package_id bigint unsigned NOT NULL,service varchar(190) NOT NULL,quantity int unsigned NOT NULL,PRIMARY KEY  (id),KEY package_id (package_id)) $c;");
 dbDelta("CREATE TABLE {$t['contacts']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,ovf_client_id bigint unsigned NOT NULL DEFAULT 0,name varchar(190) NOT NULL,phone varchar(40) NOT NULL,phone_digits varchar(20) NOT NULL,email varchar(190) NOT NULL DEFAULT '',birthday date DEFAULT NULL,marketing_consent tinyint(1) NOT NULL DEFAULT 0,consent_at datetime DEFAULT NULL,access_token varchar(64) NOT NULL,created_at datetime NOT NULL,PRIMARY KEY  (id),UNIQUE KEY business_phone (business_id,phone_digits),UNIQUE KEY access_token (access_token),KEY ovf_client (business_id,ovf_client_id)) $c;");
 dbDelta("CREATE TABLE {$t['contracts']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,contact_id bigint unsigned NOT NULL,package_id bigint unsigned NOT NULL,package_name varchar(190) NOT NULL,price decimal(12,2) NOT NULL,starts_on date NOT NULL,expires_on date NOT NULL,status varchar(20) NOT NULL DEFAULT 'active',created_by bigint unsigned NOT NULL,created_at datetime NOT NULL,PRIMARY KEY  (id),KEY business_contact (business_id,contact_id),KEY expires_on (expires_on)) $c;");
 dbDelta("CREATE TABLE {$t['balances']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,contract_id bigint unsigned NOT NULL,service varchar(190) NOT NULL,total int unsigned NOT NULL,remaining int unsigned NOT NULL,PRIMARY KEY  (id),KEY contract_id (contract_id)) $c;");
 dbDelta("CREATE TABLE {$t['uses']} (id bigint unsigned NOT NULL AUTO_INCREMENT,business_id bigint unsigned NOT NULL,contract_id bigint unsigned NOT NULL,balance_id bigint unsigned NOT NULL,quantity int NOT NULL,kind varchar(20) NOT NULL DEFAULT 'consume',reversal_of bigint unsigned DEFAULT NULL,request_id varchar(64) NOT NULL,staff_id bigint unsigned NOT NULL,note varchar(255) NOT NULL DEFAULT '',created_at datetime NOT NULL,PRIMARY KEY  (id),UNIQUE KEY business_request (business_id,request_id),UNIQUE KEY reversal_of (reversal_of),KEY business_contract (business_id,contract_id)) $c;");
 update_option('ovm_schema_version',OVM_VERSION,false);
}
register_activation_hook(__FILE__,function(){if(!function_exists('ovf_tables'))return;ovm_schema();ovm_page();flush_rewrite_rules();});
add_action('admin_init',function(){if(ovm_ready()&&!get_option('ovm_schema_version'))ovm_schema();});
function ovm_page(){ $id=(int)get_option('ovm_page_id');if($id&&get_post_status($id))return $id;$p=get_page_by_path('ov-membresias-panel');if($p&&$p->post_type==='page'){$id=(int)$p->ID;}else{$id=wp_insert_post(['post_title'=>'Membresías y paquetes','post_name'=>'ov-membresias-panel','post_status'=>'publish','post_type'=>'page','post_content'=>'[ov_membresias_panel]']);}if($id&&!is_wp_error($id))update_option('ovm_page_id',$id,false);return $id;}
add_action('init',function(){if(ovm_ready() && !get_option('ovm_page_id'))ovm_page();},20);
function ovm_url($args=[]){$id=(int)get_option('ovm_page_id');$url=$id?get_permalink($id):home_url('/ov-membresias-panel/');return $args?add_query_arg($args,$url):$url;}
function ovm_bid(){return ovm_ready()?absint(ovf_business_id()):0;}
function ovm_enabled($bid=0){$bid=$bid?:ovm_bid();return $bid>0 && get_option('ovm_enabled_'.$bid,'0')==='1';}
function ovm_authorized($owner=false){if(!ovm_ready()||!is_user_logged_in()||!ovf_v02_staff_cap()||!ovm_enabled())return false;return !$owner || ovf_v02_owner_cap();}
function ovm_enqueue_unslop_style(){
 $path=plugin_dir_path(__FILE__).'assets/unslop.css';
 wp_enqueue_style('ovm-unslop',plugins_url('assets/unslop.css',__FILE__),[],is_file($path)?(string)filemtime($path):OVM_VERSION);
}
function ovm_digits($phone){$p=preg_replace('/\D+/','',(string)$phone);if(strlen($p)===12&&substr($p,0,2)==='52')$p=substr($p,2);return strlen($p)===10?$p:'';}
function ovm_date($value){$d=DateTimeImmutable::createFromFormat('!Y-m-d',(string)$value);return $d&&$d->format('Y-m-d')===$value?$value:'';}
function ovm_notice($type,$message){return '<div class="ovm-alert ovm-'.esc_attr($type).'">'.esc_html($message).'</div>';}
function ovm_go($params=[]){wp_safe_redirect(ovm_url(array_merge(['ovm_msg'=>'saved'],$params)));exit;}
function ovm_find_contact($phone,$bid){global $wpdb;$t=ovm_tables();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d AND phone_digits=%s",$bid,$phone));}
/** Reversible, 128-bit private identifier: same random token, fewer characters. */
function ovm_short_from_token($token){
 $token=(string)$token;
 if(!preg_match('/^[a-f0-9]{32}$/D',$token))return '';
 return rtrim(strtr(base64_encode(hex2bin($token)),'+/','-_'),'=');
}
function ovm_token_from_short($code){
 $code=(string)$code;
 if(!preg_match('/^[A-Za-z0-9_-]{22}$/D',$code))return '';
 $bytes=base64_decode(strtr($code,'-_','+/').'==',true);
 if($bytes===false||strlen($bytes)!==16)return '';
 $token=bin2hex($bytes);
 return hash_equals(ovm_short_from_token($token),$code)?$token:'';
}
function ovm_customer_link($contact){
 $short=ovm_short_from_token($contact->access_token??'');
 return $short?home_url('/m/'.$short.'/'):ovm_url(['ovm_card'=>$contact->access_token]);
}
/** Resolve short cards through the existing public membership page. */
add_action('init',function(){
 add_rewrite_rule('^m/([A-Za-z0-9_-]{22})/?$','index.php?pagename=ov-membresias-panel&ovm_short=$matches[1]','top');
},5);
add_filter('query_vars',function($vars){$vars[]='ovm_short';return $vars;});
add_filter('redirect_canonical',function($redirect){return get_query_var('ovm_short','') ? false : $redirect;});
add_action('template_redirect',function(){if(get_query_var('ovm_short','')||!empty($_GET['ovm_card']))nocache_headers();},0);
add_action('init',function(){
 if(get_option('ovm_short_routes_version')!==OVM_VERSION){
  flush_rewrite_rules(false);
  update_option('ovm_short_routes_version',OVM_VERSION,false);
 }
},25);

/** Connect existing loyalty clients without granting a new loyalty card to a membership-only contact. */
function ovm_match_ovf($digits,$bid){
 if(!$digits || !$bid || !function_exists('ovf_set_business_context'))return null;
 global $wpdb;
 $previous=ovf_set_business_context($bid);$ot=ovf_tables();
 $rows=$wpdb->get_results($wpdb->prepare("SELECT id,name,phone,email,birthday,email_marketing,email_consent_at FROM {$ot['clients']} WHERE status='active' AND phone<>'' ORDER BY id DESC LIMIT %d",5000));
 ovf_set_business_context($previous);
 foreach($rows as $r)if(ovm_digits($r->phone)===$digits)return $r;
 return null;
}
function ovm_add_contact($data,$bid){global $wpdb;$t=ovm_tables();$digits=ovm_digits($data['phone']??'');if(!$digits)return new WP_Error('phone','El WhatsApp debe tener 10 dígitos.');$existing=ovm_find_contact($digits,$bid);if($existing)return (int)$existing->id;
 $loyalty=ovm_match_ovf($digits,$bid);$name=sanitize_text_field($data['name']??'');$email=sanitize_email($data['email']??'');if(!$name && $loyalty)$name=$loyalty->name;if(!$email && $loyalty)$email=$loyalty->email;if(!$name)return new WP_Error('name','El nombre es obligatorio.');if(!$email||!is_email($email))return new WP_Error('email','Se requiere un correo con formato válido.');
 $birthday=ovm_date($data['birthday']??'');if(!$birthday&&$loyalty)$birthday=ovm_date($loyalty->birthday??'');$consent=!empty($data['consent'])?1:0;if($loyalty&&!$consent)$consent=(int)$loyalty->email_marketing;
 $token=bin2hex(random_bytes(16));$ok=$wpdb->insert($t['contacts'],['business_id'=>$bid,'ovf_client_id'=>$loyalty?(int)$loyalty->id:0,'name'=>$name,'phone'=>$digits,'phone_digits'=>$digits,'email'=>$email,'birthday'=>$birthday?:null,'marketing_consent'=>$consent,'consent_at'=>$consent?current_time('mysql'):null,'access_token'=>$token,'created_at'=>current_time('mysql')]);if(!$ok){$existing=ovm_find_contact($digits,$bid);return $existing?(int)$existing->id:new WP_Error('db','No se pudo guardar el cliente.');}return (int)$wpdb->insert_id;
}
function ovm_handle(){if(empty($_POST['ovm_action']))return;if(!ovm_authorized())wp_die('Acceso no autorizado.',403);$bid=ovm_bid();$action=sanitize_key(wp_unslash($_POST['ovm_action']));if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce']??'')),'ovm_'.$action))wp_die('Formulario caducado.',403);$owner=ovm_authorized(true);$t=ovm_tables();global $wpdb;
 $fail=function($msg) use($action){$map=['use'=>'sessions','reverse'=>'sessions','contact'=>'register','sell'=>'assign','package'=>'packages','package_delete'=>'packages','package_status'=>'packages'];$target=$map[$action]??'dashboard';wp_safe_redirect(ovm_url(['ovm_msg'=>'error','ovm_detail'=>rawurlencode($msg),'tab'=>$target]));exit;};
 if($action==='package'){
 if(!$owner)wp_die('Acceso restringido.',403);$name=sanitize_text_field(wp_unslash($_POST['name']??''));$price=(float)($_POST['price']??0);$days=absint($_POST['days']??365);$services=array_map('sanitize_text_field',(array)wp_unslash($_POST['service']??[]));$quantities=array_map('absint',(array)($_POST['quantity']??[]));$items=[];foreach($services as $k=>$s){if($s!==''&&($quantities[$k]??0)>0)$items[]=[$s,min(100000,$quantities[$k])];}if(count($items)>30)$fail('Máximo 30 servicios por paquete.');if(!$name||$price<0||$days<1||$days>3650||!$items)$fail('Completa nombre, vigencia y al menos un servicio.');$wpdb->query('START TRANSACTION');$ok=$wpdb->insert($t['packages'],['business_id'=>$bid,'name'=>$name,'price'=>round($price,2),'valid_days'=>$days,'status'=>'active','created_at'=>current_time('mysql')]);$pid=(int)$wpdb->insert_id;foreach($items as $it){if(!$wpdb->insert($t['items'],['business_id'=>$bid,'package_id'=>$pid,'service'=>$it[0],'quantity'=>$it[1]]))$ok=false;}if(!$ok){$wpdb->query('ROLLBACK');$fail('No fue posible guardar el paquete.');}$wpdb->query('COMMIT');ovm_go(['tab'=>'packages']);
 }
 if($action==='package_delete'){if(!$owner)wp_die('Acceso restringido.',403);$id=absint($_POST['package_id']??0);$package=$wpdb->get_row($wpdb->prepare("SELECT id FROM {$t['packages']} WHERE id=%d AND business_id=%d",$id,$bid));if(!$package)$fail('No se encontró el paquete.');$wpdb->update($t['packages'],['status'=>'deleted'],['id'=>$id,'business_id'=>$bid]);ovm_go(['tab'=>'packages']);}
 if($action==='package_status'){if(!$owner)wp_die('Acceso restringido.',403);$id=absint($_POST['package_id']??0);$package=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['packages']} WHERE id=%d AND business_id=%d",$id,$bid));if(!$package||$package->status==='deleted')$fail('Paquete no encontrado.');$wpdb->update($t['packages'],['status'=>$package->status==='active'?'inactive':'active'],['id'=>$id,'business_id'=>$bid]);ovm_go(['tab'=>'packages']);}
 if($action==='contact'){$id=ovm_add_contact(['name'=>sanitize_text_field(wp_unslash($_POST['name']??'')),'phone'=>sanitize_text_field(wp_unslash($_POST['phone']??'')),'email'=>sanitize_email(wp_unslash($_POST['email']??'')),'birthday'=>sanitize_text_field(wp_unslash($_POST['birthday']??'')),'consent'=>!empty($_POST['consent'])],$bid);if(is_wp_error($id))$fail($id->get_error_message());ovm_go(['tab'=>'register','contact_id'=>$id]);}
 if($action==='sell'){
 $cid=absint($_POST['contact_id']??0);$pid=absint($_POST['package_id']??0);$day=ovm_date(sanitize_text_field(wp_unslash($_POST['starts_on']??'')));$contact=$wpdb->get_row($wpdb->prepare("SELECT id FROM {$t['contacts']} WHERE id=%d AND business_id=%d",$cid,$bid));$package=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['packages']} WHERE id=%d AND business_id=%d AND status='active'",$pid,$bid));if(!$contact||!$package||!$day)$fail('Selecciona cliente, paquete y fecha válida.');$items=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['items']} WHERE package_id=%d AND business_id=%d",$pid,$bid));if(!$items)$fail('El paquete no tiene servicios.');$expires=(new DateTimeImmutable($day))->modify('+'.((int)$package->valid_days-1).' days')->format('Y-m-d');$wpdb->query('START TRANSACTION');$ok=$wpdb->insert($t['contracts'],['business_id'=>$bid,'contact_id'=>$cid,'package_id'=>$pid,'package_name'=>$package->name,'price'=>$package->price,'starts_on'=>$day,'expires_on'=>$expires,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);$contract=(int)$wpdb->insert_id;foreach($items as $item){if(!$wpdb->insert($t['balances'],['business_id'=>$bid,'contract_id'=>$contract,'service'=>$item->service,'total'=>$item->quantity,'remaining'=>$item->quantity]))$ok=false;}if(!$ok){$wpdb->query('ROLLBACK');$fail('No se pudo asignar la membresía.');}$wpdb->query('COMMIT');ovm_go(['tab'=>'assign','contact_id'=>$cid,'ovm_delivered'=>$contract]);
 }
 if($action==='use'){
 $balance=absint($_POST['balance_id']??0);$qty=absint($_POST['qty']??1);$request=sanitize_text_field(wp_unslash($_POST['request_id']??''));if(!$request||strlen($request)>64||$qty<1||$qty>100)$fail('Cantidad o solicitud inválida.');$wpdb->query('START TRANSACTION');$row=$wpdb->get_row($wpdb->prepare("SELECT b.id,b.contract_id,c.status,c.starts_on,c.expires_on FROM {$t['balances']} b INNER JOIN {$t['contracts']} c ON c.id=b.contract_id AND c.business_id=b.business_id WHERE b.id=%d AND b.business_id=%d FOR UPDATE",$balance,$bid));$today=current_time('Y-m-d');if(!$row||$row->status!=='active'||$today<$row->starts_on||$today>$row->expires_on){$wpdb->query('ROLLBACK');$fail('La membresía no está vigente.');}$ok=$wpdb->query($wpdb->prepare("UPDATE {$t['balances']} SET remaining=remaining-%d WHERE id=%d AND business_id=%d AND remaining >=%d",$qty,$balance,$bid,$qty));if($ok!==1){$wpdb->query('ROLLBACK');$fail('No hay sesiones suficientes.');}$saved=$wpdb->insert($t['uses'],['business_id'=>$bid,'contract_id'=>$row->contract_id,'balance_id'=>$balance,'quantity'=>$qty,'kind'=>'consume','request_id'=>$request,'staff_id'=>get_current_user_id(),'note'=>sanitize_text_field(wp_unslash($_POST['note']??'')),'created_at'=>current_time('mysql')]);if(!$saved){$wpdb->query('ROLLBACK');$fail('Esta solicitud ya fue registrada o ocurrió un error.');}$wpdb->query('COMMIT');ovm_go(['tab'=>'sessions','contract_id'=>$row->contract_id]);
 }
 if($action==='reverse'){
 if(!$owner)wp_die('Acceso restringido.',403);$id=absint($_POST['use_id']??0);$reason=sanitize_text_field(wp_unslash($_POST['reason']??''));if(strlen($reason)<5)$fail('Escribe un motivo de al menos cinco caracteres.');$wpdb->query('START TRANSACTION');$use=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['uses']} WHERE id=%d AND business_id=%d AND kind='consume' FOR UPDATE",$id,$bid));if(!$use){$wpdb->query('ROLLBACK');$fail('Movimiento no encontrado.');}$already=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['uses']} WHERE reversal_of=%d",$id));if($already){$wpdb->query('ROLLBACK');$fail('Este consumo ya fue revertido.');}$ok=$wpdb->query($wpdb->prepare("UPDATE {$t['balances']} SET remaining=remaining+%d WHERE id=%d AND business_id=%d AND remaining+%d <= total",$use->quantity,$use->balance_id,$bid,$use->quantity));if($ok!==1){$wpdb->query('ROLLBACK');$fail('No es posible restaurar este saldo.');}$saved=$wpdb->insert($t['uses'],['business_id'=>$bid,'contract_id'=>$use->contract_id,'balance_id'=>$use->balance_id,'quantity'=>-(int)$use->quantity,'kind'=>'reverse','reversal_of'=>$id,'request_id'=>wp_generate_uuid4(),'staff_id'=>get_current_user_id(),'note'=>$reason,'created_at'=>current_time('mysql')]);if(!$saved){$wpdb->query('ROLLBACK');$fail('No se pudo revertir.');}$wpdb->query('COMMIT');ovm_go(['tab'=>'sessions','contract_id'=>$use->contract_id]);
 }
 if($action==='contract_status'){if(!$owner)wp_die('Acceso restringido.',403);$id=absint($_POST['contract_id']??0);$desired=sanitize_key($_POST['status']??'');if(!in_array($desired,['active','cancelled'],true))$fail('Estado inválido.');$ok=$wpdb->update($t['contracts'],['status'=>$desired],['id'=>$id,'business_id'=>$bid]);if($ok===false)$fail('No se pudo actualizar.');ovm_go(['tab'=>'sessions','contract_id'=>$id]);}
}
add_action('template_redirect','ovm_handle',1);
function ovm_form_start($action,$extra=''){echo '<form method="post" class="ovm-form" '.$extra.'>';wp_nonce_field('ovm_'.$action);echo '<input type="hidden" name="ovm_action" value="'.esc_attr($action).'">';}
function ovm_form_end($label){echo '<button class="ovm-btn" type="submit">'.esc_html($label).'</button></form>';}
/** SVG icons use fixed server-controlled shapes; no external icon library needed. */
function ovm_nav_icon($name){
 $paths=[
  'sessions'=>'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 12h8M12 8v8"/>',
  'dashboard'=>'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  'clients'=>'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 11a3 3 0 1 0-1-6M17 15a5 5 0 0 1 4 5"/>',
  'register'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/>',
  'assign'=>'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 10h18M8 15h4M17 13v5M14.5 15.5h5"/>',
  'packages'=>'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M12 7v14M3 12h18M12 7c-6-1-6-6-3-6 2 0 3 3 3 6Zm0 0c6-1 6-6 3-6-2 0-3 3-3 6Z"/>',
  'reports'=>'<path d="M3 3v18h18M7 16v-5M12 16V7M17 16v-8"/>',
  'more'=>'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  'fidelidad'=>'<path d="M15 18l-6-6 6-6"/><path d="M9 12h12"/>'
 ];
 return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.($paths[$name]??$paths['more']).'</svg>';
}
/** Report periods use WordPress business-local calendar days, inclusive. */
function ovm_report_filters($raw){
 $today=current_time('Y-m-d');$now=new DateTimeImmutable($today);
 $period=sanitize_key(wp_unslash($raw['period']??'month'));
 $allowed=['today','week','last7','fortnight','last15','month','previous_month','year','custom'];
 if(!in_array($period,$allowed,true))$period='month';
 $from=$today;$to=$today;
 switch($period){
  case 'week':$from=$now->modify('monday this week')->format('Y-m-d');break;
  case 'last7':$from=$now->modify('-6 days')->format('Y-m-d');break;
  case 'fortnight':$from=$now->format('Y-m-').((int)$now->format('d')<=15?'01':'16');break;
  case 'last15':$from=$now->modify('-14 days')->format('Y-m-d');break;
  case 'month':$from=$now->format('Y-m-01');break;
  case 'previous_month':$from=$now->modify('first day of previous month')->format('Y-m-d');$to=$now->modify('last day of previous month')->format('Y-m-d');break;
  case 'year':$from=$now->format('Y-01-01');break;
  case 'custom':$from=ovm_date(sanitize_text_field(wp_unslash($raw['from']??'')));$to=ovm_date(sanitize_text_field(wp_unslash($raw['to']??'')));break;
 }
 if(!$from||!$to||$from>$to)return new WP_Error('invalid_dates','Selecciona un intervalo válido.');
 if((new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days>1095)return new WP_Error('range','El intervalo máximo es de tres años.');
 $status=sanitize_key(wp_unslash($raw['filter']??'all'));
 if(!in_array($status,['all','active','expired','cancelled'],true))$status='all';
 return ['period'=>$period,'from'=>$from,'to'=>$to,'search'=>substr(trim(sanitize_text_field(wp_unslash($raw['search']??''))),0,120),
  'client_id'=>absint($raw['client_id']??0),'package_id'=>absint($raw['package_id']??0),'filter'=>$status];
}
function ovm_report_scope($f,$bid){
 global $wpdb;$t=ovm_tables();$today=current_time('Y-m-d');
 $where='c.business_id=%d';$args=[$bid];
 if($f['client_id']){$where.=' AND c.contact_id=%d';$args[]=$f['client_id'];}
 if($f['package_id']){$where.=' AND c.package_id=%d';$args[]=$f['package_id'];}
 if($f['filter']==='active'){$where.=" AND c.status='active' AND c.starts_on<=%s AND c.expires_on>=%s";array_push($args,$today,$today);}
 elseif($f['filter']==='expired'){$where.=" AND c.status='active' AND c.expires_on<%s";$args[]=$today;}
 elseif($f['filter']==='cancelled'){$where.=" AND c.status='cancelled'";}
 if($f['search']!==''){$like='%'.$wpdb->esc_like($f['search']).'%';$where.=' AND (ct.name LIKE %s OR ct.phone_digits LIKE %s OR ct.email LIKE %s OR c.package_name LIKE %s)';array_push($args,$like,$like,$like,$like);}
 return [$where,$args];
}
function ovm_report_dataset($f,$bid,$page=1,$per=12){
 global $wpdb;$t=ovm_tables();[$where,$args]=ovm_report_scope($f,$bid);
 // Period applies to both registered sales and performed sessions; current balances are clearly identified as current.
 $from=$f['from'].' 00:00:00';$until=(new DateTimeImmutable($f['to']))->modify('+1 day')->format('Y-m-d').' 00:00:00';
 $base="FROM {$t['contracts']} c INNER JOIN {$t['contacts']} ct ON ct.id=c.contact_id AND ct.business_id=c.business_id WHERE {$where}";
 $sales_base=$base." AND c.created_at >= %s AND c.created_at < %s";
 $sales_args=array_merge($args,[$from,$until]);
 $sales_sql=$wpdb->prepare("SELECT c.id,c.package_name,c.price,c.created_at,c.expires_on,c.status,ct.name,ct.phone,ct.email,c.contact_id,c.package_id FROM {$sales_base} ORDER BY c.created_at DESC,c.id DESC",...$sales_args);
 $sales_all=$wpdb->get_results($sales_sql);
 $sales_count=count($sales_all);
 $sales_value=0.;$distinct_clients=[];$top=[];$trend=[];
 foreach($sales_all as $r){if($r->status==='cancelled')continue;$sales_value+=(float)$r->price;$distinct_clients[$r->contact_id]=true;$top[$r->package_name]=($top[$r->package_name]??0)+1;$day=substr($r->created_at,0,10);$trend[$day]['sales']=($trend[$day]['sales']??0)+1;}
 // All activity queries enforce both the authenticated business and matching customer ownership.
 $uses=$wpdb->get_results($wpdb->prepare("SELECT u.quantity,u.kind,u.created_at,u.staff_id,c.id AS contract_id,c.package_name,ct.name AS client_name,ct.phone AS client_phone FROM {$t['uses']} u INNER JOIN {$t['contracts']} c ON c.id=u.contract_id AND c.business_id=u.business_id INNER JOIN {$t['contacts']} ct ON ct.id=c.contact_id AND ct.business_id=c.business_id WHERE {$where} AND u.business_id=%d AND u.created_at >= %s AND u.created_at < %s ORDER BY u.created_at DESC",...array_merge($args,[$bid,$from,$until])));
 $used=0;$consumptions=[];$staff_uses=[];$client_uses=[];
 foreach($uses as $r){$used+=(int)$r->quantity;$day=substr($r->created_at,0,10);$trend[$day]['sessions']=($trend[$day]['sessions']??0)+(int)$r->quantity;$consumptions[]=$r;$staff_uses[$r->staff_id]=($staff_uses[$r->staff_id]??0)+(int)$r->quantity;$client_key=$r->client_name.' · '.$r->client_phone;$client_uses[$client_key]=($client_uses[$client_key]??0)+(int)$r->quantity;}
 // Current inventory is not historical. Restrict it to today's valid contracts and the selected client/package/status/search.
 $today=current_time('Y-m-d');$inventory=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(b.remaining),0) FROM {$t['balances']} b INNER JOIN {$t['contracts']} c ON c.id=b.contract_id AND c.business_id=b.business_id INNER JOIN {$t['contacts']} ct ON ct.id=c.contact_id AND ct.business_id=c.business_id WHERE {$where} AND b.business_id=%d AND c.status='active' AND c.starts_on<=%s AND c.expires_on>=%s",...array_merge($args,[$bid,$today,$today])));
 $renewal_to=(new DateTimeImmutable($today))->modify('+30 days')->format('Y-m-d');
 $renewals=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) {$base} AND c.status='active' AND c.expires_on BETWEEN %s AND %s",...array_merge($args,[$today,$renewal_to])));
 arsort($top);ksort($trend);
 $pages=max(1,(int)ceil($sales_count/max(1,$per)));$page=min(max(1,$page),$pages);
 $slice=$per?array_slice($sales_all,($page-1)*$per,$per):$sales_all;
 $items=[];foreach($slice as $r){$items[]=['client'=>$r->name,'phone'=>$r->phone,'package'=>$r->package_name,'price'=>'$'.number_format_i18n((float)$r->price,2),'expires'=>$r->expires_on,'status'=>$r->status,'created'=>substr($r->created_at,0,10)];}
 $top_items=[];foreach(array_slice($top,0,6,true) as $name=>$qty)$top_items[]=['name'=>$name,'qty'=>$qty];
 $trend_items=[];foreach($trend as $date=>$count)$trend_items[]=['date'=>$date,'sales'=>$count['sales']??0,'sessions'=>$count['sessions']??0];
 arsort($staff_uses);arsort($client_uses);$staff_items=[];foreach(array_slice($staff_uses,0,8,true) as $uid=>$qty){$u=get_userdata((int)$uid);$staff_items[]=['name'=>$u?$u->display_name:'Usuario #'.(int)$uid,'qty'=>$qty];}$client_items=[];foreach(array_slice($client_uses,0,8,true) as $name=>$qty)$client_items[]=['name'=>$name,'qty'=>$qty];
 return ['items'=>$items,'total'=>$sales_count,'page'=>$page,'pages'=>$pages,'sales_value'=>$sales_value,'sales_count'=>array_sum($top),'clients_count'=>count($distinct_clients),'sessions_used'=>$used,'sessions_pending'=>$inventory,'renewals'=>$renewals,'top'=>$top_items,'trend'=>$trend_items,'staff_top'=>$staff_items,'clients_top'=>$client_items,'sales_rows'=>$sales_all,'use_rows'=>$consumptions,'dates'=>['from'=>$f['from'],'to'=>$f['to']]];
}
function ovm_report_controls($bid,$dashboard=false){
 global $wpdb;$t=ovm_tables();
 $packages=$wpdb->get_results($wpdb->prepare("SELECT id,name FROM {$t['packages']} WHERE business_id=%d ORDER BY name ASC LIMIT 1000",$bid));
 echo '<section class="ovm-analytics-controls" data-ovm-analytics="'.($dashboard?'dashboard':'reports').'" aria-label="Filtros del reporte">';
 echo '<div class="ovm-analytics-control-heading"><div><span class="ovm-analytics-control-kicker">Filtros</span><h3>Personaliza los resultados</h3><p>Consulta todos los clientes o busca a uno en particular.</p></div><span class="ovm-analytics-scope" aria-live="polite">Todos los clientes</span></div>';
 echo '<div class="ovm-analytics-group ovm-analytics-group-period"><div class="ovm-analytics-group-title"><span>01</span><div><strong>Periodo de análisis</strong><small>Las ventas y sesiones se filtran por su fecha de registro.</small></div></div><div class="ovm-analytics-date-fields">';
 echo '<label>Periodo<select class="ovm-analytics-period"><option value="today">Hoy</option><option value="week">Esta semana</option><option value="last7">Últimos 7 días</option><option value="fortnight">Quincena actual</option><option value="last15">Últimos 15 días</option><option value="month" selected>Mes actual</option><option value="previous_month">Mes anterior</option><option value="year">Este año</option><option value="custom">Personalizado</option></select></label>';
 echo '<label>Desde<input type="date" class="ovm-analytics-from" disabled></label><label>Hasta<input type="date" class="ovm-analytics-to" disabled></label></div></div>';
 echo '<div class="ovm-analytics-group ovm-analytics-group-audience"><div class="ovm-analytics-group-title"><span>02</span><div><strong>Clientes y membresías</strong><small>Selecciona una persona o mantén el resumen general.</small></div></div>';
 echo '<div class="ovm-analytics-customer-selector"><div class="ovm-analytics-client-selector-header"><span>Cliente</span><button type="button" class="ovm-analytics-all-clients is-active" aria-pressed="true">✓ Todos los clientes</button></div>';
 echo '<div class="ovm-analytics-client-field"><label for="ovm-analytics-client-search">Buscar cliente individual</label><div class="ovm-analytics-client-control"><input type="search" id="ovm-analytics-client-search" class="ovm-analytics-client-search" placeholder="Nombre, WhatsApp o correo" autocomplete="off" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-controls="ovm-analytics-client-results"><input type="hidden" class="ovm-analytics-client" value="0"><button type="button" class="ovm-analytics-client-clear" aria-label="Quitar cliente seleccionado" hidden>×</button><div id="ovm-analytics-client-results" class="ovm-analytics-client-results" role="listbox" hidden></div></div><small class="ovm-analytics-client-help" aria-live="polite">Vista general: todos los clientes</small></div></div>';
 echo '<div class="ovm-analytics-extra-filters"><label>Membresía<select class="ovm-analytics-package"><option value="0">Todos los paquetes</option>';
 foreach($packages as $c)echo '<option value="'.(int)$c->id.'">'.esc_html($c->name).'</option>';
 echo '</select></label>';
 if(!$dashboard)echo '<label>Estado de membresía<select class="ovm-analytics-status"><option value="all">Todos los estados</option><option value="active">Vigentes</option><option value="expired">Vencidas</option><option value="cancelled">Canceladas</option></select></label>';
 echo '</div></div>';
 echo '<div class="ovm-analytics-footer"><span class="ovm-analytics-note">Ventas y usos: actividad del periodo. Saldos y vencimientos: situación actual.</span><button class="ovm-analytics-reset" type="button">Restablecer filtros</button></div></section>';
}

function ovm_panel(){
 $short=ovm_token_from_short(get_query_var('ovm_short',''));
 if($short)return ovm_public_card($short,false);
 if(!empty($_GET['ovm_card'])) return ovm_public_card(sanitize_text_field(wp_unslash($_GET['ovm_card'])),false);
 if(!ovm_ready()) return ovm_notice('error','OV Membresías requiere OV Fidelidad activo y compatible.');
 if(!ovm_authorized()) return ovm_notice('error','Las membresías no están habilitadas para este negocio, o no tienes acceso. Consulta al administrador.');
 global $wpdb; $t=ovm_tables(); $bid=ovm_bid(); $owner=ovm_authorized(true);
 $tab=sanitize_key($_GET['tab']??'dashboard');
 if(!in_array($tab,['dashboard','packages','register','assign','clients','sessions','reports'],true)) $tab='dashboard';
 wp_enqueue_style('ovm-css',plugins_url('assets/ovm.css',__FILE__),[],OVM_VERSION);wp_enqueue_style('ovm-premium-public',plugins_url('assets/ovm-public-premium.css',__FILE__),['ovm-css'],OVM_VERSION);
 wp_enqueue_script('ovm-qr',plugins_url('assets/qrcode.min.js',__FILE__),[],OVM_VERSION,true);
 wp_enqueue_script('ovm-card-actions',plugins_url('assets/ovm-card-actions.js',__FILE__),['ovm-qr'],OVM_VERSION,true);
 $primary=sanitize_hex_color(ovf_get_option('ovf_primary','#315b46'))?:'#315b46';
 $accent=sanitize_hex_color(ovf_get_option('ovf_accent','#111827'))?:'#111827';
 $background=sanitize_hex_color(ovf_get_option('ovf_background','#f5f6f7'))?:'#f5f6f7';
 wp_enqueue_script('ovm-panel',plugins_url('assets/ovm-panel.js',__FILE__),[],OVM_VERSION,true);
 wp_enqueue_style('ovm-account',plugins_url('assets/ovm-account.css',__FILE__),['ovm-css'],OVM_VERSION);
 wp_enqueue_style('ovm-desktop-layout',plugins_url('assets/ovm-desktop-layout.css',__FILE__),['ovm-account'],OVM_VERSION);
 wp_enqueue_style('ovm-analytics',plugins_url('assets/ovm-analytics.css',__FILE__),['ovm-desktop-layout'],OVM_VERSION);
 wp_add_inline_script('ovm-panel','window.OVM_AJAX='.wp_json_encode(['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('ovm_ajax')]).';','before');
 $packages=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['packages']} WHERE business_id=%d AND status<>'deleted' ORDER BY id DESC",$bid));
 $contacts=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d ORDER BY id DESC LIMIT 250",$bid));
 $selected_contact_id=absint($_GET['contact_id']??0);if($selected_contact_id && !array_filter($contacts,function($item)use($selected_contact_id){return (int)$item->id===$selected_contact_id;})){$chosen=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d AND id=%d",$bid,$selected_contact_id));if($chosen)$contacts[]=$chosen;}
 $contracts=$wpdb->get_results($wpdb->prepare("SELECT c.*,p.name AS client_name,p.phone AS phone FROM {$t['contracts']} c JOIN {$t['contacts']} p ON p.id=c.contact_id AND p.business_id=c.business_id WHERE c.business_id=%d ORDER BY c.id DESC LIMIT 250",$bid));
 $today=current_time('Y-m-d');
 $active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['contracts']} WHERE business_id=%d AND status='active' AND starts_on<=%s AND expires_on>=%s",$bid,$today,$today));
 $sales=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(price),0) FROM {$t['contracts']} WHERE business_id=%d AND status<>'cancelled'",$bid));
 $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(b.remaining),0) FROM {$t['balances']} b JOIN {$t['contracts']} c ON c.id=b.contract_id AND c.business_id=b.business_id WHERE b.business_id=%d AND c.status='active' AND c.expires_on>=%s",$bid,$today));
 ob_start();
 echo '<div class="ovm-app" style="--ovm-primary:'.esc_attr($primary).';--ovm-accent:'.esc_attr($accent).';--ovm-bg:'.esc_attr($background).'"><div class="ovm-shell"><nav class="ovm-tabs" aria-label="Secciones de membresías">';
 foreach(['sessions'=>'Registrar uso','dashboard'=>'Resumen','register'=>'Registrar cliente','assign'=>'Asignar membresía','packages'=>'Paquetes','clients'=>'Clientes y CRM','reports'=>'Reportes'] as $k=>$label){
   if(!$owner&&in_array($k,['packages','reports'],true)) continue;
   echo '<a class="'.($tab===$k?'is-active':'').'" '.($tab===$k?'aria-current="page"':'').' href="'.esc_url(ovm_url(['tab'=>$k])).'">'.ovm_nav_icon($k).'<span>'.esc_html($label).'</span></a>';
 }
 echo '<a class="ovm-return-nav" href="'.esc_url(ovf_page_url('ovf_page_portal')).'">'.ovm_nav_icon('fidelidad').'<span>Volver a OV Fidelidad</span></a>';
 echo '<div class="ovm-sidebar-account">'.(function_exists('ovf_shared_account_menu_html')?ovf_shared_account_menu_html():'').'</div>';
 echo '</nav>';
 $more_active=in_array($tab,['register','assign','packages','reports'],true);
 echo '<nav class="ovm-mobile-nav" aria-label="Navegación de membresías">';
 foreach(['sessions'=>'Uso','dashboard'=>'Inicio','clients'=>'Clientes'] as $k=>$label){
   echo '<a class="ovm-mobile-nav-item '.($tab===$k?'is-active':'').'" '.($tab===$k?'aria-current="page"':'').' href="'.esc_url(ovm_url(['tab'=>$k])).'">'.ovm_nav_icon($k).'<span>'.esc_html($label).'</span></a>';
 }
 echo '<button class="ovm-mobile-nav-item ovm-mobile-more-trigger '.($more_active?'is-active':'').'" id="ovm-mobile-more-trigger" type="button" aria-expanded="false" aria-controls="ovm-mobile-more-menu">'.ovm_nav_icon('more').'<span>Más</span></button></nav>';
 echo '<div class="ovm-mobile-more-backdrop" id="ovm-mobile-more-backdrop" hidden></div><nav class="ovm-mobile-more-menu" id="ovm-mobile-more-menu" aria-label="Más opciones de membresías" hidden><div class="ovm-mobile-more-title"><strong>Más opciones</strong><button type="button" id="ovm-mobile-more-close" aria-label="Cerrar menú">×</button></div>';
 foreach(['register'=>'Registrar cliente','assign'=>'Asignar membresía','packages'=>'Paquetes','reports'=>'Reportes'] as $k=>$label){
   if(!$owner&&in_array($k,['packages','reports'],true))continue;
   echo '<a class="'.($tab===$k?'is-active':'').'" '.($tab===$k?'aria-current="page"':'').' href="'.esc_url(ovm_url(['tab'=>$k])).'">'.ovm_nav_icon($k).'<span>'.esc_html($label).'</span></a>';
 }
 echo '<a class="ovm-return-more" href="'.esc_url(ovf_page_url('ovf_page_portal')).'">'.ovm_nav_icon('fidelidad').'<span>Volver a OV Fidelidad</span></a>';
 $brand_name=trim((string)ovf_get_option('ovf_brand_name',''));
 if($brand_name===''){$business=ovf_business_row($bid);$brand_name=$business?$business->name:get_bloginfo('name');}
 $brand_logo=function_exists('ovf_v02_logo_html')?ovf_v02_logo_html('ovm-brand-image'):'';
 if(!$brand_logo){$brand_logo='<span class="ovm-brand-fallback">'.esc_html(function_exists('mb_substr')?mb_substr($brand_name,0,1):substr($brand_name,0,1)).'</span>';}
 echo '</nav><div class="ovm-mobile-header"><div class="ovm-mobile-brand"><span class="ovm-mobile-brand-logo">'.$brand_logo.'</span><span class="ovm-mobile-brand-copy"><span class="ovm-mobile-brand-name">'.esc_html($brand_name).'</span><span class="ovm-mobile-brand-subtitle">Club de membresías</span></span></div><div class="ovm-mobile-account">'.(function_exists('ovf_shared_account_menu_html')?ovf_shared_account_menu_html():'').'</div></div><div class="ovm-main"><div class="ovm-top"><div class="ovm-heading-wrap"><div class="ovm-business-identity"><span class="ovm-brand-logo">'.$brand_logo.'</span><span class="ovm-business-name">'.esc_html($brand_name).'</span></div><span class="ovm-kicker">Gestión de servicios</span><h1>Membresías y paquetes</h1><p>Administra tus servicios, paquetes, clientes y sesiones desde un solo lugar.</p></div><a class="ovm-back" href="'.esc_url(ovf_page_url('ovf_page_portal')).'">← Volver a Fidelidad</a></div>';
 if(!$owner)echo '<p class="ovm-staff-notice">Acceso de empleado: registra clientes, asigna membresías, consulta saldos y registra usos. Los paquetes, cancelaciones y reportes administrativos se gestionan desde la cuenta del encargado.</p>';
 if(!empty($_GET['ovm_msg'])) echo ovm_notice($_GET['ovm_msg']==='saved'?'ok':'error',$_GET['ovm_msg']==='saved'?'Operación guardada correctamente.':sanitize_text_field(wp_unslash($_GET['ovm_detail']??'Revisa los datos.')));
 if($tab==='dashboard'){
   echo '<section class="ovm-analytics-view"><div class="ovm-analytics-title"><div><span class="ovm-kicker">Panorama del negocio</span><h2>Resumen de membresías</h2><p>Filtra ventas, servicios y clientes por periodo.</p></div></div>';
   ovm_report_controls($bid,true);
   echo '<div class="ovm-analytics-stats"><article><small>'.($owner?'Ventas registradas':'Membresías registradas').'</small><strong data-ovm-metric="'.($owner?'sales_value':'sales_count').'">—</strong></article><article><small>Membresías vendidas</small><strong data-ovm-metric="sales_count">—</strong></article><article><small>Sesiones consumidas netas</small><strong data-ovm-metric="sessions_used">—</strong></article><article><small>Sesiones disponibles hoy</small><strong data-ovm-metric="sessions_pending">—</strong></article></div>';
   echo '<section class="ovm-card ovm-analytics-chart-card"><h3>Actividad del periodo</h3><div class="ovm-analytics-chart" aria-label="Actividad por día"></div></section>';
   echo '<div class="ovm-analytics-feedback" role="status" aria-live="polite">Cargando indicadores…</div></section>';
   echo '<h2>Últimas membresías vendidas</h2>';ovm_contract_table(array_slice($contracts,0,12),$t,$bid);
   echo '<p class="ovm-hint">Los importes son precios registrados, no cobros confirmados. Los filtros no alteran los registros.</p>';
 }elseif($tab==='packages'){
   if(!$owner){ echo ovm_notice('error','Solo el encargado administra paquetes.'); }
   else {
     echo '<div class="ovm-grid"><section class="ovm-card"><div class="ovm-section-head"><div><span class="ovm-kicker">Paquetes</span><h2>Crear membresía o paquete</h2></div></div><p class="ovm-hint">Define lo que incluye el paquete. Agrega tantos servicios como necesites; cada uno conserva su propio saldo.</p>';
     ovm_form_start('package');
     echo '<label>Nombre del paquete<input name="name" maxlength="190" required placeholder="Ej. Facial Premium · 6 sesiones"></label><div class="ovm-two"><label>Precio de venta (MXN)<input name="price" type="number" step="0.01" min="0" required placeholder="4800"></label><label>Vigencia (días)<input name="days" type="number" min="1" max="3650" value="365" required></label></div><div class="ovm-services-title"><b>Servicios incluidos</b><span>Sesiones por servicio</span></div><div id="ovm-services-list"><div class="ovm-service"><input name="service[]" maxlength="190" placeholder="Ej. Limpieza facial" required><input name="quantity[]" type="number" min="1" max="100000" value="6" aria-label="Sesiones" required><button class="ovm-remove-service" type="button" aria-label="Quitar servicio" disabled>×</button></div></div><button type="button" id="ovm-add-service" class="ovm-add-service">＋ Agregar otro servicio</button>';
     ovm_form_end('Guardar paquete');
     echo '</section><section class="ovm-card"><div class="ovm-section-head"><div><span class="ovm-kicker">Servicios disponibles</span><h2>Mis paquetes</h2></div><span class="ovm-count">'.count($packages).'</span></div>';
     foreach($packages as $p){
       echo '<div class="ovm-package"><div class="ovm-package-heading"><div><b>'.esc_html($p->name).'</b><small>$'.esc_html(number_format_i18n($p->price,2)).' · '.(int)$p->valid_days.' días</small></div><span class="ovm-status '.($p->status==='active'?'is-on':'is-off').'">'.($p->status==='active'?'En venta':'Pausado').'</span></div>';
       $pi=$wpdb->get_results($wpdb->prepare("SELECT service,quantity FROM {$t['items']} WHERE business_id=%d AND package_id=%d",$bid,$p->id));
       echo '<div class="ovm-package-services">'; foreach($pi as $item) echo '<small>'.esc_html($item->service).' <b>'.(int)$item->quantity.' sesiones</b></small>'; echo '</div><div class="ovm-package-actions">';
       ovm_form_start('package_status'); echo '<input type="hidden" name="package_id" value="'.(int)$p->id.'">'; ovm_form_end($p->status==='active'?'Pausar ventas':'Reactivar ventas');
       ovm_form_start('package_delete','onsubmit="return confirm(\'¿Retirar este paquete del catálogo? Las membresías vendidas y el historial se conservarán.\')"'); echo '<input type="hidden" name="package_id" value="'.(int)$p->id.'">'; ovm_form_end('Eliminar del catálogo');
       echo '</div></div>';
     }
     if(!$packages) echo '<div class="ovm-empty"><b>Aún no hay paquetes</b><p>Crea el primero en el formulario. Aparecerá aquí para gestionarlo.</p></div>';
     echo '</section></div>';
   }
 }elseif($tab==='register'){
   echo '<section class="ovm-card"><div class="ovm-section-head"><div><span class="ovm-kicker">Alta manual</span><h2>Registrar cliente</h2><p class="ovm-hint">Crea el perfil del cliente sin generar una tarjeta de sellos. Si el WhatsApp ya existe en OV Fidelidad, el sistema lo vinculará automáticamente.</p></div></div>';
   ovm_form_start('contact');
   echo '<div class="ovm-two"><label>Nombre<input name="name" maxlength="190" required></label><label>WhatsApp (10 dígitos)<input name="phone" type="tel" inputmode="tel" required pattern="[0-9 +()-]{10,20}"></label></div><div class="ovm-two"><label>Correo electrónico<input name="email" type="email" required></label><label>Cumpleaños (opcional)<input name="birthday" type="date"></label></div><label class="ovm-check"><input type="checkbox" name="consent" value="1"> Aceptó recibir promociones (solo con consentimiento documentado)</label>';
   ovm_form_end('Registrar cliente');
   echo '</section>';
 }elseif($tab==='assign'){
   echo '<section class="ovm-card"><div class="ovm-section-head"><div><span class="ovm-kicker">Venta registrada</span><h2>Asignar membresía a un cliente</h2><p class="ovm-hint">Registra la venta de un paquete, su fecha de inicio y deja lista la membresía para consumir servicios.</p></div></div>';
   $delivery_id=absint($_GET['ovm_delivered']??0);
   if($delivery_id){
     $sale=$wpdb->get_row($wpdb->prepare("SELECT c.id,c.package_name,c.starts_on,c.expires_on,ct.name,ct.phone,ct.access_token FROM {$t['contracts']} c INNER JOIN {$t['contacts']} ct ON ct.id=c.contact_id AND ct.business_id=c.business_id WHERE c.id=%d AND c.business_id=%d",$delivery_id,$bid));
     if($sale){
       $link=ovm_customer_link($sale);
       $message='Hola '.$sale->name.', tu membresía '.$sale->package_name.' ya fue registrada. Consulta los servicios, sesiones disponibles y vigencia en tu tarjeta digital: '.$link;
       $wa=ovm_digits($sale->phone)?'https://wa.me/52'.ovm_digits($sale->phone).'?text='.rawurlencode($message):'';
       echo '<div class="ovm-delivery"><span class="ovm-kicker">Membresía asignada</span><h3>Entrega la tarjeta digital al cliente</h3><p>Se registró '.esc_html($sale->package_name).' a nombre de '.esc_html($sale->name).'. La tarjeta conserva sus saldos y vigencia actualizados.</p><div class="ovm-delivery-links"><a href="'.esc_url($link).'" target="_blank" rel="noopener">Ver tarjeta</a><button type="button" data-ovm-copy="'.esc_attr($link).'">Copiar enlace</button>'.($wa?'<a href="'.esc_url($wa).'" target="_blank" rel="noopener">Enviar por WhatsApp</a>':'').'</div><small>El registro del paquete no acredita por sí mismo el cobro. Confirma el pago mediante el procedimiento habitual del negocio.</small></div>';
     }
   }
   if(!$contacts||!array_filter($packages,function($p){ return $p->status==='active'; })) echo '<div class="ovm-empty"><b>Aún no es posible asignar membresías</b><p>Primero registra un cliente y crea un paquete activo.</p></div>';
   else {
      ovm_form_start('sell');
      $preselected=$selected_contact_id?$wpdb->get_row($wpdb->prepare("SELECT id,name,phone FROM {$t['contacts']} WHERE id=%d AND business_id=%d",$selected_contact_id,$bid)):null;
      echo '<div class="ovm-assign-step"><div class="ovm-step-number">1</div><div class="ovm-assign-step-body"><h3>Seleccionar cliente</h3><p class="ovm-hint">Busca por nombre o WhatsApp. Selecciona una coincidencia para continuar.</p><label for="ovm-assign-search">Buscar cliente<input id="ovm-assign-search" type="search" placeholder="Nombre o número de WhatsApp" autocomplete="off" aria-controls="ovm-assign-results"></label><div class="ovm-assign-filters"><label for="ovm-assign-filter">Mostrar<select id="ovm-assign-filter"><option value="all">Todos los clientes</option><option value="active">Con membresía vigente</option><option value="none">Sin membresía vigente</option></select></label></div><p id="ovm-assign-feedback" class="ovm-hint" role="status" aria-live="polite">Buscando clientes…</p><div id="ovm-assign-results" class="ovm-assign-results" role="group" aria-label="Clientes encontrados"></div><nav id="ovm-assign-pagination" class="ovm-pagination" aria-label="Páginas de búsqueda"></nav><input id="ovm-assign-client-id" type="hidden" name="contact_id" value="'.($preselected?(int)$preselected->id:0).'" required><div id="ovm-assign-selected" class="ovm-assign-selected" '.($preselected?'':'hidden').'><span>Cliente seleccionado</span><strong id="ovm-assign-selected-name">'.($preselected?esc_html($preselected->name).' · '.esc_html($preselected->phone):'').'</strong><button type="button" id="ovm-assign-clear">Cambiar</button></div></div></div>';
      echo '<div class="ovm-assign-step"><div class="ovm-step-number">2</div><div class="ovm-assign-step-body"><h3>Configurar la membresía</h3><div class="ovm-two"><label>Paquete<select name="package_id" required>'; foreach($packages as $p) if($p->status==='active') echo '<option value="'.(int)$p->id.'">'.esc_html($p->name).' · $'.esc_html(number_format_i18n($p->price,2)).'</option>'; echo '</select></label><label>Fecha de inicio<input type="date" name="starts_on" value="'.esc_attr(current_time('Y-m-d')).'" required></label></div></div></div>';
      ovm_form_end('Asignar membresía');
   }
   echo '</section>';
 }elseif($tab==='clients'){
   echo '<section class="ovm-card ovm-crm-v2"><div class="ovm-section-head"><div><span class="ovm-kicker">Seguimiento de clientes</span><h2>Clientes y CRM</h2><p class="ovm-hint">Consulta paquetes, sesiones, vencimientos y conversaciones de seguimiento desde un solo lugar.</p></div><span class="ovm-count" id="ovm-crm-total">—</span></div>';
   echo '<div class="ovm-crm-kpis" id="ovm-crm-kpis"><div><small>Clientes</small><strong>—</strong></div><div><small>Con membresía vigente</small><strong>—</strong></div><div><small>Sesiones disponibles</small><strong>—</strong></div><div><small>Vencen en 30 días</small><strong>—</strong></div></div>';
   echo '<div class="ovm-crm-controls"><label>Buscar cliente<input id="ovm-crm-search" type="search" placeholder="Nombre, WhatsApp o correo" autocomplete="off"></label><label>Segmento<select id="ovm-crm-filter"><option value="all">Todos los clientes</option><option value="active">Membresía vigente</option><option value="expired">Sin membresía vigente</option><option value="none">Sin membresías</option><option value="expiring">Por vencer en 30 días</option><option value="remaining">Con sesiones disponibles</option><option value="inactive">Sin uso en 60 días</option><option value="marketing">Marketing autorizado</option><option value="birthday">Cumpleaños en 30 días</option></select></label></div>';
   echo '<p id="ovm-crm-feedback" class="ovm-hint" role="status" aria-live="polite">Cargando clientes…</p><div class="ovm-crm-table-scroll" role="region" aria-label="Directorio de clientes" tabindex="0"><table class="ovm-crm-table"><thead><tr><th>Cliente</th><th>Membresías</th><th>Sesiones</th><th>Vencimiento</th><th>Acciones</th></tr></thead><tbody id="ovm-crm-results"></tbody></table></div><div id="ovm-crm-cards" class="ovm-crm-cards" aria-label="Tarjetas de clientes"></div><nav id="ovm-crm-pagination" class="ovm-pagination" aria-label="Páginas de clientes"></nav></section>';
   echo '<div class="ovm-crm-drawer" id="ovm-crm-drawer" hidden><div class="ovm-crm-shade" data-ovm-crm-close="1"></div><aside class="ovm-crm-drawer-panel" role="dialog" aria-modal="true" aria-labelledby="ovm-crm-drawer-title" tabindex="-1"><div class="ovm-crm-drawer-head"><div><span class="ovm-kicker">Ficha del cliente</span><h2 id="ovm-crm-drawer-title">Detalle del cliente</h2></div><button type="button" class="ovm-crm-x" data-ovm-crm-close="1" aria-label="Cerrar ficha">×</button></div><div id="ovm-crm-drawer-body" class="ovm-crm-drawer-body"></div></aside></div>';
   wp_enqueue_style('ovm-crm',plugins_url('assets/ovm-crm.css',__FILE__),['ovm-css'],OVM_VERSION);
   ovm_enqueue_unslop_style();
   wp_enqueue_script('ovm-crm',plugins_url('assets/ovm-crm.js',__FILE__),['ovm-panel'],OVM_VERSION,true);
 }elseif($tab==='sessions'){
 echo '<section class="ovm-card ovm-session-hero"><span class="ovm-kicker">Sesiones</span><h2>Registrar sesión</h2><p>Escanea el QR o busca el WhatsApp. Confirma el servicio en una ventana, sin salir de esta pantalla.</p><div class="ovm-session-options"><button type="button" class="ovm-method is-active" data-ovm-method="phone"><span class="ovm-method-icon">◎</span><strong>Buscar por WhatsApp</strong><small>Identifica al cliente en segundos</small></button><button type="button" class="ovm-method" data-ovm-method="qr"><span class="ovm-method-icon">▦</span><strong>Escanear QR</strong><small>Usa la cámara del equipo</small></button></div><form id="ovm-session-lookup-form" class="ovm-lookup"><label for="ovm-client-lookup" class="ovm-lookup-label">WhatsApp o enlace de tarjeta<input type="search" name="lookup" id="ovm-client-lookup" placeholder="Ej. 3312345678" autocomplete="off" required></label><button type="submit" class="ovm-btn">Buscar cliente</button><button type="button" id="ovm-start-camera" class="ovm-btn ovm-secondary" hidden>Iniciar cámara</button></form><video id="ovm-camera" playsinline muted hidden></video><p id="ovm-camera-info" class="ovm-hint" role="status"></p><p id="ovm-session-feedback" class="ovm-hint" role="status" aria-live="polite">Introduce el WhatsApp del cliente o selecciona Escanear QR.</p></section>';
 echo '<div class="ovm-modal" id="ovm-session-modal" hidden><div class="ovm-modal-backdrop" data-ovm-close="1"></div><section class="ovm-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="ovm-modal-title" tabindex="-1"><div class="ovm-modal-head"><div><span class="ovm-kicker">Registro de sesión</span><h2 id="ovm-modal-title">Confirmar servicio</h2></div><button class="ovm-modal-close" type="button" data-ovm-close="1" aria-label="Cerrar ventana">×</button></div><div id="ovm-modal-body"></div><p id="ovm-modal-feedback" role="status" aria-live="polite"></p></section></div>';
 wp_enqueue_script('ovm-scanner',plugins_url('assets/ovm-scanner.js',__FILE__),[],OVM_VERSION,true);
 wp_add_inline_script('ovm-scanner','window.OVM_JSQR='.wp_json_encode(plugins_url('assets/jsqr.min.js',OVM_FILE)).';','before');
 }elseif($tab==='reports'){
   if(!$owner)echo ovm_notice('error','Solo encargados pueden ver reportes.');
   else {
     echo '<section class="ovm-card ovm-analytics-view"><div class="ovm-section-head"><div><span class="ovm-kicker">Seguimiento comercial</span><h2>Reportes de membresías y paquetes</h2><p class="ovm-hint">Analiza ventas y sesiones, filtra por cliente o paquete y exporta los resultados para Excel.</p></div><a class="ovm-btn" id="ovm-report-export" href="'.esc_url(admin_url('admin-ajax.php?action=ovm_report_export&nonce='.wp_create_nonce('ovm_ajax'))).'">Exportar CSV para Excel</a></div>';
     ovm_report_controls($bid,false);
     echo '<div class="ovm-analytics-stats"><article><small>Valor registrado</small><strong data-ovm-metric="sales_value">—</strong></article><article><small>Paquetes vendidos</small><strong data-ovm-metric="sales_count">—</strong></article><article><small>Sesiones consumidas netas</small><strong data-ovm-metric="sessions_used">—</strong></article><article><small>Por vencer en 30 días</small><strong data-ovm-metric="renewals">—</strong></article></div>';
     echo '<section class="ovm-card ovm-analytics-chart-card"><h3>Evolución de actividad</h3><div class="ovm-analytics-chart" aria-label="Actividad por fecha"></div></section>';
     echo '<section class="ovm-card ovm-report-top"><h3>Paquetes más vendidos en el periodo</h3><div class="ovm-bars ovm-analytics-top"></div></section>';
     echo '<div class="ovm-report-rank-grid"><section class="ovm-card"><h3>Clientes con más sesiones</h3><div class="ovm-analytics-client-rank"></div></section><section class="ovm-card"><h3>Servicios registrados por empleado</h3><div class="ovm-analytics-staff-rank"></div></section></div>';
     echo '<section class="ovm-card ovm-report-explorer"><div class="ovm-section-head"><h3>Explorar ventas registradas</h3><small>Se muestran ventas cuya fecha de registro cae dentro del periodo</small></div><div class="ovm-toolbar ovm-report-toolbar"><label>Buscar<input id="ovm-report-search" type="search" placeholder="Nombre, WhatsApp, correo o paquete" autocomplete="off"></label></div><div id="ovm-report-feedback" class="ovm-hint" role="status" aria-live="polite">Cargando reporte…</div><div class="ovm-table-wrap"><table class="ovm-data-table"><thead><tr><th>Cliente</th><th>Paquete</th><th>WhatsApp</th><th>Precio registrado</th><th>Registrada</th><th>Vencimiento</th><th>Estado actual</th></tr></thead><tbody id="ovm-report-results"></tbody></table></div><nav class="ovm-pagination" id="ovm-report-pagination" aria-label="Páginas del reporte"></nav></section></section>';
   }

 }
 echo '</div></div>';
 ovm_enqueue_unslop_style();
 return ob_get_clean();
}

function ovm_contract_table($contracts,$t,$bid){global $wpdb;echo '<div class="ovm-table-wrap"><table><thead><tr><th>Cliente</th><th>Paquete</th><th>Vigencia</th><th>Estado</th><th>Disponible</th><th></th></tr></thead><tbody>';if($contracts){foreach($contracts as $contract){$rem=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(remaining),0) FROM {$t['balances']} WHERE business_id=%d AND contract_id=%d",$bid,$contract->id));echo '<tr><td>'.esc_html($contract->client_name).'</td><td>'.esc_html($contract->package_name).'</td><td>'.esc_html($contract->expires_on).'</td><td>'.esc_html($contract->status).'</td><td>'.$rem.'</td><td><a href="'.esc_url(ovm_url(['tab'=>'sessions','contract_id'=>$contract->id])).'">Abrir</a></td></tr>';}}else{echo '<tr><td colspan="6" class="ovm-empty-row">No hay membresías para mostrar.</td></tr>';}echo '</tbody></table></div>';}


/** Business-scoped AJAX lookup for the analytics client combobox. */
add_action('wp_ajax_ovm_report_clients','ovm_ajax_report_clients');
function ovm_ajax_report_clients(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');
 global $wpdb;$t=ovm_tables();$bid=ovm_bid();
 $search=substr(trim(sanitize_text_field(wp_unslash($_POST['search']??''))),0,100);
 if($search===''){wp_send_json_success(['items'=>[]]);}
 $like='%'.$wpdb->esc_like($search).'%';
 $items=$wpdb->get_results($wpdb->prepare("SELECT id,name,phone FROM {$t['contacts']} WHERE business_id=%d AND (name LIKE %s OR phone_digits LIKE %s OR email LIKE %s) ORDER BY name ASC,id ASC LIMIT 8",$bid,$like,$like,$like));
 wp_send_json_success(['items'=>array_map(function($c){return ['id'=>(int)$c->id,'name'=>$c->name,'phone'=>$c->phone];},$items)]);
}
add_action('wp_ajax_ovm_report_search','ovm_ajax_report_search');
function ovm_ajax_report_search(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');
 $f=ovm_report_filters($_POST);if(is_wp_error($f))wp_send_json_error(['message'=>$f->get_error_message()],400);
 $bid=ovm_bid();$owner=ovm_authorized(true);$data=ovm_report_dataset($f,$bid,max(1,absint($_POST['page']??1)),12);
 if(!$owner){unset($data['sales_value'],$data['sales_rows'],$data['use_rows']);foreach($data['items'] as &$r){unset($r['price']);}unset($r);}
 else{unset($data['sales_rows'],$data['use_rows']);}
 wp_send_json_success($data);
}
add_action('wp_ajax_ovm_report_export','ovm_ajax_report_export');
function ovm_ajax_report_export(){
 if(!ovm_authorized(true))wp_die('Acceso no autorizado.',403);
 check_ajax_referer('ovm_ajax','nonce');
 $f=ovm_report_filters($_GET);if(is_wp_error($f))wp_die(esc_html($f->get_error_message()),400);
 $d=ovm_report_dataset($f,ovm_bid(),1,0);
 nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('X-Content-Type-Options: nosniff');header('Content-Disposition: attachment; filename="ov-membresias-'.esc_attr($f['from'].'-'.$f['to']).'.csv"');
 $out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");
 $clean=function($v){$s=(string)$v;return preg_match('/^[=+@\-\t\r]/u',$s)?"'".$s:$s;};
 $put=function($arr)use($out,$clean){fputcsv($out,array_map($clean,$arr));};
 $put(['OV Membresías - Reporte comercial']);$put(['Desde',$f['from'],'Hasta',$f['to'],'Generado',current_time('mysql')]);
 $put(['Ventas registradas (no equivalen a cobros confirmados)',$d['sales_count'],'Valor registrado',$d['sales_value']]);
 $put(['Sesiones consumidas netas',$d['sessions_used'],'Sesiones disponibles hoy',$d['sessions_pending']]);
 $put([]);$put(['VENTAS']);$put(['Cliente','WhatsApp','Correo','Membresía','Precio registrado','Registrada','Vencimiento','Estado actual']);
 foreach($d['sales_rows'] as $r)$put([$r->name,$r->phone,$r->email,$r->package_name,$r->price,$r->created_at,$r->expires_on,$r->status]);
 $put([]);$put(['SESIONES Y CORRECCIONES']);$put(['Cliente','WhatsApp','Paquete','Movimiento','Cantidad neta','Fecha','Empleado ID']);
 foreach($d['use_rows'] as $r)$put([$r->client_name,$r->client_phone,$r->package_name,$r->kind,$r->quantity,$r->created_at,$r->staff_id]);
 fclose($out);exit;
}

add_shortcode('ov_membresias_panel','ovm_panel');
function ovm_public_card($token='',$loyalty=false){
 if(!ovm_ready()||!$token)return '';
 global $wpdb;$t=ovm_tables();$bid=0;$contact=null;
 if($loyalty){
  $ot=ovf_tables();$customer=$wpdb->get_row($wpdb->prepare("SELECT id,phone FROM {$ot['clients']} WHERE token=%s",$token));if(!$customer)return '';
  $bid=ovm_bid();$contact=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE ovf_client_id=%d AND business_id=%d",$customer->id,$bid));
  if(!$contact){$digits=ovm_digits($customer->phone);if($digits){$contact=ovm_find_contact($digits,$bid);if($contact)$wpdb->update($t['contacts'],['ovf_client_id'=>$customer->id],['id'=>$contact->id,'business_id'=>$bid]);}}
 }else{$contact=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE access_token=%s",$token));if($contact)$bid=(int)$contact->business_id;}
 if(!$contact||!ovm_enabled($bid))return '';
 $contracts=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['contracts']} WHERE contact_id=%d AND business_id=%d AND status<>'cancelled' ORDER BY id DESC",$contact->id,$bid));if(!$contracts)return '';
 wp_enqueue_style('ovm-css',plugins_url('assets/ovm.css',__FILE__),[],OVM_VERSION);wp_enqueue_style('ovm-premium-public',plugins_url('assets/ovm-public-premium.css',__FILE__),['ovm-css'],OVM_VERSION);
 if($loyalty)wp_enqueue_style('ovm-loyalty-integration',plugins_url('assets/ovm-loyalty-integration.css',__FILE__),['ovm-premium-public'],OVM_VERSION);
 ovm_enqueue_unslop_style();
 $primary='#315b46';$accent='#111827';if(function_exists('ovf_set_business_context')){$old=ovf_set_business_context($bid);$primary=sanitize_hex_color(ovf_get_option('ovf_primary','#315b46'))?:'#315b46';$accent=sanitize_hex_color(ovf_get_option('ovf_accent','#111827'))?:'#111827';ovf_set_business_context($old);}
 $biz_name='';$biz_logo='';if(function_exists('ovf_set_business_context')){$old_ctx=ovf_set_business_context($bid);$biz_name=trim((string)ovf_get_option('ovf_brand_name',''));$biz_logo=function_exists('ovf_v02_logo_html')?ovf_v02_logo_html('ovm-public-brand-img'):'';ovf_set_business_context($old_ctx);}if($biz_name===''){ $business=function_exists('ovf_business_row')?ovf_business_row($bid):null; $biz_name=$business?$business->name:get_bloginfo('name'); } if(!$biz_logo){$biz_logo='<span class="ovm-public-brand-fallback">'.esc_html(function_exists('mb_substr')?mb_substr($biz_name,0,1):substr($biz_name,0,1)).'</span>';}
 $wrapper_class='ovm-public'.($loyalty?' ovm-public--embedded':'');
 $heading_logo=$loyalty?'':'<span class="ovm-public-brand-logo">'.$biz_logo.'</span>';
 $heading_name=$loyalty?'':'<p class="ovm-public-brand-name">'.esc_html($biz_name).'</p>';
 $html='<section class="'.esc_attr($wrapper_class).'" style="--ovm-primary:'.esc_attr($primary).';--ovm-accent:'.esc_attr($accent).'" aria-label="Mis membresías">';
 if($loyalty){
   $html.='<header class="ovm-embed-heading"><div class="ovm-embed-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/></svg></div><div class="ovm-embed-heading-copy"><span class="ovm-public-kicker">Paquetes y servicios</span><h2>Mis membresías y paquetes</h2><p>Independientes de tus sellos. Consulta las sesiones disponibles de cada paquete.</p></div><span class="ovm-public-count">'.count($contracts).' '.(count($contracts)===1?'paquete':'paquetes').'</span></header><div class="ovm-embed-summary-slot"></div><div class="ovm-embed-plans">';
 }else{
   $html.='<div class="ovm-public-heading"><div class="ovm-public-brand">'.$heading_logo.'<div class="ovm-public-brand-copy"><span class="ovm-public-kicker">Tus paquetes y servicios</span><h2>Mis membresías</h2>'.$heading_name.'</div></div><span class="ovm-public-count">'.count($contracts).' '.(count($contracts)===1?'paquete':'paquetes').'</span></div>';
 }
 $ovm_summary_available=0;$ovm_summary_active=0;$ovm_next_expiry='';
 $today=current_time('Y-m-d');
 $ovm_tones=['ovm-card-tone-1','ovm-card-tone-2','ovm-card-tone-3','ovm-card-tone-4'];
 $ovm_i=0;
 foreach($contracts as $c){
  $balances=$wpdb->get_results($wpdb->prepare("SELECT service,total,remaining FROM {$t['balances']} WHERE business_id=%d AND contract_id=%d",$bid,$c->id));
  $total=0;$left=0;foreach($balances as $b){$total+=(int)$b->total;$left+=(int)$b->remaining;}
  $valid=$c->status==='active'&&$today>=$c->starts_on&&$today<=$c->expires_on;
  if($loyalty&&$valid){$ovm_summary_active++;$ovm_summary_available+=$left;if(!$ovm_next_expiry||$c->expires_on<$ovm_next_expiry)$ovm_next_expiry=$c->expires_on;}
  $status=$valid?'Activa':($today>$c->expires_on?'Vencida':'Próximamente');
  $percent=$total>0?round(($left/$total)*100):0;
  $tone=$ovm_tones[$ovm_i % count($ovm_tones)]; $ovm_i++;
  $html.='<article class="ovm-member-card '.esc_attr($tone).'"><div class="ovm-member-top"><div><span class="ovm-member-eyebrow">MEMBRESÍA DE SERVICIOS · FOLIO MB-'.(int)$bid.'-'.(int)$c->id.'</span><h3>'.esc_html($c->package_name).'</h3><p class="ovm-member-dates">Vigencia: '.esc_html(date_i18n('d M Y',strtotime($c->starts_on))).' al '.esc_html(date_i18n('d M Y',strtotime($c->expires_on))).'</p></div><span class="ovm-member-status '.($valid?'is-valid':'').'">'.esc_html($status).'</span></div><div class="ovm-member-summary"><div><small>Sesiones disponibles</small><strong>'.(int)$left.' <span>/ '.(int)$total.'</span></strong></div><span>'.(int)$percent.'% restante</span></div><div class="ovm-member-meter" role="progressbar" aria-label="Sesiones disponibles" aria-valuenow="'.(int)$left.'" aria-valuemin="0" aria-valuemax="'.(int)$total.'"><span style="width:'.(int)$percent.'%"></span></div><div class="ovm-member-services">';
  foreach($balances as $b)$html.='<div class="ovm-public-saldo"><span>'.esc_html($b->service).'</span><strong>'.(int)$b->remaining.' de '.(int)$b->total.'</strong></div>';
  $html.='</div></article>';
 }
 if($loyalty){
   $expiry_label=$ovm_next_expiry?date_i18n('d M Y',strtotime($ovm_next_expiry)):'Sin vencimientos';
   $summary='<div class="ovm-embed-summary" aria-label="Resumen de tus membresías"><div><span>Paquetes activos</span><strong>'.(int)$ovm_summary_active.'</strong></div><div><span>Sesiones disponibles</span><strong>'.(int)$ovm_summary_available.'</strong></div><div><span>Próximo vencimiento</span><strong class="ovm-summary-date">'.esc_html($expiry_label).'</strong></div></div>';
   $html=str_replace('<div class="ovm-embed-summary-slot"></div>',$summary,$html);
   $html.='</div><p class="ovm-embed-note"><span aria-hidden="true">ⓘ</span> Los usos de membresías no generan sellos automáticamente.</p>';
 }
 if(!$loyalty){
   wp_enqueue_script('ovm-qr',plugins_url('assets/qrcode.min.js',__FILE__),[],OVM_VERSION,true);
   wp_enqueue_script('ovm-card-actions',plugins_url('assets/ovm-card-actions.js',__FILE__),['ovm-qr'],OVM_VERSION,true);
   $url=ovm_customer_link($contact);
   $whats=ovm_digits($contact->phone)?'https://wa.me/52'.ovm_digits($contact->phone).'?text='.rawurlencode('Hola '.$contact->name.', aquí tienes el enlace privado de tu tarjeta de membresía: '.$url):'';
   $html.='<section class="ovm-membership-proof"><div class="ovm-proof-copy"><span class="ovm-proof-eyebrow">Tu tarjeta digital</span><h3>Presenta este QR en cada visita</h3><p>Tu paquete, servicios y saldos se actualizan después de cada uso registrado por el negocio.</p></div><div class="ovm-proof-owner"><span>Titular</span><strong>'.esc_html($contact->name).'</strong></div><div class="ovm-member-qr" data-ovm-qr="'.esc_attr($url).'" aria-label="QR de tu tarjeta digital"></div><div class="ovm-proof-actions"><button type="button" data-ovm-copy="'.esc_attr($url).'">Copiar enlace</button>'.($whats?'<a href="'.esc_url($whats).'" target="_blank" rel="noopener">Compartir por WhatsApp</a>':'').'</div><p class="ovm-proof-hint">Guarda este enlace privado. No es una tarjeta de sellos; muestra únicamente tus membresías.</p></section>';
   $business=ovf_business_row($bid);
   if($business){$previous=ovf_set_business_context($bid);$reg=ovf_page_url('ovf_page_register');ovf_set_business_context($previous);$html.='<p class="ovm-opt-loyalty">¿Quieres obtener también sellos y recompensas? <a href="'.esc_url($reg).'">Registra tu tarjeta de fidelidad</a>. Usa el mismo WhatsApp para vincular ambos servicios.</p>';}
 }
 return $html.'</section>';
}
add_shortcode('ov_membresias_cliente',function(){
 $short=ovm_token_from_short(get_query_var('ovm_short',''));
 return ovm_public_card($short?:sanitize_text_field(wp_unslash($_GET['ovm_card']??'')),false);
});
/** Render memberships as a sibling panel following the loyalty card.
 * OV Fidelidad returns .ovf-app > .ovf-public-card. Insert between the two
 * final closing divs, without moving or modifying any other HTML or business logic.
 * We intentionally keep the standalone membership view completely separate.
 */
add_filter('do_shortcode_tag',function($output,$tag){
 if($tag!=='ov_fidelidad_cliente'||!ovm_ready()) return $output;
 $token=sanitize_text_field(wp_unslash($_GET['ovf']??''));
 if(!$token||strpos($output,'class="ovf-public-card"')===false) return $output;
 $membership=ovm_public_card($token,true);
 if(!$membership) return $output;
 // The final two wrapper closures belong to .ovf-public-card and .ovf-app.
 // Insert between them to avoid embedding the membership module inside the white loyalty card.
 $tail='</div></div>';
 $pos=strrpos($output,$tail);
 if($pos===false) return $output;
 $card_closed=substr($output,0,$pos).'</div>';
 $app_closed=substr($output,$pos+6);
 return $card_closed.$membership.$app_closed;
},25,2);

/** Hide WordPress chrome for business users on frontend and keep them out of wp-admin. */
add_filter('show_admin_bar',function($show){
 if(is_admin()) return $show;
 if(is_user_logged_in() && !current_user_can('manage_options') && function_exists('ovf_v02_staff_cap') && ovf_v02_staff_cap()) return false;
 return $show;
},99);
add_action('admin_init',function(){
 if(wp_doing_ajax() || !is_user_logged_in() || current_user_can('manage_options')) return;
 if(function_exists('ovf_v02_staff_cap') && ovf_v02_staff_cap()){
  wp_safe_redirect(function_exists('ovf_page_url') ? ovf_page_url('ovf_page_portal') : home_url('/'));
  exit;
 }
},1);

/** Integrated navigation: no floating link under the OV Fidelidad application. */
add_filter('do_shortcode_tag',function($output,$tag){
 if($tag==='ov_fidelidad_app' && ovm_authorized()){
  $url=esc_url(ovm_url());
  $icon='<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8v13M3 12h18M12 8c-7-1-7-7-3-7 2 0 3 3 3 7Zm0 0c7-1 7-7 3-7-2 0-3 3-3 7Z"/></svg>';
  $link='<a class="ovf-nav-desktop ovm-integrated-link" href="'.$url.'">'.$icon.'<span>Membresías y paquetes</span></a>';
  // Put the link *inside* the existing sidebar before the mobile navigation.
  // Never append after </nav>: that previously made it overlap the account area.
  if(strpos($output,'ovm-integrated-link')===false){
   $output=preg_replace('~(?=<a class="ovf-nav-mobile\b)~',$link,$output,1,$found);
   if(!$found){
    // Safe fallback: add after the last desktop entry, but only within the nav.
    $output=preg_replace('~(</a>)(?=\s*<details class="ovf-nav-more")~','$1'.$link,$output,1);
   }
  }
  $mobile='<a href="'.$url.'">'.$icon.'<span>Membresías y paquetes</span></a>';
  $output=str_replace('<div class="ovf-nav-more-panel">','<div class="ovf-nav-more-panel">'.$mobile,$output);
 }
 if($tag==='ov_fidelidad_alta_negocios' && function_exists('ovf_mobile_admin_authenticated') && ovf_mobile_admin_authenticated()){
  $bid=absint($_GET['business_id']??0);
  if($bid && function_exists('ovf_business_row') && ovf_business_row($bid)){
   $control=ovm_superadmin_form($bid,true);
   // Keep the license form outside the existing settings form to avoid nested forms.
   $output=preg_replace('~(<div class="ovf-field-submit">.*?</div></form>)~s','$1'.$control,$output,1);

  }
 }
 return $output;
},20,2);
/** Site administrator controls: deny access unless license is explicitly enabled for that business. */
function ovm_superadmin_form($bid,$mobile=false){
 if(!$bid)return '';
 $action=$mobile?'ovm_mobile_license':'ovm_admin_license';
 $html='<section class="ovm-admin-license" style="margin:20px 0;padding:20px;background:#fff;border:1px solid #dce2e9;border-radius:16px"><h2>Activación comercial · OV Membresías</h2><p>El negocio solo puede acceder al módulo si este interruptor está habilitado. La fidelidad funciona por separado.</p><form method="post">'.wp_nonce_field('ovm_license_'.$bid,'ovm_license_nonce',true,false).'<input type="hidden" name="ovm_license_action" value="'.$action.'"><input type="hidden" name="ovm_business_id" value="'.(int)$bid.'"><label style="display:flex;gap:10px;align-items:center;margin:14px 0"><input type="checkbox" name="ovm_enable" value="1" '.checked(ovm_enabled($bid),true,false).'> Habilitar membresías para este negocio</label><button type="submit" class="button button-primary ovf-app-primary">Guardar licencia</button></form></section>';
 return $html;
}
add_action('template_redirect','ovm_handle_license',2);
add_action('admin_init','ovm_handle_license',2);
function ovm_handle_license(){
 if(empty($_POST['ovm_license_action']))return;
 $action=sanitize_key(wp_unslash($_POST['ovm_license_action']));
 $mobile=$action==='ovm_mobile_license';
 if(!in_array($action,['ovm_mobile_license','ovm_admin_license'],true))return;
 $allowed=$mobile?(function_exists('ovf_mobile_admin_authenticated')&&ovf_mobile_admin_authenticated()):current_user_can('manage_options');
 if(!$allowed)wp_die('Sin autorización para administrar licencias.',403);
 $bid=absint($_POST['ovm_business_id']??0);
 if(!$bid||!ovm_ready()||!ovf_business_row($bid))wp_die('Negocio no válido.',400);
 if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ovm_license_nonce']??'')),'ovm_license_'.$bid))wp_die('La sesión de seguridad caducó.',403);
 update_option('ovm_enabled_'.$bid,empty($_POST['ovm_enable'])?'0':'1',false);
 $redirect=$mobile&&function_exists('ovf_mobile_onboarding_url')?ovf_mobile_onboarding_url(['business_id'=>$bid,'ovm_saved'=>'1']):admin_url('admin.php?page=ovm-licenses&business_id='.$bid.'&ovm_saved=1');
 wp_safe_redirect($redirect);exit;
}
add_action('admin_menu',function(){add_submenu_page('ov-fidelidad','Licencias de membresías','Licencias de membresías','manage_options','ovm-licenses','ovm_admin_licenses_page');},30);
function ovm_admin_licenses_page(){
 if(!current_user_can('manage_options'))wp_die('Acceso restringido.');
 wp_enqueue_style('ovm-admin',plugins_url('assets/ovm-admin.css',__FILE__),[],OVM_VERSION);
 ovm_enqueue_unslop_style();
 wp_enqueue_script('ovm-admin',plugins_url('assets/ovm-admin.js',__FILE__),[],OVM_VERSION,true);
 wp_add_inline_script('ovm-admin','window.OVM_ADMIN_AJAX='.wp_json_encode(['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('ovm_admin_ajax')]).';','before');
 echo '<div class="wrap ovm-license-admin"><div class="ovm-admin-hero"><span class="ovm-kicker">Licencias</span><h1>Licencias de membresías</h1><p>Activa o desactiva el módulo por negocio. Los paquetes, saldos e historial se conservan al desactivar.</p></div>';
 if(!ovm_ready()){echo '<p>Activa primero OV Fidelidad.</p></div>';return;}
 $selected=absint($_GET['business_id']??0);
 if($selected && ($row=ovf_business_row($selected))){echo '<div class="ovm-admin-selected"><h2>'.esc_html($row->name).'</h2><p>'.esc_html($row->phone).' · '.esc_html($row->slug).'</p>'.ovm_superadmin_form($selected).'</div>';}
 echo '<div class="ovm-admin-list"><div class="ovm-admin-list-head"><h2>Negocios registrados</h2><span id="ovm-admin-count">—</span></div><div class="ovm-toolbar"><label for="ovm-admin-search">Buscar negocio<input id="ovm-admin-search" type="search" placeholder="Nombre, teléfono o identificador"></label><label for="ovm-admin-filter">Licencia<select id="ovm-admin-filter"><option value="all">Todos</option><option value="active">Activas</option><option value="inactive">Desactivadas</option></select></label></div><p role="status" aria-live="polite" id="ovm-admin-feedback">Cargando negocios…</p><div class="ovm-table-wrap"><table class="widefat striped"><thead><tr><th>Negocio</th><th>Teléfono</th><th>Membresías</th><th>Configurar</th></tr></thead><tbody id="ovm-admin-results"></tbody></table></div><nav class="ovm-pagination" id="ovm-admin-pagination" aria-label="Páginas de negocios"></nav></div></div>';
}
add_action('admin_notices',function(){if(current_user_can('activate_plugins')&&!ovm_ready())echo '<div class="notice notice-warning"><p><strong>OV Membresías:</strong> activa OV Fidelidad para utilizar este complemento.</p></div>';});

/** 1.3.2: one secure lookup flow for WhatsApp, OV Fidelidad QR and membership link. */
function ovm_session_find_contact($value,$bid){
 global $wpdb;$t=ovm_tables();$value=trim((string)$value);if($value==='')return null;
 $phone=ovm_digits($value);if($phone)return ovm_find_contact($phone,$bid);
 // Membership-only QR link: identifier identifies the contact, not authorize a consumption.
 if(filter_var($value,FILTER_VALIDATE_URL)){
   $path=wp_parse_url($value,PHP_URL_PATH);
   if(preg_match('#^/m/([A-Za-z0-9_-]{22})/?$#',$path?:'',$shortMatch)){
     $token=ovm_token_from_short($shortMatch[1]);
     if($token)return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d AND access_token=%s",$bid,$token));
   }
 }
 if(filter_var($value,FILTER_VALIDATE_URL)){
   $u=wp_parse_url($value);$parts=[];parse_str($u['query']??'',$parts);
   if(!empty($parts['ovm_card'])){
     $token=sanitize_text_field($parts['ovm_card']);return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d AND access_token=%s",$bid,$token));
   }
 }
 $client_id=0;
 if(stripos($value,'OVF:')===0){$found=ovf_client_by_token(substr($value,4));if($found)$client_id=(int)$found->id;}
 elseif(filter_var($value,FILTER_VALIDATE_URL)){
   $url=wp_parse_url($value);$parts=[];parse_str($url['query']??'',$parts);
   if(!empty($parts['ovf'])){$found=ovf_client_by_token(sanitize_text_field($parts['ovf']));if($found)$client_id=(int)$found->id;}
   elseif(preg_match('#/t/([a-z0-9-]+)/([A-Za-z0-9_-]{16})/?$#',$url['path']??'',$m)){
     $business=ovf_business_row($bid);
     if($business&&$business->slug===$m[1]){$ot=ovf_tables();$client_id=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$ot['clients']} WHERE short_code=%s",$m[2]));}
   }
 }
 if(!$client_id)return null;
 $contact=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['contacts']} WHERE business_id=%d AND ovf_client_id=%d",$bid,$client_id));
 // Old contacts may not be linked by ID yet; match by WhatsApp in this business.
 if(!$contact){$ot=ovf_tables();$loyalty=$wpdb->get_row($wpdb->prepare("SELECT phone FROM {$ot['clients']} WHERE id=%d",$client_id));if($loyalty){$digits=ovm_digits($loyalty->phone);if($digits)$contact=ovm_find_contact($digits,$bid);}}
 return $contact;
}
add_action('wp_ajax_ovm_session_lookup','ovm_ajax_session_lookup');
function ovm_ajax_session_lookup(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');global $wpdb;$t=ovm_tables();$bid=ovm_bid();
 $value=sanitize_text_field(wp_unslash($_POST['lookup']??''));
 $contact=ovm_session_find_contact($value,$bid);
 if(!$contact)wp_send_json_error(['message'=>'No encontramos una membresía para ese WhatsApp o QR en este negocio.'],404);
 $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['contracts']} WHERE business_id=%d AND contact_id=%d ORDER BY id DESC",$bid,$contact->id));
 $items=[];$today=current_time('Y-m-d');
 foreach($rows as $row){
   $balances=$wpdb->get_results($wpdb->prepare("SELECT id,service,total,remaining FROM {$t['balances']} WHERE business_id=%d AND contract_id=%d ORDER BY id ASC",$bid,$row->id));
   $services=[];foreach($balances as $bal)$services[]=['id'=>(int)$bal->id,'name'=>$bal->service,'total'=>(int)$bal->total,'remaining'=>(int)$bal->remaining];
   $valid=$row->status==='active'&&$today>=$row->starts_on&&$today<=$row->expires_on;
   $items[]=['id'=>(int)$row->id,'name'=>$row->package_name,'expires'=>$row->expires_on,'valid'=>$valid,'status'=>$row->status,'services'=>$services];
 }
 wp_send_json_success(['client'=>['name'=>$contact->name,'phone'=>$contact->phone],'contracts'=>$items]);
}
add_action('wp_ajax_ovm_session_consume','ovm_ajax_session_consume');
function ovm_ajax_session_consume(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');
 global $wpdb;$t=ovm_tables();$bid=ovm_bid();
 $balance=absint($_POST['balance_id']??0);$qty=absint($_POST['qty']??0);
 $request=sanitize_text_field(wp_unslash($_POST['request_id']??''));$note=sanitize_text_field(wp_unslash($_POST['note']??''));
 if(!$balance||$qty<1||$qty>100||!preg_match('/^[a-zA-Z0-9-]{20,64}$/',$request))wp_send_json_error(['message'=>'Solicitud inválida.'],400);
 $wpdb->query('START TRANSACTION');
 $row=$wpdb->get_row($wpdb->prepare("SELECT b.id,b.remaining,b.contract_id,b.service,c.status,c.starts_on,c.expires_on FROM {$t['balances']} b JOIN {$t['contracts']} c ON c.id=b.contract_id AND c.business_id=b.business_id WHERE b.id=%d AND b.business_id=%d FOR UPDATE",$balance,$bid));
 $today=current_time('Y-m-d');
 if(!$row||$row->status!=='active'||$today<$row->starts_on||$today>$row->expires_on){$wpdb->query('ROLLBACK');wp_send_json_error(['message'=>'La membresía no está vigente.'],400);}
 $ok=$wpdb->query($wpdb->prepare("UPDATE {$t['balances']} SET remaining=remaining-%d WHERE id=%d AND business_id=%d AND remaining>=%d",$qty,$balance,$bid,$qty));
 if($ok!==1){$wpdb->query('ROLLBACK');wp_send_json_error(['message'=>'No hay suficientes sesiones disponibles.'],409);}
 $saved=$wpdb->insert($t['uses'],['business_id'=>$bid,'contract_id'=>$row->contract_id,'balance_id'=>$balance,'quantity'=>$qty,'kind'=>'consume','request_id'=>$request,'staff_id'=>get_current_user_id(),'note'=>$note,'created_at'=>current_time('mysql')]);
 if(!$saved){$wpdb->query('ROLLBACK');wp_send_json_error(['message'=>'Este movimiento ya se registró o no pudo guardarse.'],409);}
 // Read the resulting balance from the database rather than trusting UI calculations.
 $remaining_after=$wpdb->get_var($wpdb->prepare("SELECT remaining FROM {$t['balances']} WHERE id=%d AND business_id=%d",$balance,$bid));
 if($remaining_after===null){$wpdb->query('ROLLBACK');wp_send_json_error(['message'=>'No se pudo verificar el saldo actualizado.'],500);}
 $wpdb->query('COMMIT');
 wp_send_json_success(['service'=>$row->service,'used'=>$qty,'previous'=>(int)$row->remaining,'remaining'=>(int)$remaining_after,'contract_id'=>(int)$row->contract_id,'message'=>'Sesión registrada correctamente.']);
}
/** 1.2: authenticated, business-scoped, paginated CRM lookup. */
/** Lookup for assigning memberships. Uses this business only, with server-side pagination. */
add_action('wp_ajax_ovm_assign_search','ovm_ajax_assign_search');
function ovm_ajax_assign_search(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Sin autorización.'],403);
 check_ajax_referer('ovm_ajax','nonce');
 global $wpdb;$t=ovm_tables();$bid=ovm_bid();$today=current_time('Y-m-d');
 $search=trim(sanitize_text_field(wp_unslash($_POST['search']??'')));
 $filter=sanitize_key(wp_unslash($_POST['filter']??'all'));
 if(!in_array($filter,['all','active','none'],true))$filter='all';
 $page=max(1,absint($_POST['page']??1));$per=8;
 $where='ct.business_id=%d';$args=[$bid];
 if($search!==''){$like='%'.$wpdb->esc_like($search).'%';$where.=' AND (ct.name LIKE %s OR ct.phone_digits LIKE %s)';array_push($args,$like,$like);}
 $active=$wpdb->prepare("SELECT COUNT(*) FROM {$t['contracts']} c WHERE c.business_id=ct.business_id AND c.contact_id=ct.id AND c.status='active' AND c.starts_on<=%s AND c.expires_on>=%s",$today,$today);
 $having=$filter==='active'?'HAVING active_count>0':($filter==='none'?'HAVING active_count=0':'');
 $sql=$wpdb->prepare("SELECT ct.id,ct.name,ct.phone,({$active}) active_count FROM {$t['contacts']} ct WHERE {$where} {$having}",...$args);
 $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM ({$sql}) ovm_assign_count");
 $pages=max(1,(int)ceil($total/$per));$page=min($page,$pages);
 $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ({$sql}) ovm_assign_rows ORDER BY name ASC,id ASC LIMIT %d OFFSET %d",$per,($page-1)*$per));
 $items=[];foreach($rows as $row)$items[]=['id'=>(int)$row->id,'name'=>$row->name,'phone'=>$row->phone,'active'=>(int)$row->active_count];
 wp_send_json_success(['items'=>$items,'total'=>$total,'pages'=>$pages,'page'=>$page]);
}
add_action('wp_ajax_ovm_crm_search','ovm_ajax_crm_search');
function ovm_crm_base_query($bid,$search,$filter){
 global $wpdb;$t=ovm_tables();$today=current_time('Y-m-d');$soon=date('Y-m-d',strtotime($today.' +30 days'));
 $balance_sql="SELECT co.contact_id, SUM(CASE WHEN co.status='active' AND co.starts_on<='%s' AND co.expires_on>='%s' THEN b.remaining ELSE 0 END) AS remaining_sessions, SUM(b.total-b.remaining) AS used_sessions, MIN(CASE WHEN co.status='active' AND co.starts_on<='%s' AND co.expires_on>='%s' THEN co.expires_on ELSE NULL END) AS next_expiry, COUNT(DISTINCT co.id) AS contract_count, COUNT(DISTINCT CASE WHEN co.status='active' AND co.starts_on<='%s' AND co.expires_on>='%s' THEN co.id ELSE NULL END) AS active_count, GROUP_CONCAT(DISTINCT CASE WHEN co.status='active' AND co.starts_on<='%s' AND co.expires_on>='%s' THEN co.package_name END ORDER BY co.id DESC SEPARATOR ', ') AS plans, MAX(CASE WHEN co.status='active' AND co.expires_on BETWEEN '%s' AND '%s' THEN 1 ELSE 0 END) AS expiring FROM {$t['contracts']} co LEFT JOIN {$t['balances']} b ON b.contract_id=co.id AND b.business_id=co.business_id WHERE co.business_id=%d GROUP BY co.contact_id";
 $balance_sql=$wpdb->prepare($balance_sql,$today,$today,$today,$today,$today,$today,$today,$today,$today,$soon,$bid);
 $use_sql=$wpdb->prepare("SELECT c.contact_id,MAX(u.created_at) AS last_used FROM {$t['uses']} u JOIN {$t['contracts']} c ON c.id=u.contract_id AND c.business_id=u.business_id WHERE u.business_id=%d AND u.kind='consume' GROUP BY c.contact_id",$bid);
 $where='WHERE ct.business_id=%d';$args=[$bid];
 if($search!==''){$like='%'.$wpdb->esc_like($search).'%';$where.=' AND (ct.name LIKE %s OR ct.phone_digits LIKE %s OR ct.email LIKE %s)';array_push($args,$like,$like,$like);}
 $todaytime=current_time('mysql');$threshold=date('Y-m-d H:i:s',strtotime($todaytime.' -60 days'));
 $segment=[
 'active'=>'COALESCE(agg.active_count,0)>0',
 'expired'=>'COALESCE(agg.contract_count,0)>0 AND COALESCE(agg.active_count,0)=0',
 'none'=>'COALESCE(agg.contract_count,0)=0',
 'expiring'=>'COALESCE(agg.expiring,0)=1',
 'remaining'=>'COALESCE(agg.remaining_sessions,0)>0',
 'inactive'=>"COALESCE(agg.contract_count,0)>0 AND (lastuse.last_used IS NULL OR lastuse.last_used<'".esc_sql($threshold)."')",
 'marketing'=>'ct.marketing_consent=1',
 'birthday'=>"ct.birthday IS NOT NULL AND DATE_FORMAT(ct.birthday,'%m-%d') BETWEEN '".esc_sql(date('m-d',strtotime($today)))."' AND '".esc_sql(date('m-d',strtotime($today.' +30 days')))."'"
 ];
 if($filter==='birthday'){
  // Inclusive interval through year end, including leap-year birthdays.
  $from=date('md',strtotime($today));$to=date('md',strtotime($today.' +30 days'));
  $where.=$from<=$to?" AND DATE_FORMAT(ct.birthday,'%m%d') BETWEEN '{$from}' AND '{$to}'":" AND (DATE_FORMAT(ct.birthday,'%m%d')>='{$from}' OR DATE_FORMAT(ct.birthday,'%m%d')<='{$to}')";
 }elseif(isset($segment[$filter]))$where.=' AND ('.$segment[$filter].')';
 $sql="SELECT ct.id,ct.name,ct.phone,ct.email,ct.birthday,ct.marketing_consent,ct.access_token, COALESCE(agg.contract_count,0) AS contract_count,COALESCE(agg.active_count,0) AS active_count, COALESCE(agg.remaining_sessions,0) AS remaining_sessions,COALESCE(agg.used_sessions,0) AS used_sessions,agg.next_expiry,agg.plans,lastuse.last_used FROM {$t['contacts']} ct LEFT JOIN ({$balance_sql}) agg ON agg.contact_id=ct.id LEFT JOIN ({$use_sql}) lastuse ON lastuse.contact_id=ct.id {$where}";
 return $wpdb->prepare($sql,...$args);
}
function ovm_crm_metrics($bid){
 global $wpdb;$t=ovm_tables();$today=current_time('Y-m-d');$soon=date('Y-m-d',strtotime($today.' +30 days'));
 $clients=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['contacts']} WHERE business_id=%d",$bid));
 $active=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$t['contracts']} WHERE business_id=%d AND status='active' AND starts_on<=%s AND expires_on>=%s",$bid,$today,$today));
 $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(b.remaining),0) FROM {$t['balances']} b JOIN {$t['contracts']} c ON c.id=b.contract_id AND c.business_id=b.business_id WHERE b.business_id=%d AND c.status='active' AND c.starts_on<=%s AND c.expires_on>=%s",$bid,$today,$today));
 $expiring=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['contracts']} WHERE business_id=%d AND status='active' AND expires_on BETWEEN %s AND %s",$bid,$today,$soon));
 return ['clients'=>$clients,'active'=>$active,'remaining'=>$remaining,'expiring'=>$expiring];
}
function ovm_crm_whatsapp($phone,$message=''){
 $digits=ovm_digits($phone);if(!$digits)return '';
 return 'https://wa.me/52'.$digits.($message!==''?'?text='.rawurlencode($message):'');
}
function ovm_ajax_crm_search(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');global $wpdb;$bid=ovm_bid();
 $search=trim(sanitize_text_field(wp_unslash($_POST['search']??'')));
 $filter=sanitize_key(wp_unslash($_POST['filter']??'all'));
 if(!in_array($filter,['all','active','expired','none','expiring','remaining','inactive','marketing','birthday'],true))$filter='all';
 $page=max(1,absint($_POST['page']??1));$per=12;
 $sql=ovm_crm_base_query($bid,$search,$filter);
 $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM ({$sql}) ovm_crm_rows");$pages=max(1,(int)ceil($total/$per));$page=min($page,$pages);
 $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ({$sql}) ovm_crm_rows ORDER BY id DESC LIMIT %d OFFSET %d",$per,($page-1)*$per));
 $items=[];
 foreach($rows as $r){$items[]=['id'=>(int)$r->id,'name'=>$r->name,'phone'=>$r->phone,'email'=>$r->email,'birthday'=>$r->birthday?:'','marketing'=>(bool)$r->marketing_consent,'contracts'=>(int)$r->contract_count,'active'=>(int)$r->active_count,'remaining'=>(int)$r->remaining_sessions,'used'=>(int)$r->used_sessions,'expires'=>$r->next_expiry?:'','plans'=>$r->plans?:'','lastUsed'=>$r->last_used?:'','whatsapp'=>ovm_crm_whatsapp($r->phone),'assign'=>ovm_url(['tab'=>'assign','contact_id'=>$r->id]),'card'=>ovm_customer_link($r),'register'=>ovm_url(['tab'=>'sessions','lookup'=>$r->phone])];}
 wp_send_json_success(['items'=>$items,'total'=>$total,'page'=>$page,'pages'=>$pages,'metrics'=>ovm_crm_metrics($bid)]);
}
add_action('wp_ajax_ovm_crm_detail','ovm_ajax_crm_detail');
function ovm_ajax_crm_detail(){
 if(!ovm_authorized())wp_send_json_error(['message'=>'Acceso no autorizado.'],403);
 check_ajax_referer('ovm_ajax','nonce');global $wpdb;$t=ovm_tables();$bid=ovm_bid();$id=absint($_POST['contact_id']??0);
 if(!$id)wp_send_json_error(['message'=>'Cliente inválido.'],400);
 $contact=$wpdb->get_row($wpdb->prepare("SELECT id,name,phone,email,birthday,marketing_consent,created_at FROM {$t['contacts']} WHERE business_id=%d AND id=%d",$bid,$id));
 if(!$contact)wp_send_json_error(['message'=>'Cliente no encontrado en este negocio.'],404);
 $contracts=$wpdb->get_results($wpdb->prepare("SELECT id,package_name,starts_on,expires_on,status,price FROM {$t['contracts']} WHERE business_id=%d AND contact_id=%d ORDER BY id DESC LIMIT 150",$bid,$id));
 $today=current_time('Y-m-d');$plans=[];
 foreach($contracts as $c){$balances=$wpdb->get_results($wpdb->prepare("SELECT service,total,remaining FROM {$t['balances']} WHERE business_id=%d AND contract_id=%d ORDER BY id ASC",$bid,$c->id));$services=[];$total=0;$remaining=0;foreach($balances as $b){$total+=(int)$b->total;$remaining+=(int)$b->remaining;$services[]=['name'=>$b->service,'total'=>(int)$b->total,'remaining'=>(int)$b->remaining,'used'=>(int)$b->total-(int)$b->remaining];}$plans[]=['id'=>(int)$c->id,'name'=>$c->package_name,'starts'=>$c->starts_on,'expires'=>$c->expires_on,'status'=>$c->status,'valid'=>$c->status==='active'&&$c->starts_on<=$today&&$c->expires_on>=$today,'total'=>$total,'remaining'=>$remaining,'used'=>$total-$remaining,'services'=>$services];}
 $movements=$wpdb->get_results($wpdb->prepare("SELECT u.id,u.created_at,u.quantity,u.kind,u.note,u.staff_id,b.service,c.package_name FROM {$t['uses']} u JOIN {$t['contracts']} c ON c.id=u.contract_id AND c.business_id=u.business_id JOIN {$t['balances']} b ON b.id=u.balance_id AND b.business_id=u.business_id WHERE u.business_id=%d AND c.contact_id=%d ORDER BY u.id DESC LIMIT 60",$bid,$id));
 $history=[];foreach($movements as $m)$history[]=['date'=>$m->created_at,'quantity'=>(int)$m->quantity,'kind'=>$m->kind,'service'=>$m->service,'package'=>$m->package_name,'note'=>$m->note,'staff'=>(int)$m->staff_id];
 $consent=(bool)$contact->marketing_consent;
 $followups=[];
 if($consent){
   $name=$contact->name;
   $followups=[
     ['label'=>'Recordar sesiones','url'=>ovm_crm_whatsapp($contact->phone,'Hola '.$name.', te recordamos que tienes sesiones disponibles en tu membresía. Si necesitas ayuda para programar tu visita, estamos a tus órdenes.')],
     ['label'=>'Invitar a renovar','url'=>ovm_crm_whatsapp($contact->phone,'Hola '.$name.', queremos compartirte información sobre la renovación de tu membresía. ¿Te gustaría conocer las opciones disponibles?')],
     ['label'=>'Saludo de cumpleaños','url'=>ovm_crm_whatsapp($contact->phone,'¡Feliz cumpleaños, '.$name.'! Te deseamos un excelente día y agradecemos tu preferencia.')]
   ];
 }
 wp_send_json_success(['client'=>['name'=>$contact->name,'phone'=>$contact->phone,'email'=>$contact->email,'birthday'=>$contact->birthday?:'','marketing'=>$consent,'registered'=>$contact->created_at,'whatsapp'=>ovm_crm_whatsapp($contact->phone),'followups'=>$followups],'contracts'=>$plans,'history'=>$history,'assign'=>ovm_url(['tab'=>'assign','contact_id'=>$id]),'card'=>ovm_customer_link($contact),'register'=>ovm_url(['tab'=>'sessions','lookup'=>$contact->phone])]);
}
/** 1.2: secure admin AJAX license directory and search. */
add_action('wp_ajax_ovm_admin_search','ovm_ajax_admin_search');
function ovm_ajax_admin_search(){
 if(!current_user_can('manage_options'))wp_send_json_error(['message'=>'Sin autorización.'],403);
 check_ajax_referer('ovm_admin_ajax','nonce');if(!ovm_ready())wp_send_json_error(['message'=>'OV Fidelidad no está activo.'],400);
 global $wpdb;$search=trim(sanitize_text_field(wp_unslash($_POST['search']??'')));$status=sanitize_key(wp_unslash($_POST['filter']??'all'));$page=max(1,absint($_POST['page']??1));$per=15;
 $where='1=1';$args=[];if($search!==''){$like='%'.$wpdb->esc_like($search).'%';$where='(name LIKE %s OR phone LIKE %s OR slug LIKE %s)';$args=[$like,$like,$like];}
 $table=ovf_businesses_table();$sql="SELECT id,name,phone,slug FROM {$table} WHERE {$where} ORDER BY name ASC";$rows=$wpdb->get_results($args?$wpdb->prepare($sql,...$args):$sql);
 $rows=array_values(array_filter($rows,function($r)use($status){return $status==='all'||($status==='active')===ovm_enabled($r->id);}));
 $total=count($rows);$pages=max(1,(int)ceil($total/$per));$page=min($page,$pages);$rows=array_slice($rows,($page-1)*$per,$per);
 $items=[];foreach($rows as $r)$items[]=['id'=>(int)$r->id,'name'=>$r->name,'phone'=>$r->phone,'slug'=>$r->slug,'enabled'=>ovm_enabled($r->id),'manage'=>admin_url('admin.php?page=ovm-licenses&business_id='.$r->id)];
 wp_send_json_success(['items'=>$items,'total'=>$total,'page'=>$page,'pages'=>$pages]);
}
