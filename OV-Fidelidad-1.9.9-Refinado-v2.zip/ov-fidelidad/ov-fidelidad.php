<?php
/**
 * Plugin Name: OV Fidelidad
 * Description: Plataforma multinegocio de fidelización para WordPress: negocios aislados, tarjetas QR, compras, beneficios, campañas por correo y Web App.
 * Version: 1.9.9
 * Author: OV DIVI
 * Text Domain: ov-fidelidad
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */
if (!defined('ABSPATH')) exit;

define('OVF_VERSION','1.9.9');
define('OVF_FILE',__FILE__);
define('OVF_URL',plugin_dir_url(__FILE__));
define('OVF_PATH',plugin_dir_path(__FILE__));
require_once OVF_PATH.'includes-v02.php';
require_once OVF_PATH.'includes/template.php';
require_once OVF_PATH.'includes/front-actions.php';
require_once OVF_PATH.'includes/avatars.php';
require_once OVF_PATH.'includes/global-login.php';
require_once OVF_PATH.'includes/platform-admin.php';
require_once OVF_PATH.'includes/admin-workspace.php';
require_once OVF_PATH.'includes/marketing.php';
require_once OVF_PATH.'includes/smtp.php';
require_once OVF_PATH.'includes/rewards.php';
require_once OVF_PATH.'includes/pwa.php';
require_once OVF_PATH.'includes/cache.php';
require_once OVF_PATH.'includes/insights.php';

function ovf_businesses_table(){global $wpdb;return $wpdb->prefix.'ovf_businesses';}
function ovf_business_context_id(){global $ovf_business_context_id;return isset($ovf_business_context_id)?absint($ovf_business_context_id):0;}
function ovf_business_table_ready(){static $ready=null;if($ready!==null)return $ready;global $wpdb;$table=ovf_businesses_table();$ready=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))===$table;return $ready;}
function ovf_business_row($id){global $wpdb;if(!ovf_business_table_ready())return null;$table=ovf_businesses_table();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",absint($id)));}
function ovf_business_by_slug($slug){global $wpdb;if(!ovf_business_table_ready())return null;$table=ovf_businesses_table();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE slug=%s",sanitize_title($slug)));}
function ovf_business_id(){
 static $resolved=null;global $ovf_business_context_id;
 if(!empty($ovf_business_context_id))return absint($ovf_business_context_id);
 if(is_user_logged_in()&&current_user_can('manage_options')){$requested=absint($_REQUEST['ovf_business_id']??0);if($requested&&ovf_business_row($requested)){update_user_meta(get_current_user_id(),'ovf_active_business_id',$requested);return $resolved=$requested;}}
 if(!is_user_logged_in()||(is_user_logged_in()&&current_user_can('manage_options'))){$slug=sanitize_title(wp_unslash($_REQUEST['ovf_business']??''));if($slug&&($business=ovf_business_by_slug($slug)))return $resolved=(int)$business->id;}
 if($resolved!==null)return $resolved;
 if(is_user_logged_in()&&!current_user_can('manage_options')){$id=absint(get_user_meta(get_current_user_id(),'ovf_business_id',true));if($id&&ovf_business_row($id))return $resolved=$id;if(current_user_can('ovf_register_sales')||current_user_can('ovf_manage_staff'))return $resolved=1;}
 if(is_user_logged_in()&&current_user_can('manage_options')){$id=absint(get_user_meta(get_current_user_id(),'ovf_active_business_id',true));if($id&&ovf_business_row($id))return $resolved=$id;}
 return $resolved=1;
}
function ovf_set_business_context($id){global $ovf_business_context_id;$old=ovf_business_id();$ovf_business_context_id=absint($id)?:1;return $old;}
function ovf_get_option($key,$default=false){$key=sanitize_key($key);$id=ovf_business_id();if($id===1)return get_option($key,$default);$sentinel='__ovf_missing_option__';$value=get_option('ovf_biz_'.$id.'_'.$key,$sentinel);return $value===$sentinel?$default:$value;}
function ovf_update_option($key,$value,$autoload=null){$key=sanitize_key($key);$id=ovf_business_id();if($id===1)return update_option($key,$value,$autoload);return update_option('ovf_biz_'.$id.'_'.$key,$value,$autoload);}
function ovf_add_option($key,$value='',$deprecated='',$autoload='yes'){$key=sanitize_key($key);$id=ovf_business_id();return add_option($id===1?$key:'ovf_biz_'.$id.'_'.$key,$value,$deprecated,$autoload);}
function ovf_delete_option($key){$key=sanitize_key($key);$id=ovf_business_id();return delete_option($id===1?$key:'ovf_biz_'.$id.'_'.$key);}
function ovf_program_features(){ $features=ovf_get_option('ovf_program_features',null);if(!is_array($features))return ['points','cashback'];return array_values(array_intersect(['points','cashback'],$features)); }
function ovf_program_feature_enabled($feature){return in_array(sanitize_key($feature),ovf_program_features(),true);}
function ovf_purchase_rules_summary(){ $parts=[];if(ovf_program_feature_enabled('points'))$parts[]=sprintf(__('puntos: 1 por cada $%s MXN','ov-fidelidad'),number_format_i18n(ovf_get_option('ovf_points_per_amount',10)));if(ovf_program_feature_enabled('cashback'))$parts[]=sprintf(__('cashback: %s%%','ov-fidelidad'),number_format_i18n(ovf_get_option('ovf_cashback_percent',0),1));if(!$parts)return __('Captura el importe antes de cualquier descuento. Se registra 1 sello por compra.','ov-fidelidad');return sprintf(__('Captura el importe antes de cualquier descuento. Se registra 1 sello y aplican %s.','ov-fidelidad'),implode(' · ',$parts)); }
function ovf_install_businesses_schema(){global $wpdb;$table=ovf_businesses_table();if(get_option('ovf_businesses_schema_version')==='1.0'&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))===$table)return;$charset=$wpdb->get_charset_collate();require_once ABSPATH.'wp-admin/includes/upgrade.php';dbDelta("CREATE TABLE {$table} (id bigint unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL, slug varchar(190) NOT NULL, email varchar(190) NOT NULL DEFAULT '', phone varchar(60) NOT NULL DEFAULT '', owner_user_id bigint unsigned NOT NULL DEFAULT 0, status varchar(20) NOT NULL DEFAULT 'active', created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY slug(slug), KEY status(status), KEY owner_user_id(owner_user_id)) {$charset};");$n=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}");if(!$n){$wpdb->insert($table,['id'=>1,'name'=>ovf_get_option('ovf_brand_name',get_bloginfo('name'))?:get_bloginfo('name'),'slug'=>'principal','email'=>get_option('admin_email'),'status'=>'active','created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]);}$legacy=get_users(['role__in'=>['ovf_owner','ovf_staff','editor'],'fields'=>'ID']);$first_owner=0;foreach($legacy as $uid){if(!get_user_meta($uid,'ovf_business_id',true))update_user_meta($uid,'ovf_business_id',1);if(!$first_owner&&user_can($uid,'ovf_manage_staff'))$first_owner=(int)$uid;}if($first_owner)$wpdb->update($table,['owner_user_id'=>$first_owner],['id'=>1]);update_option('ovf_businesses_schema_version','1.0');}
function ovf_create_business_tables($id){$old=ovf_set_business_context($id);ovf_install_schema();ovf_ensure_clients_schema();ovf_ensure_moves_schema();ovf_set_business_context($old);}
add_action('init','ovf_install_businesses_schema',0);
add_action('init',function(){if(is_admin()&&current_user_can('manage_options')&&!empty($_GET['page'])&&strpos(sanitize_key($_GET['page']),'ov-fidelidad')===0){$id=absint($_GET['ovf_business_id']??0);if($id&&ovf_business_row($id))update_user_meta(get_current_user_id(),'ovf_active_business_id',$id);}},1);

function ovf_tables(){ global $wpdb; $id=ovf_business_id();$suffix=$id>1?'_b'.$id:'';return [
 'clients'=>$wpdb->prefix.'ovf_clients'.$suffix,'moves'=>$wpdb->prefix.'ovf_movements'.$suffix,'rewards'=>$wpdb->prefix.'ovf_rewards'.$suffix,'rules'=>$wpdb->prefix.'ovf_reward_rules'.$suffix
]; }

/** Ensure legacy OV Fidelidad client tables have every column required by current releases. */
function ovf_ensure_clients_schema(){
 global $wpdb; $t=ovf_tables();
 if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t['clients']))!==$t['clients']){ovf_install_schema();}
 $cols=$wpdb->get_col("SHOW COLUMNS FROM {$t['clients']}",0);
 if(!$cols){ovf_install_schema();$cols=$wpdb->get_col("SHOW COLUMNS FROM {$t['clients']}",0);}
 $alters=[];
 if(!in_array('status',$cols,true))$alters[]="ADD status varchar(20) NOT NULL DEFAULT 'active'";
 if(!in_array('notes',$cols,true))$alters[]="ADD notes text NULL";
 if(!in_array('updated_at',$cols,true))$alters[]="ADD updated_at datetime NULL";
 if(!in_array('visits',$cols,true))$alters[]="ADD visits int unsigned NOT NULL DEFAULT 0";
 if(!in_array('birthday',$cols,true))$alters[]="ADD birthday date DEFAULT NULL";
 if(!in_array('referral_code',$cols,true))$alters[]="ADD referral_code varchar(24) NOT NULL DEFAULT ''";
 if(!in_array('short_code',$cols,true))$alters[]="ADD short_code varchar(20) NOT NULL DEFAULT ''";
 if(!in_array('referred_by',$cols,true))$alters[]="ADD referred_by bigint unsigned NOT NULL DEFAULT 0";
 if(!in_array('referral_rewarded',$cols,true))$alters[]="ADD referral_rewarded tinyint(1) NOT NULL DEFAULT 0";
 foreach($alters as $sql){$wpdb->query("ALTER TABLE {$t['clients']} {$sql}");}
 $indexes=$wpdb->get_col("SHOW INDEX FROM {$t['clients']} WHERE Key_name='short_code'",2);
 if(!$indexes)$wpdb->query("ALTER TABLE {$t['clients']} ADD UNIQUE KEY short_code (short_code)");
 // Asigna un código de referido estable a los clientes existentes de versiones anteriores.
 $wpdb->query("UPDATE {$t['clients']} SET referral_code=CONCAT('OV',UPPER(CONV(id,10,36))) WHERE referral_code='' OR referral_code IS NULL");
 // Backfill updated_at for installations upgraded from early releases.
 $wpdb->query("UPDATE {$t['clients']} SET updated_at=created_at WHERE updated_at IS NULL OR updated_at='0000-00-00 00:00:00'");
 return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t['clients']))===$t['clients'];
}

function ovf_insert_client($data){
 global $wpdb; $t=ovf_tables(); ovf_ensure_clients_schema();
 $defaults=['short_code'=>ovf_new_short_code(),'token'=>wp_generate_password(32,false,false),'name'=>'','email'=>'','phone'=>'','visits'=>0,'status'=>'active','notes'=>'','birthday'=>null,'referral_code'=>strtoupper(wp_generate_password(8,false,false)),'referred_by'=>0,'referral_rewarded'=>0,'email_marketing'=>0,'email_consent_at'=>null,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')];
 $data=wp_parse_args($data,$defaults);
 $formats=[];foreach($data as $key=>$value)$formats[]=in_array($key,['visits','referred_by','referral_rewarded','email_marketing'],true)?'%d':'%s';
 $ok=$wpdb->insert($t['clients'],$data,$formats);
 if($ok===false||!(int)$wpdb->insert_id){return new WP_Error('ovf_client_insert',__('No se pudo guardar el cliente.','ov-fidelidad'),['db_error'=>$wpdb->last_error]);}
 return (int)$wpdb->insert_id;
}

function ovf_log_client_registration($client_id,$method='staff',$user_id=null){
 global $wpdb;$t=ovf_tables();$uid=$user_id===null?get_current_user_id():absint($user_id);
 $wpdb->insert($t['moves'],['client_id'=>absint($client_id),'type'=>'registration','amount'=>0,'note'=>'','user_id'=>$uid,'method'=>sanitize_key($method)?:'staff','created_at'=>current_time('mysql')]);
}

register_activation_hook(__FILE__,'ovf_activate');
register_deactivation_hook(__FILE__,function(){wp_clear_scheduled_hook('ovf_daily_birthday_rewards');});
function ovf_install_schema(){
 global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=ovf_tables(); $c=$wpdb->get_charset_collate();
 dbDelta("CREATE TABLE {$t['clients']} (id bigint unsigned NOT NULL AUTO_INCREMENT, token varchar(64) NOT NULL, short_code varchar(20) NOT NULL DEFAULT '', name varchar(190) NOT NULL, email varchar(190) DEFAULT '', phone varchar(60) DEFAULT '', visits int unsigned NOT NULL DEFAULT 0, status varchar(20) NOT NULL DEFAULT 'active', notes text, birthday date DEFAULT NULL, referral_code varchar(24) NOT NULL DEFAULT '', referred_by bigint unsigned NOT NULL DEFAULT 0, referral_rewarded tinyint(1) NOT NULL DEFAULT 0, email_marketing tinyint(1) NOT NULL DEFAULT 0, email_consent_at datetime DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY token(token), UNIQUE KEY short_code(short_code), KEY referral_code(referral_code), KEY email(email), KEY status(status), KEY referred_by(referred_by)) $c;");
 dbDelta("CREATE TABLE {$t['moves']} (id bigint unsigned NOT NULL AUTO_INCREMENT, client_id bigint unsigned NOT NULL, type varchar(30) NOT NULL, amount int NOT NULL DEFAULT 0, sale_amount decimal(10,2) NOT NULL DEFAULT 0, gross_amount decimal(10,2) NOT NULL DEFAULT 0, discount_amount decimal(10,2) NOT NULL DEFAULT 0, points_delta int NOT NULL DEFAULT 0, balance_delta decimal(10,2) NOT NULL DEFAULT 0, reward_id bigint unsigned DEFAULT 0, receipt_number varchar(80) NOT NULL DEFAULT '', note text, user_id bigint unsigned DEFAULT 0, method varchar(30) NOT NULL DEFAULT 'manual', created_at datetime NOT NULL, PRIMARY KEY(id), KEY client_id(client_id), KEY type(type), KEY created_at(created_at)) $c;");
 dbDelta("CREATE TABLE {$t['rewards']} (id bigint unsigned NOT NULL AUTO_INCREMENT, client_id bigint unsigned NOT NULL, rule_id bigint unsigned NOT NULL DEFAULT 0, milestone int unsigned NOT NULL, title varchar(190) NOT NULL, status varchar(20) NOT NULL DEFAULT 'available', unlocked_at datetime NOT NULL, redeemed_at datetime DEFAULT NULL, user_id bigint unsigned DEFAULT 0, move_id bigint unsigned NOT NULL DEFAULT 0, expires_at datetime DEFAULT NULL, PRIMARY KEY(id), KEY client_id(client_id), KEY status(status)) $c;");
 dbDelta("CREATE TABLE {$t['rules']} (id bigint unsigned NOT NULL AUTO_INCREMENT, milestone int unsigned NOT NULL, title varchar(190) NOT NULL, description text, enabled tinyint(1) NOT NULL DEFAULT 1, repeats tinyint(1) NOT NULL DEFAULT 0, expires_days int unsigned NOT NULL DEFAULT 0, sort_order int NOT NULL DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY(id), KEY milestone(milestone), KEY enabled(enabled)) $c;");
}
function ovf_activate(){
 $first_install = get_option('ovf_version',false)===false;
 ovf_install_schema(); ovf_ensure_clients_schema(); ovf_ensure_pages(); ovf_register_short_routes();
 if($first_install){ovf_update_option('ovf_setup_complete','no');set_transient('ovf_setup_redirect',1,60);}
 $role=get_role('administrator'); if($role) $role->add_cap('manage_ov_fidelidad');
 $editor=get_role('editor'); if($editor) $editor->add_cap('manage_ov_fidelidad');
 ovf_add_option('ovf_brand_name',get_bloginfo('name')); ovf_add_option('ovf_primary','#315b46'); ovf_add_option('ovf_accent','#0f172a'); add_option('ovf_delete_data','0');
 update_option('ovf_version',OVF_VERSION); flush_rewrite_rules();
}

add_action('admin_init','ovf_runtime_migrations');
function ovf_ensure_moves_schema(){ global $wpdb;$t=ovf_tables();$cols=$wpdb->get_col("SHOW COLUMNS FROM {$t['moves']}",0);if(!$cols)return;if(!in_array('method',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD method varchar(30) NOT NULL DEFAULT 'manual' AFTER user_id");if(!in_array('sale_amount',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD sale_amount decimal(10,2) NOT NULL DEFAULT 0 AFTER amount");if(!in_array('gross_amount',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD gross_amount decimal(10,2) NOT NULL DEFAULT 0 AFTER sale_amount");if(!in_array('discount_amount',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD discount_amount decimal(10,2) NOT NULL DEFAULT 0 AFTER gross_amount");if(!in_array('points_delta',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD points_delta int NOT NULL DEFAULT 0 AFTER discount_amount");if(!in_array('balance_delta',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD balance_delta decimal(10,2) NOT NULL DEFAULT 0 AFTER points_delta");if(!in_array('receipt_number',$cols,true))$wpdb->query("ALTER TABLE {$t['moves']} ADD receipt_number varchar(80) NOT NULL DEFAULT '' AFTER reward_id");}

function ovf_runtime_migrations(){
 if(!current_user_can('manage_options')) return;
 $role=get_role('administrator');
 if($role && !$role->has_cap('manage_ov_fidelidad')) $role->add_cap('manage_ov_fidelidad');
 $editor=get_role('editor');
 if($editor && !$editor->has_cap('manage_ov_fidelidad')) $editor->add_cap('manage_ov_fidelidad');
 if(get_option('ovf_version')!==OVF_VERSION){
  ovf_install_schema();
  ovf_ensure_clients_schema();
  ovf_ensure_moves_schema();
  ovf_ensure_pages();
  ovf_register_short_routes();
  flush_rewrite_rules(false);
  // Desde 0.3.0 el encargado define las contraseñas del personal; no se obliga a cambiarlas al iniciar sesión.
  $legacy_users=get_users(['role__in'=>['ovf_owner','ovf_staff','editor'],'fields'=>'ID']);
  foreach($legacy_users as $legacy_uid) delete_user_meta($legacy_uid,'ovf_force_password_change');
  update_option('ovf_version',OVF_VERSION);
 }
}

function ovf_ensure_pages(){
 $pages=[
  'ovf_page_portal'=>[__('Web App del equipo','ov-fidelidad'),'[ov_fidelidad_app]','fidelidad-app'],
  'ovf_page_register'=>[__('Únete a nuestro programa','ov-fidelidad'),'[ov_fidelidad_registro]','fidelidad-registro'],
  'ovf_page_card'=>[__('Mi tarjeta','ov-fidelidad'),'[ov_fidelidad_cliente]','mi-tarjeta'],
  'ovf_page_superadmin'=>[__('Alta de negocios','ov-fidelidad'),'[ov_fidelidad_alta_negocios]','alta-negocios'],
 ];
 foreach($pages as $key=>$p){ $id=(int)get_option($key); if($id && get_post($id)) continue; $found=get_page_by_path($p[2]);
  if($found){update_option($key,$found->ID);continue;}
  $id=wp_insert_post(['post_title'=>$p[0],'post_content'=>$p[1],'post_status'=>'publish','post_type'=>'page','post_name'=>$p[2],'comment_status'=>'closed']); if(!is_wp_error($id)) update_option($key,$id);
 }
 // Compatibilidad: acceso y escáner forman parte de la Web App, no son destinos que el negocio deba administrar.
 $app=(int)get_option('ovf_page_portal'); if($app){update_option('ovf_page_login',$app);update_option('ovf_page_scanner',$app);}
}


add_action('wp_enqueue_scripts','ovf_register_assets'); add_action('admin_enqueue_scripts','ovf_register_assets');
function ovf_enqueue_unslop_style(){
    if (!wp_style_is('ovf-ui','enqueued') && !wp_style_is('ovf-app-v02','enqueued') && !wp_style_is('ovf-admin-v02','enqueued') && !wp_style_is('ovfp-platform','enqueued') && !wp_style_is('ovf-workspace','enqueued')) return;
    wp_enqueue_style('ovf-unslop',OVF_URL.'assets/unslop.css',[],ovf_asset_version('assets/unslop.css'));
}
add_action('wp_enqueue_scripts','ovf_enqueue_unslop_style',999);
add_action('admin_enqueue_scripts','ovf_enqueue_unslop_style',999);
function ovf_asset_version($relative){$path=OVF_PATH.ltrim($relative,'/');return is_file($path)?(string)filemtime($path):OVF_VERSION;}
function ovf_register_assets(){ wp_register_style('ovf-ui',OVF_URL.'assets/ovf.css',[],ovf_asset_version('assets/ovf.css')); wp_register_script('ovf-qr',OVF_URL.'assets/qrcode.min.js',[],OVF_VERSION,true); wp_register_script('ovf-ui',OVF_URL.'assets/ovf.js',['ovf-qr'],ovf_asset_version('assets/ovf.js'),true); }
/** @param bool $with_style La hoja heredada ovf.css solo se carga en wp-admin y en la tarjeta del cliente; la Web App usa únicamente app-v02.css. */
function ovf_assets($with_style=true){ if($with_style) wp_enqueue_style('ovf-ui'); wp_enqueue_script('ovf-ui'); static $done=false; if($done) return; $done=true; wp_localize_script('ovf-ui','OVF_DATA',['scanner'=>add_query_arg('view','scanner',ovf_page_url('ovf_page_portal')),'card'=>ovf_page_url('ovf_page_card'),'jsqr'=>OVF_URL.'assets/jsqr.min.js?ver='.OVF_VERSION,'unsaved'=>__('Tienes cambios sin guardar.','ov-fidelidad'),'ajax'=>admin_url('admin-ajax.php'),'clientSearchNonce'=>wp_create_nonce('ovf_client_search'),'businessSearchNonce'=>wp_create_nonce('ovf_business_search'),'nonce'=>(is_user_logged_in()&&function_exists('ovf_v02_staff_cap')&&ovf_v02_staff_cap())?wp_create_nonce('ovf_scan'):'','t'=>[
 'confirmTitle'=>__('¿Registrar compra?','ov-fidelidad'),'confirm'=>__('Registrar compra','ov-fidelidad'),'cancel'=>__('Cancelar','ov-fidelidad'),
 'amountLabel'=>__('Importe de la compra (MXN)','ov-fidelidad'),'amountHelp'=>ovf_purchase_rules_summary(),'amountHint'=>__('El importe debe ser mayor que $0.00.','ov-fidelidad'),'amountRequired'=>__('Captura un importe mayor que $0.00 para registrar la compra.','ov-fidelidad'),'receiptAsk'=>__('¿Introducir número de ticket?','ov-fidelidad'),'receiptLabel'=>__('Número de ticket','ov-fidelidad'),'receiptPlaceholder'=>__('Ej. A-1048','ov-fidelidad'),'receiptHint'=>__('Escribe el número que aparece en el comprobante.','ov-fidelidad'),'receiptRequired'=>__('Escribe el número de ticket o vuelve y elige No.','ov-fidelidad'),'yes'=>__('Sí','ov-fidelidad'),'no'=>__('No, continuar','ov-fidelidad'),'back'=>__('Volver','ov-fidelidad'),'referralDiscount'=>__('Descuento de invitación','ov-fidelidad'),'referralPreview'=>__('Se aplicará en esta primera compra.','ov-fidelidad'),'discountValue'=>__('Descuento estimado: %1$s · total: %2$s','ov-fidelidad'),'ticket'=>__('Ticket','ov-fidelidad'),'totalAfterDiscount'=>__('Total después del descuento','ov-fidelidad'),
 'purchases'=>__('compras','ov-fidelidad'),'purchase1'=>__('compra','ov-fidelidad'),'next'=>__('Próximo: %1$s · faltan %2$d','ov-fidelidad'),
 'done'=>__('Compra registrada','ov-fidelidad'),'nowHas'=>__('Ahora tiene %d compras','ov-fidelidad'),'nowHas1'=>__('Ahora tiene %d compra','ov-fidelidad'),'unlocked'=>__('Beneficio disponible: %s','ov-fidelidad'),
 'available'=>__('Beneficios para canjear','ov-fidelidad'),'redeem'=>__('Canjear','ov-fidelidad'),'redeemed'=>__('Canjeado: %s','ov-fidelidad'),
 'redeemConfirm'=>__('¿Canjear “%s” ahora?','ov-fidelidad'),'scanNext'=>__('Escanear siguiente','ov-fidelidad'),'profile'=>__('Ver ficha','ov-fidelidad'),
 'retry'=>__('Escanear de nuevo','ov-fidelidad'),'notFound'=>__('Código no reconocido','ov-fidelidad'),'inactive'=>__('Tarjeta inactiva','ov-fidelidad'),
 'net'=>__('No hay conexión. Revisa tu internet e inténtalo de nuevo.','ov-fidelidad'),'working'=>__('Registrando…','ov-fidelidad'),'dup'=>__('Registrar de todos modos','ov-fidelidad')],'copied'=>__('Enlace copiado ✓','ov-fidelidad'),'confirmDelete'=>__('¿Eliminar este cliente? Esta acción no se puede deshacer.','ov-fidelidad'),'i18n'=>['scanning'=>__('Apunta al código QR…','ov-fidelidad'),'open'=>__('Abrir cámara','ov-fidelidad'),'noCamera'=>__('No fue posible abrir la cámara. Revisa los permisos del navegador o busca al cliente manualmente.','ov-fidelidad'),'https'=>__('La cámara solo funciona en sitios con HTTPS.','ov-fidelidad')]]); }
function ovf_cap(){if(is_user_logged_in()&&!current_user_can('manage_options')&&function_exists('ovf_v02_staff_cap')&&!ovf_v02_staff_cap())return false;if(is_user_logged_in()&&get_user_meta(get_current_user_id(),'ovf_access_disabled',true)==='1'&&!current_user_can('manage_options'))return false;return current_user_can('ovf_register_sales')||current_user_can('manage_ov_fidelidad')||current_user_can('manage_options');}
function ovf_business_slug(){ $b=ovf_business_row(ovf_business_id());return $b?$b->slug:'principal';}
function ovf_page_url($key){$id=(int)get_option($key);$url=$id?get_permalink($id):home_url('/');$business=ovf_business_row(ovf_business_id());return $business?add_query_arg('ovf_business',$business->slug,$url):$url;}
/** Contenido del QR de la tarjeta: un código que solo entiende el escáner de la Web App (no abre ninguna página con la cámara del teléfono). */
function ovf_qr_payload($token){return 'OVF:'.$token;}
/** Permanent, independently random URL code. The internal QR token remains unchanged. */
function ovf_new_short_code(){
 return rtrim(strtr(base64_encode(random_bytes(12)),'+/','-_'),'='); // 96 random bits, 16 URL-safe characters.
}
function ovf_short_code_for_token($token){
 static $checked=[];
 $business_id=ovf_business_id();
 if(empty($checked[$business_id])){ovf_ensure_clients_schema();$checked[$business_id]=true;}
 global $wpdb;$t=ovf_tables();
 $c=$wpdb->get_row($wpdb->prepare("SELECT id,short_code FROM {$t['clients']} WHERE token=%s LIMIT 1",$token));
 if(!$c)return '';
 if(!empty($c->short_code))return $c->short_code;
 // Legacy rows receive a code once, without changing their token, QR or purchases.
 for($i=0;$i<5;$i++){
  $code=ovf_new_short_code();
  $ok=$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET short_code=%s WHERE id=%d AND (short_code='' OR short_code IS NULL)",$code,(int)$c->id));
  if($ok===1)return $code;
  if($ok===0){$existing=$wpdb->get_var($wpdb->prepare("SELECT short_code FROM {$t['clients']} WHERE id=%d",(int)$c->id));if($existing)return $existing;}
 }
 return '';
}
function ovf_card_url($token){
 $code=ovf_short_code_for_token($token);
 if($code)return home_url('/t/'.rawurlencode(ovf_business_slug()).'/'.rawurlencode($code).'/');
 return add_query_arg('ovf',rawurlencode($token),ovf_page_url('ovf_page_card'));
}
/** Route /t/{business}/{code}/ to the existing card shortcode, without exposing internal tokens. */
function ovf_register_short_routes(){
 add_rewrite_rule('^t/([a-z0-9-]+)/([A-Za-z0-9_-]{16})/?$','index.php?ovf_short_business=$matches[1]&ovf_short_code=$matches[2]','top');
}
add_action('init','ovf_register_short_routes',5);
add_filter('query_vars',function($vars){$vars[]='ovf_short_business';$vars[]='ovf_short_code';return $vars;});
add_filter('request',function($query){
 if(empty($query['ovf_short_business'])||empty($query['ovf_short_code']))return $query;
 global $wpdb;
 $slug=sanitize_title($query['ovf_short_business']);
 $code=sanitize_text_field($query['ovf_short_code']);
 if(!preg_match('/^[A-Za-z0-9_-]{16}$/D',$code))return ['error'=>'404'];
 $business=ovf_business_by_slug($slug);
 if(!$business)return ['error'=>'404'];
 $id=(int)$business->id;
 $table=$wpdb->prefix.'ovf_clients'.($id>1?'_b'.$id:'');
 $token=$wpdb->get_var($wpdb->prepare("SELECT token FROM {$table} WHERE short_code=%s LIMIT 1",$code));
 $page_id=(int)get_option('ovf_page_card');
 if(!$token||!$page_id||!get_post($page_id))return ['error'=>'404'];
 $_GET['ovf_business']=$slug;
 $_GET['ovf']=$token;
 // Explicit context ensures shortcode, branding and rewards use the matching business.
 $GLOBALS['ovf_business_context_id']=$id;
 return ['page_id'=>$page_id,'ovf_short_business'=>$slug,'ovf_short_code'=>$code];
});
add_filter('redirect_canonical',function($redirect){
 if(get_query_var('ovf_short_code'))return false;
 return $redirect;
});
/** Refresh rewrite rules once after a plugin update, even if the admin migration has not run. */
add_action('init',function(){
 if(get_option('ovf_short_route_rewrite_version')==='1')return;
 flush_rewrite_rules(false);
 update_option('ovf_short_route_rewrite_version','1',false);
},99);

function ovf_scan_url($token){return add_query_arg('ovf',rawurlencode($token),ovf_page_url('ovf_page_portal'));}
function ovf_client_by_token($token){global $wpdb;$t=ovf_tables();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['clients']} WHERE token=%s",$token));}
function ovf_client($id){global $wpdb;$t=ovf_tables();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['clients']} WHERE id=%d",$id));}
function ovf_rules(){global $wpdb;$t=ovf_tables();return $wpdb->get_results("SELECT * FROM {$t['rules']} WHERE enabled=1 ORDER BY milestone ASC,sort_order ASC,id ASC");}
function ovf_all_rules(){global $wpdb;$t=ovf_tables();return $wpdb->get_results("SELECT * FROM {$t['rules']} ORDER BY milestone ASC,sort_order ASC,id ASC");}
function ovf_initial($name){$x=function_exists('mb_substr')?mb_substr($name,0,1):substr($name,0,1);return function_exists('mb_strtoupper')?mb_strtoupper($x):strtoupper($x);}
function ovf_brand(){return esc_html(ovf_get_option('ovf_brand_name',get_bloginfo('name')));}
function ovf_date($s){return date_i18n(get_option('date_format').' · '.get_option('time_format'),strtotime($s));}
/** Compatibilidad: delega en el motor 0.13 (includes/rewards.php). Devuelve los títulos desbloqueados. */
function ovf_unlock_rewards($client_id,$visits){return ovf_unlock_rewards_v2($client_id,$visits);}
function ovf_referral_discount_percent($client){if(!$client||empty($client->referred_by)||!empty($client->referral_rewarded))return 0.0;return min(100,max(0,(float)ovf_get_option('ovf_referral_discount_percent',0)));}
function ovf_referral_discount_quote($client,$gross_amount,$apply_discount=true){$gross=max(0,round((float)$gross_amount,2));$percent=$gross>0&&$apply_discount?ovf_referral_discount_percent($client):0;$discount=round($gross*$percent/100,2);return ['gross_amount'=>$gross,'discount_percent'=>$percent,'discount_amount'=>$discount,'sale_amount'=>max(0,round($gross-$discount,2))];}
function ovf_register_purchase($client_id,$note='',$method='manual',$sale_amount=0,$balance_used=0,&$purchase_details=null,$receipt_number='',$apply_referral_discount=true){
	global $wpdb;$t=ovf_tables();ovf_ensure_moves_schema();$c=ovf_client($client_id);if(!$c||$c->status!=='active')return new WP_Error('invalid',__('Cliente no disponible.','ov-fidelidad'));
	$receipt_number=substr(sanitize_text_field($receipt_number),0,80);
	$gross_amount=max(0,round((float)$sale_amount,2));$balance_used=max(0,round((float)$balance_used,2));$wallet=ovf_client_balance($client_id);$quote=ovf_referral_discount_quote($c,$gross_amount,$apply_referral_discount);
	if($balance_used>$wallet||$balance_used>$quote['sale_amount'])return new WP_Error('wallet',__('El saldo aplicado no puede superar el saldo disponible ni el total después del descuento.','ov-fidelidad'));
	// Reclamo atómico de la primera compra: evita aplicar el descuento dos veces si dos empleados registran a la vez.
	$referral_first_purchase=$gross_amount>0&&!empty($c->referred_by)&&empty($c->referral_rewarded);$referral_claimed=false;
	if($referral_first_purchase){$claimed=$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET referral_rewarded=1,updated_at=%s WHERE id=%d AND referred_by>0 AND referral_rewarded=0",current_time('mysql'),$client_id));if($claimed===1){$referral_claimed=true;}elseif($claimed===false){return new WP_Error('referral_claim',__('No se pudo verificar el descuento de invitación. Inténtalo de nuevo.','ov-fidelidad'));}else{$c=ovf_client($client_id);$referral_first_purchase=false;$quote=ovf_referral_discount_quote($c,$gross_amount,$apply_referral_discount);if($balance_used>$quote['sale_amount'])return new WP_Error('wallet',__('El saldo cashback supera el total disponible después de aplicar las promociones.','ov-fidelidad'));}}
	$sale_amount=$quote['sale_amount'];$discount_amount=$quote['discount_amount'];$net=max(0,$sale_amount-$balance_used);$step=max(1,absint(ovf_get_option('ovf_points_per_amount',10)));$points=ovf_program_feature_enabled('points')?(int)floor($net/$step):0;$cashback_rate=ovf_program_feature_enabled('cashback')?min(100,max(0,(float)ovf_get_option('ovf_cashback_percent',0))):0;$cashback=round($net*$cashback_rate/100,2);
	$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET visits=visits+1,updated_at=%s WHERE id=%d",current_time('mysql'),$client_id));
	$new=(int)$wpdb->get_var($wpdb->prepare("SELECT visits FROM {$t['clients']} WHERE id=%d",$client_id));
	$inserted=$wpdb->insert($t['moves'],['client_id'=>$client_id,'type'=>'purchase','amount'=>1,'sale_amount'=>$sale_amount,'gross_amount'=>$gross_amount,'discount_amount'=>$discount_amount,'points_delta'=>$points,'balance_delta'=>$cashback-$balance_used,'receipt_number'=>sanitize_text_field($receipt_number),'note'=>sanitize_text_field($note),'user_id'=>get_current_user_id(),'method'=>sanitize_key($method)?:'manual','created_at'=>current_time('mysql')]);$move_id=(int)$wpdb->insert_id;if(!$inserted){$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET visits=GREATEST(visits-1,0),updated_at=%s WHERE id=%d",current_time('mysql'),$client_id));if($referral_claimed)$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET referral_rewarded=0 WHERE id=%d AND referral_rewarded=1",$client_id));return new WP_Error('purchase_save',__('No se pudo guardar la compra. Inténtalo de nuevo.','ov-fidelidad'));}
	$purchase_details=['gross_amount'=>$gross_amount,'discount_percent'=>$quote['discount_percent'],'discount_amount'=>$discount_amount,'sale_amount'=>$sale_amount,'balance_used'=>$balance_used,'total_due'=>max(0,round($sale_amount-$balance_used,2)),'receipt_number'=>sanitize_text_field($receipt_number)];
 if(function_exists('ovf_award_birthday_bonus'))ovf_award_birthday_bonus($client_id);
	if($referral_first_purchase){$ref=(int)$c->referred_by;$bonus_type=ovf_get_option('ovf_referral_bonus_type','points');$bonus=$bonus_type==='stamps'?min(2,max(0,absint(ovf_get_option('ovf_referral_bonus_stamps',0)))):max(0,absint(ovf_get_option('ovf_referral_bonus_points',0)));$refc=ovf_client($ref);if($refc&&$bonus){if($bonus_type==='stamps'){$wpdb->query($wpdb->prepare("UPDATE {$t['clients']} SET visits=visits+%d,updated_at=%s WHERE id=%d",$bonus,current_time('mysql'),$ref));$ref_visits=(int)$wpdb->get_var($wpdb->prepare("SELECT visits FROM {$t['clients']} WHERE id=%d",$ref));$wpdb->insert($t['moves'],['client_id'=>$ref,'type'=>'referral_bonus','amount'=>$bonus,'points_delta'=>0,'note'=>sprintf(_n('Bono de invitación: %d sello','Bono de invitación: %d sellos',$bonus,'ov-fidelidad'),$bonus).' · '.$c->name,'user_id'=>get_current_user_id(),'method'=>'system','created_at'=>current_time('mysql')]);ovf_unlock_rewards($ref,$ref_visits);}else{$wpdb->insert($t['moves'],['client_id'=>$ref,'type'=>'referral_bonus','amount'=>0,'points_delta'=>$bonus,'note'=>sprintf(__('Bono de invitación: %d puntos','ov-fidelidad'),$bonus).' · '.$c->name,'user_id'=>get_current_user_id(),'method'=>'system','created_at'=>current_time('mysql')]);}}}
	 ovf_unlock_rewards($client_id,$new);
 if($move_id){$unlocked=$wpdb->get_results($wpdb->prepare("SELECT id,title FROM {$t['rewards']} WHERE client_id=%d AND move_id=%d AND status='available'",$client_id,$move_id));}
 return $new;
}

// Clientes procesa formularios dentro de la página y redirige al guardar/eliminar: se guarda la salida en búfer
// para que la redirección funcione (antes fallaba con "headers already sent").
add_action('admin_init',function(){if(($_GET['page']??'')==='ov-fidelidad-clients'&&(!empty($_POST)||($_GET['action']??'')==='delete'))ob_start();});
add_action('admin_menu','ovf_admin_menu');
/** Legacy onboarding links with an explicit tenant ID still open their tenant summary. */
function ovf_platform_main_dashboard(){
 if(!current_user_can('manage_options'))wp_die('Acceso restringido');
 $id=absint($_GET['ovf_business_id']??0);
 if($id && ovf_business_row($id)){ovf_platform_business_dashboard();return;}
 ovf_platform_dashboard();
}
function ovf_admin_menu(){
 add_menu_page('OV Fidelidad','OV Fidelidad','manage_options','ov-fidelidad','ovf_platform_main_dashboard','dashicons-awards',30);
 add_submenu_page('ov-fidelidad',__('Negocios','ov-fidelidad'),__('Negocios','ov-fidelidad'),'manage_options','ov-fidelidad-businesses','ovf_admin_businesses');
  add_submenu_page('ov-fidelidad',__('Clientes','ov-fidelidad'),__('Clientes','ov-fidelidad'),'manage_options','ov-fidelidad-clients','ovf_admin_clients');
 add_submenu_page('ov-fidelidad',__('Beneficios','ov-fidelidad'),__('Beneficios','ov-fidelidad'),'manage_options','ov-fidelidad-rewards','ovf_admin_rewards');
 add_submenu_page('ov-fidelidad',__('Historial','ov-fidelidad'),__('Historial','ov-fidelidad'),'manage_options','ov-fidelidad-history','ovf_admin_history');
 add_submenu_page('ov-fidelidad',__('Reportes','ov-fidelidad'),__('Reportes','ov-fidelidad'),'manage_options','ov-fidelidad-reports','ovf_admin_reports');
 add_submenu_page('ov-fidelidad',__('Reglas de acumulación','ov-fidelidad'),__('Reglas de acumulación','ov-fidelidad'),'manage_options','ov-fidelidad-program','ovf_admin_program');
 add_submenu_page('ov-fidelidad',__('✉ Banner y envío de promociones','ov-fidelidad'),__('✉ Banner y envío de promociones','ov-fidelidad'),'manage_options','ov-fidelidad-marketing','ovf_admin_marketing');
 add_submenu_page('ov-fidelidad',__('Correo SMTP','ov-fidelidad'),__('Correo SMTP','ov-fidelidad'),'manage_options','ov-fidelidad-mail','ovf_admin_smtp');
}
add_action('admin_menu',function(){global $submenu;if(isset($submenu['ov-fidelidad'][0]))$submenu['ov-fidelidad'][0][0]=__('Dashboard de plataforma','ov-fidelidad');},999);
function ovf_admin_businesses(){
 if(!current_user_can('manage_options'))return;
 global $wpdb;$table=ovf_businesses_table();$error='';
 if(isset($_POST['ovf_create_business'])&&check_admin_referer('ovf_create_business')){
  $name=sanitize_text_field(wp_unslash($_POST['business_name']??''));$email=sanitize_email(wp_unslash($_POST['owner_email']??''));$phone=sanitize_text_field(wp_unslash($_POST['business_phone']??''));$password=(string)($_POST['owner_password']??'');$color=sanitize_hex_color(wp_unslash($_POST['business_color']??''))?:'#334155';$points=max(1,absint($_POST['points_per_amount']??10));$cashback=max(0,min(100,(float)($_POST['cashback_percent']??0)));$referral_type=in_array($_POST['referral_bonus_type']??'points',['points','stamps'],true)?$_POST['referral_bonus_type']:'points';$referral_amount=max(0,absint($_POST['referral_bonus_amount']??$_POST['referral_bonus_points']??0));$referral_points=$referral_type==='points'?$referral_amount:0;$referral_stamps=$referral_type==='stamps'?min(2,$referral_amount):0;$referral_discount=max(0,min(100,(float)($_POST['referral_discount_percent']??0)));$birthday_points=max(0,absint($_POST['birthday_bonus_points']??0));$reward_title=sanitize_text_field(wp_unslash($_POST['first_reward_title']??''));$reward_milestone=max(1,absint($_POST['first_reward_milestone']??10));
  if(!$name||!is_email($email)||strlen($password)<12)$error=__('Completa el nombre, un correo válido y una contraseña de al menos 12 caracteres.','ov-fidelidad');
  elseif(email_exists($email))$error=__('Ese correo ya tiene una cuenta WordPress. Usa un correo nuevo para asignar un encargado sin afectar otras cuentas.','ov-fidelidad');
  else{
   $slug=sanitize_title($name)?:'negocio';$base=$slug;$n=2;while($wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE slug=%s",$slug)))$slug=$base.'-'.$n++;
   $now=current_time('mysql');$wpdb->insert($table,['name'=>$name,'slug'=>$slug,'email'=>$email,'phone'=>$phone,'status'=>'active','created_at'=>$now,'updated_at'=>$now]);$business_id=(int)$wpdb->insert_id;
   if(!$business_id)$error=__('No se pudo crear el negocio. Revisa la base de datos e inténtalo de nuevo.','ov-fidelidad');
   else{
    $old=ovf_set_business_context($business_id);$user_id=wp_create_user($email,$password,$email);
    if(is_wp_error($user_id)){$wpdb->delete($table,['id'=>$business_id]);$error=$user_id->get_error_message();}
    else{
     $user=new WP_User($user_id);$user->set_role('ovf_owner');wp_update_user(['ID'=>$user_id,'display_name'=>$name,'first_name'=>$name]);update_user_meta($user_id,'ovf_business_id',$business_id);$wpdb->update($table,['owner_user_id'=>$user_id],['id'=>$business_id]);
     foreach(['ovf_brand_name'=>$name,'ovf_app_name'=>$name.' Club','ovf_app_short_name'=>$name,'ovf_primary'=>$color,'ovf_accent'=>'#0f172a','ovf_background'=>'#f4f5f7','ovf_points_per_amount'=>$points,'ovf_points_per_peso'=>$points,'ovf_cashback_percent'=>$cashback,'ovf_referral_bonus_points'=>$referral_points,'ovf_referral_bonus_type'=>$referral_type,'ovf_referral_bonus_stamps'=>$referral_stamps,'ovf_referral_discount_percent'=>$referral_discount,'ovf_birthday_bonus_points'=>$birthday_points,'ovf_purchase_window_days'=>0,'ovf_privacy_required'=>'1'] as $key=>$value)ovf_update_option($key,$value);
     ovf_create_business_tables($business_id);$reward_context=ovf_set_business_context($business_id);if($reward_title){$tnew=ovf_tables();$wpdb->insert($tnew['rules'],['milestone'=>$reward_milestone,'title'=>$reward_title,'description'=>'','enabled'=>1,'repeats'=>0,'expires_days'=>0,'sort_order'=>$reward_milestone,'created_at'=>$now]);}ovf_set_business_context($reward_context);ovf_set_business_context($old);
     set_transient('ovf_onboarding_credentials_'.$business_id.'_'.get_current_user_id(),['owner_id'=>(int)$user_id,'email'=>$email,'password'=>$password],2*HOUR_IN_SECONDS);wp_safe_redirect(add_query_arg(['page'=>'ov-fidelidad','ovf_business_id'=>$business_id,'onboarding'=>'1'],admin_url('admin.php')));exit;
    }
    ovf_set_business_context($old);
   }
  }
 }
 $business_search=sanitize_text_field(wp_unslash($_GET['business_search']??''));$business_page=max(1,absint($_GET['business_page']??1));$business_per_page=10;$business_sort=sanitize_key($_GET['business_sort']??'newest');if(!in_array($business_sort,['newest','clients','activity'],true))$business_sort='newest';$business_status=sanitize_key($_GET['business_status']??'all');if(!in_array($business_status,['all','active','paused'],true))$business_status='all';$where='1=1';$query_args=[];if($business_status!=='all'){$where.=' AND b.status=%s';$query_args[]=$business_status;}if($business_search!==''){$like='%'.$wpdb->esc_like($business_search).'%';$where.=' AND (b.name LIKE %s OR b.slug LIKE %s OR b.email LIKE %s)';array_push($query_args,$like,$like,$like);}$count_sql="SELECT COUNT(*) FROM {$table} b WHERE {$where}";$total_businesses=(int)($query_args?$wpdb->get_var($wpdb->prepare($count_sql,$query_args)):$wpdb->get_var($count_sql));$total_business_pages=max(1,(int)ceil($total_businesses/$business_per_page));$business_page=min($business_page,$total_business_pages);$stat_parts=[];$business_ids=$wpdb->get_col("SELECT id FROM {$table}");$since_activity=wp_date('Y-m-d H:i:s',current_time('timestamp',true)-30*DAY_IN_SECONDS);foreach($business_ids as $bid){$bid=(int)$bid;$suffix=$bid>1?'_b'.$bid:'';$client_table=$wpdb->prefix.'ovf_clients'.$suffix;$move_table=$wpdb->prefix.'ovf_movements'.$suffix;$stat_parts[]=$wpdb->prepare("SELECT %d business_id,(SELECT COUNT(*) FROM {$client_table} WHERE status='active') client_count,(SELECT COUNT(*) FROM {$move_table} WHERE type='purchase' AND created_at >= %s) activity_count",$bid,$since_activity);}$stats_sql=$stat_parts?'('.implode(' UNION ALL ',$stat_parts).')':'(SELECT 0 business_id,0 client_count,0 activity_count)';$order_sql=$business_sort==='clients'?'COALESCE(st.client_count,0) DESC,b.id DESC':($business_sort==='activity'?'COALESCE(st.activity_count,0) DESC,b.id DESC':'b.id DESC');$list_sql="SELECT b.*,u.display_name owner_name,COALESCE(st.client_count,0) client_count,COALESCE(st.activity_count,0) activity_count FROM {$table} b LEFT JOIN {$wpdb->users} u ON u.ID=b.owner_user_id LEFT JOIN {$stats_sql} st ON st.business_id=b.id WHERE {$where} ORDER BY {$order_sql} LIMIT %d OFFSET %d";$list_args=array_merge($query_args,[$business_per_page,($business_page-1)*$business_per_page]);$businesses=$wpdb->get_results($wpdb->prepare($list_sql,$list_args));
 ovf_admin_header(__('Negocios','ov-fidelidad'),__('Crea y administra negocios en esta instalación. Cada negocio usa sus propias tarjetas, compras, beneficios y configuración.', 'ov-fidelidad'),false);
 if($error)ovf_notice($error,'error');if(isset($_GET['created']))ovf_notice(__('Negocio creado. Su encargado ya puede entrar a la Web App con las credenciales configuradas.','ov-fidelidad'));
 echo '<div class="ovf-business-layout"><section class="ovf-panel ovf-business-create"><span class="ovf-eyebrow">'.esc_html__('NUEVO NEGOCIO','ov-fidelidad').'</span><h2>'.esc_html__('Dar de alta un negocio','ov-fidelidad').'</h2><p>'.esc_html__('Se crea un espacio independiente y una cuenta de encargado. El correo o teléfono de sus clientes podrá registrarse también en otros negocios.','ov-fidelidad').'</p><form method="post" class="ovf-fields">';wp_nonce_field('ovf_create_business');
 echo '<label><span>'.esc_html__('Nombre del negocio','ov-fidelidad').'</span><input name="business_name" required maxlength="190" value="'.esc_attr(wp_unslash($_POST['business_name']??'')).'" placeholder="Cafetería Centro"></label><label><span>'.esc_html__('Correo del encargado','ov-fidelidad').'</span><input type="email" name="owner_email" required autocomplete="email" value="'.esc_attr(wp_unslash($_POST['owner_email']??'')).'" placeholder="encargado@negocio.com"></label><label><span>'.esc_html__('Contraseña inicial','ov-fidelidad').'</span><input type="password" name="owner_password" required minlength="12" autocomplete="new-password" placeholder="Mínimo 12 caracteres"></label><label><span>'.esc_html__('Teléfono del negocio (opcional)','ov-fidelidad').'</span><input name="business_phone" value="'.esc_attr(wp_unslash($_POST['business_phone']??'')).'" placeholder="33 1234 5678"></label><label class="ovf-color-field"><span>'.esc_html__('Color principal','ov-fidelidad').'</span><input type="color" name="business_color" value="'.esc_attr(wp_unslash($_POST['business_color']??'#334155')).'"></label><label><span>'.esc_html__('Gasto para ganar 1 punto (MXN)','ov-fidelidad').'</span><input type="number" name="points_per_amount" min="1" value="'.esc_attr(wp_unslash($_POST['points_per_amount']??'10')).'"><small>'.esc_html__('Por ejemplo, 10 significa 1 punto por cada $10 de compra.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Cashback por compra (%)','ov-fidelidad').'</span><input type="number" name="cashback_percent" min="0" max="100" step="0.1" value="'.esc_attr(wp_unslash($_POST['cashback_percent']??'0')).'"><small>'.esc_html__('Porcentaje del total de compra que se agrega como saldo. Usa 0 para desactivarlo.','ov-fidelidad').'</small></label><label><span>'.esc_html__('El bono de invitación se entrega como','ov-fidelidad').'</span><select name="referral_bonus_type"><option value="points" '.selected($_POST['referral_bonus_type']??'points','points',false).'>'.esc_html__('Puntos','ov-fidelidad').'</option><option value="stamps" '.selected($_POST['referral_bonus_type']??'points','stamps',false).'>'.esc_html__('Sellos de compra','ov-fidelidad').'</option></select></label><label><span>'.esc_html__('Cantidad del bono de invitación','ov-fidelidad').'</span><input type="number" name="referral_bonus_amount" data-referral-bonus-amount min="0" max="100000" value="'.esc_attr(wp_unslash($_POST['referral_bonus_amount']??'0')).'"><small>'.esc_html__('Si eliges sellos, puedes entregar 1 o 2. El bono se otorga cuando el invitado hace su primera compra.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Descuento al invitado en su primera compra (%)','ov-fidelidad').'</span><input type="number" name="referral_discount_percent" min="0" max="100" step="0.1" value="'.esc_attr(wp_unslash($_POST['referral_discount_percent']??'0')).'"></label><label><span>'.esc_html__('Bono de cumpleaños (puntos)','ov-fidelidad').'</span><input type="number" name="birthday_bonus_points" min="0" value="'.esc_attr(wp_unslash($_POST['birthday_bonus_points']??'0')).'"><small>'.esc_html__('Puntos que se entregan una vez al año, en el cumpleaños. Usa 0 para desactivarlo.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Nombre del primer beneficio','ov-fidelidad').'</span><input name="first_reward_title" value="'.esc_attr(wp_unslash($_POST['first_reward_title']??'Producto gratis')).'"></label><label><span>'.esc_html__('Compras necesarias para ganar este beneficio','ov-fidelidad').'</span><input type="number" name="first_reward_milestone" min="1" value="'.esc_attr(wp_unslash($_POST['first_reward_milestone']??'10')).'"><small>'.esc_html__('Número de compras registradas que debe alcanzar el cliente.','ov-fidelidad').'</small></label><button class="ovf-admin-btn" name="ovf_create_business" value="1">＋ '.esc_html__('Crear negocio','ov-fidelidad').'</button></form></section><section class="ovf-panel ovf-business-list"><div class="ovf-panel-title"><h2>'.esc_html__('Negocios registrados','ov-fidelidad').'</h2><span class="ovf-count-pill">'.$total_businesses.'</span></div><form class="ovf-business-search" method="get" data-ovf-business-search><input type="hidden" name="page" value="ov-fidelidad-businesses"><label class="screen-reader-text" for="ovf-business-search-input">'.esc_html__('Buscar negocios','ov-fidelidad').'</label><input id="ovf-business-search-input" type="search" name="business_search" value="'.esc_attr($business_search).'" placeholder="'.esc_attr__('Buscar por nombre, correo o enlace','ov-fidelidad').'" autocomplete="off"><div class="ovf-search-suggestions ovf-business-suggestions" data-ovf-business-results hidden></div><label class="screen-reader-text" for="ovf-business-status">'.esc_html__('Filtrar por estado','ov-fidelidad').'</label><select id="ovf-business-status" name="business_status" onchange="this.form.submit()"><option value="all" '.selected($business_status,'all',false).'>'.esc_html__('Todos los estados','ov-fidelidad').'</option><option value="active" '.selected($business_status,'active',false).'>'.esc_html__('Activos','ov-fidelidad').'</option><option value="paused" '.selected($business_status,'paused',false).'>'.esc_html__('Pausados','ov-fidelidad').'</option></select><label class="screen-reader-text" for="ovf-business-sort">'.esc_html__('Ordenar negocios','ov-fidelidad').'</label><select id="ovf-business-sort" name="business_sort" onchange="this.form.submit()"><option value="newest" '.selected($business_sort,'newest',false).'>'.esc_html__('Últimos registrados','ov-fidelidad').'</option><option value="clients" '.selected($business_sort,'clients',false).'>'.esc_html__('Más clientes','ov-fidelidad').'</option><option value="activity" '.selected($business_sort,'activity',false).'>'.esc_html__('Más activos · compras últimos 30 días','ov-fidelidad').'</option></select><button class="button">'.esc_html__('Buscar','ov-fidelidad').'</button></form><div class="ovf-business-table-wrap"><table class="ovf-table"><thead><tr><th>'.esc_html__('Negocio','ov-fidelidad').'</th><th>'.esc_html__('Encargado','ov-fidelidad').'</th><th>'.esc_html__('Clientes','ov-fidelidad').'</th><th>'.esc_html__('Compras · 30 días','ov-fidelidad').'</th><th>'.esc_html__('Estado','ov-fidelidad').'</th><th>'.esc_html__('Acciones','ov-fidelidad').'</th></tr></thead><tbody>';
 foreach($businesses as $b){$portal=add_query_arg('ovf_business',$b->slug,ovf_page_url('ovf_page_portal'));$signup=add_query_arg('view','signup',$portal);$register=add_query_arg('ovf_business',$b->slug,ovf_page_url('ovf_page_register'));$select=add_query_arg(['page'=>'ov-fidelidad','ovf_business_id'=>(int)$b->id],admin_url('admin.php'));echo '<tr><td><b>'.esc_html($b->name).'</b><small class="ovf-business-slug">'.esc_html($b->slug).'</small></td><td>'.esc_html($b->owner_name?:$b->email?:'—').'</td><td><b>'.number_format_i18n((int)$b->client_count).'</b></td><td><b>'.number_format_i18n((int)$b->activity_count).'</b></td><td><span class="ovf-status '.esc_attr($b->status).'">'.esc_html($b->status==='active'?__('Activo','ov-fidelidad'):__('Pausado','ov-fidelidad')).'</span></td><td class="ovf-business-actions"><a href="'.esc_url($select).'">'.esc_html__('Abrir panel','ov-fidelidad').'</a><a target="_blank" rel="noopener" href="'.esc_url($portal).'">'.esc_html__('Web App','ov-fidelidad').' ↗</a><a target="_blank" rel="noopener" href="'.esc_url($signup).'">'.esc_html__('QR de registro','ov-fidelidad').' ↗</a><a target="_blank" rel="noopener" href="'.esc_url($register).'">'.esc_html__('Formulario','ov-fidelidad').' ↗</a></td></tr>';}
 if(!$businesses)echo '<tr><td colspan="6">'.esc_html__('Aún no hay negocios.','ov-fidelidad').'</td></tr>';
 echo '</tbody></table></div>';if($total_business_pages>1){echo '<nav class="ovf-business-pagination" aria-label="'.esc_attr__('Paginación de negocios','ov-fidelidad').'">';$page_numbers=array_unique(array_merge([1,$total_business_pages],range(max(1,$business_page-2),min($total_business_pages,$business_page+2))));sort($page_numbers);$last_page_number=0;foreach($page_numbers as $pnum){if($last_page_number&&$pnum>$last_page_number+1)echo '<span class="ovf-page-gap" aria-hidden="true">…</span>';if($pnum===$business_page)echo '<span aria-current="page">'.$pnum.'</span>';else echo '<a href="'.esc_url(add_query_arg(['page'=>'ov-fidelidad-businesses','business_page'=>$pnum,'business_search'=>$business_search,'business_sort'=>$business_sort,'business_status'=>$business_status],admin_url('admin.php'))).'">'.$pnum.'</a>';$last_page_number=$pnum;}echo '</nav>';}echo '</section></div>';ovf_admin_end();
}

add_action('wp_ajax_ovf_business_suggest','ovf_ajax_business_suggest');
function ovf_ajax_business_suggest(){
 if(!current_user_can('manage_options'))wp_send_json_error(['message'=>__('No tienes permiso para buscar negocios.','ov-fidelidad')],403);
 check_ajax_referer('ovf_business_search','nonce');
 global $wpdb;$q=sanitize_text_field(wp_unslash($_POST['q']??''));if(strlen($q)<2)wp_send_json_success([]);
 $table=ovf_businesses_table();$like='%'.$wpdb->esc_like($q).'%';
 $rows=$wpdb->get_results($wpdb->prepare("SELECT id,name,slug,email,status FROM {$table} WHERE name LIKE %s OR slug LIKE %s OR email LIKE %s ORDER BY name ASC LIMIT 8",$like,$like,$like));
 $items=[];foreach($rows as $row)$items[]=['name'=>$row->name,'email'=>$row->email,'status'=>$row->status,'url'=>add_query_arg(['page'=>'ov-fidelidad','ovf_business_id'=>(int)$row->id],admin_url('admin.php'))];
 wp_send_json_success($items);
}

function ovf_brand_style(){return '--ovf-brand:'.esc_attr(sanitize_hex_color(get_option('ovf_superadmin_primary','#4fae91'))?:'#4fae91').';--ovf-brand-dark:'.esc_attr(sanitize_hex_color(get_option('ovf_superadmin_accent','#172033'))?:'#172033').';--ovf-admin-bg:'.esc_attr(sanitize_hex_color(get_option('ovf_superadmin_background','#f3f5f4'))?:'#f3f5f4');}
function ovf_admin_header($title,$desc='',$show_new=true){
 ovf_assets();$active=ovf_business_id();$active_row=ovf_business_row($active);$active_name=$active_row?$active_row->name:__('Negocio principal','ov-fidelidad');
 echo '<div class="wrap ovf-admin" style="'.ovf_brand_style().'">';
 echo '<div class="ovf-admin-head"><div class="ovf-admin-heading"><span class="ovf-eyebrow">OV FIDELIDAD</span><h1>'.esc_html($title).'</h1>'.($desc?'<p>'.esc_html($desc).'</p>':'').'</div>'.($show_new?'<a class="ovf-admin-btn" href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-clients&action=new')).'">+ '.esc_html__('Nuevo cliente','ov-fidelidad').'</a>':'').'</div>';
 if(current_user_can('manage_options')){global $wpdb;$bt=ovf_businesses_table();$bs=$wpdb->get_results("SELECT id,name FROM {$bt} WHERE status='active' ORDER BY name");if($bs){echo '<div class="ovf-tenant-context"><div class="ovf-tenant-context-copy"><span class="ovf-tenant-context-icon">⌂</span><span><small>'.esc_html__('ESTÁS ADMINISTRANDO','ov-fidelidad').'</small><b>'.esc_html($active_name).'</b></span></div>';if(count($bs)>1&&count($bs)<=30){echo '<form class="ovf-business-switch" method="get" action="'.esc_url(admin_url('admin.php')).'"><input type="hidden" name="page" value="'.esc_attr(sanitize_key($_GET['page']??'ov-fidelidad')).'"><label><span>'.esc_html__('Cambiar negocio','ov-fidelidad').'</span><select name="ovf_business_id" onchange="this.form.submit()">';foreach($bs as $b)echo '<option value="'.(int)$b->id.'" '.selected($active,(int)$b->id,false).'>'.esc_html($b->name).'</option>';echo '</select></label></form>';}elseif(count($bs)>30)echo '<a class="ovf-tenant-manage" href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-businesses')).'">'.esc_html__('Buscar o cambiar negocio','ov-fidelidad').' →</a>';echo '</div>';}}
}
function ovf_admin_end(){echo '</div>';}
function ovf_notice($msg,$type='ok'){echo '<div class="ovf-notice '.esc_attr($type).'">'.esc_html($msg).'</div>';}

function ovf_admin_business_access_card($business,$credentials=[]){
 if(!$business)return '';
 $owner_id=absint($business->owner_user_id??0);$owner=$owner_id?get_user_by('id',$owner_id):false;
 if(!$owner)return '';
 $email=$owner->user_email;$password='';if(!empty($credentials['password'])&&absint($credentials['owner_id']??0)===$owner_id)$password=(string)$credentials['password'];
 $panel=ovf_v02_url('ovf_page_portal');$register=ovf_v02_url('ovf_page_register');
 $intro=sprintf(__('Hola %1$s 👋','ov-fidelidad'),$owner->display_name);
 $base_message=implode("\n",[$intro,'',sprintf(__('Te comparto los accesos de %s:','ov-fidelidad'),$business->name),'','🔐 *Panel del encargado*',$panel,'','📧 *Correo de acceso*',$email,'','📝 *Registro de clientes*',$register,'',__('Inicia sesión con el correo y la contraseña que ya tienes. Si no la recuerdas, dime y preparo una nueva.','ov-fidelidad')]);
 $wa_phone=preg_replace('/\D+/','',(string)($business->phone??''));if(strlen($wa_phone)===10)$wa_phone='52'.$wa_phone;
 $wa_base='https://web.whatsapp.com/send?'.($wa_phone?'phone='.rawurlencode($wa_phone).'&':'');
 $base_wa_url=$wa_base.'text='.urlencode($base_message);
 ob_start();?><section class="ovf-panel ovf-business-access-card"><div class="ovf-panel-title"><div><span class="ovf-eyebrow"><?php esc_html_e('ACCESOS PARA EL NEGOCIO','ov-fidelidad');?></span><h2><?php echo esc_html($business->name);?></h2></div><span class="ovf-status-badge"><?php esc_html_e('Listo para compartir','ov-fidelidad');?></span></div>
 <div class="ovf-business-access-grid"><div><small><?php esc_html_e('PANEL DEL ENCARGADO','ov-fidelidad');?></small><a target="_blank" rel="noopener" href="<?php echo esc_url($panel);?>"><?php esc_html_e('Abrir Web App ↗','ov-fidelidad');?></a><code><?php echo esc_html($panel);?></code></div><div><small><?php esc_html_e('REGISTRO DE CLIENTES','ov-fidelidad');?></small><a target="_blank" rel="noopener" href="<?php echo esc_url($register);?>"><?php esc_html_e('Abrir formulario ↗','ov-fidelidad');?></a><code><?php echo esc_html($register);?></code></div><div><small><?php esc_html_e('CORREO DE ACCESO','ov-fidelidad');?></small><b><?php echo esc_html($email);?></b><span><?php esc_html_e('Se utiliza como usuario para iniciar sesión.','ov-fidelidad');?></span></div>
 <?php if($password):?><div class="ovf-business-access-password"><small><?php esc_html_e('CONTRASEÑA NUEVA','ov-fidelidad');?></small><code><?php echo esc_html($password);?></code><span><?php esc_html_e('Temporal. Compártela ahora; el dueño podrá cambiarla después.','ov-fidelidad');?></span></div><?php endif;?></div>
 <div class="ovf-business-access-footer"><div><b><?php esc_html_e('Compartir accesos','ov-fidelidad');?></b><p><?php esc_html_e('Puedes reenviar los enlaces y el correo sin modificar la contraseña. Si el dueño no la recuerda, genera una nueva; eso invalidará la anterior.','ov-fidelidad');?></p></div><div class="ovf-business-access-actions"><a class="ovf-admin-btn ovf-business-whatsapp" target="_blank" rel="noopener" href="<?php echo esc_attr($base_wa_url);?>"><?php esc_html_e('WhatsApp: compartir sin cambiar contraseña','ov-fidelidad');?> ↗</a>
 <?php if($password):$full_message=implode("\n",[$intro,'',sprintf(__('Tu acceso a %s está listo:','ov-fidelidad'),$business->name),'','🔐 *Panel del encargado*',$panel,'','📧 *Correo de acceso*',$email,'','🔑 *Contraseña temporal*',$password,'','📝 *Registro de clientes*',$register,'',__('Al entrar podrás atender clientes, registrar compras, consultar reportes y administrar los beneficios de tu negocio.','ov-fidelidad')]);$full_wa_url=$wa_base.'text='.urlencode($full_message);?><a class="ovf-secondary-btn ovf-business-whatsapp" target="_blank" rel="noopener" href="<?php echo esc_attr($full_wa_url);?>"><?php esc_html_e('WhatsApp: enviar contraseña nueva','ov-fidelidad');?> ↗</a>
 <?php else:?><form method="post" onsubmit="return confirm('<?php echo esc_js(__('Se cambiará la contraseña del encargado y la anterior dejará de funcionar. ¿Continuar?','ov-fidelidad'));?>');"><?php wp_nonce_field('ovf_reset_business_owner_access');?><input type="hidden" name="business_id" value="<?php echo (int)$business->id;?>"><button class="ovf-secondary-btn" name="ovf_reset_business_owner_access" value="1"><?php esc_html_e('Generar contraseña nueva','ov-fidelidad');?></button></form><?php endif;?></div></div>
 <p class="ovf-business-whatsapp-note"><?php esc_html_e('WhatsApp Web abrirá el texto preparado; revísalo y pulsa Enviar.','ov-fidelidad');?></p></section><?php return ob_get_clean();
}

require_once OVF_PATH.'includes/mobile-onboarding.php';

function ovf_admin_dashboard(){
 if(isset($_POST['ovf_reset_business_owner_access'])&&current_user_can('manage_options')&&check_admin_referer('ovf_reset_business_owner_access')){$bid=absint($_POST['business_id']??0);$b=ovf_business_row($bid);$oid=$b?absint($b->owner_user_id):0;$owner=$oid?get_user_by('id',$oid):false;if($owner&&in_array('ovf_owner',$owner->roles,true)&&absint(get_user_meta($oid,'ovf_business_id',true))===$bid){$password=wp_generate_password(18,true,true);wp_set_password($password,$oid);set_transient('ovf_onboarding_credentials_'.$bid.'_'.get_current_user_id(),['owner_id'=>$oid,'email'=>$owner->user_email,'password'=>$password],HOUR_IN_SECONDS);wp_safe_redirect(add_query_arg(['page'=>'ov-fidelidad','ovf_business_id'=>$bid,'credentials'=>'1'],admin_url('admin.php')));exit;}}
 $business=ovf_business_row(ovf_business_id());$credentials=get_transient('ovf_onboarding_credentials_'.ovf_business_id().'_'.get_current_user_id());if($credentials)delete_transient('ovf_onboarding_credentials_'.ovf_business_id().'_'.get_current_user_id());
 global $wpdb;$t=ovf_tables();if(function_exists('ovf_expire_rewards'))ovf_expire_rewards();$clients=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['clients']} WHERE status='active'");$purchases=(int)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$t['moves']} WHERE type='purchase'");$available=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['rewards']} WHERE status='available'");$redeemed=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['rewards']} WHERE status='redeemed'");$recent=$wpdb->get_results("SELECT m.*,c.name FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id ORDER BY m.id DESC LIMIT 8");ovf_admin_header(__('Resumen','ov-fidelidad'),__('Todo lo importante de tu programa de fidelidad en un solo lugar.','ov-fidelidad'),false);if($business)echo ovf_admin_business_access_card($business,is_array($credentials)?$credentials:[]);if(isset($_GET['onboarding']))ovf_notice(__('Negocio creado. Revisa y comparte los accesos de su encargado.','ov-fidelidad'));if(isset($_GET['credentials']))ovf_notice(__('Se generó una nueva contraseña para el encargado.','ov-fidelidad'));if(function_exists('ovf_privacy_problem')&&($pp=ovf_privacy_problem()))echo '<div class="ovf-notice error">'.esc_html($pp).' <a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-settings#ovf-privacy')).'">'.esc_html__('Configurar aviso de privacidad','ov-fidelidad').' →</a></div>';echo '<div class="ovf-metrics"><div><span>'.esc_html__('Clientes activos','ov-fidelidad').'</span><strong>'.$clients.'</strong></div><div><span>'.esc_html__('Compras registradas','ov-fidelidad').'</span><strong>'.$purchases.'</strong></div><div><span>'.esc_html__('Beneficios disponibles','ov-fidelidad').'</span><strong>'.$available.'</strong></div><div><span>'.esc_html__('Canjes realizados','ov-fidelidad').'</span><strong>'.$redeemed.'</strong></div></div><div class="ovf-admin-grid"><section class="ovf-panel"><div class="ovf-panel-title"><h2>'.esc_html__('Actividad reciente','ov-fidelidad').'</h2><a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-history')).'">'.esc_html__('Ver historial','ov-fidelidad').'</a></div>';if(!$recent)echo '<div class="ovf-empty-mini">'.esc_html__('Aún no hay actividad.','ov-fidelidad').'</div>';else foreach($recent as $m)echo '<div class="ovf-activity"><i>'.($m->type==='purchase'?'+1':($m->type==='registration'?'＋':'✓')).'</i><div><b>'.esc_html($m->name?:__('Cliente eliminado','ov-fidelidad')).'</b><span>'.esc_html($m->type==='purchase'?__('Compra registrada','ov-fidelidad'):($m->type==='registration'?__('Nuevo cliente','ov-fidelidad'):__('Beneficio canjeado','ov-fidelidad'))).' · '.esc_html(ovf_date($m->created_at)).'</span></div></div>';echo '</section><section class="ovf-panel"><h2>'.esc_html__('Accesos rápidos','ov-fidelidad').'</h2><div class="ovf-quick">'
 .'<a target="_blank" href="'.esc_url(ovf_page_url('ovf_page_portal')).'"><i>'.ovf_v02_icon('scan').'</i><span><b>'.esc_html__('Abrir la Web App','ov-fidelidad').'</b><small>'.esc_html__('Atender clientes y registrar compras','ov-fidelidad').'</small></span></a>'
 .'<a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-rewards')).'"><i>'.ovf_v02_icon('gift').'</i><span><b>'.esc_html__('Beneficios','ov-fidelidad').'</b><small>'.esc_html__('Crear y ajustar recompensas','ov-fidelidad').'</small></span></a>'
 .'<a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-staff')).'"><i>'.ovf_v02_icon('users').'</i><span><b>'.esc_html__('Personal','ov-fidelidad').'</b><small>'.esc_html__('Accesos de encargados y empleados','ov-fidelidad').'</small></span></a>'
 .'<a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-settings#ovf-registration-qr')).'"><i>'.ovf_v02_icon('qr').'</i><span><b>'.esc_html__('QR de registro','ov-fidelidad').'</b><small>'.esc_html__('Descargar para el mostrador','ov-fidelidad').'</small></span></a>'
 .'<a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-marketing')).'"><i>✉</i><span><b>'.esc_html__('Banner y envío de promociones','ov-fidelidad').'</b><small>'.esc_html__('Enviar campañas y subir imágenes','ov-fidelidad').'</small></span></a>'
 .'</div><a class="ovf-quick-settings" href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-settings')).'">'.esc_html__('Ajustes: identidad, Web App y reglas del programa','ov-fidelidad').' →</a></section></div>';ovf_admin_end();}

function ovf_admin_clients(){wp_enqueue_script('ovf-admin-search',OVF_URL.'assets/app-v02.js',['ovf-ui'],OVF_VERSION,true);global $wpdb;$t=ovf_tables();
 // Self-heal the schema before any client operation.
 ovf_ensure_clients_schema();
 $action=sanitize_key($_GET['action']??'');$id=absint($_GET['id']??0);
 if($action==='delete'&&$id&&check_admin_referer('ovf_delete_'.$id)){ $wpdb->delete($t['moves'],['client_id'=>$id]);$wpdb->delete($t['rewards'],['client_id'=>$id]);$wpdb->delete($t['clients'],['id'=>$id]);wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-clients&deleted=1'));exit; }
 $save_error='';
 if(isset($_POST['ovf_save_client'])&&check_admin_referer('ovf_save_client')){ $pid=absint($_POST['client_id']??0);$old=$pid?ovf_client($pid):null;$em=empty($_POST['email_marketing'])?0:1;$changed=$old&&((int)($old->email_marketing??0)!==$em);$data=['name'=>sanitize_text_field(wp_unslash($_POST['name']??'')),'email'=>sanitize_email(wp_unslash($_POST['email']??'')),'phone'=>ovf_normalize_phone(wp_unslash($_POST['phone']??'')),'birthday'=>preg_match('/^\d{4}-\d{2}-\d{2}$/',$_POST['birthday']??'')?sanitize_text_field($_POST['birthday']):null,'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),'status'=>in_array($_POST['status']??'active',['active','inactive'],true)?$_POST['status']:'active','email_marketing'=>$em,'email_consent_at'=>$em?($changed?current_time('mysql'):($old->email_consent_at??current_time('mysql'))):null,'updated_at'=>current_time('mysql')];
  if(!$data['name']){$save_error=__('El nombre del cliente es obligatorio.','ov-fidelidad');}
  elseif($pid){$ok=$wpdb->update($t['clients'],$data,['id'=>$pid]);if($ok===false)$save_error=__('No se pudo actualizar el cliente.','ov-fidelidad');else{wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-clients&action=edit&id='.$pid.'&saved=1'));exit;}}
  else{$result=ovf_insert_client($data);if(is_wp_error($result)){$save_error=__('No se pudo crear el cliente. La estructura de datos fue revisada, pero la inserción falló.','ov-fidelidad');if(current_user_can('manage_options')&&$wpdb->last_error)$save_error.=' '.__('Detalle técnico:','ov-fidelidad').' '.$wpdb->last_error;}else{wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-clients&created=1'));exit;}}
 }
 if(in_array($action,['new','edit'],true)){ $c=$id?ovf_client($id):null;ovf_admin_header($c?__('Editar cliente','ov-fidelidad'):__('Nuevo cliente','ov-fidelidad'),$c?__('Actualiza sus datos, consulta su QR y administra su fidelidad.','ov-fidelidad'):__('Crea su tarjeta digital y QR único.','ov-fidelidad'),false);if(isset($_GET['saved']))ovf_notice(__('Cliente guardado correctamente.','ov-fidelidad'));if($save_error)ovf_notice($save_error,'error');echo '<div class="ovf-form-card"><form method="post">';wp_nonce_field('ovf_save_client');echo '<input type="hidden" name="client_id" value="'.($c?(int)$c->id:0).'"><div class="ovf-fields"><label><span>'.esc_html__('Nombre *','ov-fidelidad').'</span><input required name="name" value="'.esc_attr($c->name??'').'"></label><label><span>Email</span><input type="email" name="email" value="'.esc_attr($c->email??'').'"></label><label><span>'.esc_html__('Teléfono','ov-fidelidad').'</span><input name="phone" value="'.esc_attr($c->phone??'').'"></label><label><span>'.esc_html__('Fecha de nacimiento','ov-fidelidad').'</span><input type="date" name="birthday" value="'.esc_attr($c->birthday??'').'"></label><label><span>'.esc_html__('Estado','ov-fidelidad').'</span><select name="status"><option value="active" '.selected($c->status??'active','active',false).'>'.esc_html__('Activo','ov-fidelidad').'</option><option value="inactive" '.selected($c->status??'active','inactive',false).'>'.esc_html__('Inactivo','ov-fidelidad').'</option></select></label><label class="wide"><span>'.esc_html__('Notas internas','ov-fidelidad').'</span><textarea name="notes" rows="4">'.esc_textarea($c->notes??'').'</textarea></label></div>'.ovf_email_consent_field($c->email_marketing??0).'<div class="ovf-form-actions"><button class="ovf-admin-btn" name="ovf_save_client">'.esc_html__('Guardar cliente','ov-fidelidad').'</button><a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-clients')).'">'.esc_html__('Cancelar','ov-fidelidad').'</a></div></form></div>';
  if($c){$card=ovf_card_url($c->token);echo '<div class="ovf-admin-grid"><section class="ovf-panel"><h2>'.esc_html__('Tarjeta y QR','ov-fidelidad').'</h2><div class="ovf-qrbox"><div class="ovf-qr" data-qr="'.esc_attr(ovf_qr_payload($c->token)).'"></div><div><b>'.esc_html($c->name).'</b><span>'.esc_html(sprintf(_n('%d compra registrada','%d compras registradas',(int)$c->visits,'ov-fidelidad'),(int)$c->visits)).'</span><a target="_blank" href="'.esc_url($card).'">'.esc_html__('Ver tarjeta del cliente ↗','ov-fidelidad').'</a>'.(!empty($c->privacy_at)?'<small class="ovf-consent">'.esc_html(sprintf(__('Aceptó el aviso de privacidad: %s','ov-fidelidad'),ovf_date($c->privacy_at))).'</small>':'').'<button type="button" class="button ovf-print-qr">'.esc_html__('Imprimir QR','ov-fidelidad').'</button></div></div></section><section class="ovf-panel"><h2>'.esc_html__('Acciones','ov-fidelidad').'</h2><a class="ovf-action-link" target="_blank" href="'.esc_url(ovf_scan_url($c->token)).'">'.esc_html__('Registrar compra →','ov-fidelidad').'</a><a class="ovf-action-link danger ovf-confirm-delete" href="'.esc_url(wp_nonce_url(admin_url('admin.php?page=ov-fidelidad-clients&action=delete&id='.$c->id),'ovf_delete_'.$c->id)).'">'.esc_html__('Eliminar cliente →','ov-fidelidad').'</a></section></div>';
  // Diagnóstico de beneficios: explica por qué el cliente tiene (o no) cada beneficio.
  ovf_sync_client_rewards($c);$diag=ovf_reward_diagnosis($c);
  echo '<section class="ovf-panel ovf-diagnosis"><div class="ovf-panel-title"><h2>'.esc_html__('Diagnóstico de beneficios','ov-fidelidad').'</h2><a class="button" href="'.esc_url(wp_nonce_url(add_query_arg('ovf_repair','1'),'ovf_repair')).'">'.esc_html__('Revisar y reparar','ov-fidelidad').'</a></div><p class="ovf-help">'.esc_html(sprintf(__('Compras registradas: %1$d · Compras vigentes: %2$d','ov-fidelidad'),(int)$c->visits,ovf_active_purchases($c->id))).'</p>';
  if(!$diag)echo '<div class="ovf-empty-mini">'.esc_html__('No hay beneficios configurados.','ov-fidelidad').'</div>';
  foreach($diag as $d)echo '<div class="ovf-diag-row"><div><b>'.esc_html($d['rule']->title).'</b><span>'.esc_html(ovf_rule_label($d['rule'])).'</span></div><em>'.esc_html(sprintf(_n('%d otorgado','%d otorgados',$d['got'],'ov-fidelidad'),$d['got'])).'</em><p>'.esc_html($d['why']).'</p></div>';
  echo '</section>';}
  ovf_admin_end();return; }
 $q=sanitize_text_field($_GET['s']??'');$where="WHERE 1=1";$args=[];if($q){$like='%'.$wpdb->esc_like($q).'%';$where.=" AND (name LIKE %s OR email LIKE %s OR phone LIKE %s)";$args=[$like,$like,$like];}$sql="SELECT * FROM {$t['clients']} $where ORDER BY id DESC LIMIT 300";$rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);ovf_admin_header(__('Clientes','ov-fidelidad'),__('Administra tarjetas, QR, datos y actividad de tus clientes.','ov-fidelidad'));if(isset($_GET['created']))ovf_notice(__('Cliente creado correctamente.','ov-fidelidad'));if(isset($_GET['deleted']))ovf_notice(__('Cliente eliminado junto con su historial.','ov-fidelidad'));if($save_error)ovf_notice($save_error,'error');echo '<div class="ovf-toolbar"><form data-ovf-live-search="admin"><input type="hidden" name="page" value="ov-fidelidad-clients"><input type="search" name="s" value="'.esc_attr($q).'" placeholder="Buscar por nombre, email o teléfono" autocomplete="off"><div class="ovf-search-suggestions" data-ovf-search-results hidden></div><button class="button">'.esc_html__('Buscar','ov-fidelidad').'</button></form><span>'.esc_html(sprintf(_n('%d resultado','%d resultados',count($rows),'ov-fidelidad'),count($rows))).'</span></div><div class="ovf-table-wrap"><table class="ovf-table"><thead><tr><th>'.esc_html__('Cliente','ov-fidelidad').'</th><th>'.esc_html__('Estado','ov-fidelidad').'</th><th>'.esc_html__('Compras','ov-fidelidad').'</th><th>'.esc_html__('Alta','ov-fidelidad').'</th><th></th></tr></thead><tbody>';if(!$rows)echo '<tr><td colspan="5"><div class="ovf-empty-mini">'.esc_html__('No encontramos clientes.','ov-fidelidad').'</div></td></tr>';foreach($rows as $r){echo '<tr><td><div class="ovf-person-admin"><i>'.esc_html(ovf_initial($r->name)).'</i><div><b>'.esc_html($r->name).'</b><span>'.esc_html($r->email?:$r->phone?:__('Sin datos de contacto','ov-fidelidad')).'</span></div></div></td><td><span class="ovf-status '.esc_attr($r->status).'">'.($r->status==='active'?__('Activo','ov-fidelidad'):__('Inactivo','ov-fidelidad')).'</span></td><td><strong>'.(int)$r->visits.'</strong></td><td>'.esc_html(date_i18n(get_option('date_format'),strtotime($r->created_at))).'</td><td class="actions"><a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-clients&action=edit&id='.$r->id)).'">'.esc_html__('Administrar','ov-fidelidad').'</a><a target="_blank" href="'.esc_url(ovf_card_url($r->token)).'">'.esc_html__('Tarjeta ↗','ov-fidelidad').'</a></td></tr>'; } echo '</tbody></table></div>';ovf_admin_end();}

function ovf_admin_rewards(){global $wpdb;$t=ovf_tables();ovf_ensure_rules_schema();$synced=null;
 if(isset($_POST['ovf_add_rule'])&&check_admin_referer('ovf_rules')){
  $m=max(1,absint($_POST['milestone']??0));$title=sanitize_text_field(wp_unslash($_POST['title']??''));$repeats=($_POST['repeats']??'0')==='1'?1:0;
  if($title){$ok=$wpdb->insert($t['rules'],['milestone'=>$m,'title'=>$title,'description'=>sanitize_textarea_field(wp_unslash($_POST['description']??'')),'enabled'=>1,'repeats'=>$repeats,'expires_days'=>min(3650,absint($_POST['expires_days']??0)),'sort_order'=>$m,'created_at'=>current_time('mysql')]);
   if($ok){ovf_notice(__('Beneficio agregado correctamente.','ov-fidelidad'));$synced=ovf_sync_all_rewards();}else{ovf_notice(__('No se pudo guardar el beneficio. Actualiza la página e inténtalo nuevamente.','ov-fidelidad'),'error');}}
 }
 if(isset($_POST['ovf_save_rules'])&&check_admin_referer('ovf_rules')){
  foreach((array)($_POST['rules']??[]) as $rid=>$r)$wpdb->update($t['rules'],['milestone'=>max(1,absint($r['milestone']??1)),'title'=>sanitize_text_field(wp_unslash($r['title']??'')),'description'=>sanitize_textarea_field(wp_unslash($r['description']??'')),'enabled'=>empty($r['enabled'])?0:1,'repeats'=>($r['repeats']??'0')==='1'?1:0,'expires_days'=>min(3650,absint($r['expires_days']??0))],['id'=>absint($rid)]);
  ovf_notice(__('Beneficios actualizados.','ov-fidelidad'));$synced=ovf_sync_all_rewards();
 }
 if(isset($_GET['delete_rule'])){$rid=absint($_GET['delete_rule']);if(check_admin_referer('ovf_rule_delete_'.$rid))$wpdb->delete($t['rules'],['id'=>$rid]);}
 if($synced)ovf_notice(sprintf(_n('Se asignó %d beneficio a clientes que ya cumplían el requisito.','Se asignaron %d beneficios a clientes que ya cumplían el requisito.',$synced,'ov-fidelidad'),$synced));
 $rules=ovf_all_rules();
 ovf_admin_header(__('Beneficios','ov-fidelidad'),__('Define las recompensas que tus clientes desbloquearán al acumular compras.','ov-fidelidad'),false);
 $mode_select=function($name,$repeats){return '<select class="ovf-repeat-select" name="'.esc_attr($name).'"><option value="0" '.selected($repeats,0,false).'>'.esc_html__('Una sola vez','ov-fidelidad').'</option><option value="1" '.selected($repeats,1,false).'>'.esc_html__('Se repite (cíclico)','ov-fidelidad').'</option></select>';};
 echo '<div class="ovf-admin-grid rewards"><section class="ovf-panel ovf-rewards-list"><div class="ovf-panel-heading"><div><h2>'.esc_html__('Niveles configurados','ov-fidelidad').'</h2><p>'.esc_html__('Los cambios se aplican también a los clientes que ya tienen compras.','ov-fidelidad').' '.(ovf_purchase_window_days()?sprintf(esc_html__('Solo cuentan las compras de los últimos %d días.','ov-fidelidad'),ovf_purchase_window_days()):esc_html__('Las compras no caducan.','ov-fidelidad')).' <a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-settings#ovf-program-rules')).'">'.esc_html__('Cambiar','ov-fidelidad').'</a></p></div><span class="ovf-count-pill">'.sprintf(esc_html(_n('%d nivel','%d niveles',count($rules),'ov-fidelidad')),count($rules)).'</span></div><form method="post" class="ovf-rules-form">';wp_nonce_field('ovf_rules');
 if(!$rules)echo '<div class="ovf-empty-mini">'.esc_html__('Aún no has configurado beneficios. Crea el primero desde el formulario de la derecha.','ov-fidelidad').'</div>';
 foreach($rules as $r){$rep=ovf_rule_repeats($r)?1:0;
  echo '<article class="ovf-rule-card'.($rep?' is-cyclic':'').'"><div class="ovf-rule-milestone"><span class="ovf-rule-kicker" data-once="'.esc_attr__('AL LLEGAR A','ov-fidelidad').'" data-cyclic="'.esc_attr__('CADA','ov-fidelidad').'">'.($rep?esc_html__('CADA','ov-fidelidad'):esc_html__('AL LLEGAR A','ov-fidelidad')).'</span><div><input aria-label="'.esc_attr__('Número de compras','ov-fidelidad').'" type="number" min="1" name="rules['.$r->id.'][milestone]" value="'.(int)$r->milestone.'"><small>'.esc_html__('compras','ov-fidelidad').'</small></div>'.($rep?'<em class="ovf-cycle-badge">↻ '.esc_html__('Cíclico','ov-fidelidad').'</em>':'').'</div>';
  echo '<div class="ovf-rule-fields"><label><span>'.esc_html__('Nombre del beneficio','ov-fidelidad').'</span><input name="rules['.$r->id.'][title]" value="'.esc_attr($r->title).'" required></label><label><span>'.esc_html__('Descripción','ov-fidelidad').'</span><textarea name="rules['.$r->id.'][description]" rows="2">'.esc_textarea($r->description).'</textarea></label><div class="ovf-rule-row"><label><span>'.esc_html__('Frecuencia','ov-fidelidad').'</span>'.$mode_select('rules['.$r->id.'][repeats]',$rep).'</label><label><span>'.esc_html__('Días para canjear','ov-fidelidad').'</span><input type="number" min="0" max="3650" name="rules['.$r->id.'][expires_days]" value="'.(int)ovf_rule_expires_days($r).'"><small>'.esc_html__('0 = sin vencimiento','ov-fidelidad').'</small></label></div>';
  echo '<div class="ovf-rule-footer"><label class="ovf-switch"><input type="checkbox" name="rules['.$r->id.'][enabled]" value="1" '.checked($r->enabled,1,false).'><span class="ovf-switch-ui"></span><b>'.esc_html__('Activo','ov-fidelidad').'</b></label><a class="ovf-trash ovf-confirm-delete" href="'.esc_url(wp_nonce_url(admin_url('admin.php?page=ov-fidelidad-rewards&delete_rule='.$r->id),'ovf_rule_delete_'.$r->id)).'">'.esc_html__('Eliminar','ov-fidelidad').'</a></div></div></article>';}
 if($rules)echo '<div class="ovf-rules-save"><button class="ovf-admin-btn ovf-save-dirty" name="ovf_save_rules" disabled>'.esc_html__('Guardar cambios','ov-fidelidad').'</button><small class="ovf-save-hint">'.esc_html__('No hay cambios pendientes.','ov-fidelidad').'</small></div>';
 echo '</form></section><section class="ovf-panel ovf-new-reward"><span class="ovf-eyebrow">'.esc_html__('NUEVA RECOMPENSA','ov-fidelidad').'</span><h2>'.esc_html__('Agregar beneficio','ov-fidelidad').'</h2><p class="ovf-panel-intro">'.esc_html__('Define cuándo se desbloquea y qué recibirá el cliente.','ov-fidelidad').'</p><form method="post" class="ovf-stack ovf-new-rule">';wp_nonce_field('ovf_rules');
 echo '<label><span>'.esc_html__('Nombre del beneficio','ov-fidelidad').'</span><input name="title" placeholder="'.esc_attr__('Ej. Café americano gratis','ov-fidelidad').'" required></label>';
 echo '<label><span>'.esc_html__('Número de compras','ov-fidelidad').'</span><input type="number" min="1" name="milestone" value="5" required></label>';
 echo '<fieldset class="ovf-choice"><legend>'.esc_html__('¿Cada cuánto se gana?','ov-fidelidad').'</legend><label><input type="radio" name="repeats" value="0" checked><span><b>'.esc_html__('Una sola vez','ov-fidelidad').'</b><small>'.esc_html__('Se gana una vez al llegar al número de compras. Ideal para premios grandes.','ov-fidelidad').'</small></span></label><label><input type="radio" name="repeats" value="1"><span><b>'.esc_html__('Se repite (cíclico)','ov-fidelidad').'</b><small>'.esc_html__('Se vuelve a ganar cada vez que se completa el número de compras.','ov-fidelidad').'</small></span></label></fieldset>';
 echo '<p class="ovf-rule-preview" data-once="'.esc_attr__('El cliente lo gana una vez, en la compra %d.','ov-fidelidad').'" data-cyclic="'.esc_attr__('El cliente lo gana en las compras %1$d, %2$d, %3$d…','ov-fidelidad').'"></p>';
 echo '<label><span>'.esc_html__('Días para canjear','ov-fidelidad').'</span><input type="number" min="0" max="3650" name="expires_days" value="0"><small class="ovf-field-help">'.esc_html__('Tiempo que tiene el cliente para usarlo una vez que lo gana. 0 = sin vencimiento.','ov-fidelidad').'</small></label>';
 echo '<label><span>'.esc_html__('Descripción','ov-fidelidad').'</span><textarea name="description" rows="3" placeholder="'.esc_attr__('Explica qué recibe el cliente y cómo puede utilizarlo.','ov-fidelidad').'"></textarea></label><button class="ovf-admin-btn" name="ovf_add_rule">+ '.esc_html__('Agregar beneficio','ov-fidelidad').'</button></form>';
 echo '<div class="ovf-tip"><b>'.esc_html__('Ejemplo','ov-fidelidad').'</b><p>'.esc_html__('“Café gratis cada 5 compras” (cíclico) + “15% de descuento al llegar a 20 compras” (una sola vez).','ov-fidelidad').'</p></div></section></div>';
 ovf_admin_end();}

function ovf_recalculate_client($client_id){global $wpdb;$t=ovf_tables();$client_id=absint($client_id);if(!$client_id)return;$visits=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t['moves']} WHERE client_id=%d AND type='purchase'",$client_id));$wpdb->update($t['clients'],['visits'=>max(0,$visits),'updated_at'=>current_time('mysql')],['id'=>$client_id]);// Conserva los beneficios ya canjeados; solo retira los disponibles cuya compra se eliminó.
ovf_rewards_after_moves_deleted($client_id);}
/** Filtros del historial (escritorio): devuelve [WHERE sql, args, valores limpios]. */
function ovf_history_filters(){
 global $wpdb;
 $f=[
  'q'=>sanitize_text_field(wp_unslash($_GET['q']??'')),
  'staff'=>sanitize_text_field(wp_unslash($_GET['staff']??'')),
  'type'=>sanitize_key($_GET['type']??''),
  'method'=>sanitize_key($_GET['method']??''),
  'from'=>preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['from']??'')?$_GET['from']:'',
  'to'=>preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['to']??'')?$_GET['to']:'',
  'client'=>absint($_GET['client']??0),
 ];
 $w=['1=1'];$a=[];
 if($f['q']!==''){$like='%'.$wpdb->esc_like($f['q']).'%';$digits=preg_replace('/\D+/','',$f['q']);$w[]='(c.name LIKE %s OR c.phone LIKE %s OR c.email LIKE %s OR m.note LIKE %s OR m.receipt_number LIKE %s'.($digits!==''?' OR c.phone LIKE %s':'').')';array_push($a,$like,$like,$like,$like,$like);if($digits!=='')$a[]='%'.$wpdb->esc_like($digits).'%';}
 if($f['client']){$w[]='m.client_id=%d';$a[]=$f['client'];}
 if($f['staff']==='none'){$w[]='(m.user_id=0 OR m.user_id IS NULL)';}
 elseif($f['staff']!==''){$w[]='m.user_id=%d';$a[]=absint($f['staff']);}
 if(in_array($f['type'],['purchase','redeem','registration','scan'],true)){$w[]='m.type=%s';$a[]=$f['type'];}
 if(in_array($f['method'],['qr','search','manual','self','staff'],true)){$w[]='m.method=%s';$a[]=$f['method'];}
 if($f['from']){$w[]='m.created_at>=%s';$a[]=$f['from'].' 00:00:00';}
 if($f['to']){$w[]='m.created_at<=%s';$a[]=$f['to'].' 23:59:59';}
 return [implode(' AND ',$w),$a,$f];
}
function ovf_history_labels($r){
 $type=$r->type==='purchase'?__('+1 compra','ov-fidelidad'):($r->type==='redeem'?__('Beneficio canjeado','ov-fidelidad'):($r->type==='registration'?__('Alta de cliente','ov-fidelidad'):($r->type==='scan'?__('Escaneo QR','ov-fidelidad'):__('Ajuste','ov-fidelidad'))));
 $method=$r->method==='qr'?__('QR escaneado','ov-fidelidad'):($r->method==='search'?__('Búsqueda manual','ov-fidelidad'):($r->method==='self'?__('Autorregistro','ov-fidelidad'):__('Manual','ov-fidelidad')));
 return [$type,$method];
}
// Exportar a CSV lo que muestran los filtros (antes de imprimir la página).
add_action('admin_init',function(){
 if(($_GET['page']??'')!=='ov-fidelidad-history'||empty($_GET['ovf_export'])||!current_user_can('manage_options'))return;
 check_admin_referer('ovf_history_export');
 global $wpdb;$t=ovf_tables();[$where,$args]=ovf_history_filters();
 ovf_ensure_moves_schema();$sql="SELECT m.*,c.name,c.phone,c.email,u.display_name staff FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE $where ORDER BY m.id DESC LIMIT 20000";
 $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
 nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=historial-fidelidad-'.wp_date('Y-m-d').'.csv');
 $out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF"); // BOM para que Excel respete acentos
 fputcsv($out,[__('Fecha y hora','ov-fidelidad'),__('Cliente','ov-fidelidad'),__('Teléfono','ov-fidelidad'),'Email',__('Acción','ov-fidelidad'),__('Número de ticket','ov-fidelidad'),__('Realizado por','ov-fidelidad'),__('Identificación','ov-fidelidad'),__('Nota','ov-fidelidad')]);
 foreach($rows as $r){[$type,$method]=ovf_history_labels($r);fputcsv($out,[$r->created_at,$r->name?:__('Cliente eliminado','ov-fidelidad'),$r->phone,$r->email,$type,$r->receipt_number,$r->staff?:'—',$method,$r->note]);}
 fclose($out);exit;
});
function ovf_admin_history(){global $wpdb;$t=ovf_tables();ovf_ensure_moves_schema();
 if(isset($_POST['ovf_history_delete'])&&check_admin_referer('ovf_history_delete')){$ids=array_values(array_filter(array_map('absint',(array)($_POST['move_ids']??[]))));if($ids){$clients=[];foreach($ids as $mid){$cid=(int)$wpdb->get_var($wpdb->prepare("SELECT client_id FROM {$t['moves']} WHERE id=%d",$mid));if($cid)$clients[$cid]=1;$wpdb->delete($t['moves'],['id'=>$mid]);}foreach(array_keys($clients) as $cid)ovf_recalculate_client($cid);}}
 [$where,$args,$f]=ovf_history_filters();
 $per=50;$paged=max(1,absint($_GET['paged']??1));
 $from="FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE $where";
 $total=(int)($args?$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) $from",$args)):$wpdb->get_var("SELECT COUNT(*) $from"));
 $pages=max(1,(int)ceil($total/$per));$paged=min($paged,$pages);
 $sql="SELECT m.*,c.name,c.phone,u.display_name staff $from ORDER BY m.id DESC LIMIT %d OFFSET %d";
 $rows=$wpdb->get_results($wpdb->prepare($sql,array_merge($args,[$per,($paged-1)*$per])));
 // Personas que han registrado movimientos (incluye cuentas eliminadas del equipo, sin nombre)
 $staff=$wpdb->get_results("SELECT DISTINCT m.user_id, u.display_name FROM {$t['moves']} m LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.user_id>0 ORDER BY u.display_name");
 $active=array_filter($f,function($v){return $v!==''&&$v!==0;});
 $base=admin_url('admin.php?page=ov-fidelidad-history');
 $url=function($extra=[])use($f,$base){return add_query_arg(array_merge(array_filter($f,function($v){return $v!==''&&$v!==0;}),$extra),$base);};

 ovf_admin_header(__('Historial','ov-fidelidad'),__('Auditoría de cada operación: quién la realizó, qué tarjeta fue atendida, cuándo y cómo se identificó al cliente.','ov-fidelidad'),false);
 if(isset($_POST['ovf_history_delete']))ovf_notice(__('Registros eliminados y estado de los clientes recalculado.','ov-fidelidad'));

 // ---- Filtros ----
 echo '<form method="get" class="ovf-panel ovf-history-filters" data-ovf-live-search="history"><input type="hidden" name="page" value="ov-fidelidad-history">';
 if($f['client'])echo '<input type="hidden" name="client" value="'.(int)$f['client'].'">';
 echo '<div class="ovf-hf-search"><label for="ovf-history-q"><span>'.esc_html__('Cliente o nota','ov-fidelidad').'</span></label><input id="ovf-history-q" type="search" name="q" value="'.esc_attr($f['q']).'" placeholder="'.esc_attr__('Nombre, teléfono, email o texto de la nota','ov-fidelidad').'" autocomplete="off"><div class="ovf-search-suggestions" data-ovf-search-results hidden></div></div>';
 wp_enqueue_script('ovf-admin-search',OVF_URL.'assets/app-v02.js',['ovf-ui'],OVF_VERSION,true);
 echo '<label><span>'.esc_html__('Realizado por','ov-fidelidad').'</span><select name="staff"><option value="">'.esc_html__('Todo el equipo','ov-fidelidad').'</option>';
 foreach($staff as $s)echo '<option value="'.(int)$s->user_id.'" '.selected($f['staff'],(string)$s->user_id,false).'>'.esc_html($s->display_name?:sprintf(__('Usuario eliminado (#%d)','ov-fidelidad'),$s->user_id)).'</option>';
 echo '<option value="none" '.selected($f['staff'],'none',false).'>'.esc_html__('Sin usuario (autorregistro)','ov-fidelidad').'</option></select></label>';
 echo '<label><span>'.esc_html__('Acción','ov-fidelidad').'</span><select name="type"><option value="">'.esc_html__('Todas','ov-fidelidad').'</option>';
 foreach(['purchase'=>__('Compras','ov-fidelidad'),'redeem'=>__('Canjes','ov-fidelidad'),'registration'=>__('Altas de clientes','ov-fidelidad'),'scan'=>__('Escaneos QR','ov-fidelidad')] as $k=>$l)echo '<option value="'.esc_attr($k).'" '.selected($f['type'],$k,false).'>'.esc_html($l).'</option>';
 echo '</select></label><label><span>'.esc_html__('Identificación','ov-fidelidad').'</span><select name="method"><option value="">'.esc_html__('Todas','ov-fidelidad').'</option>';
 foreach(['qr'=>__('QR escaneado','ov-fidelidad'),'search'=>__('Búsqueda manual','ov-fidelidad'),'manual'=>__('Manual','ov-fidelidad'),'self'=>__('Autorregistro','ov-fidelidad')] as $k=>$l)echo '<option value="'.esc_attr($k).'" '.selected($f['method'],$k,false).'>'.esc_html($l).'</option>';
 echo '</select></label><label><span>'.esc_html__('Desde','ov-fidelidad').'</span><input type="date" name="from" value="'.esc_attr($f['from']).'"></label><label><span>'.esc_html__('Hasta','ov-fidelidad').'</span><input type="date" name="to" value="'.esc_attr($f['to']).'"></label>';
 echo '<div class="ovf-hf-actions"><button class="ovf-admin-btn">'.esc_html__('Filtrar','ov-fidelidad').'</button>'.($active?'<a class="button" href="'.esc_url($base).'">'.esc_html__('Limpiar filtros','ov-fidelidad').'</a>':'').'</div>';
 // atajos de fecha
 $today=current_time('Y-m-d');$d7=wp_date('Y-m-d',current_time('timestamp',true)-6*DAY_IN_SECONDS);$m1=current_time('Y-m-01');
 echo '<div class="ovf-hf-quick"><span>'.esc_html__('Rápido:','ov-fidelidad').'</span><a href="'.esc_url($url(['from'=>$today,'to'=>$today,'paged'=>false])).'">'.esc_html__('Hoy','ov-fidelidad').'</a><a href="'.esc_url($url(['from'=>$d7,'to'=>$today,'paged'=>false])).'">'.esc_html__('Últimos 7 días','ov-fidelidad').'</a><a href="'.esc_url($url(['from'=>$m1,'to'=>$today,'paged'=>false])).'">'.esc_html__('Este mes','ov-fidelidad').'</a></div>';
 echo '</form>';

 // ---- Resumen del resultado + exportar ----
 $client_name=$f['client']?$wpdb->get_var($wpdb->prepare("SELECT name FROM {$t['clients']} WHERE id=%d",$f['client'])):'';
 echo '<div class="ovf-history-bar"><p>'.esc_html(sprintf(_n('%s movimiento','%s movimientos',$total,'ov-fidelidad'),number_format_i18n($total)));
 if($client_name)echo ' · '.esc_html(sprintf(__('Cliente: %s','ov-fidelidad'),$client_name)).' <a href="'.esc_url(remove_query_arg(['client','paged'],$url())).'">'.esc_html__('quitar','ov-fidelidad').'</a>';
 echo '</p>'.($total?'<a class="button" href="'.esc_url(wp_nonce_url($url(['ovf_export'=>1,'paged'=>false]),'ovf_history_export')).'">'.esc_html__('Exportar CSV','ov-fidelidad').'</a>':'').'</div>';

 echo '<form method="post">';wp_nonce_field('ovf_history_delete');
 echo '<div class="ovf-table-wrap"><table class="ovf-table"><thead><tr><th><input type="checkbox" class="ovf-check-all" aria-label="'.esc_attr__('Seleccionar todo','ov-fidelidad').'"></th><th>'.esc_html__('Fecha y hora','ov-fidelidad').'</th><th>'.esc_html__('Cliente / tarjeta','ov-fidelidad').'</th><th>'.esc_html__('Acción','ov-fidelidad').'</th><th>'.esc_html__('Número de ticket','ov-fidelidad').'</th><th>'.esc_html__('Realizado por','ov-fidelidad').'</th><th>'.esc_html__('Identificación','ov-fidelidad').'</th><th>'.esc_html__('Nota','ov-fidelidad').'</th></tr></thead><tbody>';
 foreach($rows as $r){[$type,$method]=ovf_history_labels($r);
  $client_link=$r->name?'<a class="ovf-hf-link" href="'.esc_url(add_query_arg(['page'=>'ov-fidelidad-history','client'=>(int)$r->client_id],admin_url('admin.php'))).'" title="'.esc_attr__('Ver solo este cliente','ov-fidelidad').'">'.esc_html($r->name).'</a>':esc_html__('Cliente eliminado','ov-fidelidad');
  $staff_cell=$r->user_id?'<a class="ovf-hf-link" href="'.esc_url($url(['staff'=>(int)$r->user_id,'paged'=>false])).'" title="'.esc_attr__('Ver solo esta persona','ov-fidelidad').'">'.esc_html($r->staff?:sprintf(__('Usuario eliminado (#%d)','ov-fidelidad'),$r->user_id)).'</a>':'—';
  echo '<tr><td><input class="ovf-move-check" type="checkbox" name="move_ids[]" value="'.(int)$r->id.'"></td><td>'.esc_html(ovf_date($r->created_at)).'</td><td><b>'.$client_link.'</b><small style="display:block">'.esc_html($r->phone?:'ID '.(int)$r->client_id).'</small></td><td><span class="ovf-move '.esc_attr($r->type).'">'.esc_html($type).'</span></td><td>'.esc_html($r->receipt_number?:'—').'</td><td>'.$staff_cell.'</td><td>'.esc_html($method).'</td><td>'.esc_html($r->note?:'—').'</td></tr>';}
 if(!$rows)echo '<tr><td colspan="8"><div class="ovf-empty-mini">'.esc_html($active?__('No hay movimientos con estos filtros.','ov-fidelidad'):__('Aún no hay movimientos.','ov-fidelidad')).'</div></td></tr>';
 echo '</tbody></table></div>';
 // ---- Paginación ----
 if($pages>1){echo '<div class="ovf-pager">';
  if($paged>1)echo '<a class="button" href="'.esc_url($url(['paged'=>$paged-1])).'">← '.esc_html__('Anteriores','ov-fidelidad').'</a>';
  echo '<span>'.esc_html(sprintf(__('Página %1$d de %2$d','ov-fidelidad'),$paged,$pages)).'</span>';
  if($paged<$pages)echo '<a class="button" href="'.esc_url($url(['paged'=>$paged+1])).'">'.esc_html__('Siguientes','ov-fidelidad').' →</a>';
  echo '</div>';}
 echo '<div class="ovf-form-actions"><button class="ovf-danger-btn" name="ovf_history_delete" value="1" onclick="return confirm('.esc_attr(wp_json_encode(__('¿Eliminar los registros seleccionados? Las compras y beneficios de esos clientes se recalcularán.','ov-fidelidad'))).')">'.esc_html__('Eliminar seleccionados','ov-fidelidad').'</button><small class="ovf-help">'.esc_html__('El personal no puede borrar movimientos. Úsalo solo para registros de prueba o errores.','ov-fidelidad').'</small></div></form>';
 echo '<script>document.addEventListener("change",function(e){if(e.target.classList.contains("ovf-check-all"))document.querySelectorAll(".ovf-move-check").forEach(function(c){c.checked=e.target.checked;});});</script>';
 ovf_admin_end();}



function ovf_front_wrap($content){return '<div class="ovf-app" style="--ovf-primary:'.esc_attr(ovf_get_option('ovf_primary','#315b46')).';--ovf-accent:'.esc_attr(ovf_get_option('ovf_accent','#0f172a')).';--ovf-bg:'.esc_attr(ovf_get_option('ovf_background','#f6f6f1')).'">'.$content.'</div>';}
add_shortcode('ov_fidelidad_cliente','ovf_sc_card');
function ovf_sc_card(){ovf_assets();global $wpdb;$t=ovf_tables();$token=sanitize_text_field($_GET['ovf']??'');$c=$token?ovf_client_by_token($token):null;if(!$c)return ovf_front_wrap('<div class="ovf-public-card ovf-centered"><div class="ovf-logo-mark">OV</div><h1>'.esc_html__('Tarjeta de fidelidad','ov-fidelidad').'</h1><p>'.esc_html__('Abre tu enlace personal o escanea el QR que te compartió el negocio.','ov-fidelidad').'</p></div>');ovf_sync_client_rewards($c);$rewards=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE client_id=%d ORDER BY (status='available') DESC, id DESC",$c->id));$moves=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['moves']} WHERE client_id=%d ORDER BY id DESC LIMIT 8",$c->id));$next=ovf_next_reward((int)$c->visits,(int)$c->id);$ref_stats=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total,SUM(CASE WHEN referral_rewarded=0 THEN 1 ELSE 0 END) pending FROM {$t['clients']} WHERE referred_by=%d AND status='active'",$c->id));$ref_points=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(points_delta),0) FROM {$t['moves']} WHERE client_id=%d AND type='referral_bonus'",$c->id));$ref_stamps=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t['moves']} WHERE client_id=%d AND type='referral_bonus'",$c->id));$welcome_discount=ovf_referral_discount_percent($c);ob_start();?><div class="ovf-public-card"><header class="ovf-public-head"><div class="ovf-brandmark"><div class="ovf-brand-logo"><?php echo ovf_v02_logo_html('ovf-brand-logo-img');?></div><span><?php echo ovf_brand();?><small><?php esc_html_e('Programa de fidelidad','ov-fidelidad');?></small></span></div><span class="ovf-card-state"><?php esc_html_e('Tarjeta activa','ov-fidelidad');?></span></header><?php echo ovf_promo_slider_html();?><?php if(isset($_GET['bienvenida'])):?><div class="ovf-flash">✓ <?php esc_html_e('Tu tarjeta está lista. Guarda esta página o descarga tu QR para mostrarlo en cada visita.','ov-fidelidad');?></div><?php endif;?><?php if(isset($_GET['invitacion'])):?><div class="ovf-flash">✓ <?php esc_html_e('Tu código de invitación quedó aplicado. La persona que te invitó recibirá el bono cuando completes tu primera compra.','ov-fidelidad');?></div><?php endif;?><?php if($welcome_discount>0):?><div class="ovf-referral-offer"><b><?php printf(esc_html__('Tienes un descuento de bienvenida del %s%%.','ov-fidelidad'),number_format_i18n($welcome_discount,1));?></b><span><?php esc_html_e('Pide al personal que lo aplique en caja en tu primera compra. Se registrará al confirmar la venta.','ov-fidelidad');?></span></div><?php endif;?><?php if(is_user_logged_in()&&ovf_v02_staff_cap()):?><a class="ovf-staff-serve" href="<?php echo esc_url(add_query_arg('source','qr',ovf_scan_url($c->token)));?>"><?php esc_html_e('Eres parte del equipo · Registrar compra o canjear','ov-fidelidad');?> →</a><?php endif;?><div class="ovf-hello"><span><?php esc_html_e('Tu tarjeta','ov-fidelidad');?></span><h1><?php echo esc_html($c->name);?></h1><p><?php esc_html_e('Cada compra suma. Aquí puedes consultar tu progreso y beneficios.','ov-fidelidad');?></p></div><?php $ovf_stamp_goal=$next?max(1,(int)$next['target']-(int)$next['from']):10;$ovf_stamp_goal=min(30,$ovf_stamp_goal);$ovf_stamp_done=$next?max(0,min($ovf_stamp_goal,(int)$c->visits-(int)$next['from'])):min($ovf_stamp_goal,(int)$c->visits);?>
<section class="ovf-total ovf-stamp-card" aria-label="<?php esc_attr_e('Tarjeta de compras','ov-fidelidad');?>"><div class="ovf-total-count"><strong><?php echo (int)$c->visits;?></strong><span><?php echo (int)$c->visits===1?wp_kses(__('compra<br>registrada','ov-fidelidad'),['br'=>[]]):wp_kses(__('compras<br>registradas','ov-fidelidad'),['br'=>[]]);?></span></div><div class="ovf-stamp-track" role="img" aria-label="<?php echo esc_attr(sprintf(__('Llevas %1$d de %2$d sellos','ov-fidelidad'),$ovf_stamp_done,$ovf_stamp_goal));?>"><?php for($ovf_stamp_i=0;$ovf_stamp_i<$ovf_stamp_goal;$ovf_stamp_i++):?><span class="ovf-stamp <?php echo $ovf_stamp_i<$ovf_stamp_done?'is-stamped':'';?>" aria-hidden="true">★</span><?php endfor;?></div><p class="ovf-stamp-note"><?php if($next):?><?php echo esc_html(sprintf(_n('Te falta %1$d compra para desbloquear %2$s','Te faltan %1$d compras para desbloquear %2$s',(int)$next['left'],'ov-fidelidad'),(int)$next['left'],$next['rule']->title));?><?php else:esc_html_e('Cada compra queda registrada en tu tarjeta.','ov-fidelidad');?><?php endif;?><?php if($next&&ovf_purchase_window_days()):?><br><small><?php printf(esc_html__('Cuentan tus compras de los últimos %d días.','ov-fidelidad'),ovf_purchase_window_days());?></small><?php endif;?></p></section><div class="ovf-loyalty-wallet"><?php if(ovf_program_feature_enabled('points')):?><span><small><?php esc_html_e('Puntos','ov-fidelidad');?></small><b><?php echo number_format_i18n(ovf_client_points($c->id));?></b></span><?php endif;?><?php if(ovf_program_feature_enabled('cashback')):?><span><small><?php esc_html_e('Saldo cashback','ov-fidelidad');?></small><b>$<?php echo number_format_i18n(ovf_client_balance($c->id),2);?> <em>MXN</em></b></span><?php endif;?><span><small><?php esc_html_e('Nivel','ov-fidelidad');?></small><b><?php echo esc_html(ovf_client_vip_level($c->id));?></b></span></div><?php if(!empty($ovf_av_pre=array_filter($rewards,function($x){return $x->status==='available';}))):?><div class="ovf-reward-ready"><i>★</i><div><b><?php echo esc_html(count($ovf_av_pre)===1?sprintf(__('Beneficio disponible: %s','ov-fidelidad'),reset($ovf_av_pre)->title):sprintf(__('%d beneficios disponibles','ov-fidelidad'),count($ovf_av_pre)));?></b><span><?php esc_html_e('Muestra tu QR en el mostrador y pide que te lo canjeen.','ov-fidelidad');?><?php $ovf_exp=array_filter(array_map(function($x){return $x->expires_at;},$ovf_av_pre));if($ovf_exp){sort($ovf_exp);echo ' '.esc_html(sprintf(__('Vence el %s.','ov-fidelidad'),date_i18n(get_option('date_format'),strtotime($ovf_exp[0]))));}?></span></div></div><?php endif;?><section class="ovf-customer-qr"><div class="ovf-customer-qr-copy"><span><?php esc_html_e('Mi código QR','ov-fidelidad');?></span><h2><?php esc_html_e('Muéstralo en cada visita','ov-fidelidad');?></h2><p><?php echo esc_html(sprintf(__('El personal de %s lo escaneará para identificar tu tarjeta y registrar tu compra.','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))));?></p></div><div class="ovf-qr ovf-public-qr" data-qr="<?php echo esc_attr(ovf_qr_payload($c->token));?>" data-size="208"></div><div class="ovf-qr-actions"><button type="button" class="ovf-qr-action ovf-download-qr" data-filename="qr-<?php echo esc_attr(sanitize_title($c->name));?>.png"><?php esc_html_e('Descargar QR','ov-fidelidad');?></button><button type="button" class="ovf-qr-action ovf-download-card-image" data-card-url="<?php echo esc_attr(ovf_card_url($c->token));?>" data-filename="tarjeta-fidelidad-<?php echo esc_attr(sanitize_title($c->name));?>.png"><?php esc_html_e('Guardar mi tarjeta','ov-fidelidad');?></button><button type="button" class="ovf-qr-action ovf-share-card" data-url="<?php echo esc_attr(ovf_card_url($c->token));?>" data-title="<?php echo esc_attr(sprintf(__('Mi tarjeta de %s','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))));?>" data-done="<?php esc_attr_e('Enlace copiado ✓','ov-fidelidad');?>"><?php esc_html_e('Compartir enlace','ov-fidelidad');?></button></div><p class="ovf-save-tip"><?php esc_html_e('Guarda este enlace o añade la página a tu pantalla de inicio: es tu tarjeta.','ov-fidelidad');?></p><button type="button" id="ovf-card-install" class="ovf-qr-action ovf-install-card"><?php esc_html_e('Agregar tarjeta al teléfono','ov-fidelidad');?></button><p id="ovf-card-install-help" class="ovf-install-help" hidden><?php esc_html_e('En iPhone: abre esta página en Safari, toca Compartir y elige “Agregar a pantalla de inicio”. En Android: abre el menú del navegador y elige “Instalar app” o “Agregar a pantalla principal”.','ov-fidelidad');?></p><small><?php esc_html_e('Este QR es único y permanente para tu tarjeta.','ov-fidelidad');?></small></section><?php $ovf_review_url=ovf_get_option('ovf_google_review_url','');if($ovf_review_url):?><section class="ovf-google-review"><div class="ovf-google-review-mark" aria-hidden="true"><svg viewBox="0 0 48 48" focusable="false"><path fill="#4285F4" d="M43.6 24.5c0-1.4-.1-2.7-.4-4H24v7.6h11a9.4 9.4 0 0 1-4.1 6.2v5h6.7c3.9-3.6 6-8.8 6-14.8Z"/><path fill="#34A853" d="M24 44c5.5 0 10.1-1.8 13.5-4.8l-6.7-5c-1.8 1.2-4 1.9-6.8 1.9-5.2 0-9.6-3.5-11.2-8.2H5.9v5.2A20 20 0 0 0 24 44Z"/><path fill="#FBBC05" d="M12.8 27.9a12 12 0 0 1 0-7.8v-5.2H5.9a20 20 0 0 0 0 18.2l6.9-5.2Z"/><path fill="#EA4335" d="M24 12c3 0 5.7 1 7.8 3.1l5.8-5.8C34.1 6 29.5 4 24 4A20 20 0 0 0 5.9 14.9l6.9 5.2C14.4 15.5 18.8 12 24 12Z"/></svg></div><div class="ovf-google-review-copy"><span><?php esc_html_e('¿Cómo fue tu experiencia?','ov-fidelidad');?></span><b><?php echo esc_html(sprintf(__('Cuéntale a Google qué te pareció %s.','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))));?></b><small><?php esc_html_e('Tu opinión ayuda a otras personas a conocer el negocio.','ov-fidelidad');?></small></div><a href="<?php echo esc_url($ovf_review_url);?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Dejar una reseña','ov-fidelidad');?> <span aria-hidden="true">↗</span></a></section><?php endif;?><section class="ovf-referral-share"><b><?php esc_html_e('Invita a tus amigos','ov-fidelidad');?></b><p><?php printf(esc_html__('Comparte tu código %s. Al registrarse, la invitación queda pendiente; cuando tu invitado haga su primera compra, se completa y recibirás el bono configurado.','ov-fidelidad'),esc_html($c->referral_code));?></p><div class="ovf-referral-stats"><span><?php esc_html_e('Invitaciones registradas','ov-fidelidad');?> <b><?php echo (int)($ref_stats->total??0);?></b></span><span><?php esc_html_e('Pendientes de primera compra','ov-fidelidad');?> <b><?php echo (int)($ref_stats->pending??0);?></b></span><span><?php esc_html_e('Invitaciones completadas','ov-fidelidad');?> <b><?php echo max(0,(int)($ref_stats->total??0)-(int)($ref_stats->pending??0));?></b></span><span><?php esc_html_e('Puntos ganados por invitaciones','ov-fidelidad');?> <b><?php echo number_format_i18n($ref_points);?></b></span><span><?php esc_html_e('Sellos ganados por invitaciones','ov-fidelidad');?> <b><?php echo number_format_i18n($ref_stamps);?></b></span></div><div class="ovf-qr-actions"><button type="button" class="ovf-qr-action ovf-share-referral" data-url="<?php echo esc_attr(add_query_arg('ref',$c->referral_code,ovf_page_url('ovf_page_register')));?>" data-title="<?php echo esc_attr(sprintf(__('Únete al programa de %s','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))));?>" data-done="<?php esc_attr_e('Enlace copiado ✓','ov-fidelidad');?>"><?php esc_html_e('Compartir mi invitación','ov-fidelidad');?></button><button type="button" class="ovf-qr-action ovf-copy-referral" data-code="<?php echo esc_attr($c->referral_code);?>"><?php esc_html_e('Copiar código','ov-fidelidad');?></button></div></section><section class="ovf-benefits"><div class="ovf-section-title"><span><?php esc_html_e('Tus beneficios','ov-fidelidad');?></span><?php $ovf_av=count(array_filter($rewards,function($x){return $x->status==='available';}));?><b><?php printf(esc_html(_n('%d disponible','%d disponibles',$ovf_av,'ov-fidelidad')),$ovf_av);?></b></div><?php if(!$rewards):?><div class="ovf-soft-empty"><?php esc_html_e('Tus beneficios aparecerán aquí cuando alcances el primer nivel.','ov-fidelidad');?></div><?php else:foreach($rewards as $rw):?><div class="ovf-benefit <?php echo esc_attr($rw->status);?>"><i><?php echo $rw->status==='available'?'★':($rw->status==='expired'?'⌛':'✓');?></i><div><b><?php echo esc_html($rw->title);?></b><span><?php if($rw->status==='available'){echo esc_html(ovf_reward_expiry_text($rw)?:__('Disponible para canjear','ov-fidelidad'));}elseif($rw->status==='expired'){printf(esc_html__('Venció el %s','ov-fidelidad'),esc_html(date_i18n(get_option('date_format'),strtotime($rw->expires_at))));}else{printf(esc_html__('Canjeado el %s','ov-fidelidad'),esc_html(date_i18n(get_option('date_format'),strtotime($rw->redeemed_at))));}?></span></div><em><?php echo $rw->status==='available'?esc_html__('Disponible','ov-fidelidad'):($rw->status==='expired'?esc_html__('Vencido','ov-fidelidad'):esc_html__('Usado','ov-fidelidad'));?></em></div><?php endforeach;endif;?></section><details class="ovf-details"><summary><?php esc_html_e('Actividad reciente','ov-fidelidad');?> <span>⌄</span></summary><div><?php if(!$moves)echo '<p>'.esc_html__('No hay movimientos todavía.','ov-fidelidad').'</p>';foreach($moves as $m):?><div class="ovf-history-row"><i><?php echo $m->type==='purchase'?'+1':($m->type==='registration'?'＋':'✓');?></i><p><b><?php echo $m->type==='purchase'?esc_html__('Compra registrada','ov-fidelidad'):(($m->type==='registration'?esc_html__('Tarjeta creada','ov-fidelidad'):($m->type==='referral_bonus'?esc_html__('Bono por invitación','ov-fidelidad'):esc_html(sprintf(__('Canjeaste: %s','ov-fidelidad'),$m->note?:__('beneficio','ov-fidelidad'))))));?></b><span><?php echo esc_html(ovf_date($m->created_at));?></span></p></div><?php endforeach;?></div></details></div><?php return ovf_front_wrap(ob_get_clean());}

add_shortcode('ov_fidelidad_scanner','ovf_sc_scanner');
/**
 * Escáner y ficha del cliente para el equipo (0.12).
 * Los POST se procesan en includes/front-actions.php; aquí solo se pinta la vista.
 */
function ovf_sc_scanner(){
 ovf_assets(false);
 if(!is_user_logged_in()) return ovf_v02_login();
 if(!ovf_cap()) return ovf_v02_shell('<div class="ovf-state"><h1>'.esc_html__('Sin permisos','ov-fidelidad').'</h1><p>'.esc_html__('Tu cuenta no tiene acceso al programa de fidelidad.','ov-fidelidad').'</p></div>',false);
 global $wpdb;$t=ovf_tables();
 $token=sanitize_text_field(wp_unslash($_GET['ovf']??''));
 $c=$token?ovf_client_by_token($token):null;
 $source=sanitize_key($_GET['source']??'');
 $home=ovf_v02_url('ovf_page_portal');
 ob_start();
 echo ovf_flash_html();
 if(!$c): ?>
 <section class="ovf-app-section ovf-scan-view">
  <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
  <?php if($token):?><div class="ovf-app-alert error"><?php esc_html_e('No encontramos esa tarjeta. Puede que el QR sea de otro negocio o que el cliente haya sido eliminado.','ov-fidelidad');?></div><?php endif;?>
  <span class="ovf-kicker"><?php esc_html_e('Registrar compra','ov-fidelidad');?></span>
  <h1><?php esc_html_e('Registrar visita o compra','ov-fidelidad');?></h1>
  <p><?php esc_html_e('Escanea la tarjeta del cliente o encuéntrala por su WhatsApp registrado. En ambos casos confirmarás la compra antes de acreditarla.','ov-fidelidad');?></p>
  <div class="ovf-scan-tabs" role="tablist" aria-label="Método para localizar al cliente">
   <button type="button" role="tab" id="ovf-tab-qr" aria-controls="ovf-method-qr" aria-selected="true" class="is-active" data-ovf-scan-tab="qr"><?php echo ovf_v02_icon('scan');?> <?php esc_html_e('Escanear QR','ov-fidelidad');?></button>
   <button type="button" role="tab" id="ovf-tab-whatsapp" aria-controls="ovf-method-whatsapp" aria-selected="false" data-ovf-scan-tab="whatsapp"><?php echo ovf_v02_icon('chat');?> <?php esc_html_e('Registrar con WhatsApp','ov-fidelidad');?></button>
  </div>
  <div id="ovf-method-qr" class="ovf-scan-method" role="tabpanel" aria-labelledby="ovf-tab-qr">
  <div class="ovf-scan-panel">
   <div id="ovf-camera" class="ovf-camera" data-autostart="0" hidden><video playsinline muted></video><div class="ovf-scan-frame"></div><p class="ovf-camera-status" id="ovf-camera-status"></p></div>
   <div class="ovf-scan-buttons">
    <button type="button" class="ovf-app-primary ovf-wide" id="ovf-start-camera"><?php echo ovf_v02_icon('scan');?><span><?php esc_html_e('Abrir cámara','ov-fidelidad');?></span></button>
    <button type="button" class="ovf-app-secondary ovf-wide" id="ovf-stop-camera" hidden><?php esc_html_e('Cancelar','ov-fidelidad');?></button>
   </div>
   <p class="ovf-camera-error" id="ovf-camera-error" hidden></p>
  </div>
  </div>
  <div id="ovf-method-whatsapp" class="ovf-scan-method" role="tabpanel" aria-labelledby="ovf-tab-whatsapp" hidden>
   <div class="ovf-phone-lookup">
    <label for="ovf-whatsapp-number"><?php esc_html_e('WhatsApp del cliente','ov-fidelidad');?></label>
    <form id="ovf-whatsapp-form" autocomplete="off">
     <input id="ovf-whatsapp-number" name="phone" type="tel" inputmode="tel" autocomplete="off" placeholder="Ej. 3312345678" aria-describedby="ovf-whatsapp-help" required>
     <button class="ovf-app-primary" type="submit"><?php echo ovf_v02_icon('search');?> <?php esc_html_e('Buscar cliente','ov-fidelidad');?></button>
    </form>
    <p id="ovf-whatsapp-help" class="ovf-help"><?php esc_html_e('Escribe los 10 dígitos del número registrado. Verifica el nombre antes de confirmar la compra.','ov-fidelidad');?></p>
    <div id="ovf-whatsapp-results" aria-live="polite"></div>
   </div>
  </div>
 </section>
 <?php else:
  ovf_sync_client_rewards($c);
  $available=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE client_id=%d AND status='available' ORDER BY milestone ASC",$c->id));
  $redeemed=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE client_id=%d AND status='redeemed' ORDER BY redeemed_at DESC LIMIT 3",$c->id));
  $nx=ovf_next_reward((int)$c->visits,(int)$c->id);$next=$nx?$nx['rule']:null;
  $back=$source==='search'?[ovf_v02_url('ovf_page_portal',['view'=>'clients']),__('Clientes','ov-fidelidad')]:[ovf_v02_url('ovf_page_portal',['view'=>'scanner']),__('Escanear otro cliente','ov-fidelidad')];
 ?>
 <section class="ovf-app-section ovf-client-view">
  <?php echo ovf_v02_back($back[0],$back[1]);?>
  <div class="ovf-client-head">
   <i class="ovf-client-avatar"><?php echo esc_html(ovf_initial($c->name));?></i>
   <div class="ovf-client-id"><span class="ovf-kicker"><?php esc_html_e('Cliente','ov-fidelidad');?></span><h1><?php echo esc_html($c->name);?></h1><p><?php echo esc_html(ovf_contact_display($c) ?: __('Sin datos de contacto','ov-fidelidad'));?></p></div>
   <div class="ovf-client-count"><strong><?php echo (int)$c->visits;?></strong><small><?php echo esc_html(_n('compra','compras',(int)$c->visits,'ov-fidelidad'));?></small></div>
  </div>
  <?php $client_card_url=ovf_card_url($c->token);?><div class="ovf-client-share-actions"><a class="ovf-app-secondary" href="<?php echo esc_url($client_card_url);?>" target="_blank" rel="noopener"><?php esc_html_e('Ver tarjeta del cliente','ov-fidelidad');?> ↗</a><button type="button" class="ovf-app-primary ovf-share-customer-card" data-card-url="<?php echo esc_attr($client_card_url);?>" data-customer-name="<?php echo esc_attr($c->name);?>">↗ <?php esc_html_e('Compartir tarjeta con el cliente','ov-fidelidad');?></button></div>
  <?php if($c->status!=='active'):?><div class="ovf-app-alert error"><?php esc_html_e('Esta tarjeta está inactiva. Actívala desde el escritorio para registrar compras.','ov-fidelidad');?></div><?php endif;?>
  <?php $points=ovf_client_points($c->id);$wallet=ovf_client_balance($c->id);$vip=ovf_client_vip_level($c->id);?><div class="ovf-metrics ovf-client-loyalty"><div><span><?php esc_html_e('Puntos','ov-fidelidad');?></span><strong><?php echo number_format_i18n($points);?></strong></div><div><span><?php esc_html_e('Saldo cashback','ov-fidelidad');?></span><strong>$<?php echo number_format_i18n($wallet,2);?> MXN</strong></div><div><span><?php esc_html_e('Nivel VIP','ov-fidelidad');?></span><strong><?php echo esc_html($vip);?></strong></div></div>
  <?php if($points>0&&$c->status==='active'):?><form method="post" class="ovf-inline-password ovf-points-convert-form"><?php wp_nonce_field('ovf_staff_'.$c->id);?><label><?php esc_html_e('Convertir puntos a saldo','ov-fidelidad');?><input type="number" name="points_to_convert" min="1" max="<?php echo (int)$points;?>" step="1" required><small><?php printf(esc_html__('Disponible: %1$d puntos · %2$d puntos por cada $1 MXN.','ov-fidelidad'),$points,(int)ovf_get_option('ovf_points_per_peso',10));?></small></label><button class="ovf-app-secondary" name="ovf_convert_points" value="1"><?php esc_html_e('Convertir','ov-fidelidad');?></button></form><?php endif;?>
  <?php $ref_url=add_query_arg('ref',$c->referral_code,ovf_page_url('ovf_page_register'));?><p class="ovf-help ovf-client-referral"><?php printf(esc_html__('Código para invitar: %1$s · comparte el enlace %2$s','ov-fidelidad'),esc_html($c->referral_code),'<a href="'.esc_url($ref_url).'" target="_blank" rel="noopener">'.esc_html__('abrir enlace','ov-fidelidad').'</a>');?></p>
  <?php if($next): $left=$nx['target']-(int)$c->visits; ?>
  <div class="ovf-next">
   <div><small><?php esc_html_e('Próximo beneficio','ov-fidelidad');?></small><b><?php echo esc_html($next->title);?></b></div>
   <span><?php printf(esc_html(_n('Falta %d compra','Faltan %d compras',$left,'ov-fidelidad')),$left);?></span>
   <div class="ovf-progress"><i style="width:<?php echo (int)min(100,round(((int)$c->visits-$nx['from'])/max(1,$nx['target']-$nx['from'])*100));?>%"></i></div>
  </div>
  <?php endif;?>
  <form method="post" class="ovf-purchase-form" data-ovf-confirm="<?php echo esc_attr(wp_json_encode(['icon'=>'+1','title'=>sprintf(__('¿Registrar compra para %s?','ov-fidelidad'),$c->name),'text'=>sprintf(_n('Se sumará 1 compra a su tarjeta (tendrá %d compra).','Se sumará 1 compra a su tarjeta (tendrá %d compras).',(int)$c->visits+1,'ov-fidelidad'),(int)$c->visits+1),'ok'=>__('Sí, registrar','ov-fidelidad'),'cancel'=>__('Cancelar','ov-fidelidad')]));?>">
   <?php wp_nonce_field('ovf_staff_'.$c->id);$first_discount=ovf_referral_discount_percent($c);?>
   <label><?php esc_html_e('Importe original del ticket (MXN)','ov-fidelidad');?><input name="sale_amount" type="number" min="0" max="10000000" step="0.01" inputmode="decimal" value="0" data-referral-amount aria-describedby="ovf-sale-help"><small id="ovf-sale-help"><?php esc_html_e('Captura el importe antes de cualquier descuento; puntos y cashback se calculan sobre el total final.','ov-fidelidad');?></small></label><?php if($first_discount>0):?><div class="ovf-referral-offer" data-referral-rate="<?php echo esc_attr(number_format($first_discount,2,'.',''));?>"><b><?php printf(esc_html__('Descuento de invitación: %s%%','ov-fidelidad'),number_format_i18n($first_discount,1));?></b><small data-referral-estimate><?php esc_html_e('Confirma si lo aplicaste manualmente en caja.','ov-fidelidad');?></small><fieldset class="ovf-referral-decision"><legend><?php esc_html_e('¿Aplicar este descuento en caja?','ov-fidelidad');?></legend><label><input type="radio" name="apply_referral_discount" value="1" required> <?php esc_html_e('Sí, ya lo apliqué','ov-fidelidad');?></label><label><input type="radio" name="apply_referral_discount" value="0" required> <?php esc_html_e('No, registrar sin descuento','ov-fidelidad');?></label></fieldset></div><?php endif;?>
   <label><?php esc_html_e('Número de ticket (opcional)','ov-fidelidad');?><input name="receipt_number" type="text" maxlength="80" placeholder="<?php esc_attr_e('Ej. A-1048','ov-fidelidad');?>"><small><?php esc_html_e('Puedes dejarlo vacío si el negocio no utiliza tickets.','ov-fidelidad');?></small></label>
   <?php $wallet=ovf_client_balance($c->id);if($wallet>0):?><label><?php esc_html_e('Aplicar saldo cashback (MXN)','ov-fidelidad');?><input name="balance_used" type="number" min="0" max="<?php echo esc_attr(number_format($wallet,2,'.',''));?>" step="0.01" inputmode="decimal" value="0"><small><?php printf(esc_html__('Saldo disponible: $%s MXN.','ov-fidelidad'),number_format_i18n($wallet,2));?></small></label><?php endif;?>
   <label><?php esc_html_e('Nota (opcional)','ov-fidelidad');?><input name="note" placeholder="<?php esc_attr_e('Ej. Compra en sucursal centro','ov-fidelidad');?>"></label>
   <button class="ovf-app-primary ovf-wide ovf-purchase" name="ovf_purchase" value="1" <?php disabled($c->status!=='active');?>>＋ <?php esc_html_e('Registrar compra','ov-fidelidad');?></button>
  </form>
  <section class="ovf-redeem">
   <div class="ovf-section-title"><span><?php esc_html_e('Beneficios disponibles','ov-fidelidad');?></span><b><?php echo count($available);?></b></div>
   <?php if(!$available):?><div class="ovf-state compact"><?php esc_html_e('Este cliente no tiene beneficios pendientes de canje.','ov-fidelidad');?></div>
   <?php else: foreach($available as $rw):?>
   <form method="post" class="ovf-redeem-row" data-ovf-confirm="<?php echo esc_attr(wp_json_encode(['icon'=>'★','title'=>sprintf(__('¿Canjear “%s”?','ov-fidelidad'),$rw->title),'text'=>sprintf(__('Entrega el beneficio a %s. Quedará marcado como usado.','ov-fidelidad'),$c->name),'ok'=>__('Sí, canjear','ov-fidelidad'),'cancel'=>__('Cancelar','ov-fidelidad')]));?>">
    <?php wp_nonce_field('ovf_staff_'.$c->id);?><input type="hidden" name="reward_id" value="<?php echo (int)$rw->id;?>">
    <i>★</i><div><b><?php echo esc_html($rw->title);?></b><span><?php printf(esc_html__('Ganado en la compra %d','ov-fidelidad'),(int)$rw->milestone);?><?php if($ovf_e=ovf_reward_expiry_text($rw)):?> · <strong class="ovf-expiry"><?php echo esc_html($ovf_e);?></strong><?php endif;?></span></div>
    <button class="ovf-app-secondary" name="ovf_redeem" value="1"><?php esc_html_e('Canjear','ov-fidelidad');?></button>
   </form>
   <?php endforeach; endif;?>
   <?php /* Los canjes aparecen en el historial del cliente (debajo). */ ?>
  </section>
  <?php
  // Historial completo del cliente: compras, canjes y alta, con quién lo registró.
  $ovf_hist=$wpdb->get_results($wpdb->prepare("SELECT m.*,u.display_name staff FROM {$t['moves']} m LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.client_id=%d ORDER BY m.id DESC LIMIT 60",$c->id));
  $ovf_hist_total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE client_id=%d",$c->id));
  ?>
  <details class="ovf-client-history">
   <summary><span class="ovf-ch-title"><?php esc_html_e('Historial del cliente','ov-fidelidad');?><small><?php echo $ovf_hist?esc_html(sprintf(__('Último movimiento: %s','ov-fidelidad'),date_i18n(get_option('date_format'),strtotime($ovf_hist[0]->created_at)))):esc_html__('Sin movimientos','ov-fidelidad');?></small></span><b><?php echo (int)$ovf_hist_total;?></b><i aria-hidden="true">⌄</i></summary>
   <?php if(!$ovf_hist):?><div class="ovf-state compact"><?php esc_html_e('Aún no hay movimientos.','ov-fidelidad');?></div><?php else:?>
   <div class="ovf-feed">
   <?php $ovf_day='';foreach($ovf_hist as $i=>$m):
    $d=date_i18n(get_option('date_format'),strtotime($m->created_at));
    if($d!==$ovf_day){$ovf_day=$d;echo '<h3 class="ovf-feed-day">'.esc_html($d).'</h3>';}
    if($m->type==='purchase'){$lb=__('Compra registrada','ov-fidelidad');$ic='+1';}
    elseif($m->type==='redeem'){$lb=sprintf(__('Canjeó: %s','ov-fidelidad'),$m->note?:__('beneficio','ov-fidelidad'));$ic='★';}
    elseif($m->type==='registration'){$lb=$m->method==='self'?__('Se registró desde el QR del negocio','ov-fidelidad'):__('Tarjeta creada','ov-fidelidad');$ic='＋';}
    else{$lb=__('Ajuste','ov-fidelidad');$ic='·';}
    $how=$m->method==='qr'?__('QR','ov-fidelidad'):($m->method==='search'?__('búsqueda','ov-fidelidad'):'');
    $meta=array_filter([$m->staff?:'',$m->type!=='redeem'&&$m->note?$m->note:'',!empty($m->receipt_number)?__('Ticket','ov-fidelidad').': '.$m->receipt_number:'',$how]);?>
    <div class="ovf-feed-row is-<?php echo esc_attr($m->type);?>"><i><?php echo esc_html($ic);?></i><div><b><?php echo esc_html($lb);?></b><?php if($meta):?><span><?php echo esc_html(implode(' · ',$meta));?></span><?php endif;?></div><time><?php echo esc_html(date_i18n(get_option('time_format'),strtotime($m->created_at)));?></time></div>
   <?php endforeach;?>
   </div>
   <?php if($ovf_hist_total>count($ovf_hist)):?><p class="ovf-results-meta"><?php printf(esc_html__('Se muestran los últimos %d movimientos.','ov-fidelidad'),count($ovf_hist));?></p><?php endif;?>
   <?php endif;?>
  </details>
  <a class="ovf-card-link" href="<?php echo esc_url(ovf_card_url($c->token));?>"><?php esc_html_e('Ver la tarjeta que ve el cliente','ov-fidelidad');?> →</a>
 </section>
 <?php endif;
 return ovf_v02_shell(ob_get_clean(),true);
}
add_shortcode('ov_fidelidad_panel','ovf_sc_portal');
function ovf_sc_portal(){return ovf_v02_app();}


/** 0.10 onboarding: guided first-run setup. */
// Página oculta del asistente: se registra bajo el menú (para que tenga título) y se oculta del submenú.
add_action('admin_head',function(){remove_submenu_page('ov-fidelidad','ov-fidelidad-setup');});
add_action('admin_menu',function(){add_submenu_page('ov-fidelidad',__('Configurar OV Fidelidad','ov-fidelidad'),__('Configurar OV Fidelidad','ov-fidelidad'),'manage_options','ov-fidelidad-setup','ovf_setup_wizard');},99);
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||wp_doing_ajax())return;
 // Solo una redirección tras activar; antes cualquier pantalla sin ?page= (Entradas, Plugins…) quedaba secuestrada por el asistente.
 if(ovf_get_option('ovf_setup_complete','yes')==='no' && get_transient('ovf_setup_redirect') && empty($_GET['page']) && empty($_GET['activate-multi'])){delete_transient('ovf_setup_redirect');wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-setup'));exit;}
});
/** Procesa el asistente antes de imprimir la página (si no, las redirecciones fallaban: "headers already sent"). */
add_action('admin_init',function(){
 if(($_GET['page']??'')!=='ov-fidelidad-setup'||!current_user_can('manage_options'))return;
 $step=max(1,min(5,absint($_GET['step']??1)));$err='';
 if($_SERVER['REQUEST_METHOD']==='POST'&&check_admin_referer('ovf_setup_'.$step)){
  if($step===1){ovf_update_option('ovf_brand_name',sanitize_text_field(wp_unslash($_POST['brand']??'')));ovf_update_option('ovf_primary',sanitize_hex_color($_POST['primary']??'')?:'#334155');ovf_update_option('ovf_logo_id',absint($_POST['logo_id']??0));}
  if($step===2){ovf_update_option('ovf_app_name',sanitize_text_field(wp_unslash($_POST['app_name']??'')));ovf_update_option('ovf_app_short_name',sanitize_text_field(wp_unslash($_POST['short_name']??'')));ovf_update_option('ovf_app_icon_id',absint($_POST['icon_id']??0));}
  if($step===3){$mode=sanitize_key($_POST['owner_mode']??'current');if($mode==='current'){$u=wp_get_current_user();$u->add_role('ovf_owner');}else{$name=sanitize_text_field(wp_unslash($_POST['owner_name']??''));$email=sanitize_email($_POST['owner_email']??'');$pass=(string)($_POST['owner_password']??'');if(!$name||!is_email($email)||strlen($pass)<8)$err=__('Completa nombre, email válido y una contraseña de al menos 8 caracteres.','ov-fidelidad');else{$uid=email_exists($email);if(!$uid)$uid=wp_create_user($email,$pass,$email);if(is_wp_error($uid))$err=$uid->get_error_message();else{$u=new WP_User($uid);$u->set_role('ovf_owner');wp_update_user(['ID'=>$uid,'display_name'=>$name]);}}}}
  if($step===4&&!empty($_POST['reward_title'])&&!ovf_all_rules()){global $wpdb;$t=ovf_tables();$milestones=(array)($_POST['milestone']??[]);$titles=(array)($_POST['reward_title']??[]);foreach($titles as $i=>$title){$title=sanitize_text_field(wp_unslash($title));$m=absint($milestones[$i]??0);if($title&&$m)$wpdb->insert($t['rules'],['milestone'=>$m,'title'=>$title,'description'=>'','enabled'=>1,'sort_order'=>$i,'created_at'=>current_time('mysql')]);}}
  if($err){set_transient('ovf_setup_err_'.get_current_user_id(),$err,60);wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-setup&step='.$step));exit;}
  if(!$err){if($step<5){wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-setup&step='.($step+1)));exit;}ovf_update_option('ovf_setup_complete','yes');wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad'));exit;}
 }});
function ovf_setup_wizard(){
 if(!current_user_can('manage_options'))return;
 $step=max(1,min(5,absint($_GET['step']??1)));$err='';
 $err=get_transient('ovf_setup_err_'.get_current_user_id());if($err)delete_transient('ovf_setup_err_'.get_current_user_id());

 wp_enqueue_media();wp_enqueue_style('ovf-app-v02',OVF_URL.'assets/app-v02.css',[],OVF_VERSION);$brand=ovf_get_option('ovf_brand_name',get_bloginfo('name'));$app=ovf_get_option('ovf_app_name',$brand.' Club');
 echo '<div class="wrap ovf-setup" style="'.ovf_brand_style().'"><div class="ovf-setup-shell"><header><span class="ovf-eyebrow">OV FIDELIDAD</span><h1>'.esc_html__('Configura tu programa','ov-fidelidad').'</h1><div class="ovf-setup-progress"><i style="width:'.esc_attr(($step/5)*100).'%"></i></div><small>'.sprintf(esc_html__('Paso %1$d de 5','ov-fidelidad'),$step).'</small></header>';
 if($err)echo '<div class="notice notice-error"><p>'.esc_html($err).'</p></div>';echo '<form method="post" class="ovf-setup-card">';wp_nonce_field('ovf_setup_'.$step);
 if($step===1)echo '<span class="ovf-kicker">NEGOCIO</span><h2>'.esc_html__('Hazlo tuyo','ov-fidelidad').'</h2><p>'.esc_html__('Nombre, logo y color principal del programa.','ov-fidelidad').'</p><label>'.esc_html__('Nombre del negocio','ov-fidelidad').'<input name="brand" required value="'.esc_attr($brand).'"></label><label>'.esc_html__('Color principal','ov-fidelidad').'<input type="color" name="primary" value="'.esc_attr(ovf_get_option('ovf_primary','#315b46')).'"></label><input type="hidden" name="logo_id" id="ovf-setup-logo" value="'.absint(ovf_get_option('ovf_logo_id')).'"><button type="button" class="button ovf-media-pick" data-target="ovf-setup-logo">'.esc_html__('Seleccionar logo','ov-fidelidad').'</button>';
 if($step===2)echo '<span class="ovf-kicker">'.esc_html__('WEB APP','ov-fidelidad').'</span><h2>'.esc_html__('La app de tu equipo','ov-fidelidad').'</h2><p>'.esc_html__('Así aparecerá cuando el personal la instale en su teléfono.','ov-fidelidad').'</p><label>'.esc_html__('Nombre de la Web App','ov-fidelidad').'<input name="app_name" required value="'.esc_attr($app).'"></label><label>'.esc_html__('Nombre corto','ov-fidelidad').'<input name="short_name" maxlength="20" value="'.esc_attr(ovf_get_option('ovf_app_short_name',$brand)).'"></label><input type="hidden" name="icon_id" id="ovf-setup-icon" value="'.absint(ovf_get_option('ovf_app_icon_id')).'"><button type="button" class="button ovf-media-pick" data-target="ovf-setup-icon">'.esc_html__('Seleccionar icono','ov-fidelidad').'</button>';
 if($step===3)echo '<span class="ovf-kicker">ENCARGADO</span><h2>'.esc_html__('¿Quién administrará el negocio?','ov-fidelidad').'</h2><p>'.esc_html__('El encargado (dueño, gerente o responsable) puede hacer todo lo del empleado y además gestionar beneficios, equipo y actividad.','ov-fidelidad').'</p><label class="ovf-radio"><input type="radio" name="owner_mode" value="current" checked> '.esc_html__('Usar mi cuenta actual de WordPress','ov-fidelidad').'</label><label class="ovf-radio"><input type="radio" name="owner_mode" value="new"> '.esc_html__('Crear una cuenta independiente','ov-fidelidad').'</label><div class="ovf-owner-fields"><label>'.esc_html__('Nombre','ov-fidelidad').'<input name="owner_name"></label><label>Email<input type="email" name="owner_email"></label><label>'.esc_html__('Contraseña','ov-fidelidad').'<input type="password" name="owner_password" minlength="8"></label></div>';
 if($step===4)echo '<span class="ovf-kicker">BENEFICIOS</span><h2>'.esc_html__('Crea tus primeros niveles','ov-fidelidad').'</h2><p>'.esc_html__('Puedes omitirlos y configurarlos después.','ov-fidelidad').'</p><div class="ovf-setup-rewards"><div><input type="number" min="1" name="milestone[]" value="5"><input name="reward_title[]" placeholder="Ej. Café americano gratis"></div><div><input type="number" min="1" name="milestone[]" value="10"><input name="reward_title[]" placeholder="Ej. 15% de descuento"></div><div><input type="number" min="1" name="milestone[]" value="20"><input name="reward_title[]" placeholder="Ej. Bebida de especialidad gratis"></div></div>';
 if($step===5){$appurl=ovf_page_url('ovf_page_portal');$reg=ovf_page_url('ovf_page_register');echo '<span class="ovf-kicker">'.esc_html__('Instalación completada','ov-fidelidad').'</span><h2>'.esc_html($brand).' está listo</h2><p>'.esc_html__('Tu programa ya tiene sus páginas, permisos y estructura técnica.','ov-fidelidad').'</p><div class="ovf-ready-links"><a target="_blank" href="'.esc_url($appurl).'"><b>'.esc_html__('Web App del equipo','ov-fidelidad').'</b><span>'.esc_html($appurl).'</span></a><a target="_blank" href="'.esc_url($reg).'"><b>'.esc_html__('Registro de clientes','ov-fidelidad').'</b><span>'.esc_html($reg).'</span></a></div><p class="ovf-help">'.esc_html__('Después podrás añadir empleados, ajustar beneficios y descargar el QR de registro desde Ajustes.','ov-fidelidad').'</p>';}
 echo '<footer>';if($step>1)echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-setup&step='.($step-1))).'">'.esc_html__('Atrás','ov-fidelidad').'</a>';echo '<button class="button button-primary">'.($step===5?__('Finalizar','ov-fidelidad'):__('Continuar','ov-fidelidad')).'</button></footer></form></div></div>';
 echo '<script>document.addEventListener("click",function(e){var b=e.target.closest(".ovf-media-pick");if(!b||!window.wp||!wp.media)return;var f=wp.media({title:'.wp_json_encode(__('Seleccionar imagen','ov-fidelidad')).',multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON();document.getElementById(b.dataset.target).value=a.id;b.textContent='.wp_json_encode(__('Imagen seleccionada ✓','ov-fidelidad')).';});f.open();});</script>';
}


add_action('admin_init',function(){
 if(!current_user_can('manage_options')||empty($_POST['ovf_uninstall_pref']))return;
 check_admin_referer('ovf_uninstall_pref');
 update_option('ovf_delete_data',empty($_POST['ovf_delete_data'])?'0':'1');
 wp_safe_redirect(add_query_arg(['page'=>'ov-fidelidad-settings'],admin_url('admin.php')).'#ovf-tools');exit;
});
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||empty($_POST['ovf_clear_test_data']))return;
 if(!check_admin_referer('ovf_clear_test_data'))return;
 global $wpdb;$t=ovf_tables();$wpdb->query("TRUNCATE TABLE {$t['moves']}");$wpdb->query("TRUNCATE TABLE {$t['rewards']}");$wpdb->query("TRUNCATE TABLE {$t['clients']}");
 wp_safe_redirect(add_query_arg(['page'=>'ov-fidelidad-settings','cleared'=>'1'],admin_url('admin.php')));exit;
});

function ovf_admin_marketing(){if(!current_user_can('manage_options'))return;wp_enqueue_style('ovf-app-v02',OVF_URL.'assets/app-v02.css',[ 'ovf-ui' ],OVF_VERSION);wp_enqueue_script('ovf-marketing-ui',OVF_URL.'assets/app-v02.js',[],OVF_VERSION,true);ovf_admin_header(__('Banner y envío de promociones','ov-fidelidad'),__('Administra las imágenes que aparecen en las tarjetas y envía campañas de correo con consentimiento.','ov-fidelidad'),false);echo '<div class="ovf-v02 ovf-app-2026">'.ovf_email_campaign_view().'</div>';ovf_admin_end();}
