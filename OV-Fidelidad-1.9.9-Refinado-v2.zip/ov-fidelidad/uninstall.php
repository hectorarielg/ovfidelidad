<?php
/**
 * OV Fidelidad — desinstalación.
 * Por seguridad los datos se CONSERVAN al borrar el plugin, salvo que en
 * Ajustes → Herramientas se active "Borrar todos los datos al desinstalar".
 */
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

if (get_option('ovf_delete_data') !== '1') return;

global $wpdb;
$business_table=$wpdb->prefix.'ovf_businesses';
$business_ids=$wpdb->get_col("SELECT id FROM {$business_table}");
foreach (array_merge([1],array_map('absint',(array)$business_ids)) as $business_id) {
	$suffix=$business_id>1?'_b'.absint($business_id):'';
	foreach (['ovf_clients','ovf_movements','ovf_rewards','ovf_reward_rules'] as $table) $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}{$table}{$suffix}");
	if($business_id>1)$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like('ovf_biz_'.$business_id.'_').'%'));
}
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ovf_whatsapp_messages"); // Tabla de cola antigua, solo para limpieza al desinstalar.
$wpdb->query("DROP TABLE IF EXISTS {$business_table}");
$wpdb->delete($wpdb->usermeta,['meta_key'=>'ovf_business_id']);
$wpdb->delete($wpdb->usermeta,['meta_key'=>'ovf_active_business_id']);
// Páginas creadas por el plugin.
foreach (['ovf_page_portal', 'ovf_page_register', 'ovf_page_card'] as $key) {
	$id = (int) get_option($key);
	if ($id) wp_delete_post($id, true);
}

// Las cuentas del equipo se conservan como suscriptores; se eliminan los roles y capacidades propios.
foreach (get_users(['role__in' => ['ovf_owner', 'ovf_staff']]) as $user) {
	$user->remove_role('ovf_owner');
	$user->remove_role('ovf_staff');
	if (!$user->roles) $user->set_role('subscriber');
	delete_user_meta($user->ID, 'ovf_access_disabled');
	delete_user_meta($user->ID, 'ovf_force_password_change');
}
remove_role('ovf_owner');
remove_role('ovf_staff');
foreach (['administrator', 'editor'] as $role_name) {
	$role = get_role($role_name);
	if (!$role) continue;
	foreach (['manage_ov_fidelidad', 'ovf_manage_staff', 'ovf_manage_clients', 'ovf_register_sales', 'ovf_redeem_rewards', 'ovf_view_reports'] as $cap) $role->remove_cap($cap);
}

// Opciones y datos temporales.
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'ovf\\_%' OR option_name LIKE '\\_transient\\_ovf\\_%' OR option_name LIKE '\\_transient\\_timeout\\_ovf\\_%'");
