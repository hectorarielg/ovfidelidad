/* OV Fidelidad 1.9.4: búsquedas progresivas, sin modificar la navegación nativa de WordPress. */
(()=>{'use strict';
// Re-render existing server-side search results asynchronously without changing WordPress endpoints.
const delay=(fn,ms)=>{let timer;return(...args)=>{clearTimeout(timer);timer=setTimeout(()=>fn(...args),ms)}};
async function refresh(form,page,query){
 const u=new URL(form.action||location.href,location.href);
 const data=new FormData(form);for(const [key,val] of data.entries())u.searchParams.set(key,val);
 u.searchParams.set('page',page);u.searchParams.delete('paged');u.searchParams.delete('business_page');
 if(query)u.searchParams.set(query.name,query.value);
 const container=form.closest('[data-ovfp-live]')||form.closest('.ovf-business-list');
 if(!container)return;
 const previous=container.dataset.requestId||'0';container.dataset.requestId=String(Number(previous)+1);
 const id=container.dataset.requestId;
 container.classList.add('ovfp-is-loading');container.setAttribute('aria-busy','true');
 try{
  const response=await fetch(u.href,{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});
  if(!response.ok)throw Error('HTTP '+response.status);
  const doc=new DOMParser().parseFromString(await response.text(),'text/html');
  const selector=page==='ov-fidelidad-businesses'?'.ovf-business-list':'[data-ovfp-live="users"]';
  const updated=doc.querySelector(selector);
  if(!updated)throw Error('No se encontró la tabla del reporte');
  if(id!==container.dataset.requestId)return;
  // Preserve typing focus and caret so filtering feels native.
  const focused=document.activeElement;const fieldName=focused?.getAttribute('name');const focusInside=container.contains(focused);
  const caret=focusInside&&focused?.selectionStart!=null?focused.selectionStart:null;
  container.innerHTML=updated.innerHTML;
  if(focusInside&&fieldName){const input=container.querySelector('[name="'+CSS.escape(fieldName)+'"]');if(input){input.focus({preventScroll:true});if(caret!==null&&input.setSelectionRange)try{input.setSelectionRange(caret,caret)}catch(_){}}}
  history.replaceState(null,'',u.href);
 }catch(error){
  if(id===container.dataset.requestId){const message=container.querySelector('.ovfp-ajax-error')||document.createElement('p');message.className='ovfp-ajax-error';message.textContent='No se pudo actualizar el listado. Usa Buscar para consultar normalmente.';container.prepend(message)}
 }finally{if(id===container.dataset.requestId){container.classList.remove('ovfp-is-loading');container.removeAttribute('aria-busy')}}
}
const runSearch=delay(form=>{if(form.isConnected)refresh(form,form.querySelector('[name="page"]')?.value||'ov-fidelidad-businesses')},320);
document.addEventListener('input',event=>{
 const el=event.target;if(!(el instanceof HTMLInputElement))return;
 const form=el.closest('form');if(!form)return;
 if((el.name==='business_search' && form.matches('.ovf-business-search'))||(el.name==='s'&&form.closest('[data-ovfp-live="users"]'))){runSearch(form)}
});
document.addEventListener('change',event=>{
 const target=event.target;if(!(target instanceof HTMLSelectElement))return;
 const form=target.closest('form');if(form && form.closest('[data-ovfp-live="users"]'))refresh(form,'ov-fidelidad-platform-users');
 // Businesses already have native onchange submit; preserve its behavior.
});
document.addEventListener('submit',event=>{
 const form=event.target;if(!(form instanceof HTMLFormElement))return;
 if(form.closest('[data-ovfp-live="users"]')||form.matches('.ovf-business-search')){
  event.preventDefault();refresh(form,form.querySelector('[name="page"]')?.value||'ov-fidelidad-businesses');
 }
});
document.addEventListener('click',event=>{
 const a=event.target.closest('a');if(!a)return;
 const list=a.closest('[data-ovfp-live="users"],.ovf-business-list');
 if(!list || !a.closest('.tablenav-pages,.ovf-business-pagination'))return;
 event.preventDefault();
 const form=list.querySelector('form[method="get"]');if(!form){location.href=a.href;return}
 try{
  const url=new URL(a.href,location.href);
  const key=list.matches('.ovf-business-list')?'business_page':'paged';
  refresh(form,list.matches('.ovf-business-list')?'ov-fidelidad-businesses':'ov-fidelidad-platform-users',{name:key,value:url.searchParams.get(key)||'1'});
 }catch(_){location.href=a.href}
});
// Existing AJAX suggestions endpoint; supports both search and selection in global user directory.
let userTimer=0,userController=null;
document.addEventListener('input',event=>{
 const el=event.target;if(!(el instanceof HTMLInputElement)||el.id!=='ovfp-search')return;
 const form=el.closest('form');const box=form?.querySelector('#ovfp-suggest');if(!box)return;
 clearTimeout(userTimer);box.hidden=true;box.replaceChildren();const q=el.value.trim();if(q.length<2)return;
 userTimer=setTimeout(async()=>{
  if(userController)userController.abort();userController=new AbortController();
  try{
   const url=new URL(window.OVFPAdmin?.ajax||'',location.href);
   url.searchParams.set('action','ovfp_user_suggest');url.searchParams.set('nonce',window.OVFPAdmin?.userNonce||'');url.searchParams.set('q',q);
   const json=await fetch(url,{credentials:'same-origin',signal:userController.signal}).then(r=>r.json());
   if(!json.success||!Array.isArray(json.data)||!json.data.length||!box.isConnected)return;
   for(const u of json.data){const option=document.createElement('button');option.type='button';option.className='ovfp-suggestion';option.textContent=[u.name,u.email,u.business].filter(Boolean).join(' · ');option.addEventListener('click',()=>{el.value=u.login;box.hidden=true;refresh(form,'ov-fidelidad-platform-users')});box.append(option)}box.hidden=false;
  }catch(_){box.hidden=true}
 },230);
});
document.addEventListener('click',e=>{const box=document.querySelector('#ovfp-suggest');if(box&&!box.contains(e.target)&&e.target.id!=='ovfp-search')box.hidden=true});
// Quick global lookup reuses the authorized businesses suggestion endpoint.
let businessTimer=0,businessController=null;
document.addEventListener('input',e=>{
 const input=e.target;if(!(input instanceof HTMLInputElement)||input.id!=='ovfp-quick-business')return;
 const list=document.getElementById('ovfp-quick-results');if(!list)return;
 clearTimeout(businessTimer);list.hidden=true;list.replaceChildren();
 const q=input.value.trim();if(q.length<2)return;
 businessTimer=setTimeout(async()=>{
  if(businessController)businessController.abort();businessController=new AbortController();
  const data=new URLSearchParams({action:'ovf_business_suggest',nonce:window.OVFPAdmin?.businessNonce||'',q});
  try{
   const result=await fetch(window.OVFPAdmin?.ajax||'',{method:'POST',credentials:'same-origin',body:data,signal:businessController.signal}).then(r=>r.json());
   if(!result.success||!Array.isArray(result.data)||!result.data.length)return;
   for(const business of result.data){const a=document.createElement('a');a.href=business.url;a.className='ovfp-quick-result';a.textContent=[business.name,business.email].filter(Boolean).join(' · ');list.append(a)}list.hidden=false;
  }catch(_){list.hidden=true}
 },260);
});
document.addEventListener('click',e=>{const list=document.getElementById('ovfp-quick-results');if(list&&!list.contains(e.target)&&e.target.id!=='ovfp-quick-business')list.hidden=true});
})();
