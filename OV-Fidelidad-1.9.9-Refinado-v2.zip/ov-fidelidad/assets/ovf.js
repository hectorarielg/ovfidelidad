/* OV Fidelidad 0.12 — QR, escáner con cámara y utilidades de interfaz. */
(function(){
 const D=window.OVF_DATA||{},T=D.i18n||{};
 const ready=fn=>document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn);

 ready(()=>{
  /* Códigos QR locales */
  document.querySelectorAll('.ovf-qr[data-qr]').forEach(el=>{
   if(!window.QRCode)return;const size=parseInt(el.dataset.size||'180',10);
   el.innerHTML='';new QRCode(el,{text:el.dataset.qr,width:size,height:size,correctLevel:QRCode.CorrectLevel.M});
  });

  /* Confirmaciones e impresión del QR desde administración */
  document.querySelectorAll('.ovf-confirm-delete').forEach(a=>a.addEventListener('click',e=>{if(!confirm(D.confirmDelete||'¿Eliminar?'))e.preventDefault();}));
  document.querySelectorAll('.ovf-print-qr').forEach(b=>b.addEventListener('click',()=>window.print()));

  /* Tarjeta descargable vertical 4:5, pensada para guardar en el teléfono o imprimir. */
  const showToast=(message,error=false)=>{
   let region=document.querySelector('.ovf-toast-region');if(!region){region=document.createElement('div');region.className='ovf-toast-region';region.setAttribute('aria-live','polite');document.body.appendChild(region);}
   const toast=document.createElement('div');toast.className='ovf-toast'+(error?' is-error':'');toast.setAttribute('role',error?'alert':'status');toast.append(document.createTextNode(message));region.appendChild(toast);setTimeout(()=>{toast.classList.add('is-leaving');setTimeout(()=>toast.remove(),220);},4200);
  };
  document.addEventListener('click',async e=>{const btn=e.target.closest('.ovf-share-customer-card');if(!btn)return;const url=btn.dataset.cardUrl,name=btn.dataset.customerName||'Cliente';if(!url)return;try{if(navigator.share){await navigator.share({title:'Tarjeta de fidelidad de '+name,text:'Guarda aquí tu tarjeta digital:',url});}else if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(url);showToast('Enlace de la tarjeta copiado. Ya puedes pegarlo en WhatsApp.');}else{window.prompt('Copia el enlace de la tarjeta:',url);}}catch(err){if(err&&err.name!=='AbortError'){try{await navigator.clipboard.writeText(url);showToast('Enlace de la tarjeta copiado.');}catch(_){showToast('No se pudo copiar el enlace. Mantén presionado para copiarlo.',true);}}}});
  const roundRect=(ctx,x,y,w,h,r)=>{r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();};
  const fitFont=(ctx,text,maxWidth,start,min,family='Arial,sans-serif',weight='700')=>{let size=start;while(size>min){ctx.font=weight+' '+size+'px '+family;if(ctx.measureText(text).width<=maxWidth)break;size-=2;}return size;};
  const splitCanvasText=(ctx,text,maxWidth,maxLines=2)=>{const lines=[];let line='';for(const char of text){if(ctx.measureText(line+char).width>maxWidth&&line&&lines.length<maxLines-1){lines.push(line);line=char;}else line+=char;}if(line)lines.push(line);return lines.slice(0,maxLines);};
  const buildLoyaltyCard=async(button)=>{
   const card=button.closest('.ovf-public-card'),qr=card&&card.querySelector('.ovf-customer-qr .ovf-qr'),qrSource=qr&&(qr.querySelector('canvas')||qr.querySelector('img')),cardUrl=button.dataset.cardUrl||location.href;
   if(!card||!qrSource){showToast('No se encontró el código QR. Recarga la tarjeta e inténtalo de nuevo.',true);return;}
   const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');canvas.width=1200;canvas.height=1500;
   const style=getComputedStyle(card.closest('.ovf-app')||card),primary=style.getPropertyValue('--ovf-primary').trim()||'#2f8f72';
   ctx.fillStyle='#edf3ef';ctx.fillRect(0,0,1200,1500);
   ctx.save();ctx.shadowColor='rgba(18,45,31,.13)';ctx.shadowBlur=34;ctx.shadowOffsetY=14;roundRect(ctx,54,48,1092,1404,48);ctx.fillStyle='#fff';ctx.fill();ctx.restore();
   ctx.save();roundRect(ctx,54,48,1092,365,48);ctx.fillStyle=primary;ctx.fill();ctx.restore();ctx.fillStyle=primary;ctx.fillRect(54,345,1092,68);
   ctx.fillStyle='rgba(255,255,255,.14)';ctx.beginPath();ctx.arc(1070,82,220,0,Math.PI*2);ctx.fill();
   const brand=card.querySelector('.ovf-public-head .ovf-brandmark>span'),businessName=(brand?brand.childNodes[0].textContent:'').trim()||'Club de fidelidad';
   const customerName=(card.querySelector('.ovf-hello h1')||{}).textContent?.trim()||'Cliente';
   const logo=card.querySelector('.ovf-public-head .ovf-brand-logo img');
   roundRect(ctx,112,132,130,130,30);ctx.fillStyle='#fff';ctx.fill();
   let logoDrawn=false;if(logo&&logo.complete&&logo.naturalWidth){try{const src=new URL(logo.src,location.href);if(src.origin===location.origin){const ratio=Math.min(100/logo.naturalWidth,100/logo.naturalHeight),w=logo.naturalWidth*ratio,h=logo.naturalHeight*ratio;ctx.drawImage(logo,127+(100-w)/2,147+(100-h)/2,w,h);logoDrawn=true;}}catch(e){}}
   if(!logoDrawn){ctx.fillStyle=primary;ctx.font='800 46px Arial,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText((businessName.charAt(0)||'F').toUpperCase(),177,197);}
   ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.fillStyle='rgba(255,255,255,.78)';ctx.font='700 20px Arial,sans-serif';ctx.fillText('PROGRAMA DE FIDELIDAD',282,157);
   const brandSize=fitFont(ctx,businessName,760,52,30);ctx.font='800 '+brandSize+'px Arial,sans-serif';ctx.fillStyle='#fff';ctx.fillText(businessName,282,224);
   ctx.fillStyle='rgba(255,255,255,.82)';ctx.font='400 24px Arial,sans-serif';ctx.fillText('Tu tarjeta digital',282,274);
   ctx.textAlign='center';ctx.fillStyle=primary;ctx.font='800 20px Arial,sans-serif';ctx.fillText('TARJETA DE FIDELIDAD',600,515);
   const nameSize=fitFont(ctx,customerName,930,66,34);ctx.font='800 '+nameSize+'px Arial,sans-serif';ctx.fillStyle='#18251d';ctx.fillText(customerName,600,592);
   ctx.fillStyle='#718078';ctx.font='400 25px Arial,sans-serif';ctx.fillText('Muestra este código en cada visita',600,642);
   roundRect(ctx,334,682,532,532,38);ctx.fillStyle='#fff';ctx.strokeStyle='#e4ebe5';ctx.lineWidth=2;ctx.fill();ctx.stroke();
   ctx.imageSmoothingEnabled=false;const qrSize=452;ctx.drawImage(qrSource,374,722,qrSize,qrSize);ctx.imageSmoothingEnabled=true;
   ctx.fillStyle='#3a4a3f';ctx.font='700 25px Arial,sans-serif';ctx.fillText('Tu QR personal',600,1292);
   ctx.fillStyle='#859189';ctx.font='400 20px Arial,sans-serif';ctx.fillText('Escanéalo para identificar tu tarjeta',600,1322);
   ctx.fillStyle=primary;ctx.font='700 15px Arial,sans-serif';ctx.fillText('SI PIERDES ESTA IMAGEN, GUARDA ESTE ENLACE',600,1362);
   ctx.fillStyle='#40584a';ctx.font='600 15px monospace';const urlLines=splitCanvasText(ctx,cardUrl,900,2);urlLines.forEach((line,index)=>ctx.fillText(line,600,1385+index*21));
   ctx.fillStyle='#dfe8e1';ctx.fillRect(175,1421,850,2);ctx.fillStyle='#8a958d';const footerText=businessName+' · Tarjeta digital',footerSize=fitFont(ctx,footerText,850,16,11,'Arial,sans-serif','600');ctx.font='600 '+footerSize+'px Arial,sans-serif';ctx.fillText(footerText,600,1442);
   const filename=button.dataset.filename||'tarjeta-fidelidad.png';
   const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
   if(!blob){showToast('No se pudo preparar la imagen. Inténtalo de nuevo.',true);return;}
   const file=typeof File!=='undefined'?new File([blob],filename,{type:'image/png'}):null;
   if(file&&navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){try{await navigator.share({files:[file],title:'Tarjeta de fidelidad de '+customerName,text:'Guarda o comparte tu tarjeta de '+businessName});return;}catch(e){if(e&&e.name==='AbortError')return;}}
   const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);showToast('Tu tarjeta 4:5 está lista para guardar o imprimir.');
  };
  document.querySelectorAll('.ovf-download-card-image').forEach(button=>button.addEventListener('click',async()=>{if(button.disabled)return;button.disabled=true;const old=button.textContent;button.textContent='Preparando…';try{await buildLoyaltyCard(button);}catch(e){showToast('No se pudo crear la tarjeta. Inténtalo de nuevo.',true);}finally{button.disabled=false;button.textContent=old;}}));

  /* Descargar QR: funciona en la tarjeta del cliente, en Ajustes y en la vista de registro público */
  document.querySelectorAll('.ovf-download-qr').forEach(btn=>btn.addEventListener('click',()=>{
   const box=btn.closest('.ovf-customer-qr,.ovf-registration-qr,.ovf-signup-view,.ovf-qrbox')||document;
   const qr=box.querySelector('.ovf-qr');if(!qr)return;
   const size=parseInt(btn.dataset.downloadSize||'1080',10),source=qr.dataset.qr;
   let output=null;
   if(source&&window.QRCode){
    const render=document.createElement('div');render.style.cssText='position:fixed;left:-10000px;top:0;width:'+size+'px;height:'+size+'px;';document.body.appendChild(render);
    try{new QRCode(render,{text:source,width:size,height:size,correctLevel:QRCode.CorrectLevel.M});output=render.querySelector('canvas');if(!output){const image=render.querySelector('img');if(image&&image.complete){output=document.createElement('canvas');output.width=size;output.height=size;output.getContext('2d').drawImage(image,0,0,size,size);}}}catch(e){}
    render.remove();
   }
   if(!output){const original=qr.querySelector('canvas'),image=qr.querySelector('img');if(!original&&!image)return;output=document.createElement('canvas');output.width=size;output.height=size;const ctx=output.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.drawImage(original||image,0,0,size,size);}
   const url=output.toDataURL('image/png');if(!url)return;
   const a=document.createElement('a');a.href=url;a.download=btn.dataset.filename||'qr-fidelidad.png';document.body.appendChild(a);a.click();a.remove();
  }));

  /* Guardar / compartir el enlace de la tarjeta (si el cliente lo pierde, pierde su tarjeta) */
  document.querySelectorAll('.ovf-share-card,.ovf-share-referral').forEach(btn=>btn.addEventListener('click',async()=>{
   const url=btn.dataset.url||location.href,title=btn.dataset.title||document.title;
   if(navigator.share){try{await navigator.share({title,url});return;}catch(e){if(e&&e.name==='AbortError')return;}}
   try{await navigator.clipboard.writeText(url);}catch(e){window.prompt(title,url);return;}
   const old=btn.textContent;btn.textContent=btn.dataset.done||'✓';setTimeout(()=>btn.textContent=old,2200);
  }));
  document.querySelectorAll('.ovf-copy-referral').forEach(btn=>btn.addEventListener('click',async()=>{
   const code=btn.dataset.code||'';try{await navigator.clipboard.writeText(code);}catch(e){window.prompt('Código de invitación',code);return;}
   const old=btn.textContent;btn.textContent=btn.dataset.done||'Copiado ✓';setTimeout(()=>btn.textContent=old,2200);
  }));
  document.querySelectorAll('[data-referral-amount]').forEach(input=>{
   const offer=input.closest('label')?.querySelector('[data-referral-rate]'),out=offer?.querySelector('[data-referral-estimate]');if(!offer||!out)return;
   const rate=parseFloat(offer.dataset.referralRate||'0'),money=n=>Number(n||0).toLocaleString('es-MX',{style:'currency',currency:'MXN'});
   const update=()=>{const gross=Math.max(0,parseFloat(input.value||'0')||0),discount=Math.round(gross*rate)/100;out.textContent='Descuento estimado: '+money(discount)+' · total después del descuento: '+money(gross-discount);};
   input.addEventListener('input',update);update();
  });

  /* Beneficios: vista previa de "una vez" / "cíclico" */
  document.querySelectorAll('.ovf-new-rule').forEach(form=>{
   const out=form.querySelector('.ovf-rule-preview'),m=form.querySelector('[name="milestone"]');if(!out||!m)return;
   const render=()=>{const n=Math.max(1,parseInt(m.value||'1',10)),cyc=(form.querySelector('[name="repeats"]:checked')||{}).value==='1';
    out.textContent=cyc?out.dataset.cyclic.replace('%1$d',n).replace('%2$d',n*2).replace('%3$d',n*3):out.dataset.once.replace('%d',n);};
   form.addEventListener('input',render);form.addEventListener('change',render);render();
  });
  document.querySelectorAll('.ovf-rule-card').forEach(card=>{
   const sel=card.querySelector('.ovf-repeat-select'),k=card.querySelector('.ovf-rule-kicker');if(!sel||!k)return;
   sel.addEventListener('change',()=>{const c=sel.value==='1';k.textContent=c?k.dataset.cyclic:k.dataset.once;card.classList.toggle('is-cyclic',c);});
  });

  /* Guardar beneficios solo cuando hay cambios */
  document.querySelectorAll('.ovf-rules-form').forEach(form=>{
   const btn=form.querySelector('.ovf-save-dirty'),hint=form.querySelector('.ovf-save-hint');if(!btn)return;
   const dirty=()=>{btn.disabled=false;if(hint)hint.textContent=D.unsaved||'Tienes cambios sin guardar.';};
   form.querySelectorAll('input,textarea,select').forEach(el=>{el.addEventListener('input',dirty);el.addEventListener('change',dirty);});
  });

  /* Evitar doble envío (doble toque en "Registrar compra") */
  document.querySelectorAll('.ovf-v02 form[method="post"]').forEach(f=>f.addEventListener('submit',e=>{
   setTimeout(()=>{if(e.defaultPrevented)return;f.querySelectorAll('button:not([type="button"])').forEach(b=>{b.disabled=true;b.classList.add('is-busy');});},0);
  }));

  initScanner();
 });

 /* ---------- Confirmación antes de acciones que no se deshacen (registrar compra, canjear) ----------
    Formularios con data-ovf-confirm='{"title","text","ok","cancel","icon"}'. Evita registros por un toque accidental. */
 const esc0=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function ovfConfirm(o){return new Promise(resolve=>{
  const root=document.createElement('div');root.className='ovf-sheet';root.setAttribute('role','alertdialog');root.setAttribute('aria-modal','true');
  root.innerHTML='<div class="ovf-sheet-back"></div><div class="ovf-sheet-card" tabindex="-1">'+(o.icon?'<div class="ovf-sheet-icon is-ask">'+esc0(o.icon)+'</div>':'')+'<h3>'+esc0(o.title)+'</h3>'+(o.text?'<p>'+esc0(o.text)+'</p>':'')+
   '<div class="ovf-sheet-actions"><button type="button" class="ovf-app-secondary" data-no>'+esc0(o.cancel||'Cancelar')+'</button><button type="button" class="ovf-app-primary" data-yes>'+esc0(o.ok||'Aceptar')+'</button></div></div>';
  (document.querySelector('.ovf-v02')||document.body).appendChild(root);
  const done=v=>{root.classList.remove('is-open');document.documentElement.classList.remove('ovf-noscroll');document.removeEventListener('keydown',key);setTimeout(()=>root.remove(),250);resolve(v);};
  const key=e=>{if(e.key==='Escape')done(false);};
  root.querySelector('[data-no]').addEventListener('click',()=>done(false));
  root.querySelector('.ovf-sheet-back').addEventListener('click',()=>done(false));
  root.querySelector('[data-yes]').addEventListener('click',()=>done(true));
  document.addEventListener('keydown',key);
  requestAnimationFrame(()=>{root.classList.add('is-open');document.documentElement.classList.add('ovf-noscroll');root.querySelector('[data-yes]').focus();});
 });}
 window.ovfConfirm=ovfConfirm;
 document.addEventListener('submit',async e=>{
  const f=e.target;if(!f.matches||!f.matches('form[data-ovf-confirm]'))return;
  if(f.dataset.ovfConfirmed==='1'){delete f.dataset.ovfConfirmed;return;}
  e.preventDefault();e.stopImmediatePropagation();
  let o={};try{o=JSON.parse(f.dataset.ovfConfirm);}catch(x){}
  const btn=e.submitter||f.querySelector('button[name]');
  if(await ovfConfirm(o)){
   f.dataset.ovfConfirmed='1';
   if(f.requestSubmit){f.requestSubmit(btn&&btn.form===f?btn:undefined);}
   else{if(btn&&btn.name){const h=document.createElement('input');h.type='hidden';h.name=btn.name;h.value=btn.value||'1';f.appendChild(h);}f.submit();}
  }
 },true);

 /* ---------- Escáner: BarcodeDetector nativo y jsQR como respaldo (iPhone/Safari, Firefox) ----------
    1.0: al leer un QR se abre una ventana para confirmar la compra; se registra sin salir del escáner. */
 function initScanner(){
  const start=document.getElementById('ovf-start-camera'),stop=document.getElementById('ovf-stop-camera'),box=document.getElementById('ovf-camera');
  if(!start||!box)return;
  const L=D.t||{},video=box.querySelector('video'),status=document.getElementById('ovf-camera-status'),errEl=document.getElementById('ovf-camera-error');
  let stream=null,running=false,detector=null,canvas=null,ctx=null,lastRaw='',lastAt=0,busy=false,lookupVia='qr';

  const showError=msg=>{if(errEl){errEl.textContent=msg;errEl.hidden=false;}};
  const loadJsQR=()=>new Promise((res,rej)=>{if(window.jsQR)return res();const s=document.createElement('script');s.src=D.jsqr;s.onload=res;s.onerror=rej;document.head.appendChild(s);});
  const stopAll=()=>{running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;box.hidden=true;box.classList.remove('active');start.hidden=false;if(stop)stop.hidden=true;};
  const detect=async()=>{
   if(detector){const codes=await detector.detect(video);return codes.length?codes[0].rawValue:null;}
   if(!video.videoWidth)return null;
   canvas=canvas||document.createElement('canvas');ctx=ctx||canvas.getContext('2d',{willReadFrequently:true});
   const w=Math.min(640,video.videoWidth),h=Math.round(video.videoHeight*w/video.videoWidth);
   canvas.width=w;canvas.height=h;ctx.drawImage(video,0,0,w,h);
   const r=window.jsQR(ctx.getImageData(0,0,w,h).data,w,h,{inversionAttempts:'dontInvert'});return r?r.data:null;
  };
  const tick=async()=>{if(!running)return;try{const raw=await detect();if(raw&&!busy&&!(raw===lastRaw&&Date.now()-lastAt<4000)){lastRaw=raw;lastAt=Date.now();onCode(raw);}}catch(e){}if(running)setTimeout(()=>requestAnimationFrame(tick),120);};

  /* ---- Ventana de confirmación ---- */
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=(str,...a)=>{let k=0;return String(str||'').replace(/%(\d\$)?[sd]/g,(m,pos)=>esc(pos?a[parseInt(pos)-1]:a[k++]));};
  const money=n=>Number(n||0).toLocaleString('es-MX',{style:'currency',currency:'MXN'});
  let sheet=null;
  const sheetEl=()=>{
   if(sheet)return sheet;
   sheet=document.createElement('div');sheet.className='ovf-sheet';sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');
   sheet.innerHTML='<div class="ovf-sheet-back"></div><div class="ovf-sheet-card" tabindex="-1"></div>';
   (document.querySelector('.ovf-v02')||document.body).appendChild(sheet);
   sheet.querySelector('.ovf-sheet-back').addEventListener('click',()=>{if(!busy)closeSheet();});
   return sheet;
  };
  const openSheet=html=>{const s=sheetEl();s.querySelector('.ovf-sheet-card').innerHTML=html;s.classList.add('is-open');document.documentElement.classList.add('ovf-noscroll');};
  const closeSheet=()=>{if(sheet){sheet.classList.remove('is-open');document.documentElement.classList.remove('ovf-noscroll');}busy=false;lastAt=Date.now();if(status)status.textContent=L.scanning||T.scanning||'';};
  const post=(action,data)=>{const fd=new FormData();fd.append('action',action);fd.append('nonce',D.nonce||'');Object.keys(data).forEach(k=>fd.append(k,data[k]));
   return fetch(D.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).catch(()=>({success:false,data:{message:L.net}}));};
  const head=c=>'<div class="ovf-sheet-client"><i>'+esc(c.initial)+'</i><div><b>'+esc(c.name)+'</b><span>'+esc(c.contact)+'</span></div><strong>'+c.visits+'<small>'+esc(c.visits===1?L.purchase1:L.purchases)+'</small></strong></div>';
  const rewardsList=c=>!c.available||!c.available.length?'':'<div class="ovf-sheet-rewards"><small>'+esc(L.available)+'</small>'+c.available.map(r=>'<div class="ovf-sheet-reward"><i>★</i><div><b>'+esc(r.title)+'</b>'+(r.expires?'<span>'+esc(r.expires)+'</span>':'')+'</div><button type="button" class="ovf-app-secondary" data-redeem="'+r.id+'" data-title="'+esc(r.title)+'">'+esc(L.redeem)+'</button></div>').join('')+'</div>';
  const errorView=msg=>openSheet('<div class="ovf-sheet-icon is-error">!</div><h3>'+esc(L.notFound)+'</h3><p>'+esc(msg)+'</p><div class="ovf-sheet-actions one"><button type="button" class="ovf-app-primary" data-act="close">'+esc(L.retry)+'</button></div>');

  const confirmView=c=>{
   openSheet('<p class="ovf-sheet-kicker">'+esc(L.confirmTitle)+'</p>'+head(c)+(c.next?'<p class="ovf-sheet-next">'+fmt(L.next,c.next.title,c.next.left)+'</p>':'')+(!c.active?'<p class="ovf-sheet-warn">'+esc(L.inactive)+'</p>':'')+
    (c.active?'<label class="ovf-sale-field"><b>'+esc(L.amountLabel||'Importe original del ticket (MXN)')+' <em aria-hidden="true">*</em></b><input type="number" min="0.01" max="10000000" step="0.01" value="" required inputmode="decimal" data-sale-amount><small>'+esc(L.amountHelp||'Captura el total antes del descuento; el beneficio se registra aquí y tú lo aplicas manualmente en caja.')+'</small></label>':'')+
    (c.referral_discount_percent>0?'<div class="ovf-referral-offer"><b>'+esc(L.referralDiscount||'Descuento de bienvenida disponible')+' · '+esc(c.referral_discount_percent)+'%</b><span data-referral-preview>'+esc('Confirma su uso antes de registrar la primera compra.')+'</span></div>':'')+
    (c.card_url?'<button type="button" class="ovf-app-secondary ovf-share-customer-card" data-card-url="'+esc(c.card_url)+'" data-customer-name="'+esc(c.name)+'">↗ '+esc('Compartir tarjeta con el cliente')+'</button>':'')+
    '<div class="ovf-sheet-actions"><button type="button" class="ovf-app-secondary" data-act="close">'+esc(L.cancel)+'</button><button type="button" class="ovf-app-primary" data-act="buy"'+(c.active?'':' disabled')+'>＋ '+esc(L.confirm)+'</button></div>'+
    (c.available&&c.available.length?rewardsList(c):''));
   bind(c);
   const b=sheet.querySelector('[data-act="buy"]');if(b)b.focus();
  };
  const doneView=c=>{
   openSheet('<div class="ovf-sheet-icon">✓</div><h3>'+esc(L.done)+'</h3><p>'+fmt(L.nowHas,c.visits)+'</p>'+
    (c.purchase&&c.purchase.receipt_number?'<p class="ovf-sheet-unlock">'+esc(L.receiptLabel||'Ticket')+': '+esc(c.purchase.receipt_number)+'</p>':'')+
    (c.purchase&&c.purchase.referral_discount_available&&!c.purchase.referral_discount_applied?'<p class="ovf-sheet-alert">El descuento no se aplicó. Al registrar esta compra termina la vigencia del beneficio de primera compra.</p>':'')+
    (c.purchase&&c.purchase.discount_amount>0?'<p class="ovf-sheet-unlock">'+esc(L.ticket||'Ticket')+': '+esc(money(c.purchase.gross_amount))+' · '+esc(L.referralDiscount||'Descuento')+': −'+esc(money(c.purchase.discount_amount))+' · '+esc(L.totalAfterDiscount||'Total después del descuento')+': '+esc(money(c.purchase.sale_amount))+'</p>':'')+
    (c.unlocked&&c.unlocked.length?'<p class="ovf-sheet-unlock">'+fmt(L.unlocked,c.unlocked.join(', '))+'</p>':'')+
    (c.redeemed?'<p class="ovf-sheet-unlock">'+fmt(L.redeemed,c.redeemed)+'</p>':'')+
    (c.card_url?'<button type="button" class="ovf-app-secondary ovf-share-customer-card" data-card-url="'+esc(c.card_url)+'" data-customer-name="'+esc(c.name)+'">↗ '+esc('Compartir tarjeta con el cliente')+'</button>':'')+'<div class="ovf-sheet-actions"><a class="ovf-app-secondary" href="'+esc(c.profile)+'">'+esc(L.profile)+'</a><button type="button" class="ovf-app-primary" data-act="close">'+esc(L.scanNext)+'</button></div>'+rewardsList(c));
   bind(c);
  };
  const bind=c=>{
   sheet.querySelectorAll('[data-act="close"]').forEach(x=>x.addEventListener('click',closeSheet));
   const saleField=sheet.querySelector('[data-sale-amount]'),preview=sheet.querySelector('[data-referral-preview]');
   if(saleField&&preview){const updatePreview=()=>{const gross=Math.max(0,parseFloat(saleField.value||'0')||0),discount=Math.round(gross*c.referral_discount_percent)/100;const due=Math.max(0,gross-discount);preview.textContent=(L.discountValue||'Descuento estimado: %1$s · total: %2$s').replace('%1$s',money(discount)).replace('%2$s',money(due));};saleField.addEventListener('input',updatePreview);updatePreview();}
   const buy=sheet.querySelector('[data-act="buy"]');
   if(buy)buy.addEventListener('click',()=>{
    const field=sheet.querySelector('[data-sale-amount]');const amount=parseFloat(String(field?field.value:'').replace(',','.'));
    if(!Number.isFinite(amount)||amount<=0||amount>10000000){alertIn(L.amountRequired||'Captura un importe mayor que $0.00 para registrar la compra.');if(field)field.focus();return;}
    const actions=buy.closest('.ovf-sheet-actions');if(!actions)return;
    const step=document.createElement('section');step.className='ovf-receipt-step';
    const cancelStep=()=>{step.remove();actions.hidden=false;};
    const finishPurchase=(amount,receiptNumber)=>{if(c.referral_discount_percent>0){step.innerHTML='<p><b>¿Aplicaste el descuento de bienvenida en caja?</b></p><p>El cliente tiene '+esc(c.referral_discount_percent)+'% disponible para esta primera compra. Confirma solo después de aplicarlo manualmente.</p><div class="ovf-sheet-actions"><button type="button" class="ovf-app-secondary" data-discount-choice="cancel">'+esc(L.cancel)+'</button><button type="button" class="ovf-app-secondary" data-discount-choice="no">No, registrar sin descuento</button><button type="button" class="ovf-app-primary" data-discount-choice="yes">Sí, aplicado en caja</button></div>';step.querySelector('[data-discount-choice="cancel"]').onclick=cancelStep;step.querySelector('[data-discount-choice="yes"]').onclick=()=>submitPurchase(amount,receiptNumber,true);step.querySelector('[data-discount-choice="no"]').onclick=()=>submitPurchase(amount,receiptNumber,false);}else submitPurchase(amount,receiptNumber,false);};
    const drawQuestion=()=>{step.innerHTML='<p>'+esc(L.receiptAsk||'¿Introducir número de ticket?')+'</p><div class="ovf-sheet-actions"><button type="button" class="ovf-app-secondary" data-receipt-choice="yes">'+esc(L.yes||'Sí')+'</button><button type="button" class="ovf-app-primary" data-receipt-choice="no">'+esc(L.no||'No, continuar')+'</button><button type="button" class="ovf-app-secondary" data-receipt-choice="cancel">'+esc(L.cancel)+'</button></div>';step.querySelector('[data-receipt-choice="cancel"]').onclick=cancelStep;step.querySelector('[data-receipt-choice="yes"]').onclick=drawTicket;step.querySelector('[data-receipt-choice="no"]').onclick=()=>finishPurchase(amount,'');};
    const drawTicket=()=>{step.innerHTML='<label class="ovf-sale-field"><b>'+esc(L.receiptLabel||'Número de ticket')+'</b><input type="text" maxlength="80" placeholder="'+esc(L.receiptPlaceholder||'Ej. A-1048')+'" data-receipt-number required><small>'+esc(L.receiptHint||'Escribe el número que aparece en el comprobante.')+'</small></label><div class="ovf-sheet-actions"><button type="button" class="ovf-app-secondary" data-receipt-choice="back">'+esc(L.back||'Volver')+'</button><button type="button" class="ovf-app-primary" data-receipt-choice="save">'+esc(L.confirm||'Registrar compra')+'</button></div>';const input=step.querySelector('[data-receipt-number]');input.focus();step.querySelector('[data-receipt-choice="back"]').onclick=drawQuestion;step.querySelector('[data-receipt-choice="save"]').onclick=()=>{const receiptNumber=input.value.trim();if(!receiptNumber){alertIn(L.receiptRequired||'Escribe el número de ticket o vuelve y elige No.');input.focus();return;}finishPurchase(amount,receiptNumber);};};
    const submitPurchase=async(amount,receiptNumber,applyDiscount,force=false)=>{busy=true;step.querySelectorAll('button').forEach(button=>button.disabled=true);let r=await post('ovf_scan_purchase',{code:'OVF:'+c.token,via:lookupVia,sale_amount:amount,receipt_number:receiptNumber,apply_referral_discount:applyDiscount?1:0,force:force?1:0});if(!r.success&&r.data&&r.data.duplicate&&!force&&window.confirm(r.data.message+'\n\n'+L.dup+'?')){busy=false;return submitPurchase(amount,receiptNumber,applyDiscount,true);}busy=false;if(r.success){if(navigator.vibrate)navigator.vibrate([40,40,40]);doneView(r.data);}else{step.querySelectorAll('button').forEach(button=>button.disabled=false);alertIn(r.data&&r.data.message);}};
    actions.hidden=true;actions.after(step);drawQuestion();
   });
   sheet.querySelectorAll('[data-redeem]').forEach(btn=>btn.addEventListener('click',async()=>{
    if(!window.confirm(fmt(L.redeemConfirm,btn.dataset.title).replace(/&quot;/g,'"').replace(/&amp;/g,'&')))return;
    busy=true;btn.disabled=true;btn.classList.add('is-busy');
    const r=await post('ovf_scan_redeem',{code:'OVF:'+c.token,via:lookupVia,reward_id:btn.dataset.redeem});busy=false;
    if(r.success)doneView(Object.assign(r.data,{unlocked:[]}));else{btn.disabled=false;btn.classList.remove('is-busy');alertIn(r.data&&r.data.message);}
   }));
  };
  const alertIn=msg=>{let a=sheet.querySelector('.ovf-sheet-alert');if(!a){a=document.createElement('p');a.className='ovf-sheet-alert';sheet.querySelector('.ovf-sheet-card').prepend(a);}a.textContent=msg||L.net;};

  const onCode=async raw=>{
   busy=true;if(navigator.vibrate)navigator.vibrate(60);
   if(!D.nonce){ // sin sesión del equipo: comportamiento anterior (abrir ficha)
    let token=raw;if(/^OVF:/i.test(raw))token=raw.slice(4);else{try{const u=new URL(raw);token=u.searchParams.get('ovf')||raw;}catch(e){}}
    const u=new URL((D.scanner||location.href).split('#')[0],location.href);u.searchParams.delete('view');u.searchParams.set('ovf',token);u.searchParams.set('source','qr');location.href=u.toString();return;
   }
   if(status)status.textContent='…';
   const r=await post('ovf_scan_lookup',{code:raw});
   if(r.success)confirmView(r.data);else errorView((r.data&&r.data.message)||L.net);
  };

  const open=async()=>{
   if(errEl)errEl.hidden=true;
   if(!window.isSecureContext){showError(T.https||'HTTPS requerido');return;}
   try{
    if('BarcodeDetector' in window){try{detector=new BarcodeDetector({formats:['qr_code']});}catch(e){detector=null;}}
    if(!detector)await loadJsQR();
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
    video.srcObject=stream;box.hidden=false;await video.play();box.classList.add('active');
    start.hidden=true;if(stop)stop.hidden=false;if(status)status.textContent=T.scanning||'';
    running=true;tick();
   }catch(err){stopAll();showError(T.noCamera||'No fue posible abrir la cámara.');}
  };
  // Modo alternativo: consulta por WhatsApp, luego reutiliza exactamente la confirmación del QR.
  const tabs=document.querySelectorAll('[data-ovf-scan-tab]');
  const phoneForm=document.getElementById('ovf-whatsapp-form');
  const phoneResults=document.getElementById('ovf-whatsapp-results');
  const phoneInput=document.getElementById('ovf-whatsapp-number');
  const switchTab=mode=>{
   if(busy)return;
   tabs.forEach(btn=>{const active=btn.dataset.ovfScanTab===mode;btn.classList.toggle('is-active',active);btn.setAttribute('aria-selected',String(active));});
   ['qr','whatsapp'].forEach(kind=>{const panel=document.getElementById('ovf-method-'+kind);if(panel)panel.hidden=(kind!==mode);});
   if(mode==='whatsapp'){stopAll();if(phoneInput)phoneInput.focus();}
  };
  tabs.forEach(btn=>btn.addEventListener('click',()=>switchTab(btn.dataset.ovfScanTab)));
  if(phoneForm&&phoneResults){
   const message=txt=>{phoneResults.replaceChildren();const el=document.createElement('p');el.className='ovf-phone-message';el.textContent=txt;phoneResults.appendChild(el);};
   phoneForm.addEventListener('submit',async e=>{
    e.preventDefault();if(busy)return;
    let digits=phoneInput.value.replace(/\D/g,'');
    if(digits.length===12&&digits.startsWith('52'))digits=digits.slice(2);
    if(digits.length===13&&digits.startsWith('521'))digits=digits.slice(3);
    if(!/^\d{10}$/.test(digits)){message('Escribe un número de WhatsApp válido de 10 dígitos.');phoneInput.focus();return;}
    const submit=phoneForm.querySelector('[type="submit"]');submit.disabled=true;message('Buscando cliente…');
    try{
     const response=await post('ovf_scan_phone_search',{phone:digits});
     if(!response.success){message(response.data&&response.data.message||'No se pudo buscar al cliente.');return;}
     const clients=Array.isArray(response.data)?response.data:[];
     phoneResults.replaceChildren();
     if(!clients.length){message('No encontramos una tarjeta con ese WhatsApp en este negocio. Verifica el número registrado.');return;}
     const intro=document.createElement('p');intro.className='ovf-phone-message';intro.textContent=clients.length===1?'Confirma que sea el cliente correcto:':'Selecciona al cliente correcto:';phoneResults.appendChild(intro);
     clients.forEach(client=>{
      const button=document.createElement('button');button.type='button';button.className='ovf-phone-client';
      const identity=document.createElement('span');const name=document.createElement('strong');name.textContent=client.name;
      const contact=document.createElement('small');contact.textContent=client.contact+(client.active?'':' · Tarjeta inactiva');identity.append(name,contact);
      const action=document.createElement('b');action.textContent='Seleccionar';button.append(identity,action);
      button.addEventListener('click',async()=>{
       if(busy)return;busy=true;lookupVia='whatsapp';button.disabled=true;
       const found=await post('ovf_scan_lookup',{code:'OVF:'+client.token,via:'whatsapp'});
       busy=false;
       if(found.success)confirmView(found.data);else errorView(found.data&&found.data.message||'No se pudo abrir la tarjeta.');
       button.disabled=false;
      });
      phoneResults.appendChild(button);
     });
    }catch(err){message('No se pudo conectar. Inténtalo nuevamente.');}
    finally{submit.disabled=false;}
   });
  }
  start.addEventListener('click',open);
  if(stop)stop.addEventListener('click',stopAll);
  window.addEventListener('pagehide',stopAll);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sheet&&sheet.classList.contains('is-open')&&!busy)closeSheet();});
  // Abre la cámara automáticamente al entrar a "Escanear" (si el navegador ya dio permiso, no pregunta de nuevo).
  if(box.dataset.autostart==='1')open();
 }
})();

(function(){
 function promoScroll(track,target,reduce){
  if(track._ovfPromoRaf)cancelAnimationFrame(track._ovfPromoRaf);
  if(track._ovfPromoResetTimer){clearTimeout(track._ovfPromoResetTimer);track._ovfPromoResetTimer=0;}
  if(reduce){track.scrollLeft=target;return;}
  var from=track.scrollLeft,delta=target-from,duration=1000,start=null;
  function frame(now){if(start===null)start=now;var t=Math.min(1,(now-start)/duration),ease=t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;track.scrollLeft=from+delta*ease;if(t<1)track._ovfPromoRaf=requestAnimationFrame(frame);else track._ovfPromoRaf=0;}
  track._ovfPromoRaf=requestAnimationFrame(frame);
 }
 document.addEventListener('click',function(e){var b=e.target.closest('.ovf-promo-dots button');if(!b)return;var box=b.closest('.ovf-promo-slider'),track=box&&box.querySelector('.ovf-promo-track');if(!track)return;var idx=Array.prototype.indexOf.call(b.parentNode.children,b),reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;promoScroll(track,idx*track.clientWidth,reduce);});
 document.querySelectorAll('.ovf-promo-slider').forEach(function(box){
  var track=box.querySelector('.ovf-promo-track'),dots=box.querySelector('.ovf-promo-dots'),slides=track?Array.prototype.slice.call(track.querySelectorAll('.ovf-promo-slide')):[];
  if(!dots||slides.length<2)return;
  var count=slides.length,timer=null,reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches,clone=slides[0].cloneNode(true);
  clone.setAttribute('aria-hidden','true');clone.querySelectorAll('[id]').forEach(function(el){el.removeAttribute('id');});track.appendChild(clone);
  slides.forEach(function(_,i){var d=document.createElement('button');d.type='button';d.setAttribute('aria-label','Mostrar promoción '+(i+1));d.setAttribute('aria-pressed',i===0?'true':'false');if(i===0)d.className='is-active';dots.appendChild(d);});
  function activeIndex(){return Math.max(0,Math.min(count-1,Math.round(track.scrollLeft/Math.max(1,track.clientWidth))));}
  function refreshDots(){var i=activeIndex();dots.querySelectorAll('button').forEach(function(d,n){d.classList.toggle('is-active',i===n);d.setAttribute('aria-pressed',i===n?'true':'false');});}
  function stop(){if(timer){window.clearInterval(timer);timer=null;}}
  function start(){stop();if(reduce||document.hidden)return;timer=window.setInterval(function(){var next=activeIndex()+1;if(next<count){promoScroll(track,next*track.clientWidth,reduce);}else{promoScroll(track,count*track.clientWidth,false);track._ovfPromoResetTimer=setTimeout(function(){track.scrollLeft=0;refreshDots();track._ovfPromoResetTimer=0;},1050);}},5000);}
  track.addEventListener('scroll',refreshDots,{passive:true});box.addEventListener('mouseenter',stop);box.addEventListener('mouseleave',start);box.addEventListener('focusin',stop);box.addEventListener('focusout',function(e){if(!box.contains(e.relatedTarget))start();});box.addEventListener('touchstart',function(){stop();if(track._ovfPromoRaf)cancelAnimationFrame(track._ovfPromoRaf);if(track._ovfPromoResetTimer){clearTimeout(track._ovfPromoResetTimer);track._ovfPromoResetTimer=0;}},{passive:true});box.addEventListener('touchend',start,{passive:true});document.addEventListener('visibilitychange',function(){if(document.hidden)stop();else start();});start();
 });
})();

/* Convierte avisos del plugin y de la app en toasts accesibles y descartables. */
(function(){
 function mount(){var nodes=document.querySelectorAll('.ovf-admin .ovf-notice,.ovf-admin .notice,.ovf-v02 .ovf-app-alert,.ovf-v02 .ovf-flash');if(!nodes.length)return;var region=document.querySelector('.ovf-toast-region');if(!region){region=document.createElement('div');region.className='ovf-toast-region';region.setAttribute('aria-live','polite');region.setAttribute('aria-relevant','additions');document.body.appendChild(region);}nodes.forEach(function(node){if(node.dataset.ovfToast==='1')return;node.dataset.ovfToast='1';var isError=node.classList.contains('error')||node.classList.contains('notice-error');var toast=document.createElement('div');toast.className='ovf-toast'+(isError?' is-error':'');toast.setAttribute('role',isError?'alert':'status');var content=document.createElement('div');while(node.firstChild)content.appendChild(node.firstChild);toast.appendChild(content);var close=document.createElement('button');close.type='button';close.className='ovf-toast-close';close.setAttribute('aria-label','Cerrar notificación');close.textContent='×';close.addEventListener('click',function(){toast.classList.add('is-leaving');setTimeout(function(){toast.remove();},220);});toast.appendChild(close);region.appendChild(toast);node.remove();if(!isError)setTimeout(function(){if(!toast.isConnected)return;toast.classList.add('is-leaving');setTimeout(function(){toast.remove();},220);},6000);});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
 var observer=new MutationObserver(function(){mount();});observer.observe(document.documentElement,{childList:true,subtree:true});
})();

/* AJAX autocompletado de negocios del panel de administración. */
(function(){document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('[data-ovf-business-search]').forEach(function(form){var input=form.querySelector('input[name="business_search"]'),box=form.querySelector('[data-ovf-business-results]');if(!input||!box)return;var timer=null,controller=null,seq=0;function hide(){box.hidden=true;box.replaceChildren();}input.addEventListener('input',function(){clearTimeout(timer);if(controller)controller.abort();var q=input.value.trim(),id=++seq;if(q.length<2){hide();return;}timer=setTimeout(async function(){if(!window.OVF_DATA||!OVF_DATA.ajax||!OVF_DATA.businessSearchNonce){hide();return;}controller=new AbortController();var body=new URLSearchParams({action:'ovf_business_suggest',nonce:OVF_DATA.businessSearchNonce,q:q});try{var res=await fetch(OVF_DATA.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),signal:controller.signal});var data=await res.json();if(id!==seq)return;box.replaceChildren();var items=data&&data.success?data.data:[];if(!items.length){var empty=document.createElement('div');empty.className='ovf-search-empty';empty.textContent='No encontramos negocios.';box.appendChild(empty);}else items.forEach(function(item){var a=document.createElement('a');a.className='ovf-search-suggestion';a.href=item.url;var initial=document.createElement('span');initial.className='ovf-search-avatar';initial.textContent=(item.name||'?').trim().charAt(0).toUpperCase();var copy=document.createElement('span');copy.className='ovf-search-copy';var name=document.createElement('strong');name.textContent=item.name||'';var detail=document.createElement('small');detail.textContent=(item.email||'')+' · '+(item.status==='active'?'Activo':'Pausado');copy.append(name,detail);a.append(initial,copy);box.appendChild(a);});box.hidden=false;}catch(e){if(e.name!=='AbortError')hide();}},220);});document.addEventListener('click',function(e){if(!form.contains(e.target))hide();});});});})();

/* Mantiene válido el campo de bono cuando se alterna entre puntos y sellos. */
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('select[name="referral_bonus_type"]').forEach(function(select){var form=select.closest('form'),amount=form&&form.querySelector('[data-referral-bonus-amount]');if(!amount)return;function sync(){if(select.value==='stamps'){amount.max='2';if(Number(amount.value)>2)amount.value='2';amount.setAttribute('aria-label','Cantidad de sellos de invitación, máximo 2');}else{amount.max='100000';amount.setAttribute('aria-label','Cantidad de puntos de invitación');}}select.addEventListener('change',sync);sync();});});
