(function(){
  'use strict';
  document.addEventListener('click',function(event){
    var button=event.target.closest('[data-generate-password]');
    if(!button)return;
    var input=button.closest('.ovf-field-password')&&button.closest('.ovf-field-password').querySelector('input');
    if(!input)return;
    var alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
    if(!window.crypto||!window.crypto.getRandomValues){input.value='';input.placeholder='Se generará una contraseña segura al crear el negocio';return;}
    var bytes=new Uint8Array(18);window.crypto.getRandomValues(bytes);
    var value='';for(var j=0;j<bytes.length;j++)value+=alphabet[bytes[j]%alphabet.length];
    input.value=value;input.focus();input.select();button.textContent='Lista ✓';
  });
  var pinForm=document.querySelector('[data-ovf-pin-form]');
  if(pinForm){
    var digits=Array.prototype.slice.call(pinForm.querySelectorAll('[data-pin-digit]'));
    var hidden=pinForm.querySelector('[data-pin-value]');
    digits.forEach(function(input,index){
      input.addEventListener('input',function(){
        var chars=input.value.replace(/\D/g,'');
        if(chars.length>1){var all=(input.value+digits.slice(index+1).map(function(el){return el.value;}).join('')).replace(/\D/g,'').slice(0,6);digits.forEach(function(el,i){el.value=all[i]||'';});digits[Math.min(all.length,5)].focus();return;}
        input.value=chars.slice(-1);if(input.value&&digits[index+1])digits[index+1].focus();
      });
      input.addEventListener('keydown',function(event){if(event.key==='Backspace'&&!input.value&&digits[index-1])digits[index-1].focus();if(event.key==='ArrowLeft'&&digits[index-1])digits[index-1].focus();if(event.key==='ArrowRight'&&digits[index+1])digits[index+1].focus();});
      input.addEventListener('paste',function(event){var text=(event.clipboardData||window.clipboardData).getData('text').replace(/\D/g,'').slice(0,6);if(!text)return;event.preventDefault();digits.forEach(function(el,i){el.value=text[i]||'';});digits[Math.min(text.length,5)].focus();});
    });
    pinForm.addEventListener('submit',function(event){hidden.value=digits.map(function(input){return input.value;}).join('');if(hidden.value.length!==6){event.preventDefault();digits.filter(function(input){return !input.value;})[0].focus();}});
    if(digits[0]&&!digits[0].disabled)digits[0].focus({preventScroll:true});
  }
  document.addEventListener('click',function(event){
    var button=event.target.closest('.ovf-reward-edit-toggle');
    if(!button)return;
    var form=document.getElementById(button.getAttribute('data-target'));
    if(form){form.hidden=!form.hidden;button.textContent=form.hidden?'Editar':'Cerrar';}
  });
  var search=document.querySelector('[data-ovf-mobile-search]'), timer;
  if(search&&window.OVF_MOBILE_PORTAL){
    var input=search.querySelector('input[type=search]'),results=search.querySelector('[data-ovf-mobile-results]');
    function close(){results.hidden=true;results.innerHTML='';}
    input.addEventListener('input',function(){window.clearTimeout(timer);var term=input.value.trim();if(term.length<2){close();return;}timer=window.setTimeout(function(){var body=new URLSearchParams({action:'ovf_mobile_business_search',nonce:OVF_MOBILE_PORTAL.nonce,term:term});fetch(OVF_MOBILE_PORTAL.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()}).then(function(r){return r.json();}).then(function(payload){if(!payload.success||!Array.isArray(payload.data)){close();return;}results.innerHTML='';payload.data.forEach(function(item){var a=document.createElement('a');a.href=item.url;a.className='ovf-mobile-search-result';var b=document.createElement('b'),small=document.createElement('small');b.textContent=item.name;small.textContent=(item.email||item.status||'');a.appendChild(b);a.appendChild(small);results.appendChild(a);});results.hidden=payload.data.length===0;}).catch(close);},220);});
    document.addEventListener('click',function(event){if(!search.contains(event.target))close();});
  }
})();
