document.addEventListener('DOMContentLoaded',()=>{
 const A=window.OVF_APP;
 // Cada interfaz registra solo su propio scope: personal o tarjeta individual del cliente.
 if('serviceWorker' in navigator && A && A.isApp){navigator.serviceWorker.register(A.sw,{scope:A.swScope||'/'}).catch(()=>{});}
 if('serviceWorker' in navigator && A && A.isCard && A.cardSw && A.cardScope){navigator.serviceWorker.register(A.cardSw,{scope:A.cardScope}).catch(()=>{});}
 let installEvent=null;const btn=document.getElementById('ovf-install-app');
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEvent=e;if(btn)btn.hidden=false;});
 if(btn)btn.addEventListener('click',async()=>{if(!installEvent)return;installEvent.prompt();await installEvent.userChoice;installEvent=null;btn.hidden=true;});
 const cardBtn=document.getElementById('ovf-card-install'),cardHelp=document.getElementById('ovf-card-install-help');let cardInstallEvent=null;
 window.addEventListener('beforeinstallprompt',e=>{if(!A||!A.isCard)return;e.preventDefault();cardInstallEvent=e;});
 if(cardBtn)cardBtn.addEventListener('click',async()=>{if(cardInstallEvent){cardInstallEvent.prompt();await cardInstallEvent.userChoice;cardInstallEvent=null;if(cardHelp)cardHelp.hidden=false;return;}if(cardHelp)cardHelp.hidden=!cardHelp.hidden;});
 // Cierra el menú de cuenta al tocar fuera.
 document.addEventListener('click',e=>{document.querySelectorAll('.ovf-account[open]').forEach(d=>{if(!d.contains(e.target))d.removeAttribute('open');});});
});

/* 1.0 — Indicador de carga al navegar entre secciones o enviar formularios */
(function(){
 const app=()=>document.querySelector('.ovf-v02');
 let bar=null,veil=null,timer=null;
 const build=()=>{
  if(bar)return;
  bar=document.createElement('div');bar.className='ovf-loadbar';bar.innerHTML='<i></i>';
  veil=document.createElement('div');veil.className='ovf-loadveil';veil.innerHTML='<span class="ovf-spinner" aria-hidden="true"></span>';
  veil.setAttribute('role','status');veil.setAttribute('aria-live','polite');
  const c=app()?getComputedStyle(app()).getPropertyValue('--ovf-primary'):'';if(c){bar.style.setProperty('--ovf-primary',c);veil.style.setProperty('--ovf-primary',c);}
  document.body.appendChild(bar);document.body.appendChild(veil);
 };
 const start=()=>{build();bar.classList.add('is-on');clearTimeout(timer);timer=setTimeout(()=>veil.classList.add('is-on'),180);};
 const stop=()=>{clearTimeout(timer);if(bar){bar.classList.remove('is-on');veil.classList.remove('is-on');}};
 window.OVF_LOADING={start,stop};
 document.addEventListener('click',e=>{
  if(!app()||e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
  const a=e.target.closest('a[href]');if(!a||!a.closest('.ovf-v02'))return;
  if(a.target==='_blank'||a.hasAttribute('download'))return;
  const u=new URL(a.href,location.href);
  if(u.origin!==location.origin||(u.pathname===location.pathname&&u.search===location.search&&u.hash))return;
  if(/\/wp-login\.php|action=logout/.test(u.href)&&!a.classList.contains('ovf-logout'))return;
  // marca al instante la pestaña tocada en el menú inferior
  const nav=a.closest('.ovf-bottom-nav');if(nav){nav.querySelectorAll('a').forEach(x=>x.classList.remove('is-active'));a.classList.add('is-active');}
  start();
 });
 document.addEventListener('submit',e=>{if(!e.defaultPrevented&&e.target.closest('.ovf-v02'))setTimeout(()=>{if(!e.defaultPrevented)start();},0);});
 window.addEventListener('pageshow',stop);
 window.addEventListener('pagehide',()=>setTimeout(stop,0));
})();

/* 1.0 — Al volver con el botón Atrás, el navegador puede mostrar una copia vieja guardada en memoria (bfcache):
   en las páginas del programa se recarga para mostrar compras y beneficios actualizados. */
window.addEventListener('pageshow',e=>{if(e.persisted&&document.querySelector('.ovf-v02,.ovf-app'))location.reload();});

/* Promo campaign card chooser and upload previews. */
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-ovf-segment]').forEach(select=>{
  const form=select.closest('form'),field=form&&form.querySelector('.ovf-client-select-field'),client=form&&form.querySelector('[data-ovf-client-select]');
  const sync=()=>{const show=select.value==='client';if(field)field.hidden=!show;if(client){client.required=show;client.disabled=!show;if(!show)client.value='';}};
  select.addEventListener('change',sync);sync();
 });
 document.querySelectorAll('input[name="promo_images[]"]').forEach(input=>{
  input.addEventListener('change',()=>{
   const form=input.closest('form');let area=form&&form.querySelector('[data-ovf-file-previews]');if(!area)return;area.replaceChildren();
   Array.from(input.files||[]).slice(0,10).forEach(file=>{if(!file.type.startsWith('image/'))return;const img=document.createElement('img');img.alt=file.name;img.title=file.name;img.src=URL.createObjectURL(file);area.appendChild(img);});
  });
 });
});

/* Sugerencias AJAX para clientes y filtros del historial. */
(function(){
 const config=()=>{const app=window.OVF_APP&&window.OVF_APP.search,admin=window.OVF_DATA;return {url:(app&&app.ajax)||(admin&&admin.ajax),nonce:(app&&app.nonce)||(admin&&admin.clientSearchNonce)};};
 document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-ovf-live-search]').forEach(form=>{
   const input=form.querySelector('input[type="search"]'),box=form.querySelector('[data-ovf-search-results]');if(!input||!box)return;
   let timer,controller,seq=0;const context=form.dataset.ovfLiveSearch;
   const close=()=>{box.hidden=true;box.replaceChildren();};
   const message=txt=>{box.replaceChildren();const row=document.createElement('div');row.className='ovf-search-empty';row.textContent=txt;box.append(row);box.hidden=false;};
   const render=items=>{box.replaceChildren();if(!items.length){if(context==='history'){close();return;}message('No encontramos clientes.');return;}
    items.forEach(item=>{const a=document.createElement('a');a.className='ovf-search-suggestion';a.href=item.url;const avatar=document.createElement('span');avatar.className='ovf-search-avatar';avatar.textContent=(item.name||'?').trim().charAt(0).toUpperCase();const copy=document.createElement('span');copy.className='ovf-search-copy';const name=document.createElement('strong');name.textContent=item.name||'';const sub=document.createElement('small');sub.textContent=item.detail||item.contact||'';copy.append(name,sub);const side=document.createElement('span');side.className='ovf-search-meta';side.textContent=context==='history'?'Ver historial':(item.visits+' compras');a.append(avatar,copy,side);box.append(a);});box.hidden=false;
   };
   input.addEventListener('input',()=>{const selected=form.querySelector('[data-ovf-report-client]');if(selected)selected.value='';clearTimeout(timer);if(controller)controller.abort();const q=input.value.trim(),id=++seq;if(q.length<2){close();return;}timer=setTimeout(async()=>{const c=config();if(!c.url||!c.nonce){close();return;}controller=new AbortController();message('Buscando…');try{const body=new URLSearchParams({action:'ovf_client_suggest',nonce:c.nonce,q,context});if(context==='reports'){const from=form.querySelector('[name="from"]'),to=form.querySelector('[name="to"]');if(from)body.append('from',from.value);if(to)body.append('to',to.value);}const res=await fetch(c.url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body,signal:controller.signal});const data=await res.json();if(id!==seq)return;if(!data.success)throw new Error('search');render(Array.isArray(data.data)?data.data:[]);}catch(e){if(e.name!=='AbortError'&&id===seq)message('No se pudo completar la búsqueda.');}},220);});
   input.addEventListener('focus',()=>{if(input.value.trim().length>=2&&!box.children.length)input.dispatchEvent(new Event('input'));});
   input.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
   document.addEventListener('click',e=>{if(!form.contains(e.target))close();});
  });
 });
})();
