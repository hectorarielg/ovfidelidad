<?php
/**
 * OV Fidelidad 1.0 — Compatibilidad con plugins y servidores de caché.
 *
 * Las páginas del programa (Web App, tarjeta del cliente y registro) muestran datos que cambian con
 * cada compra, así que nunca deben guardarse en caché:
 *  1. Se marcan como "no cachear" con las señales que respetan los plugins más usados
 *     (DONOTCACHEPAGE, cabeceras HTTP, LiteSpeed, WP Rocket, SiteGround, Cloudflare, Varnish…).
 *  2. Se purga la copia que ya pudiera existir al activar/actualizar el plugin, al guardar Ajustes
 *     o con el botón "Limpiar caché del programa" (Ajustes → Herramientas).
 */
if (!defined('ABSPATH')) exit;

/** Rutas (sin dominio) de las páginas del programa. */
function ovf_cache_paths() {
	$paths = [];
	foreach (ovf_system_page_ids() as $id) {
		$p = wp_parse_url(get_permalink($id), PHP_URL_PATH);
		if ($p) $paths[] = rtrim($p, '/') . '/';
	}
	return array_values(array_unique($paths));
}

/* ---------- 1. No cachear las páginas del programa ---------- */
add_action('template_redirect', 'ovf_cache_bypass', 0);
function ovf_cache_bypass() {
	$is_endpoint = isset($_GET['ovf_manifest']) || isset($_GET['ovf_sw']) || isset($_GET['ovf_card_manifest']) || isset($_GET['ovf_card_sw']);
	if (!$is_endpoint && !ovf_is_system_page()) return;
	if (!defined('DONOTCACHEPAGE'))   define('DONOTCACHEPAGE', true);   // WP Rocket, W3TC, WP Super Cache, WP Fastest Cache, Breeze, Comet…
	if (!defined('DONOTCACHEDB'))     define('DONOTCACHEDB', true);     // W3 Total Cache (consultas)
	if (!defined('DONOTCACHEOBJECT')) define('DONOTCACHEOBJECT', true); // W3 Total Cache (objetos)
	if (!defined('DONOTROCKETOPTIMIZE')) define('DONOTROCKETOPTIMIZE', true); // WP Rocket: sin minificar/diferir los scripts de la app
	do_action('litespeed_control_set_nocache', 'OV Fidelidad: datos en vivo'); // LiteSpeed Cache
	nocache_headers();
	header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
	header('Pragma: no-cache');
	header('X-LiteSpeed-Cache-Control: no-cache');     // servidores LiteSpeed sin el plugin
	header('X-Accel-Expires: 0');                      // NGINX FastCGI / proxy cache
	header('CDN-Cache-Control: no-store');             // Cloudflare y otros CDN
	header('Surrogate-Control: no-store');             // Varnish / Fastly
}
// SiteGround Optimizer
add_filter('sgo_bypass_cache', function ($bypass) { return ovf_is_system_page() ? true : $bypass; });
// Hummingbird
add_filter('wphb_should_cache_request_pre', function ($cache) { return ovf_is_system_page() ? false : $cache; });

// WP Rocket: excluir las rutas también en su archivo de configuración (atiende antes de cargar WordPress).
add_filter('rocket_cache_reject_uri', function ($uris) {
	foreach (ovf_cache_paths() as $p) $uris[] = $p . '(.*)';
	return $uris;
});
// LiteSpeed Cache: excluir rutas desde su lista de exclusiones.
add_filter('litespeed_cache_exc_uri', function ($uris) { return array_merge((array) $uris, ovf_cache_paths()); });

/* ---------- 2. Purgar lo que ya estuviera en caché ---------- */
/** Limpia la caché de las páginas del programa en los plugins/hostings detectados. Devuelve los nombres detectados. */
function ovf_purge_page_cache() {
	$ids = ovf_system_page_ids(); $urls = array_map('get_permalink', $ids); $hit = [];
	foreach ($ids as $i => $id) {
		$url = $urls[$i];
		if (function_exists('rocket_clean_post'))              { rocket_clean_post($id); $hit['WP Rocket'] = 1; }
		if (function_exists('w3tc_flush_post'))                { w3tc_flush_post($id); $hit['W3 Total Cache'] = 1; }
		if (function_exists('wp_cache_post_change'))           { wp_cache_post_change($id); $hit['WP Super Cache'] = 1; }
		if (defined('LSCWP_V'))                                { do_action('litespeed_purge_post', $id); $hit['LiteSpeed Cache'] = 1; }
		if (function_exists('sg_cachepress_purge_cache'))      { sg_cachepress_purge_cache($url); $hit['SiteGround Optimizer'] = 1; }
		if (class_exists('WpFastestCache') && isset($GLOBALS['wp_fastest_cache']) && method_exists($GLOBALS['wp_fastest_cache'], 'singleDeleteCache')) { $GLOBALS['wp_fastest_cache']->singleDeleteCache(false, $id); $hit['WP Fastest Cache'] = 1; }
		if (class_exists('Cache_Enabler'))                     { do_action('cache_enabler_clear_page_cache_by_post', $id); $hit['Cache Enabler'] = 1; }
		if (defined('WPHB_VERSION'))                           { do_action('wphb_clear_page_cache', $id); $hit['Hummingbird'] = 1; }
		if (class_exists('Nginx_Helper') || defined('NGINX_HELPER_BASEPATH')) { do_action('rt_nginx_helper_purge_url', $url); $hit['Nginx Helper'] = 1; }
	}
	if (class_exists('Breeze_PurgeCache') || defined('BREEZE_VERSION')) { do_action('breeze_clear_all_cache'); $hit['Breeze'] = 1; }
	if (function_exists('rocket_generate_config_file'))      rocket_generate_config_file(); // aplica las exclusiones de WP Rocket
	if (class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall')) { autoptimizeCache::clearall(); $hit['Autoptimize'] = 1; }
	do_action('ovf_purge_page_cache', $ids, $urls); // para hostings/CDN propios
	return array_keys($hit);
}

// Al actualizar el plugin (cambio de versión) se purga una vez.
add_action('admin_init', function () {
	if (!current_user_can('manage_options') || get_option('ovf_cache_purged') === OVF_VERSION) return;
	ovf_purge_page_cache();
	update_option('ovf_cache_purged', OVF_VERSION);
});
// Al guardar Ajustes (logo, colores, páginas…) también.
add_action('update_option_ovf_primary', 'ovf_purge_page_cache');
add_action('update_option_ovf_logo_id', 'ovf_purge_page_cache');

// Botón manual en Ajustes → Herramientas.
add_action('admin_init', function () {
	if (empty($_POST['ovf_purge_cache']) || !current_user_can('manage_options')) return;
	check_admin_referer('ovf_purge_cache');
	$found = ovf_purge_page_cache();
	set_transient('ovf_cache_msg_' . get_current_user_id(), $found, 60);
	wp_safe_redirect(add_query_arg(['page' => 'ov-fidelidad-settings'], admin_url('admin.php')) . '#ovf-tools'); exit;
});
add_action('admin_notices', function () {
	$k = 'ovf_cache_msg_' . get_current_user_id(); $found = get_transient($k);
	if ($found === false) return; delete_transient($k);
	$msg = $found ? sprintf(__('Caché del programa limpiada en: %s. Las páginas de OV Fidelidad ya no se guardan en caché.', 'ov-fidelidad'), implode(', ', $found))
	             : __('No se detectó un plugin de caché compatible. Si tu hosting tiene caché propia (servidor o CDN), excluye las rutas indicadas en Ajustes → Herramientas.', 'ov-fidelidad');
	echo '<div class="notice notice-success is-dismissible"><p><b>OV Fidelidad:</b> ' . esc_html($msg) . '</p></div>';
});

/** Plugins de caché activos (para mostrarlo en Herramientas). */
function ovf_detected_cache() {
	$d = [];
	if (defined('WP_ROCKET_VERSION')) $d[] = 'WP Rocket';
	if (defined('W3TC')) $d[] = 'W3 Total Cache';
	if (function_exists('wp_cache_post_change')) $d[] = 'WP Super Cache';
	if (defined('LSCWP_V')) $d[] = 'LiteSpeed Cache';
	if (function_exists('sg_cachepress_purge_cache') || defined('SiteGround_Optimizer\VERSION')) $d[] = 'SiteGround Optimizer';
	if (class_exists('WpFastestCache')) $d[] = 'WP Fastest Cache';
	if (class_exists('Cache_Enabler')) $d[] = 'Cache Enabler';
	if (defined('WPHB_VERSION')) $d[] = 'Hummingbird';
	if (defined('BREEZE_VERSION')) $d[] = 'Breeze';
	if (defined('NGINX_HELPER_BASEPATH')) $d[] = 'Nginx Helper';
	return $d;
}
