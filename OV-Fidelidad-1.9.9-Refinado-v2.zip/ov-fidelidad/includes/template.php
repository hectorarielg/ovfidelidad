<?php
/** OV Fidelidad 0.12 — Plantilla propia para las páginas del sistema. */
if (!defined('ABSPATH')) exit;

function ovf_system_page_ids() {
	return array_values(array_filter(array_map('intval', [get_option('ovf_page_portal'), get_option('ovf_page_register'), get_option('ovf_page_card'), get_option('ovf_page_superadmin')])));
}
function ovf_is_system_page() {
	$ids = ovf_system_page_ids();
	return $ids && is_page($ids);
}

/**
 * Las páginas de OV Fidelidad usan una plantilla a pantalla completa.
 * Para volver a la plantilla del tema: add_filter('ovf_use_fullscreen_template','__return_false');
 */
add_filter('template_include', function ($template) {
	if (!ovf_is_system_page() || !apply_filters('ovf_use_fullscreen_template', true)) return $template;
	return OVF_PATH . 'templates/app.php';
}, 99);

/** Sin barra de administración dentro de la app: se comporta como una app instalada. */
add_action('wp', function () {
	if (ovf_is_system_page() && apply_filters('ovf_use_fullscreen_template', true)) show_admin_bar(false);
});
