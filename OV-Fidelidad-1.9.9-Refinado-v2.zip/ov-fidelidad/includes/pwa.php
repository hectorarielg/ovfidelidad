<?php
/**
 * OV Fidelidad 1.0 — Iconos de la app (pantalla de inicio, favicon y manifest).
 *
 * Usa el "Icono de la Web App" de Ajustes; si no hay, el logo. Genera PNG cuadrados con GD en
 * los tamaños que piden iPhone (180), Android (192/512) y el navegador (32), los guarda en
 * uploads/ovf-icons y los sirve desde ?ovf_icon=TAMAÑO. Sin icono propio, iOS dibujaba una letra.
 */
if (!defined('ABSPATH')) exit;

/** [id del adjunto, 'icon'|'logo'] o [0,''] */
function ovf_icon_source() {
	$icon = absint(ovf_get_option('ovf_app_icon_id'));
	if ($icon && get_attached_file($icon)) return [$icon, 'icon'];
	$logo = absint(ovf_get_option('ovf_logo_id'));
	if ($logo && get_attached_file($logo)) return [$logo, 'logo'];
	return [0, ''];
}

function ovf_icon_url($size) {
	[$id] = ovf_icon_source();
	if (!$id) {
		$site = get_site_icon_url($size);
		return $site ?: '';
	}
	// La versión cambia cuando cambian imagen o colores → los teléfonos no se quedan con el icono viejo.
	$v = substr(md5($id . '|' . ovf_get_option('ovf_icon_bg', '#ffffff') . '|' . filemtime(get_attached_file($id)) . '|' . OVF_VERSION), 0, 8);
	return add_query_arg(['ovf_icon' => (int) $size, 'v' => $v, 'ovf_business' => ovf_business_slug()], home_url('/'));
}

add_action('template_redirect', 'ovf_serve_icon', 0);
function ovf_serve_icon() {
	if (empty($_GET['ovf_icon'])) return;
	$size = (int) $_GET['ovf_icon'];
	if (!in_array($size, [32, 180, 192, 512], true)) $size = 180;
	[$id, $kind] = ovf_icon_source();
	$file = $id ? get_attached_file($id) : '';
	if (!$file || !file_exists($file)) { status_header(404); exit; }

	$up = wp_upload_dir();
	$dir = trailingslashit($up['basedir']) . 'ovf-icons';
	$bg = sanitize_hex_color(ovf_get_option('ovf_icon_bg', '#ffffff')) ?: '#ffffff';
	$key = md5($id . '|' . filemtime($file) . '|' . $bg . '|' . $kind . '|' . OVF_VERSION);
	$out = "{$dir}/{$size}-{$key}.png";

	if (!file_exists($out)) {
		$png = ovf_render_icon($file, $size, $kind, $bg);
		if ($png === null) { wp_safe_redirect(wp_get_attachment_image_url($id, 'full')); exit; } // SVG o sin GD
		wp_mkdir_p($dir);
		file_put_contents($out, $png);
	}
	nocache_headers();
	header('Content-Type: image/png');
	header('Cache-Control: public, max-age=31536000, immutable');
	header('Content-Length: ' . filesize($out));
	readfile($out);
	exit;
}

/** Devuelve el PNG cuadrado o null si no se puede (GD ausente, SVG, imagen ilegible). */
function ovf_render_icon($file, $size, $kind, $bg_hex) {
	if (!function_exists('imagecreatetruecolor') || !function_exists('imagecreatefromstring')) return null;
	$data = @file_get_contents($file);
	if (!$data || stripos($data, '<svg') !== false) return null;
	$src = @imagecreatefromstring($data);
	if (!$src) return null;
	$sw = imagesx($src); $sh = imagesy($src);

	$dst = imagecreatetruecolor($size, $size);
	[$r, $g, $b] = sscanf($bg_hex, '#%02x%02x%02x');
	imagefill($dst, 0, 0, imagecolorallocate($dst, $r, $g, $b)); // fondo opaco: iOS pinta de negro lo transparente
	imagealphablending($dst, true);

	if ($kind === 'icon') { // icono cuadrado: ocupa todo (recorte centrado si no es cuadrado)
		$side = min($sw, $sh);
		imagecopyresampled($dst, $src, 0, 0, (int) (($sw - $side) / 2), (int) (($sh - $side) / 2), $size, $size, $side, $side);
	} else { // logo: completo, centrado y con margen
		$box = (int) round($size * 0.78);
		$scale = min($box / $sw, $box / $sh);
		$w = max(1, (int) round($sw * $scale)); $h = max(1, (int) round($sh * $scale));
		imagecopyresampled($dst, $src, (int) (($size - $w) / 2), (int) (($size - $h) / 2), 0, 0, $w, $h, $sw, $sh);
	}
	ob_start(); imagepng($dst, null, 9); $png = ob_get_clean();
	imagedestroy($src); imagedestroy($dst);
	return $png ?: null;
}

/** Etiquetas del <head> en las páginas del sistema. */
add_action('wp_head', 'ovf_icon_head', 1);
function ovf_icon_head() {
	if (!function_exists('ovf_is_system_page') || !ovf_is_system_page()) return;
	remove_action('wp_head', 'wp_site_icon', 99); // evita que el icono del tema compita con el del programa
	$is_app = is_page((int) get_option('ovf_page_portal'));
	$brand  = ovf_get_option('ovf_brand_name', get_bloginfo('name'));
	$title  = $is_app ? ovf_get_option('ovf_app_short_name', $brand) : $brand;
	echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr($title) . '">' . "\n";
	echo '<meta name="application-name" content="' . esc_attr($title) . '">' . "\n";
	if (ovf_icon_url(180)) {
		echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url(ovf_icon_url(180)) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url(ovf_icon_url(192)) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url(ovf_icon_url(32)) . '">' . "\n";
	}
}
