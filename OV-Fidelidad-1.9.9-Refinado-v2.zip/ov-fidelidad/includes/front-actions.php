<?php
/**
 * OV Fidelidad 0.12 — Procesamiento de formularios del frontend.
 *
 * Todos los POST de la Web App, el acceso y el registro público se procesan aquí,
 * ANTES de que el tema imprima HTML (template_redirect). Así:
 *  - wp_signon() puede enviar las cookies de sesión (antes fallaba dentro del shortcode).
 *  - Cada acción termina en una redirección (patrón POST → Redirect → GET): recargar la
 *    página o pulsar "Atrás" ya no vuelve a registrar una compra ni duplica clientes.
 */
if (!defined('ABSPATH')) exit;

/** Teléfono uniforme ("951 123-45-67" → "9511234567") para que la búsqueda y la detección de duplicados funcionen. */
function ovf_normalize_phone($raw) {
	$raw = trim(sanitize_text_field((string) $raw));
	return $raw === '' ? '' : (strpos($raw, '+') === 0 ? '+' : '') . preg_replace('/\D+/', '', $raw);
}
function ovf_referrer_id($code) {
	global $wpdb; $t=ovf_tables(); $code=strtoupper(sanitize_text_field((string)$code));
	return $code ? (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['clients']} WHERE referral_code=%s AND status='active' LIMIT 1",$code)) : 0;
}

/* ---------- Mensajes flash (sobreviven a una redirección) ---------- */
function ovf_flash_set($msg, $type = 'ok') {
	if (!is_user_logged_in()) return;
	set_transient('ovf_flash_' . ovf_business_id() . '_' . get_current_user_id(), ['msg' => (string) $msg, 'type' => $type], 120);
}
function ovf_flash_get() {
	if (!is_user_logged_in()) return null;
	$key = 'ovf_flash_' . ovf_business_id() . '_' . get_current_user_id();
	$f = get_transient($key);
	if ($f) delete_transient($key);
	return $f ?: null;
}
function ovf_flash_html() {
	$f = ovf_flash_get();
	if (!$f) return '';
	$cls = $f['type'] === 'error' ? 'ovf-app-alert error' : 'ovf-app-alert';
	return '<div class="' . esc_attr($cls) . '" role="status">' . esc_html($f['msg']) . '</div>';
}

/**
 * URL actual (para volver a la misma vista tras procesar un formulario).
 * Se arma con el dominio configurado en WordPress, no con el que llega en la petición: detrás de un
 * proxy, CDN, Live Link o con www/sin www, el dominio de la petición era rechazado por
 * wp_safe_redirect(), que entonces mandaba a /wp-admin… y WooCommerce a "Mi cuenta".
 */
function ovf_current_url() {
	$uri  = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
	$home = wp_parse_url(home_url('/'));
	$base = ($home['scheme'] ?? (is_ssl() ? 'https' : 'http')) . '://' . ($home['host'] ?? '') . (isset($home['port']) ? ':' . $home['port'] : '');
	return esc_url_raw($base . '/' . ltrim($uri, '/'));
}
/** Redirección segura que, si algo no cuadra, vuelve a la Web App (nunca al escritorio de WordPress). */
function ovf_redirect($url) {
	$portal = ovf_page_url('ovf_page_portal');
	wp_redirect(wp_validate_redirect($url ?: $portal, $portal), 303);
	exit;
}

add_action('template_redirect', 'ovf_front_actions', 1);
function ovf_front_actions() {
	if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;

	if (isset($_POST['ovf_recovery_request'])) ovf_action_recovery_request();
	if (isset($_POST['ovf_recovery_reset'])) ovf_action_recovery_reset();
	if (isset($_POST['ovf_login'])) ovf_action_login();
	if (isset($_POST['ovf_public_register'])) ovf_action_public_register();

	if (!is_user_logged_in() || !ovf_v02_staff_cap()) return;

	if (isset($_POST['ovf_front_program'])) ovf_action_program();
	if (isset($_POST['ovf_front_reviews'])) ovf_action_reviews();
	if (isset($_POST['ovf_purchase']) || isset($_POST['ovf_redeem'])) ovf_action_scanner();
	if (isset($_POST['ovf_front_new'])) ovf_action_new_client();
	if (isset($_POST['ovf_front_staff_add']) || isset($_POST['ovf_front_staff_password'])) ovf_action_team();
	if (isset($_POST['ovf_front_rule'])) ovf_action_rules();
}

/** Recuperación de acceso del equipo desde una pantalla de marca, sin enviar al login genérico. */
function ovf_recovery_return_url($state = '') {
    // Explicit global context: don't inherit the active business in admin.
    if (empty($_GET['ovf_business']) && function_exists('ovf_global_recovery_url')) {
        return $state === '' ? ovf_global_login_portal_url() : ovf_global_recovery_url($state);
    }
    $args = ['ovf_business' => sanitize_title(wp_unslash($_GET['ovf_business']))];
    if ($state !== '') $args['ovf_recovery'] = $state;
    return ovf_v02_url('ovf_page_portal', $args);
}

function ovf_action_recovery_request() {
	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_recovery_request')) ovf_redirect(ovf_recovery_return_url('request'));
	$identity = sanitize_text_field(wp_unslash($_POST['user_login'] ?? ''));
	$rate_key = 'ovf_recovery_rate_' . hash('sha256', sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? '')));
	$attempts = (int) get_transient($rate_key);
	if ($identity !== '' && $attempts < 5) {
		set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
		$target = is_email($identity) ? get_user_by('email', $identity) : get_user_by('login', $identity);
		// The unscoped general login accepts authorized staff across active businesses.
		// It does not change the per-business recovery flow or allow WordPress admins to reset here.
		$global_login = function_exists('ovf_global_login_request') && ovf_global_login_request();
		$business = function_exists('ovf_business_row') ? ovf_business_row(ovf_business_id()) : null;
		$belongs_to_business = $target && $business && ((int) $business->owner_user_id === (int) $target->ID || (int) get_user_meta($target->ID, 'ovf_business_id', true) === (int) $business->id);
		if ($global_login) {
			$belongs_to_business = false;
			if ($target && !user_can($target,'manage_options') && get_user_meta($target->ID,'ovf_access_disabled',true)!=='1'
			    && array_intersect(['ovf_owner','ovf_staff'],(array)$target->roles)) {
				$bid = absint(get_user_meta($target->ID,'ovf_business_id',true));
				$target_business = $bid ? ovf_business_row($bid) : null;
				$belongs_to_business = $target_business && $target_business->status === 'active';
				if (!$belongs_to_business && function_exists('ovf_businesses_table')) {
					global $wpdb;
					$owner_business_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".ovf_businesses_table()." WHERE owner_user_id=%d AND status='active' LIMIT 1",$target->ID));
					$belongs_to_business = $owner_business_id > 0;
				}
			}
		}
		if (!$belongs_to_business) { ovf_redirect(ovf_recovery_return_url('sent')); }
		$business = $global_login ? sanitize_text_field(ovf_global_login_option('name','OV Fidelidad')) : sanitize_text_field(ovf_get_option('ovf_brand_name', get_bloginfo('name')));
		$link_args = ['ovf_recovery' => 'reset'];
		if (!empty($_GET['ovf_business'])) $link_args['ovf_business'] = sanitize_title(wp_unslash($_GET['ovf_business']));
		$base = $global_login && function_exists('ovf_global_recovery_url') ? ovf_global_recovery_url('reset') : ovf_v02_url('ovf_page_portal', $link_args);
		$message_filter = function ($message, $key, $login, $user) use ($base, $business) {
			$url = add_query_arg(['key' => $key, 'login' => $login], $base);
			return "Hola,\n\nRecibimos una solicitud para cambiar la contraseña de tu acceso al equipo de {$business}.\n\nPara elegir una contraseña nueva, abre este enlace:\n{$url}\n\nSi no solicitaste este cambio, puedes ignorar este mensaje.\n";
		};
		$title_filter = function ($title) use ($business) { return sprintf(__('Acceso a %s · Cambiar contraseña', 'ov-fidelidad'), $business); };
		$from_filter = function ($name) use ($business) { return $business ?: $name; };
		add_filter('retrieve_password_message', $message_filter, 10, 4);
		add_filter('retrieve_password_title', $title_filter, 10, 1);
		add_filter('wp_mail_from_name', $from_filter, 99);
		retrieve_password($identity);
		remove_filter('retrieve_password_message', $message_filter, 10);
		remove_filter('retrieve_password_title', $title_filter, 10);
		remove_filter('wp_mail_from_name', $from_filter, 99);
	}
	ovf_redirect(ovf_recovery_return_url('sent'));
}

function ovf_action_recovery_reset() {
	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_recovery_reset')) ovf_redirect(ovf_recovery_return_url('invalid'));
	$key = sanitize_text_field(wp_unslash($_POST['key'] ?? ''));
	$login = sanitize_text_field(wp_unslash($_POST['login'] ?? ''));
	$password = (string) wp_unslash($_POST['password'] ?? '');
	$confirmation = (string) wp_unslash($_POST['password_confirm'] ?? '');
	$user = $key && $login ? check_password_reset_key($key, $login) : new WP_Error('invalid_key');
	if (is_wp_error($user)) ovf_redirect(ovf_recovery_return_url('invalid'));
	if (strlen($password) < 12 || !hash_equals($password, $confirmation)) ovf_redirect(add_query_arg(['ovf_recovery' => 'reset', 'key' => $key, 'login' => $login, 'ovf_recovery_error' => '1'], ovf_recovery_return_url()));
	reset_password($user, $password);
	ovf_redirect(ovf_recovery_return_url('complete'));
}

/** Guarda el enlace de reseñas en la configuración aislada del negocio actual. */
function ovf_action_reviews() {
	$back = ovf_v02_url('ovf_page_portal', ['view' => 'settings']);
	if (!ovf_v02_owner_cap() || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_reviews')) ovf_redirect($back);
	if (($_POST['ovf_front_reviews'] ?? '') === 'delete') {
		ovf_update_option('ovf_google_review_url', '');
		ovf_flash_set(__('Enlace eliminado. El botón ya no aparecerá en las tarjetas.', 'ov-fidelidad'));
		ovf_redirect($back);
	}
	$url = esc_url_raw(wp_unslash($_POST['ovf_google_review_url'] ?? ''));
	$parts = $url ? wp_parse_url($url) : [];
	if ($url && (!is_array($parts) || empty($parts['host']) || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true))) {
		ovf_flash_set(__('El enlace debe comenzar con http:// o https:// y ser una URL válida.', 'ov-fidelidad'), 'error');
		ovf_redirect($back);
	}
	ovf_update_option('ovf_google_review_url', $url);
	ovf_flash_set($url ? __('Enlace de reseñas guardado. Ya aparece en las tarjetas de tus clientes.', 'ov-fidelidad') : __('Se quitó el enlace de reseñas de las tarjetas.', 'ov-fidelidad'));
	ovf_redirect($back);
}

/* ---------- Acceso del equipo ---------- */
function ovf_action_login() {
	$back = remove_query_arg(['ovf_err'], ovf_current_url());
	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_login')) ovf_redirect(add_query_arg('ovf_err', 'expired', $back));
	$user = wp_signon([
		'user_login'    => sanitize_text_field(wp_unslash($_POST['login'] ?? '')),
		'user_password' => (string) wp_unslash($_POST['password'] ?? ''),
		'remember'      => !empty($_POST['remember']),
	], is_ssl());
	if (is_wp_error($user)) ovf_redirect(add_query_arg('ovf_err', 'login', $back));
	if (get_user_meta($user->ID, 'ovf_access_disabled', true) === '1' && !user_can($user, 'manage_options')) {
		wp_logout();
		ovf_redirect(add_query_arg('ovf_err', 'disabled', $back));
	}
	ovf_redirect($back); // vuelve a la misma vista (p. ej. una ficha ?ovf= abierta antes de iniciar sesión)
}

/* ---------- Registrar compra / canjear beneficio ---------- */
function ovf_action_scanner() {
	global $wpdb; $t = ovf_tables();
	$back  = ovf_current_url();
	$token = sanitize_text_field(wp_unslash($_GET['ovf'] ?? ''));
	$c     = $token ? ovf_client_by_token($token) : null;
	if (!$c || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_staff_' . $c->id)) {
		ovf_flash_set(__('La sesión del formulario caducó. Inténtalo de nuevo.', 'ov-fidelidad'), 'error');
		ovf_redirect($back);
	}
	$method = in_array($_GET['source'] ?? '', ['qr', 'search', 'manual'], true) ? $_GET['source'] : 'manual';
	if (isset($_POST['ovf_convert_points'])) {
		$credit=ovf_redeem_points($c->id,absint($_POST['points_to_convert']??0));
		if(is_wp_error($credit))ovf_flash_set($credit->get_error_message(),'error');else ovf_flash_set(sprintf(__('Puntos convertidos a $%s MXN de saldo cashback.','ov-fidelidad'),number_format_i18n($credit,2)));
		ovf_redirect($back);
	}

	if (isset($_POST['ovf_purchase'])) {
		$before = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$t['rewards']} WHERE client_id=%d", $c->id));
		$sale_amount = isset($_POST['sale_amount']) ? max(0, min(10000000, (float) wp_unslash($_POST['sale_amount']))) : 0;
		$balance_used = isset($_POST['balance_used']) ? max(0, min(10000000, (float) wp_unslash($_POST['balance_used']))) : 0;
		$purchase_quote = [];
		$receipt_number=sanitize_text_field(wp_unslash($_POST['receipt_number']??''));
		$first_discount=ovf_referral_discount_percent($c);$apply_referral_discount=$first_discount>0?(sanitize_text_field(wp_unslash($_POST['apply_referral_discount']??'0'))==='1'):true;
		$res = ovf_register_purchase($c->id, wp_unslash($_POST['note'] ?? ''), $method, $sale_amount, $balance_used, $purchase_quote, $receipt_number, $apply_referral_discount);
		$unlocked = is_wp_error($res) ? [] : $wpdb->get_col($wpdb->prepare("SELECT title FROM {$t['rewards']} WHERE client_id=%d" . ($before ? ' AND id NOT IN (' . implode(',', array_map('absint', $before)) . ')' : ''), $c->id));
		$err = ovf_get_option('ovf_last_reward_error');
		if (is_wp_error($res)) ovf_flash_set($res->get_error_message(), 'error');
		elseif ($err && strtotime($err['time']) >= current_time('timestamp') - 5) ovf_flash_set(__('La compra se guardó, pero no se pudo otorgar un beneficio por un problema técnico. Avisa al administrador: verá cómo repararlo en el escritorio.', 'ov-fidelidad'), 'error');
		elseif ($purchase_quote['discount_amount']>0) ovf_flash_set(sprintf(__('Ticket $%1$s · descuento −$%2$s · compra registrada por $%3$s.', 'ov-fidelidad'), number_format_i18n($purchase_quote['gross_amount'],2),number_format_i18n($purchase_quote['discount_amount'],2),number_format_i18n($purchase_quote['sale_amount'],2)));
		elseif ($unlocked) ovf_flash_set(sprintf(__('Compra registrada por $%1$s. 🎉 %2$s desbloqueó: %3$s.', 'ov-fidelidad'), number_format_i18n($purchase_quote['sale_amount'], 2), $c->name, implode(', ', $unlocked)));
		else ovf_flash_set(sprintf(__('Compra de $%1$s registrada. %2$s ahora tiene %3$d compras.', 'ov-fidelidad'), number_format_i18n($sale_amount, 2), $c->name, $res));
		ovf_redirect($back);
	}

	ovf_expire_rewards($c->id); // un beneficio vencido ya no se puede canjear
	$rid = absint($_POST['reward_id'] ?? 0);
	$rw  = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE id=%d AND client_id=%d AND status='available'", $rid, $c->id));
	if ($rw) {
		$wpdb->update($t['rewards'], ['status' => 'redeemed', 'redeemed_at' => current_time('mysql'), 'user_id' => get_current_user_id()], ['id' => $rid, 'status' => 'available']);
		$wpdb->insert($t['moves'], ['client_id' => $c->id, 'type' => 'redeem', 'reward_id' => $rid, 'note' => $rw->title, 'user_id' => get_current_user_id(), 'method' => $method, 'created_at' => current_time('mysql')]);
		ovf_flash_set(sprintf(__('Beneficio canjeado: %s.', 'ov-fidelidad'), $rw->title));
	} else {
		ovf_flash_set(__('Este beneficio ya no está disponible (ya se canjeó o venció).', 'ov-fidelidad'), 'error');
	}
	ovf_redirect($back);
}

/* ---------- Alta rápida de cliente desde la Web App ---------- */
function ovf_action_new_client() {
	global $wpdb; $t = ovf_tables();
	$form = ovf_v02_url('ovf_page_portal', ['view' => 'new']);
	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_new')) { ovf_flash_set(__('La sesión del formulario caducó.', 'ov-fidelidad'), 'error'); ovf_redirect($form); }
	$name  = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
	$email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
	$phone = ovf_normalize_phone(wp_unslash($_POST['phone'] ?? ''));
	if (!$name) { ovf_flash_set(__('El nombre es obligatorio.', 'ov-fidelidad'), 'error'); ovf_redirect($form); }

	// Evita duplicados: si el teléfono o email ya existe, abre ese cliente.
	$existing = null;
	if ($phone) $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['clients']} WHERE phone=%s LIMIT 1", $phone));
	if (!$existing && $email) $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['clients']} WHERE email=%s LIMIT 1", $email));
	if ($existing) {
		ovf_flash_set(sprintf(__('%s ya estaba registrado. Te mostramos su tarjeta.', 'ov-fidelidad'), $existing->name), 'error');
		ovf_redirect(add_query_arg('source', 'search', ovf_scan_url($existing->token)));
	}

	$email_marketing = empty($_POST['email_marketing']) ? 0 : 1;
	$birthday=isset($_POST['birthday'])&&preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',$_POST['birthday'])?sanitize_text_field($_POST['birthday']):null;
	$id = ovf_insert_client(['name' => $name, 'email' => $email, 'phone' => $phone, 'birthday'=>$birthday, 'referred_by'=>ovf_referrer_id(wp_unslash($_POST['referral_code']??'')), 'email_marketing'=>$email_marketing, 'email_consent_at'=>$email_marketing?current_time('mysql'):null]);
	if (is_wp_error($id)) { ovf_flash_set(__('No se pudo registrar el cliente.', 'ov-fidelidad'), 'error'); ovf_redirect($form); }
	ovf_log_client_registration($id, 'staff');
	$c = ovf_client($id);
	ovf_flash_set(sprintf(__('%s ya tiene su tarjeta. Registra su primera compra o comparte su tarjeta.', 'ov-fidelidad'), $name));
	ovf_redirect(add_query_arg('source', 'manual', ovf_scan_url($c->token)));
}

/* ---------- Gestión del equipo desde la Web App (solo encargados) ---------- */
function ovf_action_team() {
	$back = ovf_v02_url('ovf_page_portal', ['view' => 'team']);
	if (!ovf_v02_owner_cap()) ovf_redirect(ovf_page_url('ovf_page_portal'));

	if (isset($_POST['ovf_front_staff_add'])) {
		if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_staff_add')) ovf_redirect($back);
		$email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
		$name  = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
		$role  = in_array($_POST['role'] ?? '', ['ovf_owner', 'ovf_staff'], true) ? $_POST['role'] : 'ovf_staff';
		$pass  = (string) wp_unslash($_POST['password'] ?? '');
		if (strlen($pass) < 8) { ovf_flash_set(__('La contraseña debe tener al menos 8 caracteres.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
		if (!$email || email_exists($email)) { ovf_flash_set(__('Usa un email válido que no esté registrado.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
		$uid = wp_create_user($email, $pass, $email);
		if (is_wp_error($uid)) { ovf_flash_set($uid->get_error_message(), 'error'); ovf_redirect($back); }
		$u = new WP_User($uid); $u->set_role($role);update_user_meta($uid,'ovf_business_id',ovf_business_id());
		wp_update_user(['ID' => $uid, 'display_name' => $name ?: $email, 'first_name' => $name]);
		ovf_flash_set(sprintf(__('%s ya puede entrar con su email y la contraseña que definiste.', 'ov-fidelidad'), $name ?: $email));
		ovf_redirect($back);
	}

	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_staff_password')) ovf_redirect($back);
	$uid  = absint($_POST['user_id'] ?? 0);
	$pass = (string) wp_unslash($_POST['new_password'] ?? '');
	$u    = get_user_by('id', $uid);
	$me   = get_current_user_id();
	$ok   = $u && absint(get_user_meta($uid,'ovf_business_id',true))===ovf_business_id() && array_intersect(['ovf_owner', 'ovf_staff'], $u->roles) && strlen($pass) >= 8;
	// Seguridad: un encargado no administrador no puede cambiar la contraseña de un
	// administrador de WordPress ni la de otro encargado (evita escalada de privilegios).
	if ($ok && !current_user_can('manage_options') && $uid !== $me) {
		if (user_can($u, 'manage_options') || in_array('ovf_owner', $u->roles, true)) $ok = false;
	}
	if (!$ok) { ovf_flash_set(__('No se pudo actualizar la contraseña.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
	wp_set_password($pass, $uid);
	if ($uid === $me) { wp_set_current_user($uid); wp_set_auth_cookie($uid, true, is_ssl()); }
	ovf_flash_set(sprintf(__('Contraseña de %s actualizada.', 'ov-fidelidad'), $u->display_name));
	ovf_redirect($back);
}

/* ---------- Registro público de clientes ---------- */
function ovf_action_public_register() {
	global $wpdb; $t = ovf_tables();
	$back = remove_query_arg(['ovf_reg'], ovf_current_url());
	if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_public_register')) ovf_redirect(add_query_arg('ovf_reg', 'expired', $back));
	if (!empty($_POST['ovf_website'])) ovf_redirect($back); // honeypot anti-spam
	$ip  = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
	$key = 'ovf_reg_' . ovf_business_id() . '_' . md5($ip);
	$hits = (int) get_transient($key);
	if ($hits >= 8) ovf_redirect(add_query_arg('ovf_reg', 'limit', $back)); // máx. 8 altas por IP cada 15 min
	set_transient($key, $hits + 1, 15 * MINUTE_IN_SECONDS);
	$name  = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
	$email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
	$phone = ovf_normalize_phone(wp_unslash($_POST['phone'] ?? ''));
	$referral_code = strtoupper(sanitize_text_field(wp_unslash($_POST['referral_code'] ?? '')));
	// El registro público requiere los tres datos. No modificar los flujos de registro del mostrador.
	if (!$name || !$phone || !$email) ovf_redirect(add_query_arg('ovf_reg', 'missing', $back));
	if (!is_email($email)) ovf_redirect(add_query_arg('ovf_reg', 'invalid_email', $back));
	// Números mexicanos: 10 dígitos o +52 seguido de 10 dígitos.
	if (!preg_match('/^(?:\+?52)?[0-9]{10}$/', $phone)) ovf_redirect(add_query_arg('ovf_reg', 'invalid_phone', $back));
	$referrer_id = $referral_code ? ovf_referrer_id($referral_code) : 0;
	if ($referral_code && !$referrer_id) ovf_redirect(add_query_arg('ovf_reg', 'referral', $back));
	if (ovf_privacy_notice() && ovf_get_option('ovf_privacy_required', '1') === '1' && empty($_POST['ovf_privacy'])) ovf_redirect(add_query_arg('ovf_reg', 'privacy', $back));

	$exists = false;
	if ($email) $exists = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['clients']} WHERE email=%s LIMIT 1", $email));
	if (!$exists && $phone) $exists = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['clients']} WHERE phone=%s LIMIT 1", $phone));
	// Privacidad: nunca se entrega la tarjeta de otra persona solo por conocer su teléfono o email.
	if ($exists) ovf_redirect(add_query_arg('ovf_reg', 'exists', $back));

	$email_marketing = empty($_POST['email_marketing']) ? 0 : 1;
	$birthday=isset($_POST['birthday'])&&preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',$_POST['birthday'])?sanitize_text_field($_POST['birthday']):null;
	$id = ovf_insert_client(['name' => $name, 'email' => $email, 'phone' => $phone, 'birthday'=>$birthday, 'referred_by'=>$referrer_id, 'email_marketing'=>$email_marketing, 'email_consent_at'=>$email_marketing?current_time('mysql'):null]);
	if (is_wp_error($id)) ovf_redirect(add_query_arg('ovf_reg', 'error', $back));
	if (!empty($_POST['ovf_privacy'])) { global $wpdb; $wpdb->update(ovf_tables()['clients'], ['privacy_at' => current_time('mysql')], ['id' => $id]); }
	ovf_log_client_registration($id, 'self', 0);
	$c = ovf_client($id);
	$card_args=['bienvenida'=>'1'];if($referrer_id)$card_args['invitacion']='1';
	ovf_redirect(add_query_arg($card_args, ovf_card_url($c->token)));
}

/* ---------- Beneficios desde la Web App (solo encargados) ---------- */

function ovf_action_program() {
	$back = ovf_v02_url('ovf_page_portal', ['view' => 'program']);
	if (!ovf_v02_owner_cap() || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_program')) ovf_redirect($back);
	$features = array_values(array_intersect(['points', 'cashback'], array_map('sanitize_key', (array) wp_unslash($_POST['program_features'] ?? []))));
	ovf_update_option('ovf_program_features', $features);
	ovf_update_option('ovf_points_per_amount', max(1, min(100000, absint($_POST['points_per_amount'] ?? 10))));
	ovf_update_option('ovf_cashback_percent', max(0, min(100, (float) ($_POST['cashback_percent'] ?? 0))));
	ovf_update_option('ovf_birthday_bonus_points', max(0, min(100000, absint($_POST['birthday_bonus'] ?? 0))));
	$bonus_type=in_array($_POST['referral_bonus_type']??'points',['points','stamps'],true)?$_POST['referral_bonus_type']:'points';$bonus_amount=max(0,absint($_POST['referral_bonus_amount']??0));ovf_update_option('ovf_referral_bonus_type',$bonus_type);ovf_update_option('ovf_referral_bonus_points',$bonus_type==='points'?$bonus_amount:0);ovf_update_option('ovf_referral_bonus_stamps',$bonus_type==='stamps'?min(2,$bonus_amount):0);
	ovf_update_option('ovf_referral_discount_percent', max(0, min(100, (float) ($_POST['referral_discount_percent'] ?? 0))));
	ovf_update_option('ovf_points_per_peso', max(1, min(100000, absint($_POST['points_per_peso'] ?? 10))));
	$defaults = ['', 'Bronce', 'Plata', 'Oro'];
	foreach ([1, 2, 3] as $i) {
		$name = sanitize_text_field(wp_unslash($_POST['vip'.$i.'_name'] ?? ''));
		ovf_update_option('ovf_vip'.$i.'_name', $name !== '' ? $name : $defaults[$i]);
		ovf_update_option('ovf_vip'.$i.'_amount', max(0, min(100000000, (float) ($_POST['vip'.$i.'_amount'] ?? 0))));
	}
	ovf_flash_set(__('Reglas de acumulación guardadas.','ov-fidelidad'));
	ovf_redirect($back);
}

function ovf_action_rules() {
	global $wpdb; $t = ovf_tables();
	$back = ovf_v02_url('ovf_page_portal', ['view' => 'rewards']);
	if (!ovf_v02_owner_cap() || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ovf_front_rule')) ovf_redirect($back);
	$op = sanitize_key($_POST['ovf_front_rule']);
	$id = absint($_POST['rule_id'] ?? 0);
	if ($op === 'delete' && $id) {
		$wpdb->delete($t['rules'], ['id' => $id]);
		ovf_flash_set(__('Beneficio eliminado. Los que ya se otorgaron a clientes se conservan.', 'ov-fidelidad'));
		ovf_redirect($back);
	}
	if ($op === 'toggle' && $id) {
		$on = (int) $wpdb->get_var($wpdb->prepare("SELECT enabled FROM {$t['rules']} WHERE id=%d", $id));
		$wpdb->update($t['rules'], ['enabled' => $on ? 0 : 1], ['id' => $id]);
		$n = $on ? 0 : ovf_sync_all_rewards();
		ovf_flash_set($on ? __('Beneficio pausado. Ya no se otorgará hasta que lo actives.', 'ov-fidelidad') : __('Beneficio activado.', 'ov-fidelidad') . ($n ? ' ' . sprintf(_n('Se otorgó %d beneficio a clientes que ya cumplían.', 'Se otorgaron %d beneficios a clientes que ya cumplían.', $n, 'ov-fidelidad'), $n) : ''));
		ovf_redirect($back);
	}
	$data = ovf_rule_data_from($_POST);
	if ($data['title'] === '') { ovf_flash_set(__('Escribe el nombre del beneficio.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
	[$ok, $n] = ovf_save_rule($data, $op === 'update' ? $id : 0);
	if (!$ok) { ovf_flash_set(__('No se pudo guardar el beneficio.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
	$msg = $op === 'update' ? __('Beneficio actualizado.', 'ov-fidelidad') : sprintf(__('Beneficio “%s” creado.', 'ov-fidelidad'), $data['title']);
	if ($n) $msg .= ' ' . sprintf(_n('Se otorgó %d beneficio a clientes que ya cumplían.', 'Se otorgaron %d beneficios a clientes que ya cumplían.', $n, 'ov-fidelidad'), $n);
	ovf_flash_set($msg);
	ovf_redirect($back);
}

/* =====================================================================
   1.0 — Escaneo rápido desde la Web App: escanear → confirmar → compra registrada.
   Solo usuarios del equipo con sesión iniciada (wp_ajax_, sin versión pública).
   ===================================================================== */
function ovf_scan_guard() {
	if (!is_user_logged_in() || !ovf_v02_staff_cap() || !check_ajax_referer('ovf_scan', 'nonce', false)) {
		wp_send_json_error(['message' => __('Tu sesión caducó. Recarga la página.', 'ov-fidelidad')], 403);
	}
}
/** Extrae el código de la tarjeta de lo que leyó la cámara: "OVF:código", un enlace antiguo (?ovf=) o el código suelto. */
function ovf_scan_token($raw) {
	$raw = trim((string) wp_unslash($raw));
	if (stripos($raw, 'OVF:') === 0) return sanitize_text_field(substr($raw, 4));
	if (preg_match('#^https?://#i', $raw)) {
		$q = wp_parse_url($raw, PHP_URL_QUERY); parse_str((string) $q, $args);
		return sanitize_text_field($args['ovf'] ?? '');
	}
	return sanitize_text_field($raw);
}
function ovf_scan_payload($c) {
	global $wpdb; $t = ovf_tables();
	ovf_sync_client_rewards($c);
	$c = ovf_client($c->id);
	$nx = ovf_next_reward((int) $c->visits, (int) $c->id);
	$av = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE client_id=%d AND status='available' ORDER BY milestone ASC", $c->id));
	return [
		'token'     => $c->token,
		'name'      => $c->name,
		'initial'   => ovf_initial($c->name),
		'contact'   => ovf_contact_display($c),
		'visits'    => (int) $c->visits,
		'referral_discount_percent' => ovf_referral_discount_percent($c),
		'active'    => $c->status === 'active',
		'next'      => $nx ? ['title' => $nx['rule']->title, 'left' => (int) $nx['left']] : null,
		'available' => array_map(function ($r) { return ['id' => (int) $r->id, 'title' => $r->title, 'expires' => ovf_reward_expiry_text($r)]; }, $av),
		'profile'   => add_query_arg('source', 'qr', ovf_scan_url($c->token)),
		'card_url'  => ovf_card_url($c->token),
	];
}

/** Busca por WhatsApp exacto (10 dígitos), limitado al negocio activo. Solo personal autenticado. */
add_action('wp_ajax_ovf_scan_phone_search', function () {
 global $wpdb; $t=ovf_tables();
 ovf_scan_guard();
 $raw=$_POST['phone']??'';
 if(!is_scalar($raw))wp_send_json_error(['message'=>__('Introduce un WhatsApp válido.','ov-fidelidad')]);
 $digits=preg_replace('/\D+/','',(string)wp_unslash($raw));
 if(strlen($digits)===12&&substr($digits,0,2)==='52')$digits=substr($digits,2);
 if(strlen($digits)===13&&substr($digits,0,3)==='521')$digits=substr($digits,3);
 if(!preg_match('/^[0-9]{10}$/',$digits))wp_send_json_error(['message'=>__('Escribe un WhatsApp de 10 dígitos.','ov-fidelidad')]);
 // Últimos 8 dígitos como filtro inicial; comparación completa después de normalizar.
 $last=substr($digits,-8);
 $rows=$wpdb->get_results($wpdb->prepare("SELECT id,name,phone,token,status FROM {$t['clients']} WHERE phone LIKE %s ORDER BY name LIMIT 100",'%'.$wpdb->esc_like($last).'%'));
 $matches=[];
 foreach($rows as $c){
  $saved=preg_replace('/\D+/','',(string)$c->phone);
  if(strlen($saved)===12&&substr($saved,0,2)==='52')$saved=substr($saved,2);
  if(strlen($saved)===13&&substr($saved,0,3)==='521')$saved=substr($saved,3);
  if($saved!==$digits)continue;
  $matches[]=['name'=>$c->name,'contact'=>ovf_mask_phone($c->phone),'token'=>$c->token,'active'=>$c->status==='active'];
 }
 wp_send_json_success($matches);
});

add_action('wp_ajax_ovf_scan_lookup', function () {
	global $wpdb; $t = ovf_tables();
	ovf_scan_guard();
	$c = ovf_client_by_token(ovf_scan_token($_POST['code'] ?? ''));
	if (!$c) wp_send_json_error(['message' => __('Este código no pertenece a ninguna tarjeta del programa.', 'ov-fidelidad')]);
	// Registra la consulta QR como evento analítico, evitando duplicados por lecturas repetidas inmediatas.
	$recent = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['moves']} WHERE client_id=%d AND type='scan' AND user_id=%d AND created_at >= %s LIMIT 1", $c->id, get_current_user_id(), wp_date('Y-m-d H:i:s', current_time('timestamp', true) - 5)));
	if (!$recent && sanitize_key(wp_unslash($_POST['via']??''))!=='whatsapp') $wpdb->insert($t['moves'], ['client_id'=>absint($c->id),'type'=>'scan','amount'=>0,'note'=>'Consulta de tarjeta QR','user_id'=>get_current_user_id(),'method'=>'qr','created_at'=>current_time('mysql')]);
	wp_send_json_success(ovf_scan_payload($c));
});

add_action('wp_ajax_ovf_scan_purchase', function () {
	global $wpdb; $t = ovf_tables();
	ovf_scan_guard();
	$c = ovf_client_by_token(ovf_scan_token($_POST['code'] ?? ''));
	if (!$c) wp_send_json_error(['message' => __('Tarjeta no encontrada.', 'ov-fidelidad')]);
	if ($c->status !== 'active') wp_send_json_error(['message' => __('Esta tarjeta está inactiva.', 'ov-fidelidad')]);
	$raw_sale_amount=$_POST['sale_amount']??null;
	if(!is_scalar($raw_sale_amount)||!is_numeric($raw_sale_amount)||(float)$raw_sale_amount<=0||(float)$raw_sale_amount>10000000)wp_send_json_error(['message'=>__('Captura un importe de compra mayor que $0.00 y menor o igual a $10,000,000 MXN.','ov-fidelidad')]);
	$sale_amount=(float)$raw_sale_amount;
	// Evita doble registro por doble toque o doble lectura del mismo QR.
	$recent = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['moves']} WHERE client_id=%d AND type='purchase' AND user_id=%d AND created_at>=%s LIMIT 1", $c->id, get_current_user_id(), wp_date('Y-m-d H:i:s', current_time('timestamp', true) - 8)));
	if ($recent && empty($_POST['force'])) wp_send_json_error(['message' => __('Ya registraste una compra para este cliente hace unos segundos.', 'ov-fidelidad'), 'duplicate' => true]);
	$before = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT id FROM {$t['rewards']} WHERE client_id=%d", $c->id)));
	$discount_percent=ovf_referral_discount_percent($c);
	if($discount_percent>0&&!isset($_POST['apply_referral_discount']))wp_send_json_error(['message'=>__('Confirma si aplicarás el descuento de bienvenida antes de registrar la primera compra.','ov-fidelidad')]);
	$apply_referral_discount=$discount_percent>0?(sanitize_text_field(wp_unslash($_POST['apply_referral_discount']))==='1'):false;
	$purchase_quote=[];
	$receipt_raw=$_POST['receipt_number']??'';$receipt_number=is_scalar($receipt_raw)?sanitize_text_field(wp_unslash((string)$receipt_raw)):'';
	$method=isset($_POST['via'])&&sanitize_key(wp_unslash($_POST['via']))==='whatsapp'?'whatsapp':'qr';
	$res = ovf_register_purchase($c->id, wp_unslash($_POST['note'] ?? ''), $method, $sale_amount, 0, $purchase_quote, $receipt_number, $apply_referral_discount);
	if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);
	$new = $wpdb->get_col($wpdb->prepare("SELECT title FROM {$t['rewards']} WHERE client_id=%d" . ($before ? ' AND id NOT IN (' . implode(',', $before) . ')' : ''), $c->id));
	$data = ovf_scan_payload($c);
	$data['unlocked'] = $new;
	$purchase_quote['referral_discount_available']=$discount_percent>0;$purchase_quote['referral_discount_applied']=$apply_referral_discount;$data['purchase'] = $purchase_quote;
	wp_send_json_success($data);
});

add_action('wp_ajax_ovf_scan_redeem', function () {
	global $wpdb; $t = ovf_tables();
	ovf_scan_guard();
	$c = ovf_client_by_token(ovf_scan_token($_POST['code'] ?? ''));
	if (!$c) wp_send_json_error(['message' => __('Tarjeta no encontrada.', 'ov-fidelidad')]);
	ovf_expire_rewards($c->id);
	$rid = absint($_POST['reward_id'] ?? 0);
	$rw  = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['rewards']} WHERE id=%d AND client_id=%d AND status='available'", $rid, $c->id));
	if (!$rw) wp_send_json_error(['message' => __('Este beneficio ya no está disponible (ya se canjeó o venció).', 'ov-fidelidad')]);
	$ok = $wpdb->update($t['rewards'], ['status' => 'redeemed', 'redeemed_at' => current_time('mysql'), 'user_id' => get_current_user_id()], ['id' => $rid, 'status' => 'available']);
	if (!$ok) wp_send_json_error(['message' => __('Este beneficio ya no está disponible (ya se canjeó o venció).', 'ov-fidelidad')]);
	$wpdb->insert($t['moves'], ['client_id' => $c->id, 'type' => 'redeem', 'reward_id' => $rid, 'note' => $rw->title, 'user_id' => get_current_user_id(), 'method' => (isset($_POST['via'])&&sanitize_key(wp_unslash($_POST['via']))==='whatsapp'?'whatsapp':'qr'), 'created_at' => current_time('mysql')]);
	$data = ovf_scan_payload($c);
	$data['redeemed'] = $rw->title;
	wp_send_json_success($data);
});

/* =====================================================================
   1.0 — Privacidad: contacto parcial para empleados y aviso de privacidad.
   ===================================================================== */
/** ¿El usuario actual puede ver teléfono y correo completos? (encargados y administradores) */
function ovf_can_see_contact() {
	return (bool) apply_filters('ovf_can_see_contact', ovf_v02_owner_cap() || current_user_can('manage_options'));
}
function ovf_mask_phone($p) {
	$p = (string) $p; $d = preg_replace('/\D+/', '', $p);
	if (strlen($d) < 6) return $p === '' ? '' : '•••';
	return substr($d, 0, 3) . '•••' . substr($d, -4);
}
function ovf_mask_email($e) {
	$e = (string) $e; if ($e === '' || strpos($e, '@') === false) return $e;
	[$u, $dom] = explode('@', $e, 2);
	return mb_substr($u, 0, 1) . '•••@' . $dom;
}
/** Contacto para mostrar en la Web App: completo para encargados, parcial para empleados. */
function ovf_contact_display($c, $both = true) {
	$full = ovf_can_see_contact();
	$phone = $full ? $c->phone : ovf_mask_phone($c->phone);
	$email = $full ? $c->email : ovf_mask_email($c->email);
	return $both ? implode(' · ', array_filter([$phone, $email])) : ($phone ?: $email);
}

/** Aviso de privacidad configurado: ['url'=>…, 'page'=>ID|0] o null. */
function ovf_privacy_notice() {
	$mode = ovf_get_option('ovf_privacy_mode', 'page');
	if ($mode === 'none') return null;
	if ($mode === 'url') { $u = esc_url_raw(ovf_get_option('ovf_privacy_url', '')); return $u ? ['url' => $u, 'page' => 0] : null; }
	if ($mode === 'text') { $t = trim((string) ovf_get_option('ovf_privacy_custom', '')); return $t !== '' ? ['url' => '#ovf-privacy', 'page' => 0, 'text' => wpautop(wp_kses_post($t))] : null; }
	$pid = absint(ovf_get_option('ovf_privacy_page', 0)) ?: absint(get_option('wp_page_for_privacy_policy', 0));
	if (!$pid || get_post_status($pid) !== 'publish') return null;
	return ['url' => get_permalink($pid), 'page' => $pid];
}
/** Texto del aviso para mostrarlo en ventana (vacío si la página está hecha con un constructor y no se puede limpiar). */
function ovf_privacy_text($pid) {
	$raw = (string) get_post_field('post_content', $pid);
	if ($raw === '' || preg_match('/\[et_pb_|wp:divi\/|\[vc_|elementor/i', $raw)) return '';
	$html = wpautop(do_blocks(strip_shortcodes($raw)));
	$html = wp_kses($html, ['p' => [], 'br' => [], 'strong' => [], 'b' => [], 'em' => [], 'i' => [], 'ul' => [], 'ol' => [], 'li' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'a' => ['href' => [], 'target' => [], 'rel' => []]]);
	return trim(wp_strip_all_tags($html)) === '' ? '' : $html;
}

/** Motivo por el que el aviso no se muestra (para avisar en el escritorio) o '' si todo está bien. */
function ovf_privacy_problem() {
	$mode = ovf_get_option('ovf_privacy_mode', 'page');
	if ($mode === 'none' || ovf_privacy_notice()) return '';
	if ($mode === 'url') return __('Falta el enlace del aviso de privacidad.', 'ov-fidelidad');
	if ($mode === 'text') return __('Falta escribir el texto del aviso de privacidad.', 'ov-fidelidad');
	$pid = absint(ovf_get_option('ovf_privacy_page', 0)) ?: absint(get_option('wp_page_for_privacy_policy', 0));
	if (!$pid || !get_post($pid)) return __('No hay una página de aviso de privacidad elegida.', 'ov-fidelidad');
	return sprintf(__('La página “%s” no está publicada (está en %s), así que el registro público no muestra el aviso ni la casilla de aceptación.', 'ov-fidelidad'), get_the_title($pid), get_post_status($pid) === 'draft' ? __('borrador', 'ov-fidelidad') : get_post_status($pid));
}
