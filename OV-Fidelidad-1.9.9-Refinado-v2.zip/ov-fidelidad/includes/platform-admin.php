<?php
/** OV Fidelidad - global platform administration, isolated from tenant option context. */
if (!defined('ABSPATH')) exit;

function ovf_platform_link($page='ov-fidelidad-platform', $args=[]) {
    return add_query_arg(array_merge(['page'=>$page], $args), admin_url('admin.php'));
}
function ovf_platform_page_link($key) {
    $id=absint(get_option($key,0));
    return $id ? get_permalink($id) : '';
}
function ovf_platform_pages() {
    return [
      'ovf_page_portal'=>'Acceso y panel del equipo',
      'ovf_page_register'=>'Registro público de clientes',
      'ovf_page_card'=>'Tarjeta digital del cliente',
      'ovf_page_superadmin'=>'Panel web de superadministrador',
    ];
}
function ovf_platform_frame($section,$description='') {
    $primary=sanitize_hex_color(get_option('ovf_superadmin_primary','#4fae91'))?:'#4fae91';
    $accent=sanitize_hex_color(get_option('ovf_superadmin_accent','#172033'))?:'#172033';
    $platform=get_option('ovfp_platform_name','OV Fidelidad');
    echo '<div class="wrap ovf-platform" style="--ovfp-primary:'.esc_attr($primary).';--ovfp-accent:'.esc_attr($accent).'"><div class="ovfp-head"><div><small>'.esc_html($platform).' / ADMINISTRACIÓN GLOBAL</small><h1>'.esc_html($section).'</h1><p>'.esc_html($description).'</p></div><a class="button" href="'.esc_url(ovf_platform_link('ov-fidelidad-businesses')).'">Administrar negocios</a></div>';
    // Navigation lives in the grouped WordPress sidebar; avoid a duplicate toolbar.

}
function ovf_platform_end(){echo '</div>';}
function ovf_platform_table_exists($name) {
    global $wpdb;
    return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($name)))===$name;
}
function ovf_platform_dashboard() {
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    global $wpdb;
    $businesses=ovf_businesses_table();
    $counts=['businesses'=>0,'active'=>0,'disabled'=>0,'clients'=>0,'employees'=>0];
    $rows=[];
    if(ovf_business_table_ready()) {
        $counts['businesses']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$businesses}");
        $counts['active']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$businesses} WHERE status=%s",'active'));
        $counts['disabled']=$counts['businesses']-$counts['active'];
        $rows=$wpdb->get_results("SELECT id,name,slug,status,owner_user_id FROM {$businesses} ORDER BY id DESC LIMIT 8");
        // Only count existing tables. Read-only, no changes to tenant data.
        $all_ids=$wpdb->get_col("SELECT id FROM {$businesses} ORDER BY id ASC");
        foreach($all_ids as $raw_id){
            $id=absint($raw_id);
            $table=$wpdb->prefix.'ovf_clients'.($id>1?'_b'.$id:'');
            if(ovf_platform_table_exists($table))$counts['clients']+=(int)$wpdb->get_var("SELECT COUNT(*) FROM `{$table}`");
        }
    }
    $counts['employees']=(int)count(get_users(['role__in'=>['ovf_owner','ovf_staff'],'fields'=>'ID']));
    ovf_platform_frame('Dashboard general','Visibilidad de toda la plataforma, sin depender del negocio activo.');
    echo '<section class="ovfp-quicksearch"><label for="ovfp-quick-business">Buscar negocio para administrarlo</label><input type="search" id="ovfp-quick-business" placeholder="Nombre, correo o identificador del negocio" autocomplete="off" aria-controls="ovfp-quick-results"><div id="ovfp-quick-results" class="ovfp-quick-results" role="listbox" hidden></div><a class="button" href="'.esc_url(ovf_platform_link('ov-fidelidad-businesses')).'">Ver directorio</a></section>';
    echo '<section class="ovfp-metrics">';
    foreach(['businesses'=>'Negocios registrados','active'=>'Negocios activos','clients'=>'Perfiles de clientes','employees'=>'Cuentas del equipo'] as $key=>$title)echo '<article><span>'.esc_html($title).'</span><strong>'.number_format_i18n($counts[$key]).'</strong></article>';
    echo '</section><div class="ovfp-columns"><section class="ovfp-card"><div class="ovfp-cardhead"><h2>Negocios recientes</h2><a href="'.esc_url(ovf_platform_link('ov-fidelidad-businesses')).'">Ver todos</a></div><div class="ovfp-scroll"><table class="widefat striped"><thead><tr><th>Negocio</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>';
    foreach($rows as $r)echo '<tr><td><strong>'.esc_html($r->name).'</strong><small class="ovfp-sub">'.esc_html($r->slug).'</small></td><td>'.esc_html($r->status).'</td><td><a href="'.esc_url(ovf_platform_link('ov-fidelidad-business-dashboard',['ovf_business_id'=>(int)$r->id])).'">Administrar</a></td></tr>';
    if(!$rows)echo '<tr><td colspan="3">No hay negocios registrados.</td></tr>';
    echo '</tbody></table></div></section><section class="ovfp-card"><h2>Configuración central</h2><p>La identidad de plataforma, el acceso general y las páginas se administran sin editar los ajustes particulares de ningún negocio.</p><div class="ovfp-links">';
    foreach(['ov-fidelidad-global-login'=>'Identidad del acceso general','ov-fidelidad-platform-pages'=>'Páginas del sistema','ov-fidelidad-platform-settings'=>'Apariencia del superadministrador','ov-fidelidad-platform-users'=>'Personal y accesos'] as $slug=>$name)echo '<a href="'.esc_url(ovf_platform_link($slug)).'">'.esc_html($name).'<span>→</span></a>';
    echo '</div></section></div><p class="ovfp-note">Totales de clientes calculados a partir de las tablas existentes de cada negocio. Las sesiones, sellos y datos almacenados no se modifican.</p>';
    ovf_platform_end();
}
function ovf_platform_business_dashboard(){
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    $business_id=absint($_GET['ovf_business_id']??0);
    $business=$business_id?ovf_business_row($business_id):null;
    if(!$business) {
        ovf_platform_frame('Administración de negocios','Selecciona un negocio antes de abrir sus ajustes.');
        echo '<div class="ovfp-card"><p>Selecciona un establecimiento desde la lista para administrar sus clientes, beneficios y reglas.</p><a class="button button-primary" href="'.esc_url(ovf_platform_link('ov-fidelidad-businesses')).'">Seleccionar negocio</a></div>';
        ovf_platform_end();return;
    }
    // Preserve all old business-dashboard behavior under an explicit tenant context.
    $old=ovf_set_business_context($business_id);
    ovf_admin_dashboard();
    ovf_set_business_context($old);
}
function ovf_platform_user_authorized($user) {
    if(!$user || !($user instanceof WP_User))return false;
    if(array_intersect(['administrator','editor'],$user->roles))return false;
    if(!array_intersect(['ovf_owner','ovf_staff'],$user->roles))return false;
    $bid=absint(get_user_meta($user->ID,'ovf_business_id',true));
    $b=$bid?ovf_business_row($bid):null;
    return $b && (int)$b->id===$bid;
}
function ovf_platform_user_action(){
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    if(empty($_POST['ovfp_user_action']))return;
    check_admin_referer('ovfp_user_action');
    $id=absint($_POST['user_id']??0);$user=get_user_by('id',$id);
    if(!ovf_platform_user_authorized($user)){wp_safe_redirect(ovf_platform_link('ov-fidelidad-platform-users',['notice'=>'invalid']));exit;}
    $action=sanitize_key($_POST['ovfp_user_action']);$notice='invalid';
    if($action==='disable' || $action==='enable'){
        update_user_meta($id,'ovf_access_disabled',$action==='disable'?'1':'0');
        if(function_exists('wp_destroy_user_sessions') && $action==='disable')wp_destroy_user_sessions($id);
        else if($action==='disable'){ $tokens=WP_Session_Tokens::get_instance($id);$tokens->destroy_all(); }
        $notice=$action==='disable'?'disabled':'enabled';
    }elseif($action==='reset'){
        $key=get_password_reset_key($user);
        if(!is_wp_error($key)){
            $url=network_site_url('wp-login.php?action=rp&key='.rawurlencode($key).'&login='.rawurlencode($user->user_login),'login');
            $subject='Recuperación de acceso a OV Fidelidad';
            $message="Se solicitó restablecer la contraseña de tu cuenta.\n\nAbre este enlace seguro:\n".$url."\n\nSi no solicitaste el cambio, ignora este correo.";
            $notice=wp_mail($user->user_email,$subject,$message)?'sent':'emailerror';
        }
    }
    wp_safe_redirect(ovf_platform_link('ov-fidelidad-platform-users',['notice'=>$notice]));exit;
}
add_action('admin_post_ovfp_user_action','ovf_platform_user_action');
function ovf_platform_users(){
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    $search=sanitize_text_field(wp_unslash($_GET['s']??''));$page=max(1,absint($_GET['paged']??1));
    $business_filter=absint($_GET['business_id']??0);
    $role_filter=sanitize_key($_GET['role_filter']??'all');
    if(!in_array($role_filter,['all','ovf_owner','ovf_staff'],true))$role_filter='all';
    $status_filter=sanitize_key($_GET['status_filter']??'all');
    if(!in_array($status_filter,['all','active','disabled'],true))$status_filter='all';
    $args=['role__in'=>$role_filter==='all'?['ovf_owner','ovf_staff']:[$role_filter],'number'=>20,'offset'=>($page-1)*20,'orderby'=>'registered','order'=>'DESC','count_total'=>true];
    if($search!=='')$args['search']='*'.$search.'*';
    $meta_query=['relation'=>'AND'];
    if($business_filter)$meta_query[]=['key'=>'ovf_business_id','value'=>(string)$business_filter,'compare'=>'='];
    if($status_filter==='disabled')$meta_query[]=['key'=>'ovf_access_disabled','value'=>'1','compare'=>'='];
    if($status_filter==='active')$meta_query[]=['relation'=>'OR',['key'=>'ovf_access_disabled','compare'=>'NOT EXISTS'],['key'=>'ovf_access_disabled','value'=>'1','compare'=>'!=']];
    if(count($meta_query)>1)$args['meta_query']=$meta_query;
    $query=new WP_User_Query($args);$users=$query->get_results();$total=(int)$query->get_total();
    ovf_platform_frame('Usuarios y accesos','Busca personal de todos los negocios. Solo puedes actuar sobre cuentas de encargado o empleado.');
    $messages=['disabled'=>'Cuenta desactivada y sesiones cerradas.','enabled'=>'Acceso restaurado.','sent'=>'Se ha enviado el correo de restablecimiento.','emailerror'=>'No se pudo enviar el correo. Revisa SMTP.','invalid'=>'Acción no autorizada.'];
    $notice=sanitize_key($_GET['notice']??'');if(isset($messages[$notice]))echo '<div class="notice '.($notice==='invalid'||$notice==='emailerror'?'notice-error':'notice-success').'"><p>'.esc_html($messages[$notice]).'</p></div>';
    echo '<section class="ovfp-card ovfp-live-users" data-ovfp-live="users"><form method="get" class="ovfp-search"><input type="hidden" name="page" value="ov-fidelidad-platform-users"><label for="ovfp-search">Buscar usuario, nombre o correo</label><input class="regular-text" id="ovfp-search" name="s" value="'.esc_attr($search).'" placeholder="Buscar en todos los negocios" autocomplete="off"><div id="ovfp-suggest" role="listbox" class="ovfp-suggest" hidden></div>';
    echo '<label class="ovfp-filter-label">Negocio<select name="business_id"><option value="0">Todos los negocios</option>';
    global $wpdb;$bt=ovf_businesses_table();$businesses=ovf_business_table_ready()?$wpdb->get_results("SELECT id,name FROM {$bt} ORDER BY name ASC"):[];
    foreach($businesses as $biz)echo '<option value="'.(int)$biz->id.'" '.selected($business_filter,(int)$biz->id,false).'>'.esc_html($biz->name).'</option>';
    echo '</select></label><label class="ovfp-filter-label">Rol<select name="role_filter"><option value="all">Todos los roles</option><option value="ovf_owner" '.selected($role_filter,'ovf_owner',false).'>Encargados</option><option value="ovf_staff" '.selected($role_filter,'ovf_staff',false).'>Empleados</option></select></label><label class="ovfp-filter-label">Estado<select name="status_filter"><option value="all">Todos los estados</option><option value="active" '.selected($status_filter,'active',false).'>Activos</option><option value="disabled" '.selected($status_filter,'disabled',false).'>Suspendidos</option></select></label><button class="button button-primary">Buscar</button><a class="button" href="'.esc_url(ovf_platform_link('ov-fidelidad-platform-users')).'">Limpiar</a></form><p class="ovfp-results-count">'.esc_html(number_format_i18n($total)).' cuentas encontradas</p><div class="ovfp-scroll"><table class="widefat striped"><thead><tr><th>Usuario</th><th>Negocio</th><th>Rol</th><th>Acceso</th><th>Acciones</th></tr></thead><tbody>';
    foreach($users as $user){
        if(!ovf_platform_user_authorized($user))continue;
        $bid=absint(get_user_meta($user->ID,'ovf_business_id',true));$business=ovf_business_row($bid);
        $disabled=get_user_meta($user->ID,'ovf_access_disabled',true)==='1';
        echo '<tr><td><b>'.esc_html($user->display_name).'</b><small class="ovfp-sub">'.esc_html($user->user_email).'</small></td><td>'.esc_html($business?$business->name:'').'</td><td>'.esc_html(in_array('ovf_owner',$user->roles,true)?'Encargado':'Empleado').'</td><td>'.($disabled?'Suspendido':'Activo').'</td><td><div class="ovfp-actions">';
        foreach([($disabled?'enable':'disable')=>($disabled?'Habilitar':'Desactivar'),'reset'=>'Enviar recuperación'] as $action=>$label){
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ovfp_user_action"><input type="hidden" name="user_id" value="'.(int)$user->ID.'">';wp_nonce_field('ovfp_user_action');
            echo '<button class="button" name="ovfp_user_action" value="'.esc_attr($action).'">'.esc_html($label).'</button></form>';
        }
        echo '</div></td></tr>';
    }
    if(!$users)echo '<tr><td colspan="5">No se encontraron usuarios.</td></tr>';
    echo '</tbody></table></div>';
    $pages=(int)ceil($total/20);if($pages>1)echo '<div class="tablenav"><div class="tablenav-pages">'.wp_kses_post(paginate_links(['base'=>add_query_arg(['page'=>'ov-fidelidad-platform-users','s'=>$search,'business_id'=>$business_filter,'role_filter'=>$role_filter,'status_filter'=>$status_filter,'paged'=>'%#%'],admin_url('admin.php')),'current'=>$page,'total'=>$pages])).'</div></div>';
    echo '</section><p class="ovfp-note">La recuperación utiliza un enlace temporal de WordPress. Las cuentas administradoras no aparecen en esta lista. Envíos y entregabilidad dependen de SMTP.</p>';
    ovf_platform_end();
}
function ovf_platform_settings(){
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    if(isset($_POST['ovfp_save_settings'])){
        check_admin_referer('ovfp_settings');
        foreach(['primary'=>'#4fae91','accent'=>'#172033','background'=>'#f3f5f4'] as $key=>$fallback){
            update_option('ovf_superadmin_'.$key,sanitize_hex_color(wp_unslash($_POST[$key]??''))?:$fallback);
        }
        update_option('ovfp_platform_name',sanitize_text_field(wp_unslash($_POST['platform_name']??'OV Fidelidad')));
        echo '<div class="notice notice-success"><p>Configuración de plataforma guardada. No se han modificado ajustes de negocios.</p></div>';
    }
    ovf_platform_frame('Configuración global','Identidad del administrador. Independiente de la marca y de los beneficios de cada negocio.');
    echo '<form method="post" class="ovfp-card">';wp_nonce_field('ovfp_settings');
    echo '<h2>Apariencia del administrador</h2><p>Los colores siguientes se usan en el área del superadministrador; no cambian las tarjetas ni las páginas públicas de los negocios.</p><div class="ovfp-form"><label>Nombre interno de la plataforma<input class="regular-text" name="platform_name" value="'.esc_attr(get_option('ovfp_platform_name','OV Fidelidad')).'"></label>';
    foreach(['primary'=>'Color principal','accent'=>'Color de navegación','background'=>'Fondo del administrador'] as $key=>$label){$default=['primary'=>'#4fae91','accent'=>'#172033','background'=>'#f3f5f4'][$key];$value=sanitize_hex_color(get_option('ovf_superadmin_'.$key,$default))?:$default;echo '<label>'.esc_html($label).'<input type="color" name="'.esc_attr($key).'" value="'.esc_attr($value).'"></label>';}
    echo '</div><p><button class="button button-primary" name="ovfp_save_settings" value="1">Guardar configuración global</button></p></form>';
    echo '<div class="ovfp-card"><h2>Configuraciones relacionadas</h2><p><a href="'.esc_url(ovf_platform_link('ov-fidelidad-global-login')).'">Acceso general, logotipo, favicon y recuperación →</a></p><p><a href="'.esc_url(ovf_platform_link('ov-fidelidad-platform-pages')).'">Páginas de la plataforma →</a></p><p><a href="'.esc_url(ovf_platform_link('ov-fidelidad-mail')).'">Infraestructura de correo SMTP →</a></p></div>';
    ovf_platform_end();
}
function ovf_platform_pages_admin(){
    if(!current_user_can('manage_options'))wp_die('Acceso restringido');
    if(isset($_POST['ovfp_save_pages'])){
        check_admin_referer('ovfp_pages');
        $errors=[];
        foreach(ovf_platform_pages() as $key=>$name){
            $id=absint($_POST[$key]??0);
            if($id && (get_post_type($id)!=='page' || !get_post_status($id))){$errors[]=$name;continue;}
            update_option($key,$id);
        }
        echo $errors?'<div class="notice notice-error"><p>Algunas páginas no eran válidas: '.esc_html(implode(', ',$errors)).'</p></div>':'<div class="notice notice-success"><p>Páginas globales guardadas. Comprueba las rutas públicas antes de compartirlas.</p></div>';
    }
    ovf_platform_frame('Páginas de la plataforma','Asignación de páginas globales del sistema, sin seleccionar un negocio.');
    echo '<form method="post" class="ovfp-card">';wp_nonce_field('ovfp_pages');
    echo '<h2>Rutas globales</h2><p>Los negocios comparten estas páginas y las diferencian mediante su identificador. No se modifican sus configuraciones individuales.</p><div class="ovfp-form">';
    foreach(ovf_platform_pages() as $key=>$label){
        $id=absint(get_option($key,0));
        echo '<div><label>'.esc_html($label).'</label>';
        wp_dropdown_pages(['name'=>$key,'id'=>$key,'selected'=>$id,'show_option_none'=>'— Sin asignar —','option_none_value'=>0,'post_status'=>['publish','private','draft']]);
        if($id)echo '<small class="ovfp-sub"><a href="'.esc_url(get_permalink($id)).'" target="_blank" rel="noopener">Ver página</a></small>';
        echo '</div>';
    }
    echo '</div><p><button class="button button-primary" name="ovfp_save_pages" value="1">Guardar páginas</button></p></form>';
    ovf_platform_end();
}
/** Keep every WordPress submenu in its native structure, but order it into stable groups.
 * This is presentation-only: original slugs, callbacks and capabilities are preserved.
 */
add_action('admin_menu',function(){
    if(!current_user_can('manage_options'))return;
    global $submenu;
    if(empty($submenu['ov-fidelidad']) || !is_array($submenu['ov-fidelidad']))return;
    $order=[
      'ov-fidelidad','ov-fidelidad-platform',
      'ov-fidelidad-businesses','ov-fidelidad-mobile-onboarding','ov-fidelidad-licenses','ov-membresias-licenses',
      'ov-fidelidad-platform-users',
      'ov-fidelidad-global-login','ov-fidelidad-platform-settings','ov-fidelidad-platform-pages','ov-fidelidad-mail','ov-fidelidad-setup',
      'ov-fidelidad-business-dashboard','ov-fidelidad-clients','ov-fidelidad-rewards','ov-fidelidad-history','ov-fidelidad-reports','ov-fidelidad-program','ov-fidelidad-marketing','ov-fidelidad-staff','ov-fidelidad-settings'
    ];
    $list=array_values($submenu['ov-fidelidad']);
    usort($list,static function($a,$b)use($order){
       $ai=array_search((string)($a[2]??''),$order,true);
       $bi=array_search((string)($b[2]??''),$order,true);
       return ($ai===false?999:$ai)<=>($bi===false?999:$bi);
    });
    $submenu['ov-fidelidad']=$list;
},9999);

add_action('admin_enqueue_scripts',function($hook){
    if(!current_user_can('manage_options'))return;
    // The separate workspace owns navigation; this stylesheet styles only existing dashboard content.
    wp_enqueue_style('ovfp-platform',OVF_URL.'assets/platform-admin.css',[],ovf_asset_version('assets/platform-admin.css'));
});
add_action('admin_menu',function(){
    add_submenu_page('ov-fidelidad','Dashboard general','Dashboard general','manage_options','ov-fidelidad-platform','ovf_platform_dashboard');
    add_submenu_page('ov-fidelidad','Usuarios y accesos','Usuarios y accesos','manage_options','ov-fidelidad-platform-users','ovf_platform_users');
    add_submenu_page('ov-fidelidad','Configuración global','Configuración global','manage_options','ov-fidelidad-platform-settings','ovf_platform_settings');
    add_submenu_page('ov-fidelidad','Páginas de plataforma','Páginas de plataforma','manage_options','ov-fidelidad-platform-pages','ovf_platform_pages_admin');
    add_submenu_page('ov-fidelidad','Panel de negocio','Panel de negocio','manage_options','ov-fidelidad-business-dashboard','ovf_platform_business_dashboard');
},22);

/** AJAX autocomplete for the global users directory. Restricted to administrators. */
add_action('wp_ajax_ovfp_user_suggest',function(){
    if(!current_user_can('manage_options'))wp_send_json_error(['message'=>'Acceso no autorizado'],403);
    check_ajax_referer('ovfp_user_suggest','nonce');
    $query=sanitize_text_field(wp_unslash($_GET['q']??''));
    if(strlen($query)<2)wp_send_json_success([]);
    $users=get_users(['role__in'=>['ovf_owner','ovf_staff'],'number'=>8,'search'=>'*'.$query.'*','fields'=>'all']);
    $results=[];
    foreach($users as $user){
        if(!ovf_platform_user_authorized($user))continue;
        $bid=absint(get_user_meta($user->ID,'ovf_business_id',true));$business=ovf_business_row($bid);
        $results[]=['name'=>$user->display_name,'login'=>$user->user_login,'email'=>$user->user_email,'business'=>$business?$business->name:''];
    }
    wp_send_json_success($results);
});
