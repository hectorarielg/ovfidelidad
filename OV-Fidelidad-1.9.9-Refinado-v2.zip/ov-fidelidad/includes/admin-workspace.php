<?php
/** OV Fidelidad 1.9.9 - Admin workspace: one native entry, independent inner sidebar. */
if (!defined('ABSPATH')) exit;

function ovf_workspace_on_screen() {
    if (!is_admin() || !current_user_can('manage_options')) return false;
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    return strpos($page,'ov-fidelidad') === 0 || $page === 'ovm-licenses';
}
function ovf_workspace_sections() {
    $business_id = absint(get_user_meta(get_current_user_id(),'ovf_active_business_id',true));
    $selected = $business_id && function_exists('ovf_business_row') ? ovf_business_row($business_id) : null;
    $tenant_args = $selected ? ['ovf_business_id'=>(int)$selected->id] : [];
    $tenant_url = function($page) use($tenant_args, $selected) {
        return $selected ? ovf_platform_link($page,$tenant_args) : ovf_platform_link('ov-fidelidad-businesses');
    };
    $sections = [
      'dashboard'=>['label'=>'Dashboard','items'=>[
        ['slug'=>'ov-fidelidad','name'=>'Resumen de plataforma','url'=>ovf_platform_link('ov-fidelidad')]
      ]],
      'businesses'=>['label'=>'Negocios','items'=>[
        ['slug'=>'ov-fidelidad-businesses','name'=>'Directorio y alta','url'=>ovf_platform_link('ov-fidelidad-businesses')],
        ['slug'=>'ov-fidelidad-mobile-onboarding','name'=>'Alta móvil','url'=>ovf_platform_link('ov-fidelidad-mobile-onboarding')]
      ]],
      'users'=>['label'=>'Usuarios y accesos','items'=>[
        ['slug'=>'ov-fidelidad-platform-users','name'=>'Directorio de usuarios','url'=>ovf_platform_link('ov-fidelidad-platform-users')]
      ]],
      'global'=>['label'=>'Configuración global','items'=>[
        ['slug'=>'ov-fidelidad-global-login','name'=>'Marca y acceso general','url'=>ovf_platform_link('ov-fidelidad-global-login')],
        ['slug'=>'ov-fidelidad-platform-settings','name'=>'Ajustes de plataforma','url'=>ovf_platform_link('ov-fidelidad-platform-settings')],
        ['slug'=>'ov-fidelidad-platform-pages','name'=>'Páginas del sistema','url'=>ovf_platform_link('ov-fidelidad-platform-pages')],
        ['slug'=>'ov-fidelidad-mail','name'=>'Correo SMTP','url'=>ovf_platform_link('ov-fidelidad-mail')]
      ]],
      'tenant'=>['label'=>'Administrar negocio','items'=>[
        ['slug'=>'ov-fidelidad-business-dashboard','name'=>'Resumen del negocio','url'=>$tenant_url('ov-fidelidad-business-dashboard')],
        ['slug'=>'ov-fidelidad-clients','name'=>'Clientes','url'=>$tenant_url('ov-fidelidad-clients')],
        ['slug'=>'ov-fidelidad-rewards','name'=>'Beneficios','url'=>$tenant_url('ov-fidelidad-rewards')],
        ['slug'=>'ov-fidelidad-history','name'=>'Historial','url'=>$tenant_url('ov-fidelidad-history')],
        ['slug'=>'ov-fidelidad-reports','name'=>'Reportes','url'=>$tenant_url('ov-fidelidad-reports')],
        ['slug'=>'ov-fidelidad-program','name'=>'Reglas de acumulación','url'=>$tenant_url('ov-fidelidad-program')],
        ['slug'=>'ov-fidelidad-marketing','name'=>'Promociones','url'=>$tenant_url('ov-fidelidad-marketing')],
        ['slug'=>'ov-fidelidad-staff','name'=>'Personal','url'=>$tenant_url('ov-fidelidad-staff')],
        ['slug'=>'ov-fidelidad-settings','name'=>'Identidad y ajustes','url'=>$tenant_url('ov-fidelidad-settings')]
      ]]
    ];
    if (function_exists('ovm_admin_licenses_page')) {
        $sections['businesses']['items'][]=['slug'=>'ovm-licenses','name'=>'Licencias de Membresías','url'=>ovf_platform_link('ovm-licenses')];
    }
    return [$sections,$selected];
}
function ovf_workspace_active_group($page) {
    if ($page === 'ov-fidelidad') return 'dashboard';
    if ($page === 'ovm-licenses') return 'businesses';
    if (strpos($page,'ov-fidelidad-platform-users') === 0) return 'users';
    if (in_array($page,['ov-fidelidad-businesses','ov-fidelidad-mobile-onboarding'],true))return 'businesses';
    if (in_array($page,['ov-fidelidad-global-login','ov-fidelidad-platform-settings','ov-fidelidad-platform-pages','ov-fidelidad-mail','ov-fidelidad-setup'],true))return 'global';
    return 'tenant';
}
function ovf_workspace_sidebar() {
    if (!ovf_workspace_on_screen()) return;
    $page = sanitize_key(wp_unslash($_GET['page']??''));
    [$sections,$selected] = ovf_workspace_sections();
    $active = ovf_workspace_active_group($page);
    echo '<aside class="ovf-workspace-nav" aria-label="Navegación de OV Fidelidad">';
    echo '<div class="ovf-ws-brand"><span class="ovf-ws-mark" aria-hidden="true">OV</span><div><strong>OV Fidelidad</strong><small>Centro de administración</small></div></div>';
    echo '<div class="ovf-ws-business-context"><span>Negocio activo</span>';
    if ($selected) echo '<strong>'.esc_html($selected->name).'</strong>';
    else echo '<strong>Ninguno seleccionado</strong>';
    echo '<a href="'.esc_url(ovf_platform_link('ov-fidelidad-businesses')).'">Cambiar negocio</a></div>';
    echo '<nav class="ovf-ws-groups" aria-label="Secciones del administrador">';
    foreach ($sections as $key=>$group) {
        $is_open = $key === $active;
        echo '<details name="ovf-ws-nav" class="ovf-ws-group"'.($is_open?' open':'').'>';
        echo '<summary><span>'.esc_html($group['label']).'</span><span class="ovf-ws-chevron" aria-hidden="true">⌄</span></summary><div class="ovf-ws-items">';
        foreach($group['items'] as $item) {
            $current = $item['slug'] === $page || ($page==='ov-fidelidad' && $item['slug']==='ov-fidelidad');
            echo '<a class="'.($current?'is-current':'').'"'.($current?' aria-current="page"':'').' href="'.esc_url($item['url']).'">'.esc_html($item['name']).'</a>';
        }
        echo '</div></details>';
    }
    echo '</nav><div class="ovf-ws-foot"><a class="ovf-ws-wordpress-exit" href="'.esc_url(admin_url('index.php')).'"><span aria-hidden="true">←</span> Volver a WordPress</a></div></aside>';
}
/**
 * WordPress keeps its registered submenus for routing and authorization.
 * Their visual duplicates are hidden with CSS, never removed from $submenu.
 */

add_filter('admin_body_class',function($classes){
    return ovf_workspace_on_screen() ? $classes.' ovf-workspace-screen' : $classes;
});
add_action('admin_notices','ovf_workspace_sidebar',1);
add_action('admin_enqueue_scripts',function() {
    if (!current_user_can('manage_options')) return;
    // Globally only hide the submenu's *display*. All WP page hooks and permissions stay registered.
    wp_enqueue_style('ovf-workspace',OVF_URL.'assets/admin-workspace.css',[],ovf_asset_version('assets/admin-workspace.css'));
    if(!ovf_workspace_on_screen()) return;
    wp_enqueue_script('ovf-platform-search',OVF_URL.'assets/platform-search.js',[],ovf_asset_version('assets/platform-search.js'),true);
    wp_localize_script('ovf-platform-search','OVFPAdmin',[
      'ajax'=>admin_url('admin-ajax.php'),
      'userNonce'=>wp_create_nonce('ovfp_user_suggest'),
      'businessNonce'=>wp_create_nonce('ovf_business_search')
    ]);
},50);

/**
 * Resilient layout bootstrapping for custom admin themes (including Hostinger).
 * The native menu is only visually hidden on our own plugin screens; its
 * registered submenu callbacks, capabilities and URLs remain intact.
 */
add_action('admin_head', function () {
    if (!ovf_workspace_on_screen()) return;
    // One layout for the plugin only. Reset host-theme shell decorations; no
    // global body overlays or extreme stacking contexts that hide controls.
    echo '<style id="ovf-workspace-clean-layout">'
       . 'body.ovf-workspace-screen #adminmenumain,body.ovf-workspace-screen #adminmenuwrap,body.ovf-workspace-screen #adminmenuback{display:none!important}'
       . 'body.ovf-workspace-screen #wpcontent,body.ovf-workspace-screen #wpbody,body.ovf-workspace-screen #wpbody-content{border:0!important;box-shadow:none!important;outline:0!important;background:#f7f8fb!important}'
       . 'body.ovf-workspace-screen #wpcontent::before,body.ovf-workspace-screen #wpcontent::after,body.ovf-workspace-screen #wpbody::before,body.ovf-workspace-screen #wpbody::after,body.ovf-workspace-screen #wpbody-content::before,body.ovf-workspace-screen #wpbody-content::after{content:none!important;display:none!important}'
       . 'body.ovf-workspace-screen #wpcontent,body.ovf-workspace-screen #wpfooter{margin-left:0!important}'
       . '@media(min-width:783px){body.ovf-workspace-screen #wpcontent{position:fixed!important;inset:var(--wp-admin--admin-bar--height,32px) 0 0!important;z-index:100!important;width:100vw!important;height:calc(100dvh - var(--wp-admin--admin-bar--height,32px))!important;margin:0!important;padding:0!important;overflow-x:hidden!important;overflow-y:auto!important;isolation:isolate!important}body.ovf-workspace-screen #wpbody-content{box-sizing:border-box!important;padding-left:252px!important;padding-right:20px!important;min-width:0!important}body.ovf-workspace-screen .ovf-workspace-nav{position:fixed!important;left:16px!important;top:calc(var(--wp-admin--admin-bar--height,32px) + 16px)!important;bottom:16px!important;width:218px!important;z-index:110!important}body.ovf-workspace-screen #wpfooter{display:none!important}}'
       . '@media(min-width:783px) and (max-width:1200px){body.ovf-workspace-screen #wpbody-content{padding-left:232px!important;padding-right:12px!important}body.ovf-workspace-screen .ovf-workspace-nav{left:12px!important;width:204px!important}}'
       . '@media(max-width:782px){body.ovf-workspace-screen #wpbody-content{padding:0!important}body.ovf-workspace-screen .ovf-workspace-nav{position:relative!important;left:auto!important;top:auto!important;bottom:auto!important;width:calc(100% - 24px)!important}}'
       . '</style>';
}, 999);
add_action('admin_footer', function () {
    if (!ovf_workspace_on_screen()) return;
    echo '<script id="ovf-workspace-layout-guard">(function(){'
       . 'var b=document.body;if(!b)return;b.classList.add("ovf-workspace-screen");'
       . 'var ids=["adminmenumain","adminmenuwrap","adminmenuback"];'
       . 'ids.forEach(function(id){var e=document.getElementById(id);if(e){e.style.setProperty("display","none","important");}});'
       . 'var content=document.getElementById("wpcontent");if(content){content.style.setProperty("margin-left","0","important");}'
       . 'var footer=document.getElementById("wpfooter");if(footer){footer.style.setProperty("margin-left","0","important");}'
       . '})();</script>';
}, 999);
