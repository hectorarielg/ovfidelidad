<?php
/**
 * OV Fidelidad 0.14 — Motor de beneficios.
 *
 * Reglas:
 *  - "Una sola vez": se gana una vez cuando el cliente tiene N compras vigentes.
 *  - "Cíclica": funciona como una tarjeta de sellos. Cada N compras se gana y la cuenta vuelve a 0;
 *    las compras sobrantes pasan al siguiente ciclo.
 * Tiempo (ambos opcionales, por defecto sin caducidad):
 *  - Vigencia de compras (ajuste general `ovf_purchase_window_days`): solo cuentan las compras de los
 *    últimos X días. Las antiguas dejan de contar una a una; no hay reinicio brusco.
 *  - Vencimiento del beneficio (por regla, `expires_days`): días que tiene el cliente para canjearlo.
 * La sincronización ocurre al registrar compras, al guardar beneficios y al abrir ficha o tarjeta,
 * así un cliente que ya cumplía recibe el beneficio aunque la regla se haya creado después.
 */
if (!defined('ABSPATH')) exit;

/* ---------- Esquema (instalaciones anteriores) ---------- */
function ovf_ensure_rules_schema() {
	static $done = false; if ($done) return; $done = true;
	if (ovf_get_option('ovf_rules_schema') === '1.0' && get_transient('ovf_schema_checked_'.ovf_business_id())) return;
	ovf_ensure_rules_schema_force();
	ovf_update_option('ovf_rules_schema', '1.0');
	set_transient('ovf_schema_checked_'.ovf_business_id(), 1, HOUR_IN_SECONDS); // se vuelve a verificar cada hora
}

/** Repara la estructura de tablas (se usa si una escritura falla). */
function ovf_repair_schema() {
	delete_transient('ovf_schema_checked_'.ovf_business_id()); ovf_delete_option('ovf_rules_schema');
	if (function_exists('ovf_install_schema')) ovf_install_schema();
	ovf_ensure_rules_schema_force();
}
/**
 * Verifica columna por columna las 4 tablas y agrega las que falten.
 * Necesario porque dbDelta() no detecta columnas en sentencias CREATE de una sola línea, de modo que
 * las instalaciones antiguas (p. ej. una tabla de beneficios sin `rule_id`) nunca se actualizaban.
 * También permite NULL en columnas heredadas desconocidas que impedirían insertar registros.
 */
function ovf_schema_columns() {
	return [
		'clients' => ['token' => "varchar(64) NOT NULL DEFAULT ''", 'name' => "varchar(190) NOT NULL DEFAULT ''", 'email' => "varchar(190) DEFAULT ''", 'phone' => "varchar(60) DEFAULT ''", 'visits' => 'int unsigned NOT NULL DEFAULT 0', 'status' => "varchar(20) NOT NULL DEFAULT 'active'", 'notes' => 'text NULL', 'privacy_at' => 'datetime NULL DEFAULT NULL', 'created_at' => 'datetime NULL', 'updated_at' => 'datetime NULL'],
		'moves'   => ['client_id' => 'bigint unsigned NOT NULL DEFAULT 0', 'type' => "varchar(30) NOT NULL DEFAULT 'purchase'", 'amount' => 'int NOT NULL DEFAULT 0', 'reward_id' => 'bigint unsigned DEFAULT 0', 'note' => 'text NULL', 'user_id' => 'bigint unsigned DEFAULT 0', 'method' => "varchar(30) NOT NULL DEFAULT 'manual'", 'created_at' => 'datetime NULL'],
		'rewards' => ['client_id' => 'bigint unsigned NOT NULL DEFAULT 0', 'rule_id' => 'bigint unsigned NOT NULL DEFAULT 0', 'milestone' => 'int unsigned NOT NULL DEFAULT 0', 'title' => "varchar(190) NOT NULL DEFAULT ''", 'status' => "varchar(20) NOT NULL DEFAULT 'available'", 'unlocked_at' => 'datetime NULL', 'redeemed_at' => 'datetime NULL DEFAULT NULL', 'user_id' => 'bigint unsigned DEFAULT 0', 'move_id' => 'bigint unsigned NOT NULL DEFAULT 0', 'expires_at' => 'datetime NULL DEFAULT NULL'],
		'rules'   => ['milestone' => 'int unsigned NOT NULL DEFAULT 1', 'title' => "varchar(190) NOT NULL DEFAULT ''", 'description' => 'text NULL', 'enabled' => 'tinyint(1) NOT NULL DEFAULT 1', 'repeats' => 'tinyint(1) NOT NULL DEFAULT 0', 'expires_days' => 'int unsigned NOT NULL DEFAULT 0', 'sort_order' => 'int NOT NULL DEFAULT 0', 'created_at' => 'datetime NULL'],
	];
}
function ovf_ensure_rules_schema_force() {
	global $wpdb; $t = ovf_tables(); $log = [];
	foreach (ovf_schema_columns() as $key => $cols) {
		$table = $t[$key];
		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) continue;
		$info = $wpdb->get_results("SHOW COLUMNS FROM {$table}");
		if (!$info) continue;
		$have = [];
		foreach ($info as $c) $have[$c->Field] = $c;
		foreach ($cols as $name => $def) {
			if (!isset($have[$name])) {
				$ok = $wpdb->query("ALTER TABLE {$table} ADD {$name} {$def}");
				$log[] = ($ok === false ? 'ERROR ' : '') . "{$key}.{$name}";
			}
		}
		// Columnas heredadas que ya no usamos y exigen valor: se vuelven opcionales para no bloquear inserciones.
		foreach ($have as $name => $c) {
			if ($name === 'id' || isset($cols[$name]) || stripos((string) $c->Extra, 'auto_increment') !== false) continue;
			if ($c->Null === 'NO' && $c->Default === null) {
				$ok = $wpdb->query("ALTER TABLE {$table} MODIFY {$name} {$c->Type} NULL");
				$log[] = ($ok === false ? 'ERROR ' : '') . "{$key}.{$name} → NULL";
			}
		}
	}
	ovf_update_option('ovf_rules_schema', '0.14');
	if ($log) ovf_update_option('ovf_schema_repair_log', ['time' => current_time('mysql'), 'changes' => $log], false);
	return $log;
}
add_action('init', 'ovf_ensure_rules_schema', 6);

/* ---------- Ajustes de tiempo ---------- */
function ovf_purchase_window_days() { return absint(ovf_get_option('ovf_purchase_window_days', 0)); }
/** Fecha desde la que cuentan las compras ('' = sin caducidad). */
function ovf_window_cutoff() {
	$d = ovf_purchase_window_days();
	return $d ? wp_date('Y-m-d H:i:s', current_time('timestamp', true) - $d * DAY_IN_SECONDS) : '';
}
function ovf_rule_repeats($r) { return !empty($r->repeats); }
function ovf_rule_expires_days($r) { return isset($r->expires_days) ? absint($r->expires_days) : 0; }

/* ---------- Consultas de compras ---------- */
/** Compras vigentes del cliente (todas si no hay ventana). */
function ovf_active_purchases($client_id) {
	global $wpdb; $t = ovf_tables(); $cut = ovf_window_cutoff();
	if (!$cut) return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE client_id=%d AND type='purchase'", $client_id));
	return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE client_id=%d AND type='purchase' AND created_at>=%s", $client_id, $cut));
}
/** IDs de compras vigentes posteriores a $after_id, en orden. */
function ovf_purchase_ids_after($client_id, $after_id) {
	global $wpdb; $t = ovf_tables(); $cut = ovf_window_cutoff();
	$sql = "SELECT id FROM {$t['moves']} WHERE client_id=%d AND type='purchase' AND id>%d";
	$args = [$client_id, $after_id];
	if ($cut) { $sql .= ' AND created_at>=%s'; $args[] = $cut; }
	return array_map('intval', $wpdb->get_col($wpdb->prepare($sql . ' ORDER BY id ASC', $args)));
}
/** Número de compra (histórico) que representa un movimiento: "ganado en la compra 10". */
function ovf_purchase_number($client_id, $move_id) {
	global $wpdb; $t = ovf_tables();
	return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE client_id=%d AND type='purchase' AND id<=%d", $client_id, $move_id));
}
/** Último movimiento que "consumió" compras para una regla cíclica (convierte registros anteriores a 0.14). */
function ovf_rule_last_move($client_id, $rule) {
	global $wpdb; $t = ovf_tables();
	$rows = $wpdb->get_results($wpdb->prepare("SELECT id, milestone, move_id FROM {$t['rewards']} WHERE client_id=%d AND rule_id=%d", $client_id, $rule->id));
	$last = 0;
	foreach ($rows as $rw) {
		$mid = (int) $rw->move_id;
		if (!$mid && (int) $rw->milestone > 0) { // registro antiguo: la compra número "milestone"
			$mid = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['moves']} WHERE client_id=%d AND type='purchase' ORDER BY id ASC LIMIT 1 OFFSET %d", $client_id, (int) $rw->milestone - 1));
			if ($mid) $wpdb->update($t['rewards'], ['move_id' => $mid], ['id' => $rw->id]);
		}
		$last = max($last, $mid);
	}
	return $last;
}

/* ---------- Otorgar y vencer ---------- */
function ovf_grant_reward($client_id, $rule, $move_id) {
	global $wpdb; $t = ovf_tables();
	$days = ovf_rule_expires_days($rule);
	$row = [
		'client_id'   => $client_id,
		'rule_id'     => $rule->id,
		'milestone'   => ovf_purchase_number($client_id, $move_id),
		'move_id'     => $move_id,
		'title'       => $rule->title,
		'status'      => 'available',
		'unlocked_at' => current_time('mysql'),
		'expires_at'  => $days ? wp_date('Y-m-d 23:59:59', current_time('timestamp', true) + $days * DAY_IN_SECONDS) : null,
		'user_id'     => get_current_user_id(),
	];
	$ok = $wpdb->insert($t['rewards'], $row);
	if ($ok === false) { // estructura desactualizada: se repara y se reintenta una vez
		ovf_repair_schema();
		$ok = $wpdb->insert($t['rewards'], $row);
	}
	if ($ok === false) {
		ovf_update_option('ovf_last_reward_error', ['time' => current_time('mysql'), 'error' => $wpdb->last_error, 'rule' => $rule->title], false);
		return null;
	}
	return $rule->title;
}

/** Marca como vencidos los beneficios disponibles cuyo plazo terminó (de un cliente o de todos). */
function ovf_expire_rewards($client_id = 0) {
	global $wpdb; $t = ovf_tables();
	$sql = "UPDATE {$t['rewards']} SET status='expired' WHERE status='available' AND expires_at IS NOT NULL AND expires_at<%s";
	$args = [current_time('mysql')];
	if ($client_id) { $sql .= ' AND client_id=%d'; $args[] = $client_id; }
	$wpdb->query($wpdb->prepare($sql, $args));
}

/** Otorga lo que corresponda según las compras vigentes. Devuelve los títulos nuevos. */
function ovf_unlock_rewards_v2($client_id, $visits = null) {
	global $wpdb; $t = ovf_tables(); $new = [];
	$client_id = absint($client_id);
	ovf_expire_rewards($client_id);
	$active = ovf_active_purchases($client_id);
	foreach (ovf_rules() as $r) {
		$m = max(1, (int) $r->milestone);
		if (ovf_rule_repeats($r)) {
			$ids = ovf_purchase_ids_after($client_id, ovf_rule_last_move($client_id, $r));
			for ($i = $m - 1; $i < count($ids) && $i < 5000; $i += $m) { $g = ovf_grant_reward($client_id, $r, $ids[$i]); if ($g === null) break; $new[] = $g; }
		} else {
			$has = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['rewards']} WHERE client_id=%d AND rule_id=%d", $client_id, $r->id));
			if (!$has && $active >= $m) {
				$last = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(id) FROM {$t['moves']} WHERE client_id=%d AND type='purchase'", $client_id));
				$g = ovf_grant_reward($client_id, $r, $last); if ($g !== null) $new[] = $g;
			}
		}
	}
	return $new;
}

function ovf_sync_client_rewards($client) {
	if (!$client) return [];
	ovf_expire_rewards($client->id);
	if ($client->status !== 'active') return [];
	return ovf_unlock_rewards_v2($client->id);
}

function ovf_sync_all_rewards() {
	global $wpdb; $t = ovf_tables(); $total = 0;
	ovf_expire_rewards();
	foreach ($wpdb->get_col("SELECT id FROM {$t['clients']} WHERE status='active' AND visits>0") as $id) $total += count(ovf_unlock_rewards_v2((int) $id));
	return $total;
}

/** Tras borrar movimientos: quita beneficios disponibles cuya compra ya no existe y vuelve a calcular. */
function ovf_rewards_after_moves_deleted($client_id) {
	global $wpdb; $t = ovf_tables();
	$ids = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT id FROM {$t['moves']} WHERE client_id=%d AND type='purchase'", $client_id)));
	$rows = $wpdb->get_results($wpdb->prepare("SELECT id, move_id, milestone FROM {$t['rewards']} WHERE client_id=%d AND status='available'", $client_id));
	foreach ($rows as $rw) {
		$gone = (int) $rw->move_id ? !in_array((int) $rw->move_id, $ids, true) : ((int) $rw->milestone > count($ids));
		if ($gone) $wpdb->delete($t['rewards'], ['id' => $rw->id]);
	}
	ovf_unlock_rewards_v2($client_id);
}

/**
 * Próximo beneficio del cliente. Devuelve ['rule','left','target','from'] o null.
 * target/from se expresan sobre $visits para que la barra muestre el avance del tramo actual.
 */
function ovf_next_reward($visits, $client_id = 0) {
	$visits = (int) $visits; $best = null;
	$active = $client_id ? ovf_active_purchases($client_id) : $visits;
	foreach (ovf_rules() as $r) {
		$m = max(1, (int) $r->milestone);
		if (ovf_rule_repeats($r)) {
			$done = $client_id ? count(ovf_purchase_ids_after($client_id, ovf_rule_last_move($client_id, $r))) % $m : $visits % $m;
		} else {
			if ($client_id && ovf_client_has_rule_reward($client_id, $r->id)) continue;
			if (!$client_id && $visits >= $m) continue;
			$done = min($active, $m - 1);
		}
		$left = $m - $done;
		if (!$best || $left < $best['left']) $best = ['rule' => $r, 'left' => $left, 'target' => $visits + $left, 'from' => $visits + $left - $m];
	}
	return $best;
}
function ovf_client_has_rule_reward($client_id, $rule_id) {
	global $wpdb; $t = ovf_tables();
	return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['rewards']} WHERE client_id=%d AND rule_id=%d LIMIT 1", $client_id, $rule_id));
}

/** "Al llegar a 5 compras" / "Cada 5 compras" (+ vencimiento). */
function ovf_rule_label($r) {
	$m = (int) $r->milestone;
	$txt = ovf_rule_repeats($r)
		? sprintf(_n('Cada compra', 'Cada %d compras', $m, 'ov-fidelidad'), $m)
		: sprintf(_n('Al llegar a %d compra', 'Al llegar a %d compras', $m, 'ov-fidelidad'), $m);
	if ($d = ovf_rule_expires_days($r)) $txt .= ' · ' . sprintf(_n('%d día para canjear', '%d días para canjear', $d, 'ov-fidelidad'), $d);
	return $txt;
}
/** "Vence el 12 de octubre" para un beneficio disponible con plazo. */
function ovf_reward_expiry_text($rw) {
	if (empty($rw->expires_at)) return '';
	return sprintf(__('Vence el %s', 'ov-fidelidad'), date_i18n(get_option('date_format'), strtotime($rw->expires_at)));
}

/* ---------- Diagnóstico (escritorio) ---------- */
/** Explica, regla por regla, por qué un cliente tiene o no cada beneficio. */
function ovf_reward_diagnosis($client) {
	global $wpdb; $t = ovf_tables(); $out = [];
	$active = ovf_active_purchases($client->id);
	foreach (ovf_all_rules() as $r) {
		$m = max(1, (int) $r->milestone);
		$got = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['rewards']} WHERE client_id=%d AND rule_id=%d", $client->id, $r->id));
		if (!(int) $r->enabled) $why = __('Beneficio desactivado: no se otorga.', 'ov-fidelidad');
		elseif ($client->status !== 'active') $why = __('El cliente está inactivo.', 'ov-fidelidad');
		elseif (ovf_rule_repeats($r)) {
			$pend = count(ovf_purchase_ids_after($client->id, ovf_rule_last_move($client->id, $r)));
			$why = $pend >= $m ? __('Debería otorgarse: pulsa "Revisar y reparar".', 'ov-fidelidad') : sprintf(__('Lleva %1$d de %2$d compras del ciclo actual.', 'ov-fidelidad'), $pend, $m);
		} elseif ($got) $why = __('Ya otorgado (se gana una sola vez).', 'ov-fidelidad');
		elseif ($active >= $m) $why = __('Debería otorgarse: pulsa "Revisar y reparar".', 'ov-fidelidad');
		else $why = sprintf(__('Tiene %1$d de %2$d compras vigentes.', 'ov-fidelidad'), $active, $m);
		$out[] = ['rule' => $r, 'got' => $got, 'why' => $why];
	}
	return $out;
}

/** Aviso + reparación en el escritorio cuando un beneficio no se pudo guardar. */
add_action('admin_init', function () {
	if (!current_user_can('manage_options') || empty($_GET['ovf_repair'])) return;
	check_admin_referer('ovf_repair');
	ovf_repair_schema();
	ovf_delete_option('ovf_last_reward_error');
	$n = ovf_sync_all_rewards();
	$still = ovf_get_option('ovf_last_reward_error'); // si vuelve a fallar, se informa en lugar de dar un falso "todo bien"
	set_transient('ovf_repair_done_' . get_current_user_id(), ['n' => $n, 'ok' => !$still], 60);
	wp_safe_redirect(remove_query_arg(['ovf_repair', '_wpnonce']));
	exit;
});
add_action('admin_notices', function () {
	if (!current_user_can('manage_options')) return;
	$done = get_transient('ovf_repair_done_' . get_current_user_id());
	if ($done !== false) {
		delete_transient('ovf_repair_done_' . get_current_user_id());
		$n = is_array($done) ? (int) $done['n'] : (int) $done;
		if (!is_array($done) || $done['ok']) {
			$log = ovf_get_option('ovf_schema_repair_log');
			$fixed = $log && !empty($log['changes']) ? ' ' . sprintf(__('Columnas corregidas: %s.', 'ov-fidelidad'), implode(', ', $log['changes'])) : '';
			echo '<div class="notice notice-success is-dismissible"><p><b>OV Fidelidad:</b> ' . esc_html(sprintf(_n('Base de datos reparada. Se otorgó %d beneficio pendiente.', 'Base de datos reparada. Se otorgaron %d beneficios pendientes.', $n, 'ov-fidelidad'), $n) . $fixed) . '</p></div>';
		}
	}
	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	if ($screen && strpos((string) $screen->id, 'ov-fidelidad') === false && $screen->id !== 'dashboard' && $screen->id !== 'plugins') return;
	$e = ovf_get_option('ovf_last_reward_error');
	if (!$e) return;
	$url = wp_nonce_url(add_query_arg('ovf_repair', '1'), 'ovf_repair');
	echo '<div class="notice notice-error"><p><b>OV Fidelidad:</b> ' . esc_html(sprintf(__('No se pudo guardar el beneficio “%s”.', 'ov-fidelidad'), $e['rule'])) . ' <code>' . esc_html($e['error'] ?: '—') . '</code></p><p><a class="button button-primary" href="' . esc_url($url) . '">' . esc_html__('Revisar y reparar ahora', 'ov-fidelidad') . '</a></p></div>';
});

/* ---------- Guardar reglas (compartido por escritorio y Web App) ---------- */
function ovf_rule_data_from($src) {
	return [
		'milestone'    => max(1, min(10000, absint($src['milestone'] ?? 1))),
		'title'        => sanitize_text_field(wp_unslash($src['title'] ?? '')),
		'description'  => sanitize_textarea_field(wp_unslash($src['description'] ?? '')),
		'repeats'      => (($src['repeats'] ?? '0') === '1') ? 1 : 0,
		'expires_days' => min(3650, absint($src['expires_days'] ?? 0)),
	];
}
/** Crea o actualiza una regla y sincroniza clientes. Devuelve [ok, beneficios asignados]. */
function ovf_save_rule($data, $id = 0, $enabled = null) {
	global $wpdb; $t = ovf_tables(); ovf_ensure_rules_schema();
	if ($data['title'] === '') return [false, 0];
	if ($enabled !== null) $data['enabled'] = $enabled ? 1 : 0;
	if ($id) $ok = $wpdb->update($t['rules'], $data, ['id' => absint($id)]) !== false;
	else $ok = (bool) $wpdb->insert($t['rules'], $data + ['enabled' => 1, 'sort_order' => $data['milestone'], 'created_at' => current_time('mysql')]);
	if (!$ok) { ovf_repair_schema(); $ok = $id ? $wpdb->update($t['rules'], $data, ['id' => absint($id)]) !== false : (bool) $wpdb->insert($t['rules'], $data + ['enabled' => 1, 'sort_order' => $data['milestone'], 'created_at' => current_time('mysql')]); }
	return [$ok, $ok ? ovf_sync_all_rewards() : 0];
}
