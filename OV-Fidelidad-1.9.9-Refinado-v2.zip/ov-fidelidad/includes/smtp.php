<?php
/** Global SMTP transport and sender address configuration. */
if (!defined('ABSPATH')) exit;

function ovf_smtp_settings(){
 $defaults=['enabled'=>0,'host'=>'','port'=>587,'encryption'=>'tls','auth'=>1,'username'=>'','password'=>'','from_email'=>''];
 $saved=get_option('ovf_smtp_settings',[]);
 return wp_parse_args(is_array($saved)?$saved:[],$defaults);
}

function ovf_smtp_apply($mailer){
 $s=ovf_smtp_settings();
 if(empty($s['enabled'])||empty($s['host']))return;
 $mailer->isSMTP();
 $mailer->Host=(string)$s['host'];
 $mailer->Port=max(1,min(65535,absint($s['port'])));
 $mailer->SMTPAuth=!empty($s['auth']);
 if($mailer->SMTPAuth){$mailer->Username=(string)$s['username'];$mailer->Password=(string)$s['password'];}
 $mailer->SMTPSecure=in_array($s['encryption'],['tls','ssl'],true)?$s['encryption']:'';
 $mailer->SMTPAutoTLS=$s['encryption']==='tls';
 $mailer->Timeout=20;
 $mailer->SMTPDebug=0;
}
add_action('phpmailer_init','ovf_smtp_apply',99);

function ovf_smtp_from_address($default){$s=ovf_smtp_settings();return !empty($s['from_email'])&&is_email($s['from_email'])?$s['from_email']:$default;}

function ovf_smtp_capture_error($error){
 if(is_wp_error($error))set_transient('ovf_smtp_test_error_'.get_current_user_id(),sanitize_text_field($error->get_error_message()),2*MINUTE_IN_SECONDS);
}

function ovf_smtp_save_request(&$message,&$type){
 if(!current_user_can('manage_options'))return false;
 check_admin_referer('ovf_smtp_settings');
 $old=ovf_smtp_settings();
 $enabled=empty($_POST['smtp_enabled'])?0:1;
 $host=sanitize_text_field(wp_unslash($_POST['smtp_host']??''));
 $port=absint($_POST['smtp_port']??587);
 $encryption=sanitize_key($_POST['smtp_encryption']??'tls');
 $auth=empty($_POST['smtp_auth'])?0:1;
 $username=sanitize_text_field(wp_unslash($_POST['smtp_username']??''));
 $password=(string)wp_unslash($_POST['smtp_password']??'');
 $clear_password=!empty($_POST['smtp_clear_password']);
 $from_email=sanitize_email(wp_unslash($_POST['smtp_from_email']??''));
 if(!in_array($encryption,['tls','ssl','none'],true))$encryption='tls';
 if($port<1||$port>65535){$message=__('El puerto debe estar entre 1 y 65535.','ov-fidelidad');$type='error';return false;}
 if($enabled&&(!$host||!preg_match('/^[A-Za-z0-9.-]+$/',$host))){$message=__('Escribe un servidor SMTP válido.','ov-fidelidad');$type='error';return false;}
 if(($enabled||$from_email)&&!is_email($from_email)){$message=__('Escribe un correo remitente válido, preferiblemente del mismo dominio autenticado por tu proveedor.','ov-fidelidad');$type='error';return false;}
 if($auth&&$enabled&&(!$username||(!$password&&empty($old['password']))||$clear_password)){$message=__('Completa el usuario y la contraseña SMTP, o deja la contraseña guardada sin cambios.','ov-fidelidad');$type='error';return false;}
 if($clear_password)$password='';elseif($password==='')$password=$old['password'];
 $settings=['enabled'=>$enabled,'host'=>$host,'port'=>$port,'encryption'=>$encryption,'auth'=>$auth,'username'=>$username,'password'=>$password,'from_email'=>$from_email];
 update_option('ovf_smtp_settings',$settings,false);
 $message=__('Configuración de correo guardada.','ov-fidelidad');$type='success';
 if(($_POST['ovf_smtp_action']??'')==='test'){
  $recipient=sanitize_email(wp_unslash($_POST['smtp_test_email']??get_option('admin_email')));
  if(!is_email($recipient)){$message=__('Escribe un correo válido para recibir la prueba.','ov-fidelidad');$type='error';return false;}
  delete_transient('ovf_smtp_test_error_'.get_current_user_id());
  add_action('wp_mail_failed','ovf_smtp_capture_error');
  add_filter('wp_mail_from','ovf_smtp_from_address',99);
  $test_name=get_bloginfo('name');$test_name_filter=function($default)use($test_name){return $test_name?:$default;};add_filter('wp_mail_from_name',$test_name_filter,99);
  $sent=wp_mail($recipient,__('Prueba de configuración de correo','ov-fidelidad'),__('Este mensaje confirma que el envío de correo está configurado.','ov-fidelidad'));
  remove_filter('wp_mail_from_name',$test_name_filter,99);remove_filter('wp_mail_from','ovf_smtp_from_address',99);remove_action('wp_mail_failed','ovf_smtp_capture_error');
  $failure=get_transient('ovf_smtp_test_error_'.get_current_user_id());delete_transient('ovf_smtp_test_error_'.get_current_user_id());
  if($sent){$message=sprintf(__('Se envió una solicitud de prueba a %s. Revisa también la carpeta de spam.','ov-fidelidad'),$recipient);$type='success';}
  else{$message=$failure?sprintf(__('Falló la prueba de correo: %s','ov-fidelidad'),$failure):__('No se pudo enviar la prueba. Revisa los datos SMTP y vuelve a intentarlo.','ov-fidelidad');$type='error';}
 }
 return true;
}

function ovf_admin_smtp(){
 if(!current_user_can('manage_options'))return;
 $message='';$type='success';
 if((isset($_POST['ovf_smtp_save'])||isset($_POST['ovf_smtp_test_button']))&&ovf_smtp_save_request($message,$type)){
  set_transient('ovf_smtp_notice_'.get_current_user_id(),[$type,$message],2*MINUTE_IN_SECONDS);
  wp_safe_redirect(admin_url('admin.php?page=ov-fidelidad-mail'));exit;
 }
 if(!$message&&isset($_GET['smtp_saved'])){$notice=get_transient('ovf_smtp_notice_'.get_current_user_id());delete_transient('ovf_smtp_notice_'.get_current_user_id());if(is_array($notice))[$type,$message]=$notice;}
 $s=ovf_smtp_settings();ovf_assets();
 echo '<div class="wrap ovf-admin" style="'.ovf_brand_style().'"><div class="ovf-admin-head"><div class="ovf-admin-heading"><span class="ovf-eyebrow">OV FIDELIDAD · SISTEMA</span><h1>'.esc_html__('Correo saliente','ov-fidelidad').'</h1><p>'.esc_html__('Configura una conexión de correo para las campañas de todos los negocios. El remitente visible de cada campaña será el nombre comercial del negocio.','ov-fidelidad').'</p></div></div>';
 if($message)echo '<div class="ovf-notice '.($type==='error'?'error':'').'">'.esc_html($message).'</div>';
 echo '<div class="ovf-smtp-layout"><section class="ovf-panel"><div class="ovf-smtp-note"><b>'.esc_html__('Para evitar que el remitente aparezca como wordpress@…','ov-fidelidad').'</b><span>'.esc_html__('Configura una dirección autorizada por tu proveedor SMTP. Usa una dirección de tu dominio y publica sus registros SPF y DKIM.','ov-fidelidad').'</span></div>';
 echo '<form method="post" class="ovf-fields ovf-smtp-form">';wp_nonce_field('ovf_smtp_settings');
 echo '<label class="ovf-check-row ovf-smtp-toggle"><input type="checkbox" name="smtp_enabled" value="1" '.checked((int)$s['enabled'],1,false).'><span><b>'.esc_html__('Usar envío SMTP','ov-fidelidad').'</b><small>'.esc_html__('Si se desactiva, los mensajes utilizarán el método de correo predeterminado del servidor.','ov-fidelidad').'</small></span></label>';
 echo '<label><span>'.esc_html__('Servidor SMTP','ov-fidelidad').'</span><input name="smtp_host" value="'.esc_attr($s['host']).'" placeholder="smtp.tudominio.com" autocomplete="url"></label>';
 echo '<label><span>'.esc_html__('Puerto','ov-fidelidad').'</span><input type="number" name="smtp_port" min="1" max="65535" value="'.(int)$s['port'].'"></label>';
 echo '<label><span>'.esc_html__('Seguridad de conexión','ov-fidelidad').'</span><select name="smtp_encryption"><option value="tls" '.selected($s['encryption'],'tls',false).'>TLS (recomendado · 587)</option><option value="ssl" '.selected($s['encryption'],'ssl',false).'>SSL (465)</option><option value="none" '.selected($s['encryption'],'none',false).'>Sin cifrado</option></select></label>';
 echo '<label class="ovf-check-row"><input type="checkbox" name="smtp_auth" value="1" '.checked((int)$s['auth'],1,false).'><span><b>'.esc_html__('El servidor requiere autenticación','ov-fidelidad').'</b></span></label>';
 echo '<label><span>'.esc_html__('Usuario SMTP','ov-fidelidad').'</span><input name="smtp_username" value="'.esc_attr($s['username']).'" autocomplete="username"></label>';
 echo '<label><span>'.esc_html__('Contraseña SMTP','ov-fidelidad').'</span><input type="password" name="smtp_password" value="" autocomplete="new-password" placeholder="'.esc_attr($s['password']?__('Guardada · deja vacío para conservarla','ov-fidelidad'):__('Introduce la contraseña de aplicación','ov-fidelidad')).'"><small>'.esc_html__('Solo se muestra si la escribes; se conserva en los ajustes del sitio y no se vuelve a imprimir en pantalla.','ov-fidelidad').'</small></label>';
 if($s['password'])echo '<label class="ovf-check-row"><input type="checkbox" name="smtp_clear_password" value="1"><span><b>'.esc_html__('Eliminar la contraseña guardada','ov-fidelidad').'</b></span></label>';
 echo '<label class="ovf-span"><span>'.esc_html__('Dirección remitente autorizada','ov-fidelidad').'</span><input type="email" name="smtp_from_email" value="'.esc_attr($s['from_email']).'" placeholder="promociones@tudominio.com" autocomplete="email"><small>'.esc_html__('Debe estar permitida por el servidor SMTP y, de preferencia, pertenecer al dominio autenticado. Esta dirección reemplaza wordpress@… en las campañas del plugin.','ov-fidelidad').'</small></label>';
 echo '<label class="ovf-span"><span>'.esc_html__('Enviar prueba a','ov-fidelidad').'</span><input type="email" name="smtp_test_email" value="'.esc_attr(get_option('admin_email')).'" placeholder="tu-correo@ejemplo.com"></label>';
 echo '<div class="ovf-span ovf-smtp-actions"><button class="ovf-admin-btn" name="ovf_smtp_save" value="1" type="submit" onclick="this.form.ovf_smtp_action.value=\'save\'">'.esc_html__('Guardar configuración','ov-fidelidad').'</button><button class="button" name="ovf_smtp_test_button" value="1" type="submit" onclick="this.form.ovf_smtp_action.value=\'test\'">'.esc_html__('Guardar y enviar prueba','ov-fidelidad').'</button><input type="hidden" name="ovf_smtp_action" value="save"></div>';
 echo '</form></section><aside class="ovf-panel ovf-smtp-aside"><h2>'.esc_html__('Datos que necesitas de tu proveedor','ov-fidelidad').'</h2><ul><li>'.esc_html__('Servidor SMTP, puerto y tipo de cifrado.','ov-fidelidad').'</li><li>'.esc_html__('Usuario y contraseña o contraseña de aplicación.','ov-fidelidad').'</li><li>'.esc_html__('Una dirección remitente verificada.','ov-fidelidad').'</li><li>'.esc_html__('Registros SPF y DKIM publicados en el DNS del dominio.','ov-fidelidad').'</li></ul><p>'.esc_html__('La conexión SMTP ayuda a autenticar el envío, pero no garantiza por sí sola que todos los mensajes lleguen a la bandeja principal.','ov-fidelidad').'</p></aside></div></div>';
}
