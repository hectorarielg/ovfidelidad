<?php
/** Global staff portal branding independent from all business-specific OV Fidelidad settings. */
if (!defined('ABSPATH')) exit;

function ovf_global_login_request() {
    // Only the main staff portal, without a business slug, uses global branding and recovery.
    return is_page((int)get_option('ovf_page_portal')) && empty($_GET['ovf_business']);
}
/** The general portal never inherits the selected business' permalink context. */
function ovf_global_login_portal_url() {
    $id=(int)get_option('ovf_page_portal');
    $url=$id ? get_permalink($id) : home_url('/fidelidad-app/');
    // Never inherit a selected business or recovery state from the active admin context.
    return remove_query_arg(['ovf_business','ovf_business_id','ovf_recovery','ovf_login_scope','ovf_err','view'], $url);
}
/** Identifies the general recovery flow without relying on the active business. */
function ovf_global_recovery_url($state='') {
    $args=['ovf_login_scope'=>'global'];
    if($state!=='') $args['ovf_recovery']=$state;
    return add_query_arg($args,ovf_global_login_portal_url());
}
/** Used only on the public global sign-in/recovery flow. */
function ovf_global_login_asset_url($id, $size='medium') {
    $url=wp_get_attachment_image_url($id,$size);
    if(!$url) return '';
    // Changed each time branding is saved; protects from stale favicon/image caches.
    $revision=absint(ovf_global_login_option('revision',0));
    return add_query_arg('ovf_brand_rev',$revision ?: 1,$url);
}
add_action('template_redirect',function(){
    if(!ovf_global_login_request() || is_user_logged_in()) return;
    nocache_headers();
},1);
/** Dedicated icon for the global team portal. Does not alter the WordPress site icon. */
function ovf_global_login_icon_url($size='full') {
    $id=absint(ovf_global_login_option('favicon_id',0));
    if (!$id || !wp_attachment_is_image($id)) $id=absint(ovf_global_login_option('logo_id',0));
    return $id && wp_attachment_is_image($id) ? wp_get_attachment_image_url($id,$size) : '';
}
add_action('wp',function(){
    if (ovf_global_login_request()) remove_action('wp_head','wp_site_icon',99);
},20);
add_action('wp_head',function(){
    if (!ovf_global_login_request()) return;
    $icon=ovf_global_login_icon_url('full');
    if (!$icon) { wp_site_icon(); return; }
    $icon=add_query_arg('ovf_brand_rev',absint(ovf_global_login_option('revision',0)) ?: 1,$icon);
    echo '<link rel="icon" type="'.esc_attr(get_post_mime_type(absint(ovf_global_login_option('favicon_id',0)) ?: absint(ovf_global_login_option('logo_id',0)))).'" href="'.esc_url($icon).'">' . "\n";
    echo '<link rel="apple-touch-icon" href="'.esc_url($icon).'">' . "\n";
},100);
function ovf_global_login_option($key, $default = '') {
    return get_option('ovf_global_login_'.$key, $default);
}
function ovf_login_brand_option($key, $default = '') {
    if (!ovf_global_login_request()) return ovf_get_option($key, $default);
    $mapping = ['ovf_brand_name'=>'name','ovf_primary'=>'primary','ovf_accent'=>'accent','ovf_background'=>'background',
        'ovf_password_recovery_mode'=>'recovery_mode','ovf_password_recovery_message'=>'recovery_message'];
    return isset($mapping[$key]) ? ovf_global_login_option($mapping[$key],$default) : ovf_get_option($key,$default);
}
function ovf_login_logo_html($class='') {
    if (!ovf_global_login_request()) return ovf_v02_logo_html($class);
    $id=absint(ovf_global_login_option('logo_id',0));
    if ($id && wp_attachment_is_image($id)) {
        $src=ovf_global_login_asset_url($id,'medium');
        if($src) return '<img src="'.esc_url($src).'" class="'.esc_attr($class).'" alt="'.esc_attr(ovf_global_login_option('name','OV Fidelidad')).'" loading="eager" decoding="async">';
    }
    return '<span class="ovf-app-monogram">'.esc_html(ovf_initial(ovf_global_login_option('name','OV Fidelidad'))).'</span>';
}

add_action('admin_menu',function(){
    add_submenu_page('ov-fidelidad','Acceso general','Acceso general','manage_options','ov-fidelidad-global-login','ovf_global_login_admin_page');
},20);
add_action('admin_enqueue_scripts',function($hook){
    if ($hook==='ov-fidelidad_page_ov-fidelidad-global-login') wp_enqueue_media();
});
function ovf_global_login_admin_page() {
    if (!current_user_can('manage_options')) wp_die('Acceso denegado');
    $notice='';
    if (isset($_POST['ovf_global_save'])) {
        check_admin_referer('ovf_global_login_save');
        update_option('ovf_global_login_name',sanitize_text_field(wp_unslash($_POST['ovf_global_name']??'')) ?: 'OV Fidelidad');
        update_option('ovf_global_login_subtitle',sanitize_text_field(wp_unslash($_POST['ovf_global_subtitle']??'')) ?: 'Acceso del equipo');
        foreach (['primary'=>'#5554ae','accent'=>'#0f172a','background'=>'#f4f5f7'] as $key=>$fallback){
            update_option('ovf_global_login_'.$key,sanitize_hex_color(wp_unslash($_POST['ovf_global_'.$key]??'')) ?: $fallback);
        }
        $logo=absint($_POST['ovf_global_logo_id']??0);
        update_option('ovf_global_login_logo_id',$logo && wp_attachment_is_image($logo) ? $logo : 0);
        $favicon=absint($_POST['ovf_global_favicon_id']??0);
        update_option('ovf_global_login_favicon_id',$favicon && wp_attachment_is_image($favicon) ? $favicon : 0);
        $mode=sanitize_key(wp_unslash($_POST['ovf_global_recovery_mode']??'wordpress'));
        update_option('ovf_global_login_recovery_mode',in_array($mode,['hidden','contact','wordpress'],true) ? $mode : 'wordpress');
        update_option('ovf_global_login_recovery_message',sanitize_textarea_field(wp_unslash($_POST['ovf_global_recovery_message']??'')));
        update_option('ovf_global_login_revision',time());
        $notice='Configuración del acceso general guardada. Los negocios mantienen sus propios ajustes.';
    }
    $name=ovf_global_login_option('name','OV Fidelidad');
    $subtitle=ovf_global_login_option('subtitle','Acceso del equipo');
    $logo=absint(ovf_global_login_option('logo_id',0));
    $logo_url=$logo?wp_get_attachment_image_url($logo,'thumbnail'):'';
    $favicon=absint(ovf_global_login_option('favicon_id',0));
    $favicon_url=$favicon?wp_get_attachment_image_url($favicon,'thumbnail'):'';
    $mode=ovf_global_login_option('recovery_mode','wordpress');
    $recovery_msg=ovf_global_login_option('recovery_message','Contacta al administrador de la plataforma para recuperar tu acceso.');
    $url=get_permalink((int)get_option('ovf_page_portal'));
    ?>
    <div class="wrap ovf-global-settings" style="max-width:920px">
      <h1>Acceso general de OV Fidelidad</h1>
      <p>Personaliza exclusivamente el acceso <strong>sin</strong> <code>?ovf_business=...</code>. No modifica nombres, logos, colores ni recuperación de los negocios.</p>
      <?php if ($notice):?><div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice);?></p></div><?php endif;?>
      <div style="background:#fff;padding:22px 26px;border:1px solid #dce3ea;border-radius:16px;max-width:780px">
        <form method="post">
          <?php wp_nonce_field('ovf_global_login_save');?>
          <h2>Identidad del acceso general</h2>
          <table class="form-table" role="presentation"><tbody>
            <tr><th><label for="ovf_global_name">Nombre de la plataforma</label></th><td><input class="regular-text" id="ovf_global_name" name="ovf_global_name" value="<?php echo esc_attr($name);?>" required></td></tr>
            <tr><th><label for="ovf_global_subtitle">Subtítulo</label></th><td><input class="regular-text" id="ovf_global_subtitle" name="ovf_global_subtitle" value="<?php echo esc_attr($subtitle);?>"></td></tr>
            <tr><th>Logotipo del acceso</th><td><input type="hidden" id="ovf_global_logo_id" name="ovf_global_logo_id" value="<?php echo (int)$logo;?>"><div id="ovf-global-logo-preview" style="margin-bottom:12px"><?php if($logo_url):?><img src="<?php echo esc_url($logo_url);?>" alt="Logotipo" style="max-width:100px;max-height:100px;object-fit:contain"><?php else:?><span style="color:#64748b">Sin logotipo: se mostrará la inicial del nombre</span><?php endif;?></div><button class="button" type="button" id="ovf-global-pick-logo">Seleccionar imagen</button> <button class="button" type="button" id="ovf-global-clear-logo">Quitar logotipo</button></td></tr>
            <tr><th>Favicon del acceso general</th><td><input type="hidden" id="ovf_global_favicon_id" name="ovf_global_favicon_id" value="<?php echo (int)$favicon;?>"><div id="ovf-global-favicon-preview" style="margin-bottom:12px"><?php if($favicon_url):?><img src="<?php echo esc_url($favicon_url);?>" alt="Favicon" style="width:56px;height:56px;object-fit:contain;border-radius:10px;border:1px solid #dce3ea;padding:5px"><?php else:?><span style="color:#64748b">Sin favicon separado: se utilizará el logotipo del acceso general.</span><?php endif;?></div><button class="button" type="button" id="ovf-global-pick-favicon">Seleccionar favicon</button> <button class="button" type="button" id="ovf-global-clear-favicon">Quitar favicon</button><p class="description">Se recomienda imagen cuadrada PNG de 512 × 512 px. Solo afecta a /fidelidad-app/ sin ?ovf_business.</p></td></tr>
            <?php foreach(['primary'=>'Color principal','accent'=>'Color de botones','background'=>'Color del fondo'] as $k=>$label):$v=ovf_global_login_option($k,['primary'=>'#5554ae','accent'=>'#0f172a','background'=>'#f4f5f7'][$k]);?><tr><th><label for="ovf_global_<?php echo esc_attr($k);?>"><?php echo esc_html($label);?></label></th><td><input type="color" id="ovf_global_<?php echo esc_attr($k);?>" name="ovf_global_<?php echo esc_attr($k);?>" value="<?php echo esc_attr($v);?>"></td></tr><?php endforeach;?>
          </tbody></table>
          <hr>
          <h2>Recuperación de contraseñas</h2>
          <p>Con recuperación por correo, un dueño o empleado de un negocio activo podrá solicitar un enlace desde el acceso general sin elegir antes el negocio. No habilita el restablecimiento de cuentas administradoras de WordPress.</p>
          <table class="form-table"><tbody><tr><th><label for="ovf_global_recovery_mode">Método</label></th><td><select name="ovf_global_recovery_mode" id="ovf_global_recovery_mode"><option value="wordpress" <?php selected($mode,'wordpress');?>>Enlace seguro por correo</option><option value="contact" <?php selected($mode,'contact');?>>Mostrar mensaje de contacto</option><option value="hidden" <?php selected($mode,'hidden');?>>Ocultar recuperación</option></select></td></tr>
          <tr><th><label for="ovf_global_recovery_message">Mensaje alternativo</label></th><td><textarea rows="3" class="large-text" id="ovf_global_recovery_message" name="ovf_global_recovery_message"><?php echo esc_textarea($recovery_msg);?></textarea></td></tr></tbody></table>
          <p><button class="button button-primary button-hero" type="submit" name="ovf_global_save" value="1">Guardar acceso general</button> <?php if($url):?><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url($url);?>">Abrir acceso general</a><?php endif;?></p>
        </form>
      </div>
    </div>
    <script>
    jQuery(function($){
      var frame;
      $('#ovf-global-pick-logo').on('click',function(e){e.preventDefault();if(frame){frame.open();return;}frame=wp.media({title:'Logotipo del acceso general',button:{text:'Usar esta imagen'},library:{type:'image'},multiple:false});frame.on('select',function(){var attachment=frame.state().get('selection').first().toJSON();$('#ovf_global_logo_id').val(attachment.id);$('#ovf-global-logo-preview').empty().append($('<img>',{src:attachment.sizes?.thumbnail?.url||attachment.url,alt:'Logotipo'}).css({maxWidth:'100px',maxHeight:'100px',objectFit:'contain'}));});frame.open();});
      $('#ovf-global-clear-logo').on('click',function(e){e.preventDefault();$('#ovf_global_logo_id').val('0');$('#ovf-global-logo-preview').text('Sin logotipo: se mostrará la inicial del nombre');});
      var faviconFrame;
      $('#ovf-global-pick-favicon').on('click',function(e){e.preventDefault();if(faviconFrame){faviconFrame.open();return;}faviconFrame=wp.media({title:'Favicon del acceso general',button:{text:'Usar como favicon'},library:{type:'image'},multiple:false});faviconFrame.on('select',function(){var attachment=faviconFrame.state().get('selection').first().toJSON();$('#ovf_global_favicon_id').val(attachment.id);$('#ovf-global-favicon-preview').empty().append($('<img>',{src:attachment.sizes?.thumbnail?.url||attachment.url,alt:'Favicon'}).css({width:'56px',height:'56px',objectFit:'contain',borderRadius:'10px'}));});faviconFrame.open();});
      $('#ovf-global-clear-favicon').on('click',function(e){e.preventDefault();$('#ovf_global_favicon_id').val('0');$('#ovf-global-favicon-preview').text('Sin favicon separado: se utilizará el logotipo del acceso general.');});
    });
    </script>
    <?php
}
