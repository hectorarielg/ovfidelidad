<?php
if (!defined('ABSPATH')) exit;

/** Mobile-first, front-end business onboarding for site administrators. */
add_shortcode('ov_fidelidad_alta_negocios', 'ovf_mobile_onboarding_shortcode');
add_action('template_redirect', 'ovf_mobile_onboarding_handle', 1);
add_action('wp_enqueue_scripts', 'ovf_mobile_onboarding_assets', 30);
add_action('wp_head', function () { if (ovf_mobile_onboarding_page_id() && is_page(ovf_mobile_onboarding_page_id())) echo '<meta name="robots" content="noindex,nofollow">'; }, 1);
add_action('admin_menu', 'ovf_mobile_onboarding_admin_menu', 30);
add_action('wp_ajax_ovf_mobile_business_search', 'ovf_mobile_business_search_ajax');
add_action('wp_ajax_nopriv_ovf_mobile_business_search', 'ovf_mobile_business_search_ajax');

function ovf_mobile_onboarding_admin_menu() {
	add_submenu_page('ov-fidelidad', __('Alta móvil', 'ov-fidelidad'), __('Alta móvil', 'ov-fidelidad'), 'manage_options', 'ov-fidelidad-mobile-onboarding', 'ovf_mobile_onboarding_admin_link');
}

function ovf_mobile_onboarding_admin_link() {
	if (!current_user_can('manage_options')) return;
	$message = '';
	if (isset($_POST['ovf_mobile_pin_save']) && check_admin_referer('ovf_mobile_pin_save')) {
		$pin = (string) wp_unslash($_POST['ovf_mobile_pin'] ?? '');
		if (preg_match('/^\d{6}$/', $pin)) { update_option('ovf_mobile_admin_pin_hash', wp_hash_password($pin), false); $message = __('Código de acceso actualizado. No se guarda ni se muestra en texto legible.', 'ov-fidelidad'); }
		else $message = __('Escribe exactamente 6 dígitos numéricos.', 'ov-fidelidad');
	}
	if (isset($_POST['ovf_mobile_pin_delete']) && check_admin_referer('ovf_mobile_pin_delete')) {
		delete_option('ovf_mobile_admin_pin_hash');
		$message = __('Código eliminado. El acceso al portal queda cerrado hasta que configures un nuevo PIN.', 'ov-fidelidad');
	}
	if (isset($_POST['ovf_mobile_appearance_save']) && check_admin_referer('ovf_mobile_appearance_save')) {
		$palette = [
			'ovf_superadmin_primary' => sanitize_hex_color(wp_unslash($_POST['ovf_superadmin_primary'] ?? '')) ?: '#4fae91',
			'ovf_superadmin_accent' => sanitize_hex_color(wp_unslash($_POST['ovf_superadmin_accent'] ?? '')) ?: '#172033',
			'ovf_superadmin_background' => sanitize_hex_color(wp_unslash($_POST['ovf_superadmin_background'] ?? '')) ?: '#f3f5f4',
		];
		foreach ($palette as $key => $color) update_option($key, $color, false);
		$message = __('Colores del administrador guardados. La identidad de los negocios no cambió.', 'ov-fidelidad');
	}
	$configured = (string) get_option('ovf_mobile_admin_pin_hash', '') !== '';
	echo '<div class="wrap"><h1>' . esc_html__('Portal privado de negocios', 'ov-fidelidad') . '</h1><p>' . esc_html__('Configura un PIN de seis dígitos para entrar desde tu celular o tablet sin usar las credenciales de WordPress. El portal bloquea temporalmente intentos fallidos.', 'ov-fidelidad') . '</p>';
	if ($message) echo '<div class="notice ' . (preg_match('/exactamente/', $message) ? 'notice-error' : 'notice-success') . '"><p>' . esc_html($message) . '</p></div>';
	echo '<form method="post" style="max-width:560px;padding:20px;background:#fff;border:1px solid #dcdcde;border-radius:10px"><h2>' . esc_html($configured ? __('Cambiar PIN', 'ov-fidelidad') : __('Crear PIN', 'ov-fidelidad')) . '</h2>';
	wp_nonce_field('ovf_mobile_pin_save');
	echo '<p><label for="ovf-mobile-pin"><b>' . esc_html__('Nuevo código de 6 dígitos', 'ov-fidelidad') . '</b></label><br><input id="ovf-mobile-pin" name="ovf_mobile_pin" type="password" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" autocomplete="new-password" required style="width:100%;max-width:240px;min-height:44px;letter-spacing:.35em;font-size:20px" /></p><p class="description">' . esc_html__('El PIN se guarda protegido mediante el sistema de contraseñas de WordPress. Guardar uno nuevo cierra las sesiones móviles actuales.', 'ov-fidelidad') . '</p><button class="button button-primary" name="ovf_mobile_pin_save" value="1">' . esc_html__('Guardar PIN', 'ov-fidelidad') . '</button></form>';
	if ($configured) { echo '<form method="post" style="max-width:560px;margin-top:10px;padding:0 20px 18px;background:#fff;border:1px solid #dcdcde;border-top:0;border-radius:0 0 10px 10px">'; wp_nonce_field('ovf_mobile_pin_delete'); echo '<p class="description">' . esc_html__('Al eliminarlo, nadie podrá volver a entrar hasta que configures otro código.', 'ov-fidelidad') . '</p><button class="button" name="ovf_mobile_pin_delete" value="1" onclick="return confirm(\'' . esc_js(__('¿Eliminar el PIN actual y cerrar el acceso móvil?', 'ov-fidelidad')) . '\')">' . esc_html__('Eliminar código actual', 'ov-fidelidad') . '</button></form>'; }
	$palette = ovf_mobile_admin_palette();
	echo '<form method="post" style="max-width:760px;margin-top:18px;padding:20px;background:#fff;border:1px solid #dcdcde;border-radius:12px"><h2>' . esc_html__('Colores del administrador', 'ov-fidelidad') . '</h2><p>' . esc_html__('Esta paleta se usa en las pantallas administrativas de OV Fidelidad y en el portal privado móvil. Cada negocio conserva sus propios colores.', 'ov-fidelidad') . '</p>';
	wp_nonce_field('ovf_mobile_appearance_save');
	echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;max-width:700px">';
	foreach (['ovf_superadmin_primary'=>__('Color principal','ov-fidelidad'),'ovf_superadmin_accent'=>__('Color oscuro y botones','ov-fidelidad'),'ovf_superadmin_background'=>__('Fondo del portal','ov-fidelidad')] as $key=>$label) echo '<label style="display:grid;gap:7px;font-weight:600">'.esc_html($label).'<input type="color" name="'.esc_attr($key).'" value="'.esc_attr($palette[$key]).'" style="width:100%;height:44px;padding:4px"></label>';
	echo '</div><p><button class="button button-primary" name="ovf_mobile_appearance_save" value="1">' . esc_html__('Guardar colores del administrador', 'ov-fidelidad') . '</button></p></form>';
	echo '<div style="max-width:560px;margin-top:18px;padding:18px;background:#fff;border:1px solid #dcdcde;border-radius:10px"><h2>' . esc_html__('Acceso desde el teléfono', 'ov-fidelidad') . '</h2><p>' . esc_html__('Guarda este enlace en la pantalla de inicio. Una vez iniciada la sesión por PIN, permanece activa durante 12 horas.', 'ov-fidelidad') . '</p><p><a class="button button-primary" target="_blank" rel="noopener" href="' . esc_url(ovf_mobile_onboarding_url()) . '">' . esc_html__('Abrir portal', 'ov-fidelidad') . ' ↗</a></p><code>' . esc_html(ovf_mobile_onboarding_url()) . '</code></div></div>';
}

function ovf_mobile_admin_palette() {
	return [
		'ovf_superadmin_primary' => sanitize_hex_color(get_option('ovf_superadmin_primary', '#4fae91')) ?: '#4fae91',
		'ovf_superadmin_accent' => sanitize_hex_color(get_option('ovf_superadmin_accent', '#172033')) ?: '#172033',
		'ovf_superadmin_background' => sanitize_hex_color(get_option('ovf_superadmin_background', '#f3f5f4')) ?: '#f3f5f4',
	];
}

function ovf_mobile_admin_style() {
	$colors = ovf_mobile_admin_palette();
	return '--ovf-admin-primary:' . $colors['ovf_superadmin_primary'] . ';--ovf-admin-accent:' . $colors['ovf_superadmin_accent'] . ';--ovf-admin-background:' . $colors['ovf_superadmin_background'];
}

function ovf_mobile_onboarding_page_id() {
	return absint(get_option('ovf_page_superadmin'));
}

function ovf_mobile_onboarding_url($args = []) {
	$id = ovf_mobile_onboarding_page_id();
	$url = $id ? get_permalink($id) : home_url('/alta-negocios/');
	return $args ? add_query_arg($args, $url) : $url;
}

function ovf_mobile_admin_cookie_name() { return 'ovf_mobile_admin'; }
function ovf_mobile_admin_session_key() {
	$token = sanitize_text_field(wp_unslash($_COOKIE[ovf_mobile_admin_cookie_name()] ?? ''));
	return $token && preg_match('/^[A-Za-z0-9]{40,80}$/', $token) ? 'ovf_mobile_admin_session_' . hash('sha256', $token) : '';
}
function ovf_mobile_admin_authenticated() {
	$key = ovf_mobile_admin_session_key();
	$pin_hash = (string) get_option('ovf_mobile_admin_pin_hash', '');
	return $key !== '' && $pin_hash !== '' && get_transient($key) === $pin_hash;
}
function ovf_mobile_admin_set_session() {
	$token = wp_generate_password(56, false, false);
	$key = 'ovf_mobile_admin_session_' . hash('sha256', $token);
	set_transient($key, (string) get_option('ovf_mobile_admin_pin_hash', ''), 12 * HOUR_IN_SECONDS);
	$path = defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/';
	$domain = defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '';
	setcookie(ovf_mobile_admin_cookie_name(), $token, ['expires' => time() + 12 * HOUR_IN_SECONDS, 'path' => $path, 'domain' => $domain, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Strict']);
}
function ovf_mobile_admin_end_session() {
	$key = ovf_mobile_admin_session_key(); if ($key) delete_transient($key);
	$path = defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/'; $domain = defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '';
	setcookie(ovf_mobile_admin_cookie_name(), '', ['expires' => time() - HOUR_IN_SECONDS, 'path' => $path, 'domain' => $domain, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Strict']);
}
function ovf_mobile_admin_scope_key() { $key = ovf_mobile_admin_session_key(); return $key ? substr(hash('sha256', $key), 0, 24) : 'none'; }
function ovf_mobile_admin_rate_key() {
	$ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
	return 'ovf_mobile_pin_attempts_' . hash_hmac('sha256', $ip, wp_salt('auth'));
}

function ovf_mobile_onboarding_assets() {
	if (!ovf_mobile_onboarding_page_id() || !is_page(ovf_mobile_onboarding_page_id())) return;
	wp_enqueue_style('ovf-app-v02', OVF_URL . 'assets/app-v02.css', [], ovf_asset_version('assets/app-v02.css'));
	wp_enqueue_style('ovf-mobile-onboarding', OVF_URL . 'assets/mobile-onboarding.css', ['ovf-app-v02'], ovf_asset_version('assets/mobile-onboarding.css'));
	wp_enqueue_script('ovf-ui');
	wp_enqueue_script('ovf-mobile-onboarding', OVF_URL . 'assets/mobile-onboarding.js', [], ovf_asset_version('assets/mobile-onboarding.js'), true);
	wp_localize_script('ovf-mobile-onboarding', 'OVF_MOBILE_PORTAL', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('ovf_mobile_business_search'), 'base' => ovf_mobile_onboarding_url()]);
}

function ovf_mobile_onboarding_handle() {
	if (!ovf_mobile_onboarding_page_id() || !is_page(ovf_mobile_onboarding_page_id())) return;
	if (isset($_POST['ovf_mobile_login'])) {
		$nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? ''));
		$pin = (string) wp_unslash($_POST['pin'] ?? '');
		$rate_key = ovf_mobile_admin_rate_key(); $attempts = (int) get_transient($rate_key);
		$pin_hash = (string) get_option('ovf_mobile_admin_pin_hash', '');
		if (!wp_verify_nonce($nonce, 'ovf_mobile_login') || !$pin_hash || $attempts >= 5 || !preg_match('/^\d{6}$/', $pin) || !wp_check_password($pin, $pin_hash)) {
			set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
			wp_safe_redirect(ovf_mobile_onboarding_url(['ovf_access_error' => '1'])); exit;
		}
		delete_transient($rate_key); ovf_mobile_admin_set_session();
		wp_safe_redirect(ovf_mobile_onboarding_url()); exit;
	}
	if (isset($_POST['ovf_mobile_logout'])) {
		if (ovf_mobile_admin_authenticated() && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'ovf_mobile_logout')) ovf_mobile_admin_end_session();
		wp_safe_redirect(ovf_mobile_onboarding_url()); exit;
	}
	$action = sanitize_key(wp_unslash($_POST['ovf_mobile_action'] ?? ''));
	if (!$action) return;
	if (!ovf_mobile_admin_authenticated() || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'ovf_mobile_action')) { wp_safe_redirect(ovf_mobile_onboarding_url(['ovf_access_error' => '1'])); exit; }
	$scope = ovf_mobile_admin_scope_key();
	if ($action === 'create_business') {
		$result = ovf_mobile_create_business();
		if (is_wp_error($result)) { set_transient('ovf_mobile_error_' . $scope, $result->get_error_message(), 5 * MINUTE_IN_SECONDS); wp_safe_redirect(ovf_mobile_onboarding_url(['ovf_form_error' => '1'])); exit; }
		set_transient('ovf_mobile_created_' . $scope, $result, 30 * MINUTE_IN_SECONDS);
		wp_safe_redirect(ovf_mobile_onboarding_url(['created' => absint($result['business_id'])])); exit;
	}
	if ($action === 'save_promos' || $action === 'clear_promos') {
		$business_id = absint($_POST['business_id'] ?? 0);
		if (!$business_id || !ovf_business_row($business_id)) { wp_safe_redirect(ovf_mobile_onboarding_url(['ovf_form_error' => '1'])); exit; }
		$old_context = ovf_set_business_context($business_id); $ids = array_filter(array_map('absint', (array) ovf_get_option('ovf_promo_images', [])));
		if ($action === 'clear_promos') $ids = [];
		else {
			if (!empty($_POST['replace_promo_images'])) $ids = [];
			if (!empty($_FILES['promo_images']['name'][0])) {
				require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/media.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
				$files = $_FILES['promo_images']; $count = count(array_filter($files['name']));
				if ($count + count($ids) > 10) { ovf_set_business_context($old_context); set_transient('ovf_mobile_error_' . $scope, __('Puedes tener hasta 10 imágenes promocionales.', 'ov-fidelidad'), 5 * MINUTE_IN_SECONDS); wp_safe_redirect(ovf_mobile_onboarding_url(['business_id'=>$business_id,'ovf_form_error'=>'1'])); exit; }
				for ($i = 0; $i < count($files['name']); $i++) {
					if (!$files['name'][$i]) continue;
					if ((int)$files['size'][$i] > 8 * MB_IN_BYTES) { ovf_set_business_context($old_context); set_transient('ovf_mobile_error_' . $scope, __('Cada imagen debe pesar máximo 8 MB.', 'ov-fidelidad'), 5 * MINUTE_IN_SECONDS); wp_safe_redirect(ovf_mobile_onboarding_url(['business_id'=>$business_id,'ovf_form_error'=>'1'])); exit; }
					$_FILES['ovf_mobile_promo_single'] = ['name'=>$files['name'][$i], 'type'=>$files['type'][$i], 'tmp_name'=>$files['tmp_name'][$i], 'error'=>$files['error'][$i], 'size'=>$files['size'][$i]];
					$attachment = media_handle_upload('ovf_mobile_promo_single', 0); unset($_FILES['ovf_mobile_promo_single']);
					if (is_wp_error($attachment)) { ovf_set_business_context($old_context); set_transient('ovf_mobile_error_' . $scope, $attachment->get_error_message(), 5 * MINUTE_IN_SECONDS); wp_safe_redirect(ovf_mobile_onboarding_url(['business_id'=>$business_id,'ovf_form_error'=>'1'])); exit; }
					$ids[] = absint($attachment);
				}
			}
		}
		ovf_update_option('ovf_promo_images', array_slice(array_values(array_unique($ids)), 0, 10)); ovf_set_business_context($old_context);
		wp_safe_redirect(ovf_mobile_onboarding_url(['business_id'=>$business_id,'saved'=>'1'])); exit;
	}
	$business_id = absint($_POST['business_id'] ?? 0);
	if (!$business_id || !ovf_business_row($business_id)) { wp_safe_redirect(ovf_mobile_onboarding_url(['ovf_form_error' => '1'])); exit; }
	if ($action === 'save_business') {
		$password_updated = trim((string) wp_unslash($_POST['owner_password'] ?? '')) !== '';
		$error = ovf_mobile_save_business($business_id);
		if ($error) set_transient('ovf_mobile_error_' . $scope, $error, 5 * MINUTE_IN_SECONDS);
		$key = $error ? 'ovf_form_error' : ($password_updated ? 'password_updated' : 'saved');
		wp_safe_redirect(ovf_mobile_onboarding_url(['business_id' => $business_id, $key => '1'])); exit;
	}
	if (in_array($action, ['add_reward', 'save_reward', 'delete_reward'], true)) {
		$error = ovf_mobile_manage_reward($business_id, $action);
		if ($error) set_transient('ovf_mobile_error_' . $scope, $error, 5 * MINUTE_IN_SECONDS);
		$key = $error ? 'ovf_form_error' : 'rewards_saved';
		wp_safe_redirect(ovf_mobile_onboarding_url(['business_id' => $business_id, $key => '1'])); exit;
	}
}

function ovf_mobile_save_business($business_id) {
	global $wpdb;
	$business_id = absint($business_id); $business = ovf_business_row($business_id);
	if (!$business) return __('No se encontró el negocio.', 'ov-fidelidad');
	$name = sanitize_text_field(wp_unslash($_POST['business_name'] ?? ''));
	$email = sanitize_email(wp_unslash($_POST['owner_email'] ?? ''));
	$owner_name = sanitize_text_field(wp_unslash($_POST['owner_name'] ?? ''));
	if (!$name || !$email || !is_email($email)) return __('El nombre del negocio y un correo válido son obligatorios.', 'ov-fidelidad');
	$owner = absint($business->owner_user_id ?? 0);
	if ($owner && email_exists($email) && (int) email_exists($email) !== $owner) return __('Ese correo ya pertenece a otra cuenta de WordPress.', 'ov-fidelidad');
	$new_password = (string) wp_unslash($_POST['owner_password'] ?? '');
	if ($new_password !== '' && (!$owner || strlen($new_password) < 12)) return $owner ? __('La nueva contraseña debe tener al menos 12 caracteres.', 'ov-fidelidad') : __('Este negocio no tiene una cuenta de encargado vinculada para cambiar la contraseña.', 'ov-fidelidad');
	$old_context = ovf_set_business_context($business_id);
	$logo_id = absint(ovf_get_option('ovf_logo_id', 0)); $icon_id = absint(ovf_get_option('ovf_app_icon_id', 0));
	foreach (['business_logo' => 'logo', 'app_icon' => 'icon'] as $field => $kind) {
		if (!empty($_FILES[$field]['name'])) {
			require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/media.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
			$uploaded = media_handle_upload($field, 0);
			if (is_wp_error($uploaded)) { ovf_set_business_context($old_context); return $uploaded->get_error_message(); }
			if ($kind === 'logo') $logo_id = absint($uploaded); else $icon_id = absint($uploaded);
		}
		if (!empty($_POST['remove_' . $field])) { if ($kind === 'logo') $logo_id = 0; else $icon_id = 0; }
	}
	$features = array_values(array_intersect(['points', 'cashback'], array_map('sanitize_key', (array) wp_unslash($_POST['program_features'] ?? []))));
	$privacy_mode = sanitize_key(wp_unslash($_POST['ovf_privacy_mode'] ?? 'page'));
	if (!in_array($privacy_mode, ['page', 'url', 'text', 'none'], true)) $privacy_mode = 'page';
	$review_url = esc_url_raw(wp_unslash($_POST['ovf_google_review_url'] ?? ''));
	$review_parts = wp_parse_url($review_url);
	if ($review_url && (!is_array($review_parts) || empty($review_parts['host']) || !in_array(strtolower($review_parts['scheme'] ?? ''), ['http', 'https'], true))) { ovf_set_business_context($old_context); return __('El enlace de reseñas debe ser una URL válida que empiece con https://', 'ov-fidelidad'); }
	$ref_type = sanitize_key(wp_unslash($_POST['ovf_referral_bonus_type'] ?? 'points'));
	if (!in_array($ref_type, ['points', 'stamps'], true)) $ref_type = 'points';
	$settings = [
		'ovf_brand_name' => $name, 'ovf_app_name' => sanitize_text_field(wp_unslash($_POST['ovf_app_name'] ?? '')) ?: $name . ' Club',
		'ovf_app_short_name' => sanitize_text_field(wp_unslash($_POST['ovf_app_short_name'] ?? '')) ?: $name,
		'ovf_google_review_url' => $review_url,
		'ovf_primary' => sanitize_hex_color(wp_unslash($_POST['ovf_primary'] ?? '')) ?: '#4fae91',
		'ovf_accent' => sanitize_hex_color(wp_unslash($_POST['ovf_accent'] ?? '')) ?: '#0f172a',
		'ovf_background' => sanitize_hex_color(wp_unslash($_POST['ovf_background'] ?? '')) ?: '#f4f5f7',
		'ovf_logo_id' => $logo_id, 'ovf_app_icon_id' => $icon_id,
		'ovf_icon_bg' => sanitize_hex_color(wp_unslash($_POST['ovf_icon_bg'] ?? '')) ?: '#ffffff',
		'ovf_purchase_window_days' => min(3650, absint($_POST['ovf_purchase_window_days'] ?? 0)),
		'ovf_privacy_mode' => $privacy_mode, 'ovf_privacy_page' => absint($_POST['ovf_privacy_page'] ?? 0),
		'ovf_privacy_url' => esc_url_raw(wp_unslash($_POST['ovf_privacy_url'] ?? '')),
		'ovf_privacy_custom' => wp_kses_post(wp_unslash($_POST['ovf_privacy_custom'] ?? '')),
		'ovf_privacy_required' => empty($_POST['ovf_privacy_required']) ? '0' : '1',
		'ovf_password_recovery_mode' => in_array($_POST['ovf_password_recovery_mode'] ?? 'contact', ['hidden', 'contact', 'wordpress'], true) ? sanitize_key($_POST['ovf_password_recovery_mode']) : 'contact',
		'ovf_password_recovery_message' => sanitize_textarea_field(wp_unslash($_POST['ovf_password_recovery_message'] ?? '')),
		'ovf_program_features' => $features,
		'ovf_points_per_amount' => max(1, min(100000, absint($_POST['ovf_points_per_amount'] ?? 10))),
		'ovf_points_per_peso' => max(1, min(100000, absint($_POST['ovf_points_per_peso'] ?? 10))),
		'ovf_cashback_percent' => in_array('cashback', $features, true) ? min(100, max(0, (float) ($_POST['ovf_cashback_percent'] ?? 0))) : 0,
		'ovf_birthday_bonus_points' => max(0, min(100000, absint($_POST['ovf_birthday_bonus_points'] ?? 0))),
		'ovf_referral_bonus_type' => $ref_type,
		'ovf_referral_bonus_points' => $ref_type === 'points' ? max(0, absint($_POST['ovf_referral_bonus_amount'] ?? 0)) : 0,
		'ovf_referral_bonus_stamps' => $ref_type === 'stamps' ? min(2, max(0, absint($_POST['ovf_referral_bonus_amount'] ?? 0))) : 0,
		'ovf_referral_discount_percent' => min(100, max(0, (float) ($_POST['ovf_referral_discount_percent'] ?? 0))),
	];
	foreach ([1, 2, 3] as $level) {
		$settings['ovf_vip' . $level . '_name'] = sanitize_text_field(wp_unslash($_POST['ovf_vip' . $level . '_name'] ?? ['1'=>'Bronce','2'=>'Plata','3'=>'Oro'][$level]));
		$settings['ovf_vip' . $level . '_amount'] = max(0, (float) ($_POST['ovf_vip' . $level . '_amount'] ?? [1=>1000,2=>5000,3=>10000][$level]));
	}
	$old_window = ovf_purchase_window_days();
	foreach ($settings as $key => $value) ovf_update_option($key, $value);
	$status = sanitize_key(wp_unslash($_POST['business_status'] ?? $business->status));
	if (!in_array($status, ['active', 'paused'], true)) $status = 'active';
	$wpdb->update(ovf_businesses_table(), ['name' => $name, 'email' => $email, 'phone' => sanitize_text_field(wp_unslash($_POST['business_phone'] ?? '')), 'status' => $status, 'updated_at' => current_time('mysql')], ['id' => $business_id]);
	if ($owner) {
		wp_update_user(['ID' => $owner, 'user_email' => $email, 'display_name' => $owner_name ?: $name, 'first_name' => $owner_name ?: $name]);
		if ($new_password !== '') wp_set_password($new_password, $owner);
	}
	if ($old_window !== ovf_purchase_window_days() && function_exists('ovf_sync_all_rewards')) ovf_sync_all_rewards();
	ovf_set_business_context($old_context);
	return '';
}

function ovf_mobile_manage_reward($business_id, $action) {
	global $wpdb;
	$old_context = ovf_set_business_context($business_id); ovf_ensure_rules_schema(); $table = ovf_tables()['rules'];
	$id = absint($_POST['reward_id'] ?? 0);
	if ($action === 'delete_reward') $ok = $id && $wpdb->delete($table, ['id' => $id]);
	else {
		$title = sanitize_text_field(wp_unslash($_POST['reward_title'] ?? ''));
		if (!$title) { ovf_set_business_context($old_context); return __('Escribe el nombre del beneficio.', 'ov-fidelidad'); }
		$data = ['milestone' => max(1, absint($_POST['milestone'] ?? 1)), 'title' => $title, 'description' => sanitize_textarea_field(wp_unslash($_POST['description'] ?? '')), 'enabled' => empty($_POST['enabled']) ? 0 : 1, 'repeats' => empty($_POST['repeats']) ? 0 : 1, 'expires_days' => min(3650, absint($_POST['expires_days'] ?? 0)), 'sort_order' => max(1, absint($_POST['milestone'] ?? 1))];
		if ($action === 'save_reward' && $id) $ok = $wpdb->update($table, $data, ['id' => $id]) !== false;
		else { $data['created_at'] = current_time('mysql'); $ok = (bool) $wpdb->insert($table, $data); }
	}
	if ($ok && function_exists('ovf_sync_all_rewards')) ovf_sync_all_rewards();
	ovf_set_business_context($old_context);
	return $ok ? '' : __('No se pudo guardar el beneficio. Inténtalo otra vez.', 'ov-fidelidad');
}

function ovf_mobile_business_search_ajax() {
	check_ajax_referer('ovf_mobile_business_search', 'nonce');
	if (!ovf_mobile_admin_authenticated()) wp_send_json_error(['message' => __('Sesión vencida.', 'ov-fidelidad')], 403);
	global $wpdb; $term = sanitize_text_field(wp_unslash($_POST['term'] ?? ''));
	if (strlen($term) < 2) wp_send_json_success([]);
	$table = ovf_businesses_table(); $like = '%' . $wpdb->esc_like($term) . '%';
	$rows = $wpdb->get_results($wpdb->prepare("SELECT id,name,slug,email,status FROM {$table} WHERE name LIKE %s OR email LIKE %s OR slug LIKE %s ORDER BY updated_at DESC LIMIT 10", $like, $like, $like));
	$items = []; foreach ($rows as $row) $items[] = ['id' => (int) $row->id, 'name' => $row->name, 'email' => $row->email, 'status' => $row->status, 'url' => ovf_mobile_onboarding_url(['business_id' => (int) $row->id])];
	wp_send_json_success($items);
}

function ovf_mobile_pagination_links($page, $pages, $term = '') {
	$page = max(1, absint($page)); $pages = max(1, absint($pages));
	$numbers = array_unique(array_filter([1, $page - 1, $page, $page + 1, $pages], function ($number) use ($pages) { return $number >= 1 && $number <= $pages; }));
	sort($numbers); $html = '<nav class="ovf-mobile-pagination" aria-label="Paginación">'; $previous = 0;
	foreach ($numbers as $number) {
		if ($previous && $number > $previous + 1) $html .= '<span>…</span>';
		$url = ovf_mobile_onboarding_url(array_filter(['q' => $term, 'p' => $number]));
		$html .= '<a class="' . ($number === $page ? 'is-current' : '') . '" href="' . esc_url($url) . '">' . (int) $number . '</a>';
		$previous = $number;
	}
	return $html . '</nav>';
}

function ovf_mobile_create_business() {
	global $wpdb;
	$table = ovf_businesses_table();
	$name = sanitize_text_field(wp_unslash($_POST['business_name'] ?? ''));
	$owner_name = sanitize_text_field(wp_unslash($_POST['owner_name'] ?? ''));
	$email = sanitize_email(wp_unslash($_POST['owner_email'] ?? ''));
	$phone = sanitize_text_field(wp_unslash($_POST['business_phone'] ?? ''));
	$password = (string) wp_unslash($_POST['owner_password'] ?? '');
	if ($password === '') $password = wp_generate_password(16, true, true);
	$color = sanitize_hex_color(wp_unslash($_POST['ovf_primary'] ?? $_POST['business_color'] ?? '')) ?: '#4fae91';
	$accent = sanitize_hex_color(wp_unslash($_POST['ovf_accent'] ?? '')) ?: '#0f172a';
	$background = sanitize_hex_color(wp_unslash($_POST['ovf_background'] ?? '')) ?: '#f4f5f7';
	$icon_bg = sanitize_hex_color(wp_unslash($_POST['ovf_icon_bg'] ?? '')) ?: '#ffffff';
	$app_name = sanitize_text_field(wp_unslash($_POST['ovf_app_name'] ?? '')) ?: $name . ' Club';
	$short_name = sanitize_text_field(wp_unslash($_POST['ovf_app_short_name'] ?? '')) ?: $name;
	$review_url = esc_url_raw(wp_unslash($_POST['ovf_google_review_url'] ?? ''));
	$review_parts = wp_parse_url($review_url);
	if ($review_url && (!is_array($review_parts) || empty($review_parts['host']) || !in_array(strtolower($review_parts['scheme'] ?? ''), ['http','https'], true))) return new WP_Error('ovf_mobile_review_url', __('La URL de reseñas debe ser un enlace válido con http:// o https://.', 'ov-fidelidad'));
	$features = array_values(array_intersect(['points', 'cashback'], array_map('sanitize_key', (array) wp_unslash($_POST['program_features'] ?? []))));
	$points = max(1, min(100000, absint($_POST['points_per_amount'] ?? 10)));
	$points_per_peso = max(1, min(100000, absint($_POST['ovf_points_per_peso'] ?? $points)));
	$cashback = max(0, min(100, (float) ($_POST['ovf_cashback_percent'] ?? $_POST['cashback_percent'] ?? 0)));
	$referral_type = in_array($_POST['referral_bonus_type'] ?? 'points', ['points', 'stamps'], true) ? sanitize_key($_POST['referral_bonus_type']) : 'points';
	$referral_amount = max(0, absint($_POST['referral_bonus_amount'] ?? 0));
	$referral_discount = max(0, min(100, (float) ($_POST['referral_discount_percent'] ?? 0)));
	$birthday = max(0, min(100000, absint($_POST['ovf_birthday_bonus_points'] ?? $_POST['birthday_bonus_points'] ?? 0)));
	$reward_title = sanitize_text_field(wp_unslash($_POST['first_reward_title'] ?? ''));
	$reward_milestone = max(1, min(100000, absint($_POST['first_reward_milestone'] ?? 10)));
	$privacy_mode = sanitize_key(wp_unslash($_POST['ovf_privacy_mode'] ?? 'page'));
	if (!in_array($privacy_mode, ['page','url','text','none'], true)) $privacy_mode = 'page';
	$recovery_mode = sanitize_key(wp_unslash($_POST['ovf_password_recovery_mode'] ?? 'contact'));
	if (!in_array($recovery_mode, ['hidden','contact','wordpress'], true)) $recovery_mode = 'contact';

	if (!$name || !$owner_name || !is_email($email) || strlen($password) < 12) return new WP_Error('ovf_mobile_fields', __('Completa el nombre del negocio, el nombre y correo del encargado, y una contraseña de al menos 12 caracteres.', 'ov-fidelidad'));
	if (email_exists($email)) return new WP_Error('ovf_mobile_email', __('Ese correo ya está registrado. Usa otro correo para crear un acceso independiente para este negocio.', 'ov-fidelidad'));

	$logo_id = ovf_mobile_upload_image('business_logo');
	if (is_wp_error($logo_id)) return $logo_id;
	$app_icon_id = ovf_mobile_upload_image('app_icon');
	if (is_wp_error($app_icon_id)) { if ($logo_id) wp_delete_attachment($logo_id, true); return $app_icon_id; }

	$slug = sanitize_title($name) ?: 'negocio';
	$base = $slug; $suffix = 2;
	while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE slug=%s", $slug))) $slug = $base . '-' . $suffix++;
	$now = current_time('mysql');
	$inserted = $wpdb->insert($table, ['name' => $name, 'slug' => $slug, 'email' => $email, 'phone' => $phone, 'status' => 'active', 'created_at' => $now, 'updated_at' => $now]);
	$business_id = (int) $wpdb->insert_id;
	if (!$inserted || !$business_id) {
		if ($logo_id) wp_delete_attachment($logo_id, true);
		if ($app_icon_id) wp_delete_attachment($app_icon_id, true);
		return new WP_Error('ovf_mobile_db', __('No se pudo crear el negocio. Revisa la conexión e inténtalo de nuevo.', 'ov-fidelidad'));
	}

	$old_context = ovf_set_business_context($business_id);
	$user_id = wp_create_user($email, $password, $email);
	if (is_wp_error($user_id)) {
		ovf_set_business_context($old_context); $wpdb->delete($table, ['id' => $business_id]);
		if ($logo_id) wp_delete_attachment($logo_id, true);
		if ($app_icon_id) wp_delete_attachment($app_icon_id, true);
		return $user_id;
	}
	$user = new WP_User($user_id);
	$user->set_role('ovf_owner');
	wp_update_user(['ID' => $user_id, 'display_name' => $owner_name, 'first_name' => $owner_name]);
	update_user_meta($user_id, 'ovf_business_id', $business_id);
	$wpdb->update($table, ['owner_user_id' => $user_id], ['id' => $business_id]);

	$settings = [
		'ovf_brand_name' => $name, 'ovf_app_name' => $app_name, 'ovf_app_short_name' => $short_name,
		'ovf_google_review_url' => $review_url,
		'ovf_primary' => $color, 'ovf_accent' => $accent, 'ovf_background' => $background, 'ovf_icon_bg' => $icon_bg, 'ovf_logo_id' => $logo_id, 'ovf_app_icon_id' => $app_icon_id,
		'ovf_program_features' => $features, 'ovf_points_per_amount' => $points, 'ovf_points_per_peso' => $points_per_peso,
		'ovf_cashback_percent' => in_array('cashback', $features, true) ? $cashback : 0,
		'ovf_referral_bonus_points' => $referral_type === 'points' ? $referral_amount : 0,
		'ovf_referral_bonus_type' => $referral_type, 'ovf_referral_bonus_stamps' => $referral_type === 'stamps' ? min(2, $referral_amount) : 0,
		'ovf_referral_discount_percent' => $referral_discount, 'ovf_birthday_bonus_points' => $birthday,
		'ovf_purchase_window_days' => min(3650, absint($_POST['ovf_purchase_window_days'] ?? 0)),
		'ovf_privacy_mode' => $privacy_mode, 'ovf_privacy_page' => absint($_POST['ovf_privacy_page'] ?? 0),
		'ovf_privacy_url' => esc_url_raw(wp_unslash($_POST['ovf_privacy_url'] ?? '')),
		'ovf_privacy_custom' => wp_kses_post(wp_unslash($_POST['ovf_privacy_custom'] ?? '')),
		'ovf_privacy_required' => empty($_POST['ovf_privacy_required']) ? '0' : '1',
		'ovf_password_recovery_mode' => $recovery_mode,
		'ovf_password_recovery_message' => sanitize_textarea_field(wp_unslash($_POST['ovf_password_recovery_message'] ?? '')),
	];
	foreach ([1,2,3] as $level) {
		$settings['ovf_vip' . $level . '_name'] = sanitize_text_field(wp_unslash($_POST['ovf_vip' . $level . '_name'] ?? [1=>'Bronce',2=>'Plata',3=>'Oro'][$level]));
		$settings['ovf_vip' . $level . '_amount'] = max(0, (float) ($_POST['ovf_vip' . $level . '_amount'] ?? [1=>1000,2=>5000,3=>10000][$level]));
	}
	foreach ($settings as $key => $value) ovf_update_option($key, $value);
	ovf_create_business_tables($business_id);
	if ($reward_title) {
		$reward_context = ovf_set_business_context($business_id); $rules = ovf_tables();
		$wpdb->insert($rules['rules'], ['milestone' => $reward_milestone, 'title' => $reward_title, 'description' => '', 'enabled' => 1, 'repeats' => 0, 'expires_days' => 0, 'sort_order' => $reward_milestone, 'created_at' => $now]);
		ovf_set_business_context($reward_context);
	}
	ovf_set_business_context($old_context);
	return ['business_id' => $business_id, 'owner_id' => (int) $user_id, 'email' => $email, 'password' => $password];
}

function ovf_mobile_upload_image($field) {
	if (empty($_FILES[$field]['name'])) return 0;
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	return media_handle_upload($field, 0);
}

function ovf_mobile_onboarding_shortcode() {
	if (!ovf_mobile_admin_authenticated()) {
		$error = !empty($_GET['ovf_access_error']); $configured = (string) get_option('ovf_mobile_admin_pin_hash', '') !== '';
		ob_start(); ?>
		<div class="ovf-mobile-onboarding" style="<?php echo esc_attr(ovf_mobile_admin_style()); ?>"><section class="ovf-login ovf-mobile-login"><div class="ovf-super-brand"><span>OV</span><small>FIDELIDAD · ADMINISTRACIÓN</small></div><span class="ovf-kicker">PORTAL PRIVADO</span><h1>Administrar negocios</h1><p>Entra con el PIN privado de seis dígitos configurado en WordPress → OV Fidelidad → Alta móvil.</p>
		<?php if (!$configured): ?><div class="ovf-mobile-alert is-error">Primero configura tu PIN en WordPress → OV Fidelidad → Alta móvil.</div><?php elseif ($error): ?><div class="ovf-mobile-alert is-error">El código no es válido o se alcanzó el límite temporal de intentos.</div><?php endif; ?>
		<form method="post" action="<?php echo esc_url(ovf_mobile_onboarding_url()); ?>" data-ovf-pin-form><?php wp_nonce_field('ovf_mobile_login'); ?><label class="ovf-pin-label">Código de acceso</label><div class="ovf-pin-inputs" role="group" aria-label="PIN de seis dígitos"><?php for ($pin_digit = 0; $pin_digit < 6; $pin_digit++): ?><input type="text" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="off" aria-label="Dígito <?php echo $pin_digit + 1; ?>" data-pin-digit <?php disabled(!$configured); ?>><?php endfor; ?></div><input type="hidden" name="pin" data-pin-value><p class="ovf-pin-hint">Escribe el PIN que configuraste en Alta móvil.</p><button class="ovf-app-primary" name="ovf_mobile_login" value="1" <?php disabled(!$configured); ?>>Entrar al portal →</button></form></section></div>
		<?php return ob_get_clean();
	}
	$scope = ovf_mobile_admin_scope_key(); $error = '';
	if (!empty($_GET['ovf_form_error'])) { $error = (string) get_transient('ovf_mobile_error_' . $scope); delete_transient('ovf_mobile_error_' . $scope); }
	$business_id = absint($_GET['business_id'] ?? 0); $business = $business_id ? ovf_business_row($business_id) : null;
	$created_id = absint($_GET['created'] ?? 0); $created = get_transient('ovf_mobile_created_' . $scope);
	if (!$created || absint($created['business_id'] ?? 0) !== $created_id) $created_id = 0;
	ob_start(); ?>
	<div class="ovf-mobile-onboarding" style="<?php echo esc_attr(ovf_mobile_admin_style()); ?>"><div class="ovf-field-shell"><header class="ovf-field-header"><div class="ovf-super-brand"><span>OV</span><small>FIDELIDAD · SUPERADMIN</small></div><div class="ovf-field-user"><span>Portal privado</span><form method="post"><?php wp_nonce_field('ovf_mobile_logout'); ?><button name="ovf_mobile_logout" value="1">Salir</button></form></div></header>
	<main class="ovf-field-main"><div class="ovf-portal-top"><div><span class="ovf-kicker">GESTIÓN DESDE EL MÓVIL</span><h1><?php echo $business ? esc_html($business->name) : 'Negocios'; ?></h1><p class="ovf-field-intro"><?php echo $business ? 'Administra la identidad, reglas, privacidad y beneficios de este negocio.' : 'Busca un negocio existente o crea uno nuevo desde tu celular.'; ?></p></div><?php if ($business): ?><a class="ovf-field-new" href="<?php echo esc_url(ovf_mobile_onboarding_url()); ?>">← Todos los negocios</a><?php endif; ?></div>
	<?php if ($error): ?><div class="ovf-mobile-alert is-error"><?php echo esc_html($error); ?></div><?php elseif (!empty($_GET['password_updated'])): ?><div class="ovf-mobile-alert is-success"><b>Contraseña actualizada.</b><span>La nueva contraseña ya está activa. Compártela directamente con el encargado; por seguridad, no se volverá a mostrar.</span></div><?php elseif (!empty($_GET['saved'])): ?><div class="ovf-mobile-alert is-success">Ajustes guardados correctamente.</div><?php elseif (!empty($_GET['rewards_saved'])): ?><div class="ovf-mobile-alert is-success">Beneficio actualizado.</div><?php endif; ?>
	<?php if ($created_id && ($created_business = ovf_business_row($created_id))): $old_context = ovf_set_business_context($created_id); ?>
		<div class="ovf-mobile-alert is-success"><b>¡<?php echo esc_html($created_business->name); ?> ya está listo!</b><span>El dueño puede entrar a configurar beneficios y agregar a sus empleados.</span></div><?php echo ovf_admin_business_access_card($created_business, $created); ?><a class="ovf-field-new" href="<?php echo esc_url(ovf_mobile_onboarding_url(['business_id'=>$created_id])); ?>">Abrir ajustes completos del negocio →</a>
		<?php $register_url = add_query_arg('ovf_business', $created_business->slug, get_permalink(absint(get_option('ovf_page_register')))); ?><section class="ovf-panel ovf-field-qr"><div class="ovf-panel-title"><h2>QR de registro de clientes</h2></div><p>Descárgalo e imprímelo para el mostrador.</p><div class="ovf-registration-qr"><div class="ovf-qr" data-qr="<?php echo esc_attr($register_url); ?>" data-size="220"></div><div><h3><?php echo esc_html($created_business->name); ?></h3><p><?php echo esc_html($register_url); ?></p><button type="button" class="ovf-app-primary ovf-download-qr" data-filename="qr-registro-<?php echo esc_attr($created_business->slug); ?>.png">Descargar QR para imprimir</button></div></div></section><a class="ovf-field-new" href="<?php echo esc_url(ovf_mobile_onboarding_url()); ?>">＋ Dar de alta otro negocio</a>
	<?php elseif ($business): $old_context = ovf_set_business_context($business_id); global $wpdb; $settings = [];
		$keys = ['ovf_brand_name','ovf_app_name','ovf_app_short_name','ovf_google_review_url','ovf_primary','ovf_accent','ovf_background','ovf_icon_bg','ovf_logo_id','ovf_app_icon_id','ovf_purchase_window_days','ovf_privacy_mode','ovf_privacy_page','ovf_privacy_url','ovf_privacy_custom','ovf_privacy_required','ovf_password_recovery_mode','ovf_password_recovery_message','ovf_program_features','ovf_points_per_amount','ovf_points_per_peso','ovf_cashback_percent','ovf_birthday_bonus_points','ovf_referral_bonus_type','ovf_referral_bonus_points','ovf_referral_bonus_stamps','ovf_referral_discount_percent']; foreach ($keys as $key) $settings[$key] = ovf_get_option($key, '');
		$settings['ovf_program_features'] = ovf_program_features();
		if ($settings['ovf_privacy_mode'] === '') $settings['ovf_privacy_mode'] = 'page';
		if ($settings['ovf_privacy_required'] === '') $settings['ovf_privacy_required'] = '1';
		if ($settings['ovf_password_recovery_mode'] === '') $settings['ovf_password_recovery_mode'] = 'contact';
		$owner = $business->owner_user_id ? get_user_by('id', $business->owner_user_id) : false; ovf_ensure_rules_schema(); $rules = ovf_all_rules(); $pages = get_pages(['number' => 300, 'sort_column' => 'post_title']);
		$register_url = add_query_arg('ovf_business', $business->slug, get_permalink(absint(get_option('ovf_page_register'))));
		?>
		<form method="post" enctype="multipart/form-data" class="ovf-field-form ovf-full-settings"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="save_business"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>">
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>01</span><div><h2>Identidad y encargado</h2><p>Nombre visible para el negocio y sus clientes, datos del propietario y accesos.</p></div></div><div class="ovf-field-grid">
		<label>Nombre del negocio<input name="business_name" required value="<?php echo esc_attr($business->name); ?>"></label><label>Nombre del encargado<input name="owner_name" value="<?php echo esc_attr($owner ? $owner->display_name : $business->name); ?>"></label><label>Correo de acceso<input type="email" name="owner_email" required value="<?php echo esc_attr($business->email); ?>"></label><label class="ovf-field-password">Nueva contraseña del encargado (opcional)<input type="text" name="owner_password" minlength="12" autocomplete="new-password" placeholder="Déjalo vacío para conservar la actual"><small>Al guardar una contraseña nueva, la anterior deja de funcionar. Mínimo 12 caracteres; anótala antes de guardar para compartirla con el encargado.</small></label><label>Teléfono<input name="business_phone" value="<?php echo esc_attr($business->phone); ?>"></label><label>Estado<select name="business_status"><option value="active" <?php selected($business->status,'active'); ?>>Activo</option><option value="paused" <?php selected($business->status,'paused'); ?>>Pausado</option></select></label><label>Nombre de la Web App<input name="ovf_app_name" value="<?php echo esc_attr($settings['ovf_app_name'] ?: $business->name . ' Club'); ?>"></label><label>Nombre corto<input name="ovf_app_short_name" maxlength="20" value="<?php echo esc_attr($settings['ovf_app_short_name'] ?: $business->name); ?>"></label><label>Enlace de reseñas de Google<input type="url" name="ovf_google_review_url" value="<?php echo esc_attr($settings['ovf_google_review_url']); ?>" placeholder="https://g.page/r/.../review"><small>Déjalo vacío para ocultar la sección de reseñas.</small></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>02</span><div><h2>Colores, logo e icono</h2><p>Personaliza la tarjeta y el icono que el equipo instala en el teléfono.</p></div></div><div class="ovf-field-grid"><label>Color principal<input type="color" name="ovf_primary" value="<?php echo esc_attr($settings['ovf_primary'] ?: '#4fae91'); ?>"></label><label>Color oscuro<input type="color" name="ovf_accent" value="<?php echo esc_attr($settings['ovf_accent'] ?: '#0f172a'); ?>"></label><label>Fondo de la app<input type="color" name="ovf_background" value="<?php echo esc_attr($settings['ovf_background'] ?: '#f4f5f7'); ?>"></label><label>Fondo detrás del icono<input type="color" name="ovf_icon_bg" value="<?php echo esc_attr($settings['ovf_icon_bg'] ?: '#ffffff'); ?>"></label>
		<label class="ovf-field-logo">Logotipo<input type="file" name="business_logo" accept="image/*"><?php if ($settings['ovf_logo_id']): ?><small>Actual: <?php echo esc_html(get_the_title($settings['ovf_logo_id'])); ?> · <label class="ovf-check"><input type="checkbox" name="remove_business_logo" value="1"> Quitar logo</label></small><?php endif; ?></label><label class="ovf-field-logo">Icono de Web App<input type="file" name="app_icon" accept="image/*"><small>Recomendado: imagen cuadrada de 512 × 512 px. <?php if ($settings['ovf_app_icon_id']): ?><label class="ovf-check"><input type="checkbox" name="remove_app_icon" value="1"> Quitar icono actual</label><?php endif; ?></small></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>03</span><div><h2>Reglas de acumulación</h2><p>Configura puntos, cashback, cumpleaños, referidos y niveles VIP.</p></div></div><div class="ovf-field-feature-list"><label><input type="checkbox" name="program_features[]" value="points" <?php checked(in_array('points',(array)$settings['ovf_program_features'],true)); ?>><span><b>Puntos por compra</b><small>Activa puntos además del sello de visita.</small></span></label><label><input type="checkbox" name="program_features[]" value="cashback" <?php checked(in_array('cashback',(array)$settings['ovf_program_features'],true)); ?>><span><b>Cashback</b><small>Acumula un porcentaje del ticket como saldo.</small></span></label></div><div class="ovf-field-grid"><label>Pesos gastados para ganar 1 punto<input type="number" name="ovf_points_per_amount" min="1" value="<?php echo esc_attr($settings['ovf_points_per_amount'] ?: 10); ?>"></label><label>Puntos para convertir en $1 MXN<input type="number" name="ovf_points_per_peso" min="1" value="<?php echo esc_attr($settings['ovf_points_per_peso'] ?: 10); ?>"></label><label>Cashback por compra (%)<input type="number" name="ovf_cashback_percent" min="0" max="100" step="0.1" value="<?php echo esc_attr($settings['ovf_cashback_percent']); ?>"></label><label>Puntos extra por cumpleaños<input type="number" name="ovf_birthday_bonus_points" min="0" value="<?php echo esc_attr($settings['ovf_birthday_bonus_points']); ?>"></label><label>Tipo de bono para quien invita<select name="ovf_referral_bonus_type"><option value="points" <?php selected($settings['ovf_referral_bonus_type'],'points'); ?>>Puntos</option><option value="stamps" <?php selected($settings['ovf_referral_bonus_type'],'stamps'); ?>>Sellos</option></select></label><label>Cantidad del bono de referido<input type="number" name="ovf_referral_bonus_amount" min="0" max="100000" value="<?php echo esc_attr($settings['ovf_referral_bonus_type']==='stamps'?$settings['ovf_referral_bonus_stamps']:$settings['ovf_referral_bonus_points']); ?>"><small>Los sellos se limitan a 2 y se aplican al completar la primera compra.</small></label><label>Descuento de bienvenida (%)<input type="number" name="ovf_referral_discount_percent" min="0" max="100" step="0.1" value="<?php echo esc_attr($settings['ovf_referral_discount_percent']); ?>"></label><label>Vigencia de compras para beneficios (días)<input type="number" name="ovf_purchase_window_days" min="0" max="3650" value="<?php echo esc_attr($settings['ovf_purchase_window_days']); ?>"><small>0 = las compras no caducan.</small></label>
		<?php for($i=1;$i<=3;$i++): $vn=ovf_get_option('ovf_vip'.$i.'_name',['1'=>'Bronce','2'=>'Plata','3'=>'Oro'][$i]); $va=ovf_get_option('ovf_vip'.$i.'_amount',[1=>1000,2=>5000,3=>10000][$i]); ?><label>Nivel VIP <?php echo $i; ?> · nombre<input name="ovf_vip<?php echo $i; ?>_name" value="<?php echo esc_attr($vn); ?>"></label><label>Nivel VIP <?php echo $i; ?> · gasto acumulado<input type="number" min="0" step="0.01" name="ovf_vip<?php echo $i; ?>_amount" value="<?php echo esc_attr($va); ?>"></label><?php endfor; ?></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>04</span><div><h2>Privacidad y acceso del equipo</h2><p>Define el aviso que acepta el cliente y qué ocurre si el equipo olvida su contraseña.</p></div></div><div class="ovf-field-grid"><label>Aviso de privacidad<select name="ovf_privacy_mode"><option value="page" <?php selected($settings['ovf_privacy_mode'],'page'); ?>>Página de este sitio</option><option value="url" <?php selected($settings['ovf_privacy_mode'],'url'); ?>>Enlace externo</option><option value="text" <?php selected($settings['ovf_privacy_mode'],'text'); ?>>Texto personalizado</option><option value="none" <?php selected($settings['ovf_privacy_mode'],'none'); ?>>No mostrar</option></select></label><label>Página del aviso<select name="ovf_privacy_page"><option value="0">Usar página de privacidad predeterminada</option><?php foreach($pages as $page): ?><option value="<?php echo (int)$page->ID; ?>" <?php selected((int)$settings['ovf_privacy_page'],(int)$page->ID); ?>><?php echo esc_html($page->post_title); ?></option><?php endforeach; ?></select></label><label>URL del aviso<input type="url" name="ovf_privacy_url" value="<?php echo esc_attr($settings['ovf_privacy_url']); ?>"></label><label>Texto del aviso<textarea name="ovf_privacy_custom" rows="4"><?php echo esc_textarea($settings['ovf_privacy_custom']); ?></textarea></label><label class="ovf-check"><input type="checkbox" name="ovf_privacy_required" value="1" <?php checked($settings['ovf_privacy_required'],'1'); ?>> Pedir aceptación al registrar al cliente</label><label>Recuperación de contraseña<select name="ovf_password_recovery_mode"><option value="hidden" <?php selected(ovf_get_option('ovf_password_recovery_mode','contact'),'hidden'); ?>>No mostrar opción</option><option value="contact" <?php selected(ovf_get_option('ovf_password_recovery_mode','contact'),'contact'); ?>>Mostrar mensaje de contacto</option><option value="wordpress" <?php selected(ovf_get_option('ovf_password_recovery_mode','contact'),'wordpress'); ?>>Permitir recuperación segura por correo</option></select></label><label>Mensaje de recuperación<textarea name="ovf_password_recovery_message" rows="3"><?php echo esc_textarea(ovf_get_option('ovf_password_recovery_message','')); ?></textarea></label></div></section>
		<div class="ovf-field-submit"><p>Estos cambios se guardan solo para este negocio.</p><button class="ovf-app-primary">Guardar ajustes del negocio →</button></div></form>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>05</span><div><h2>Beneficios y promociones de tarjeta</h2><p>Edita o agrega beneficios por compras; administra también las imágenes promocionales del slider.</p></div></div><div class="ovf-mobile-reward-list"><?php if($rules): foreach($rules as $rule): ?><article><div><b><?php echo esc_html($rule->title); ?></b><small><?php echo esc_html(sprintf('%d compras · %s', (int)$rule->milestone, $rule->enabled ? 'Activo' : 'Pausado')); ?></small></div><button type="button" class="ovf-reward-edit-toggle" data-target="ovf-reward-<?php echo (int)$rule->id; ?>">Editar</button><form method="post" class="ovf-inline-edit" id="ovf-reward-<?php echo (int)$rule->id; ?>" hidden><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="save_reward"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>"><input type="hidden" name="reward_id" value="<?php echo (int)$rule->id; ?>"><label>Nombre<input name="reward_title" value="<?php echo esc_attr($rule->title); ?>" required></label><label>Compras necesarias<input type="number" name="milestone" min="1" value="<?php echo (int)$rule->milestone; ?>"></label><label>Descripción<textarea name="description" rows="2"><?php echo esc_textarea($rule->description); ?></textarea></label><div class="ovf-field-feature-list"><label><input type="checkbox" name="enabled" value="1" <?php checked($rule->enabled); ?>> Activo</label><label><input type="checkbox" name="repeats" value="1" <?php checked($rule->repeats); ?>> Se puede volver a ganar</label></div><label>Días para canjear · 0 no vence<input type="number" name="expires_days" min="0" value="<?php echo (int)ovf_rule_expires_days($rule); ?>"></label><button class="ovf-app-primary">Guardar beneficio</button></form><form method="post" onsubmit="return confirm('¿Eliminar esta regla para futuras recompensas? Los beneficios ya ganados se conservan.');"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="delete_reward"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>"><input type="hidden" name="reward_id" value="<?php echo (int)$rule->id; ?>"><button class="ovf-danger-button">Eliminar regla</button></form></article><?php endforeach; else: ?><p>Aún no hay reglas de beneficios. Agrega la primera abajo.</p><?php endif; ?></div>
		<div class="ovf-mobile-add-reward"><h3>Agregar beneficio</h3><form method="post" class="ovf-field-grid"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="add_reward"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>"><label>Nombre del beneficio<input name="reward_title" required placeholder="Ej. Bebida gratis"></label><label>Compras necesarias<input type="number" name="milestone" min="1" value="10"></label><label>Descripción<input name="description"></label><label>Días para canjear<input type="number" name="expires_days" min="0" value="0"></label><label class="ovf-check"><input type="checkbox" name="repeats" value="1"> Se puede volver a ganar</label><button class="ovf-app-primary">Agregar beneficio</button></form></div>
		<?php $promo_ids=array_filter(array_map('absint',(array)ovf_get_option('ovf_promo_images',[]))); ?><div class="ovf-mobile-promos"><h3>Imágenes del slider</h3><?php if($promo_ids): ?><div class="ovf-mobile-promo-thumbs"><?php foreach($promo_ids as $image_id): $src=wp_get_attachment_image_url($image_id,'thumbnail'); if($src): ?><img src="<?php echo esc_url($src); ?>" alt=""><?php endif; endforeach; ?></div><form method="post" onsubmit="return confirm('¿Quitar todas las imágenes promocionales?');"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="clear_promos"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>"><button class="ovf-danger-button">Quitar imágenes</button></form><?php endif; ?><form method="post" enctype="multipart/form-data"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="save_promos"><input type="hidden" name="business_id" value="<?php echo $business_id; ?>"><label>Subir imágenes promocionales<input type="file" name="promo_images[]" accept="image/jpeg,image/png,image/webp,image/gif" multiple><small>Hasta 10 imágenes · JPG, PNG, WebP o GIF · máximo 8 MB cada una.</small></label><label class="ovf-check"><input type="checkbox" name="replace_promo_images" value="1"> Reemplazar las imágenes actuales</label><button class="ovf-app-secondary">Guardar imágenes</button></form></div>
		</section>
		<section class="ovf-panel ovf-mobile-pages"><div class="ovf-field-section-title"><span>06</span><div><h2>Enlaces del sistema y QR</h2><p>Comparte el acceso y descarga el QR para registrar clientes en el local.</p></div></div><div class="ovf-mobile-url-grid"><a target="_blank" rel="noopener" href="<?php echo esc_url(add_query_arg('ovf_business',$business->slug,ovf_v02_url('ovf_page_portal'))); ?>">Web App del equipo ↗</a><a target="_blank" rel="noopener" href="<?php echo esc_url($register_url); ?>">Registro de clientes ↗</a><a target="_blank" rel="noopener" href="<?php echo esc_url(add_query_arg('ovf_business',$business->slug,ovf_v02_url('ovf_page_card'))); ?>">Tarjetas de clientes ↗</a></div><div class="ovf-registration-qr"><div class="ovf-qr" data-qr="<?php echo esc_attr($register_url); ?>" data-size="220"></div><div><h3>QR de registro de <?php echo esc_html($business->name); ?></h3><button type="button" class="ovf-app-secondary ovf-download-qr" data-filename="qr-registro-<?php echo esc_attr($business->slug); ?>.png">Descargar QR</button></div></div></section>
		<?php ovf_set_business_context($old_context); ?>
	<?php else: global $wpdb; $table=ovf_businesses_table(); $term=sanitize_text_field(wp_unslash($_GET['q'] ?? '')); $page=max(1,absint($_GET['p'] ?? 1)); $per_page=10; $where='1=1'; $args=[]; if($term){$like='%'.$wpdb->esc_like($term).'%';$where='(name LIKE %s OR email LIKE %s OR slug LIKE %s)';$args=[$like,$like,$like];} $total=(int)($args?$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}",$args)):$wpdb->get_var("SELECT COUNT(*) FROM {$table}")); $offset=($page-1)*$per_page; $businesses=$args?$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE {$where} ORDER BY updated_at DESC LIMIT %d OFFSET %d",array_merge($args,[$per_page,$offset]))):$wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY updated_at DESC LIMIT %d OFFSET %d",$per_page,$offset)); ?>
		<div class="ovf-mobile-business-toolbar"><form method="get" data-ovf-mobile-search><input type="search" name="q" value="<?php echo esc_attr($term); ?>" placeholder="Buscar negocio por nombre, correo o enlace" autocomplete="off"><button class="ovf-app-secondary">Buscar</button><div class="ovf-search-suggestions" data-ovf-mobile-results hidden></div></form><a class="ovf-app-primary" href="#ovf-create-business">＋ Dar de alta negocio</a></div><section class="ovf-panel ovf-mobile-businesses"><div class="ovf-panel-title"><h2>Negocios registrados</h2><span class="ovf-count-pill"><?php echo (int)$total; ?></span></div><?php if($businesses): ?><div class="ovf-mobile-business-list"><?php foreach($businesses as $item): $own=$item->owner_user_id?get_user_by('id',$item->owner_user_id):false; ?><article><div class="ovf-business-avatar"><?php echo esc_html(substr($item->name,0,1)); ?></div><div class="ovf-business-info"><b><?php echo esc_html($item->name); ?></b><small><?php echo esc_html($item->email ?: ($own?$own->user_email:'')); ?> · <?php echo esc_html($item->status); ?></small></div><a class="ovf-app-secondary" href="<?php echo esc_url(ovf_mobile_onboarding_url(['business_id'=>(int)$item->id])); ?>">Administrar →</a></article><?php endforeach; ?></div><?php if($total>$per_page) echo ovf_mobile_pagination_links($page,(int)ceil($total/$per_page),$term); ?><?php else: ?><div class="ovf-empty-mini">No hay negocios que coincidan con la búsqueda.</div><?php endif; ?></section>
		<section class="ovf-panel" id="ovf-create-business"><div class="ovf-field-section-title"><span>＋</span><div><h2>Dar de alta un negocio</h2><p>Completa aquí la configuración que normalmente harías en Ajustes. El dueño podrá actualizarla después.</p></div></div>
		<?php $privacy_pages = get_pages(['number'=>300,'sort_column'=>'post_title']); ?>
		<form method="post" enctype="multipart/form-data" class="ovf-field-form ovf-create-business-form"><?php wp_nonce_field('ovf_mobile_action'); ?><input type="hidden" name="ovf_mobile_action" value="create_business">
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>01</span><div><h3>Negocio, encargado e identidad de la app</h3><p>Datos de acceso y nombres que verá el equipo.</p></div></div><div class="ovf-field-grid">
		<label>Nombre del negocio<input name="business_name" required placeholder="Ej. Cafetería Centro"></label><label>Nombre del encargado<input name="owner_name" required autocomplete="name"></label><label>Correo de acceso<input type="email" name="owner_email" required autocomplete="email"></label><label>Teléfono del negocio<input name="business_phone" type="tel"></label><label class="ovf-field-password">Contraseña inicial<span><input type="text" name="owner_password" minlength="12" placeholder="Mínimo 12 caracteres"><button type="button" data-generate-password>Generar</button></span><small>Si la dejas vacía, se genera una contraseña segura.</small></label><label>Nombre de la Web App<input name="ovf_app_name" placeholder="Ej. Cafetería Centro Club"></label><label>Nombre corto<input name="ovf_app_short_name" maxlength="20" placeholder="Se muestra como nombre de la app"></label><label>Enlace de reseñas de Google<input type="url" name="ovf_google_review_url" placeholder="https://g.page/r/.../review"><small>Opcional. Déjalo vacío para ocultar reseñas.</small></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>02</span><div><h3>Colores, logotipo e icono</h3><p>Personaliza la tarjeta y la Web App del negocio.</p></div></div><div class="ovf-field-grid"><label>Color principal<input type="color" name="ovf_primary" value="#4fae91"></label><label>Color oscuro<input type="color" name="ovf_accent" value="#0f172a"></label><label>Fondo de la app<input type="color" name="ovf_background" value="#f4f5f7"></label><label>Fondo del icono en el teléfono<input type="color" name="ovf_icon_bg" value="#ffffff"></label><label class="ovf-field-logo">Logotipo del negocio<input type="file" name="business_logo" accept="image/png,image/jpeg,image/webp,image/svg+xml"><small>Aparece en las tarjetas y la Web App.</small></label><label class="ovf-field-logo">Icono de la Web App<input type="file" name="app_icon" accept="image/png,image/jpeg,image/webp"><small>Recomendado: cuadrado, mínimo 512 × 512 px.</small></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>03</span><div><h3>Reglas del programa</h3><p>El negocio siempre registra un sello por compra; activa también puntos o cashback.</p></div></div><div class="ovf-field-feature-list"><label><input type="checkbox" name="program_features[]" value="points" checked><span><b>Puntos por compra</b><small>Acumula puntos con base en el importe del ticket.</small></span></label><label><input type="checkbox" name="program_features[]" value="cashback"><span><b>Cashback</b><small>Acumula saldo como porcentaje del ticket.</small></span></label></div><div class="ovf-field-grid"><label>Pesos gastados para ganar 1 punto<input type="number" name="points_per_amount" min="1" max="100000" value="10"><small>Ejemplo: $10 de compra = 1 punto.</small></label><label>Puntos para convertir en $1 MXN<input type="number" name="ovf_points_per_peso" min="1" max="100000" value="10"></label><label>Cashback por compra (%)<input type="number" name="ovf_cashback_percent" min="0" max="100" step="0.1" value="0"></label><label>Puntos extra por cumpleaños<input type="number" name="ovf_birthday_bonus_points" min="0" max="100000" value="0"></label><label>Pesos acumulados para Nivel VIP 1<input type="number" name="ovf_vip1_amount" min="0" step="0.01" value="1000"></label><label>Nombre del Nivel VIP 1<input name="ovf_vip1_name" value="Bronce"></label><label>Pesos acumulados para Nivel VIP 2<input type="number" name="ovf_vip2_amount" min="0" step="0.01" value="5000"></label><label>Nombre del Nivel VIP 2<input name="ovf_vip2_name" value="Plata"></label><label>Pesos acumulados para Nivel VIP 3<input type="number" name="ovf_vip3_amount" min="0" step="0.01" value="10000"></label><label>Nombre del Nivel VIP 3<input name="ovf_vip3_name" value="Oro"></label><label>Vigencia de compras para beneficios (días)<input type="number" name="ovf_purchase_window_days" min="0" max="3650" value="0"><small>0 = las compras no caducan.</small></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>04</span><div><h3>Referidos y beneficio inicial</h3><p>Configura lo que recibe quien invita y prepara la primera recompensa.</p></div></div><div class="ovf-field-grid"><label>Bono para quien invita<select name="referral_bonus_type"><option value="points">Puntos</option><option value="stamps">Sellos</option></select></label><label>Cantidad del bono<input type="number" name="referral_bonus_amount" min="0" max="100000" value="0"><small>Si eliges sellos, se aplican de 1 a 2 al completarse la primera compra.</small></label><label>Descuento de bienvenida (%)<input type="number" name="referral_discount_percent" min="0" max="100" step="0.1" value="0"></label><label>Nombre del primer beneficio<input name="first_reward_title" placeholder="Opcional · Ej. Bebida gratis"></label><label>Compras para desbloquearlo<input type="number" name="first_reward_milestone" min="1" max="100000" value="10"></label></div></section>
		<section class="ovf-panel"><div class="ovf-field-section-title"><span>05</span><div><h3>Privacidad y recuperación del equipo</h3><p>Configura el aviso que se presenta al registrar clientes.</p></div></div><div class="ovf-field-grid"><label>Tipo de aviso de privacidad<select name="ovf_privacy_mode"><option value="page" selected>Página de este sitio</option><option value="url">Enlace externo</option><option value="text">Texto personalizado</option><option value="none">No mostrar aviso</option></select></label><label>Página del aviso<select name="ovf_privacy_page"><option value="0">Usar página de privacidad predeterminada</option><?php foreach($privacy_pages as $privacy_page): ?><option value="<?php echo (int)$privacy_page->ID; ?>"><?php echo esc_html($privacy_page->post_title); ?></option><?php endforeach; ?></select></label><label>URL del aviso<input type="url" name="ovf_privacy_url" placeholder="https://"></label><label>Texto del aviso<textarea name="ovf_privacy_custom" rows="4" placeholder="Escribe aquí el aviso personalizado"></textarea></label><label class="ovf-check"><input type="checkbox" name="ovf_privacy_required" value="1" checked> Pedir aceptación al registrar al cliente</label><label>Recuperación de contraseña<select name="ovf_password_recovery_mode"><option value="hidden">No mostrar opción</option><option value="contact" selected>Mostrar mensaje de contacto</option><option value="wordpress">Permitir recuperación segura por correo</option></select></label><label>Mensaje de recuperación<textarea name="ovf_password_recovery_message" rows="3">¿Olvidaste tu contraseña? Solicita el cambio al encargado del negocio.</textarea></label></div></section>
		<div class="ovf-field-submit"><p>Al crear el negocio, podrás compartir sus accesos y descargar su QR. El dueño podrá modificar estos ajustes desde su panel.</p><button class="ovf-app-primary">Crear negocio y preparar accesos →</button></div></form></section>
	<?php endif; ?></main></div></div><?php return ob_get_clean();
}
