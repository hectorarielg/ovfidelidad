<?php
/** Email marketing consent, campaigns and business promotion gallery. */
if (!defined('ABSPATH')) exit;

function ovf_email_consent_field($checked=0){
 ob_start(); ?>
 <div class="ovf-email-consent-wrap ovf-span">
  <label class="ovf-email-consent">
   <input type="checkbox" name="email_marketing" value="1" <?php checked((int)$checked,1);?>>
   <span class="ovf-email-consent-copy"><b><?php esc_html_e('Promociones y novedades por correo','ov-fidelidad');?></b><small><?php echo esc_html(sprintf(__('Acepto recibir promociones y noticias de %s. Es opcional y puedo darme de baja.','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))));?></small></span>
  </label>
 </div>
 <?php return ob_get_clean();
}

function ovf_email_campaign_view(){
 global $wpdb; $t=ovf_tables(); $msg=''; $msg_type='success';
 if(isset($_POST['ovf_promo_upload']) && ovf_v02_owner_cap() && wp_verify_nonce($_POST['_wpnonce']??'','ovf_promo_upload')){
  require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/image.php';
  $ids=empty($_POST['replace_promo_images'])?array_filter(array_map('absint',(array)ovf_get_option('ovf_promo_images',[]))):[];
  $files=$_FILES['promo_images']??[]; $uploaded=0;
  foreach((array)($files['name']??[]) as $i=>$name){
   if(!$name || count($ids)>=10)continue;
   $file=['name'=>$files['name'][$i]??'','type'=>$files['type'][$i]??'','tmp_name'=>$files['tmp_name'][$i]??'','error'=>$files['error'][$i]??UPLOAD_ERR_NO_FILE,'size'=>(int)($files['size'][$i]??0)];
   if($file['error']!==UPLOAD_ERR_OK || $file['size']>8*1024*1024 || $file['size']<=0)continue;
   $id=media_handle_sideload($file,0);
   if(!is_wp_error($id) && wp_attachment_is_image($id)){$ids[]=(int)$id;$uploaded++;}
   elseif(!is_wp_error($id)){wp_delete_attachment($id,true);}
  }
  ovf_update_option('ovf_promo_images',array_slice(array_values(array_unique($ids)),0,10),false);
  if($uploaded){$msg=sprintf(__('Se agregaron %d imágenes al slider.','ov-fidelidad'),$uploaded);}else{$msg=__('No se pudo subir ninguna imagen. Usa archivos de imagen de hasta 8 MB.','ov-fidelidad');$msg_type='error';}
 }
 if(isset($_POST['ovf_promo_clear']) && ovf_v02_owner_cap() && wp_verify_nonce($_POST['_wpnonce']??'','ovf_promo_clear')){ovf_update_option('ovf_promo_images',[],false);$msg=__('Se quitaron todas las imágenes del slider.','ov-fidelidad');}
 if(isset($_POST['ovf_email_campaign']) && ovf_v02_owner_cap() && wp_verify_nonce($_POST['_wpnonce']??'','ovf_email_campaign')){
  $segment=sanitize_key($_POST['segment']??'all'); $subject=sanitize_text_field(wp_unslash($_POST['subject']??'')); $body=wp_kses_post(wp_unslash($_POST['body']??''));
  $where="status='active' AND email_marketing=1 AND email<>''";
  if($segment==='birthday')$where.=" AND birthday IS NOT NULL AND MONTH(birthday)=".(int)current_time('m');
  if($segment==='client')$where.=$wpdb->prepare(' AND id=%d',absint($_POST['client_id']??0));
  $rows=$wpdb->get_results("SELECT id,name,email FROM {$t['clients']} WHERE $where ORDER BY name ASC LIMIT 500"); $sent=0;
  if(!$subject || !$body){$msg=__('Completa el asunto y el contenido del correo.','ov-fidelidad');$msg_type='error';}
  elseif(!$rows){$msg=__('No hay destinatarios con correo y consentimiento para esta selección.','ov-fidelidad');$msg_type='error';}
  else{
   $brand_name=ovf_get_option('ovf_brand_name',get_bloginfo('name'));$business=ovf_business_row(ovf_business_id());$smtp=ovf_smtp_settings();$from_name_filter=function($default)use($brand_name){return $brand_name?:$default;};$from_email_filter=function($default)use($smtp){return !empty($smtp['from_email'])&&is_email($smtp['from_email'])?$smtp['from_email']:$default;};add_filter('wp_mail_from_name',$from_name_filter,99);add_filter('wp_mail_from',$from_email_filter,99);
   $headers=['Content-Type: text/html; charset=UTF-8'];if($business&&is_email($business->email))$headers[]='Reply-To: '.$business->email;
   foreach($rows as $client){$html=strtr($body,['{nombre}'=>esc_html($client->name),'{negocio}'=>esc_html($brand_name)]);$html=wpautop($html);$html.='<p style="font-size:12px;color:#64748b">'.esc_html__('Recibiste este correo porque aceptaste recibir promociones. Para dejar de recibirlas, contacta al negocio.','ov-fidelidad').'</p>';if(wp_mail($client->email,$subject,$html,$headers))$sent++;}
   remove_filter('wp_mail_from_name',$from_name_filter,99);remove_filter('wp_mail_from',$from_email_filter,99);$msg=sprintf(__('Solicitud de envío procesada: el sistema aceptó %1$d de %2$d mensajes. Esto no confirma que hayan llegado a la bandeja de entrada.','ov-fidelidad'),$sent,count($rows));$msg_type=$sent?'success':'error';
  }
 }
 // List all active cards with a usable email. Cards without marketing consent are shown but cannot be selected for sending.
 $clients=$wpdb->get_results("SELECT id,name,email,email_marketing FROM {$t['clients']} WHERE status='active' AND email<>'' ORDER BY name ASC");
 $image_ids=array_filter(array_map('absint',(array)ovf_get_option('ovf_promo_images',[])));
 ob_start(); ?>
 <section class="ovf-app-section ovf-marketing-page">
  <?php if(!is_admin())echo ovf_v02_back(ovf_v02_url('ovf_page_portal'),__('Inicio','ov-fidelidad'));?>
  <?php if(!is_admin()):?><span class="ovf-kicker"><?php esc_html_e('Marketing','ov-fidelidad');?></span><h1><?php esc_html_e('Banner y envío de promociones','ov-fidelidad');?></h1><p><?php esc_html_e('Envía novedades a clientes con correo y consentimiento. Puedes elegir toda la lista, cumpleaños del mes o una tarjeta.','ov-fidelidad');?></p><?php endif;?>
  <?php if($msg):?><div class="ovf-app-alert <?php echo esc_attr($msg_type==='error'?'error':'');?>"><?php echo esc_html($msg);?></div><?php endif;?>
  <?php if(!ovf_v02_owner_cap()):?><div class="ovf-state"><?php esc_html_e('Solo el encargado puede administrar promociones.','ov-fidelidad');?></div><?php else:?>
  <div class="ovf-marketing-card ovf-promo-admin-card">
   <div class="ovf-marketing-card-head"><span class="ovf-marketing-icon">▧</span><div><h2><?php esc_html_e('Promociones en la tarjeta digital','ov-fidelidad');?></h2><p><?php esc_html_e('Carga hasta 10 imágenes. Se mostrarán como slider en las tarjetas de tus clientes.','ov-fidelidad');?></p></div></div>
   <?php if($image_ids):?><div class="ovf-promo-preview-grid"><?php foreach($image_ids as $image_id):$thumb=wp_get_attachment_image_url($image_id,'medium');if($thumb):?><div class="ovf-promo-preview"><img src="<?php echo esc_url($thumb);?>" alt="<?php echo esc_attr(get_the_title($image_id));?>"></div><?php endif;endforeach;?></div><p class="ovf-promo-count"><?php echo esc_html(sprintf(__('%d de 10 imágenes cargadas','ov-fidelidad'),count($image_ids)));?></p><?php else:?><div class="ovf-promo-empty"><?php esc_html_e('Todavía no hay imágenes.','ov-fidelidad');?></div><?php endif;?>
   <form method="post" enctype="multipart/form-data" class="ovf-promo-upload-form"><?php wp_nonce_field('ovf_promo_upload');?><label class="ovf-marketing-label"><span><?php esc_html_e('Selecciona imágenes','ov-fidelidad');?></span><input type="file" name="promo_images[]" accept="image/jpeg,image/png,image/webp,image/gif" multiple required><div class="ovf-promo-file-previews" data-ovf-file-previews></div><small><?php esc_html_e('JPG, PNG, WebP o GIF · máximo 8 MB por imagen','ov-fidelidad');?></small></label><?php if($image_ids):?><label class="ovf-marketing-replace"><input type="checkbox" name="replace_promo_images" value="1"><span><?php esc_html_e('Reemplazar las imágenes actuales','ov-fidelidad');?></span></label><?php endif;?><button class="ovf-app-primary" name="ovf_promo_upload" value="1"><?php esc_html_e('Subir imágenes','ov-fidelidad');?></button></form>
   <?php if($image_ids):?><form method="post" class="ovf-promo-clear-form" onsubmit="return confirm('¿Quitar todas las imágenes del slider?')"><?php wp_nonce_field('ovf_promo_clear');?><button class="ovf-app-secondary" name="ovf_promo_clear" value="1"><?php esc_html_e('Quitar todas las imágenes','ov-fidelidad');?></button></form><?php endif;?>
  </div>
  <div class="ovf-marketing-card ovf-campaign-card">
   <div class="ovf-marketing-card-head"><span class="ovf-marketing-icon">✉</span><div><h2><?php esc_html_e('Crear campaña de correo','ov-fidelidad');?></h2><p><?php esc_html_e('Solo se envía a clientes que aceptaron recibir promociones.','ov-fidelidad');?></p></div></div><div class="ovf-mail-delivery-note"><b><?php esc_html_e('Remitente visible:','ov-fidelidad');?></b> <?php echo esc_html(ovf_get_option('ovf_brand_name',get_bloginfo('name')));?>. <?php esc_html_e('Para mejorar la entrega, valida SPF y DKIM con tu proveedor de correo.','ov-fidelidad');?></div>
   <form method="post" class="ovf-app-form ovf-marketing-form"><?php wp_nonce_field('ovf_email_campaign');?>
    <label class="ovf-marketing-label"><span><?php esc_html_e('Destinatarios','ov-fidelidad');?></span><select name="segment" data-ovf-segment><option value="all"><?php esc_html_e('Todos los clientes con consentimiento','ov-fidelidad');?></option><option value="birthday"><?php esc_html_e('Cumpleaños de este mes','ov-fidelidad');?></option><option value="client"><?php esc_html_e('Una tarjeta específica','ov-fidelidad');?></option></select></label>
    <label class="ovf-marketing-label ovf-client-select-field" hidden><span><?php esc_html_e('Selecciona la tarjeta','ov-fidelidad');?></span><select name="client_id" data-ovf-client-select><option value=""><?php esc_html_e('Elige un cliente','ov-fidelidad');?></option><?php foreach($clients as $client):$has_consent=(int)$client->email_marketing===1;?><option value="<?php echo (int)$client->id;?>" <?php disabled(!$has_consent);?>><?php echo esc_html($client->name.' · '.$client->email.($has_consent?'':__(' · sin autorización para promociones','ov-fidelidad')));?></option><?php endforeach;?></select><small><?php esc_html_e('Las tarjetas sin consentimiento aparecen deshabilitadas y no pueden recibir campañas.','ov-fidelidad');?></small></label>
    <label class="ovf-marketing-label"><span><?php esc_html_e('Asunto','ov-fidelidad');?></span><input name="subject" maxlength="190" required placeholder="<?php esc_attr_e('Escribe el asunto del correo','ov-fidelidad');?>"></label>
    <label class="ovf-marketing-label"><span><?php esc_html_e('Contenido del correo','ov-fidelidad');?></span><textarea name="body" rows="7" required placeholder="<?php esc_attr_e('Escribe aquí tu promoción o noticia','ov-fidelidad');?>"></textarea><small><?php esc_html_e('Puedes personalizar con {nombre} y {negocio}.','ov-fidelidad');?></small></label>
    <button class="ovf-app-primary" name="ovf_email_campaign" value="1" onclick="return confirm('¿Enviar esta campaña a los destinatarios con consentimiento?')"><?php esc_html_e('Enviar campaña','ov-fidelidad');?></button>
   </form>
  </div>
  <?php endif;?>
 </section>
 <?php return ob_get_clean();
}

function ovf_promo_slider_html(){
 $ids=array_filter(array_map('absint',(array)ovf_get_option('ovf_promo_images',[])));if(!$ids)return '';
 ob_start();?><section class="ovf-promo-slider" role="region" aria-roledescription="carousel" aria-label="<?php esc_attr_e('Promociones','ov-fidelidad');?>"><div class="ovf-promo-track"><?php foreach($ids as $id):$url=wp_get_attachment_image_url($id,'large');if($url):?><div class="ovf-promo-slide"><img src="<?php echo esc_url($url);?>" alt="<?php echo esc_attr(get_post_meta($id,'_wp_attachment_image_alt',true)?:__('Promoción del negocio','ov-fidelidad'));?>" loading="lazy"></div><?php endif;endforeach;?></div><?php if(count($ids)>1):?><div class="ovf-promo-dots" aria-label="<?php esc_attr_e('Seleccionar promoción','ov-fidelidad');?>"></div><?php endif;?></section><?php return ob_get_clean();
}
add_action('wp_ajax_ovf_promo_save','ovf_promo_save');
function ovf_promo_save(){if(!ovf_v02_owner_cap()||!check_ajax_referer('ovf_promo_save','nonce',false))wp_send_json_error();$ids=array_values(array_filter(array_map('absint',(array)($_POST['ids']??[]))));ovf_update_option('ovf_promo_images',array_slice($ids,0,10),false);wp_send_json_success();}
