<?php
/** Reporting and value-based loyalty tools for OV Fidelidad 1.2.0. */
if (!defined('ABSPATH')) exit;

function ovf_lifetime_spend($client_id) {
 global $wpdb; $t=ovf_tables();
 return (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(sale_amount),0) FROM {$t['moves']} WHERE client_id=%d AND type='purchase'",absint($client_id)));
}
function ovf_client_points($client_id) {
 global $wpdb; $t=ovf_tables();
 return (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(points_delta),0) FROM {$t['moves']} WHERE client_id=%d",absint($client_id)));
}
function ovf_award_birthday_bonus($client_id) {
 global $wpdb; $t=ovf_tables();$client=ovf_client($client_id);$bonus=max(0,absint(ovf_get_option('ovf_birthday_bonus_points',0)));
 if(!$client||$client->status!=='active'||!$bonus||empty($client->birthday)||substr($client->birthday,5,5)!==current_time('m-d'))return false;
 $year=(int)current_time('Y');$exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE client_id=%d AND type='birthday_bonus' AND YEAR(created_at)=%d",$client_id,$year));
 if($exists)return false;
 $ok=$wpdb->insert($t['moves'],['client_id'=>absint($client_id),'type'=>'birthday_bonus','amount'=>0,'points_delta'=>$bonus,'note'=>'Bono de cumpleaños '.$year,'user_id'=>0,'method'=>'system','created_at'=>current_time('mysql')]);

 return (bool)$ok;
}
add_action('init',function(){if(!wp_next_scheduled('ovf_daily_birthday_rewards'))wp_schedule_event(time()+HOUR_IN_SECONDS, 'daily', 'ovf_daily_birthday_rewards');});
add_action('ovf_daily_birthday_rewards',function(){global $wpdb;$old=ovf_business_id();$businesses=$wpdb->get_col('SELECT id FROM '.ovf_businesses_table().' WHERE status=\'active\'');foreach($businesses as $business_id){ovf_set_business_context((int)$business_id);$t=ovf_tables();$ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM {$t['clients']} WHERE status='active' AND birthday IS NOT NULL AND DATE_FORMAT(birthday,'%%m-%%d')=%s",current_time('m-d')));foreach($ids as $id)ovf_award_birthday_bonus((int)$id);}ovf_set_business_context($old?:1);});
function ovf_redeem_points($client_id,$points) {
 global $wpdb; $t=ovf_tables(); $client_id=absint($client_id);$points=absint($points);$available=ovf_client_points($client_id);$rate=max(1,absint(ovf_get_option('ovf_points_per_peso',10)));
 $client=ovf_client($client_id);if(!$client||$client->status!=='active')return new WP_Error('inactive',__('La tarjeta está inactiva.','ov-fidelidad'));
 if(!$client_id||$points<1||$points>$available)return new WP_Error('points',__('Los puntos a convertir superan el saldo disponible.','ov-fidelidad'));
 $credit=round($points/$rate,2);$ok=$wpdb->insert($t['moves'],['client_id'=>$client_id,'type'=>'points_redeem','amount'=>0,'points_delta'=>-$points,'balance_delta'=>$credit,'note'=>sprintf(__('Conversión de %1$d puntos a $%2$s de saldo','ov-fidelidad'),$points,number_format_i18n($credit,2)),'user_id'=>get_current_user_id(),'method'=>'manual','created_at'=>current_time('mysql')]);
 return $ok?$credit:new WP_Error('points_save',__('No se pudo convertir el saldo de puntos.','ov-fidelidad'));
}
function ovf_client_balance($client_id) {
 global $wpdb; $t=ovf_tables();
 return (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(balance_delta),0) FROM {$t['moves']} WHERE client_id=%d",absint($client_id)));
}
function ovf_client_vip_level($client_id) {
 $spent=ovf_lifetime_spend($client_id);
 $levels=[['name'=>ovf_get_option('ovf_vip3_name','Oro'),'limit'=>(float)ovf_get_option('ovf_vip3_amount',10000)],['name'=>ovf_get_option('ovf_vip2_name','Plata'),'limit'=>(float)ovf_get_option('ovf_vip2_amount',5000)],['name'=>ovf_get_option('ovf_vip1_name','Bronce'),'limit'=>(float)ovf_get_option('ovf_vip1_amount',1000)]];
 foreach($levels as $l) if($l['limit']>0&&$spent >= $l['limit']) return $l['name'];
 return __('Cliente','ov-fidelidad');
}

/** Datos de analítica sin caché: cada carga refleja los movimientos guardados en la base. */
function ovf_reporting_summary($from, $to, $search = '', $client_id = 0, $page = 1, $per_page = 10) {
 global $wpdb; $t=ovf_tables();
 $start=$from.' 00:00:00'; $end=$to.' 23:59:59';
 $client_condition='';$client_args=[];
 if($client_id){$client_condition=' AND c.id=%d';$client_args[] = absint($client_id);}
 elseif($search!==''){$like='%'.$wpdb->esc_like($search).'%';$client_condition=' AND (c.name LIKE %s OR c.phone LIKE %s OR c.email LIKE %s)';array_push($client_args,$like,$like,$like);}
 $metrics=$wpdb->get_row($wpdb->prepare("SELECT SUM(m.type='purchase') purchases,COALESCE(SUM(CASE WHEN m.type='purchase' THEN m.sale_amount ELSE 0 END),0) revenue,COALESCE(SUM(CASE WHEN m.type='purchase' THEN m.gross_amount ELSE 0 END),0) gross,COALESCE(SUM(CASE WHEN m.type='purchase' THEN m.discount_amount ELSE 0 END),0) discounts,SUM(m.type='redeem') redemptions,SUM(m.type='scan') scans,COUNT(DISTINCT CASE WHEN m.type='purchase' THEN m.client_id END) buyers FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id WHERE m.created_at BETWEEN %s AND %s{$client_condition}",array_merge([$start,$end],$client_args)));
 $metrics=$metrics?: (object)['purchases'=>0,'revenue'=>0,'gross'=>0,'discounts'=>0,'redemptions'=>0,'scans'=>0,'buyers'=>0];
 $metrics->new_clients=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['clients']} c WHERE c.created_at BETWEEN %s AND %s{$client_condition}",array_merge([$start,$end],$client_args)));
 $known_tickets=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id WHERE m.type='purchase' AND m.sale_amount>0 AND m.created_at BETWEEN %s AND %s{$client_condition}",array_merge([$start,$end],$client_args)));
 $metrics->known_tickets=$known_tickets;$metrics->average_ticket=$known_tickets?(float)$metrics->revenue/$known_tickets:0;
 $where="m.type='purchase' AND m.created_at BETWEEN %s AND %s".$client_condition;$args=array_merge([$start,$end],$client_args);
 $total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT c.id) FROM {$t['moves']} m INNER JOIN {$t['clients']} c ON c.id=m.client_id WHERE {$where}",$args));
 $per_page=max(1,min(50000,absint($per_page)));$pages=max(1,(int)ceil($total/$per_page));$page=max(1,min(absint($page)?:1,$pages));$offset=($page-1)*$per_page;
 $top=$wpdb->get_results($wpdb->prepare("SELECT c.id,c.name,c.phone,c.email,COUNT(m.id) purchases,COALESCE(SUM(m.sale_amount),0) spent,COALESCE(AVG(NULLIF(m.sale_amount,0)),0) average_ticket,MAX(m.created_at) last_purchase FROM {$t['moves']} m INNER JOIN {$t['clients']} c ON c.id=m.client_id WHERE {$where} GROUP BY c.id,c.name,c.phone,c.email ORDER BY purchases DESC,spent DESC,last_purchase DESC LIMIT %d OFFSET %d",array_merge($args,[$per_page,$offset])));
 return ['metrics'=>$metrics,'top'=>$top,'total'=>$total,'page'=>$page,'per_page'=>$per_page,'pages'=>$pages];
}

/** Descarga un CSV UTF-8 que Excel abre correctamente, respetando el negocio de la sesión. */
function ovf_export_analytics_csv($owner_only=false) {
	if($owner_only ? !ovf_v02_owner_cap() : !current_user_can('manage_options')) wp_die(__('No tienes permiso para descargar estos datos.','ov-fidelidad'));
	if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce']??'')),'ovf_analytics_export')) wp_die(__('El enlace de descarga caducó. Recarga el reporte e inténtalo de nuevo.','ov-fidelidad'));
	global $wpdb; $t=ovf_tables();ovf_ensure_moves_schema();
	$from=sanitize_text_field(wp_unslash($_GET['from']??''));$to=sanitize_text_field(wp_unslash($_GET['to']??''));
	if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from))$from=wp_date('Y-m-01',current_time('timestamp'));
	if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))$to=current_time('Y-m-d');
	if(sanitize_key($_GET['report']??'')==='customers') {
		$summary=ovf_reporting_summary($from,$to,sanitize_text_field(wp_unslash($_GET['customer']??'')),absint($_GET['client_id']??0),1,50000);
		nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=clientes-frecuentes-'.$from.'-'.$to.'.csv');
		$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Posición','Cliente','Teléfono','Correo','Compras','Gasto total MXN','Ticket promedio MXN','Última compra'],';');
		$rank=0;foreach($summary['top'] as $c){$rank++;fputcsv($out,[$rank,$c->name,$c->phone,$c->email,$c->purchases,$c->spent,$c->average_ticket,$c->last_purchase],';');}
		fclose($out);exit;
	}
	$rows=$wpdb->get_results($wpdb->prepare("SELECT m.created_at,c.name,c.phone,c.email,m.type,m.receipt_number,m.sale_amount,m.gross_amount,m.discount_amount,m.points_delta,m.balance_delta,m.method,m.note,u.display_name staff FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.created_at BETWEEN %s AND %s ORDER BY m.created_at DESC LIMIT 50000",$from.' 00:00:00',$to.' 23:59:59'));
	nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=ov-fidelidad-analiticas-'.$from.'-'.$to.'.csv');
	$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Fecha','Cliente','Teléfono','Correo','Movimiento','Número de ticket','Venta neta MXN','Ticket original MXN','Descuento MXN','Puntos','Saldo MXN','Canal','Atendido por','Nota'],';');
	$labels=['purchase'=>'Compra','redeem'=>'Canje','registration'=>'Alta de tarjeta','scan'=>'Escaneo QR','birthday_bonus'=>'Bono de cumpleaños','referral_bonus'=>'Bono por referido'];
	foreach($rows as $r)fputcsv($out,[$r->created_at,$r->name?:'Cliente eliminado',$r->phone,$r->email,$labels[$r->type]??$r->type,$r->receipt_number,$r->sale_amount,$r->gross_amount,$r->discount_amount,$r->points_delta,$r->balance_delta,$r->method,$r->staff,$r->note],';');
	fclose($out);exit;
}
add_action('admin_post_ovf_export_admin_analytics',function(){ovf_export_analytics_csv(false);});
add_action('admin_post_ovf_export_owner_analytics',function(){ovf_export_analytics_csv(true);});

function ovf_admin_program() {
	if(!current_user_can('manage_options')) return;
	if(isset($_POST['ovf_save_loyalty_settings'])&&check_admin_referer('ovf_loyalty_settings')) {
		ovf_update_option('ovf_points_per_amount',max(1,min(100000,absint($_POST['points_per_amount']??10))));
		ovf_update_option('ovf_cashback_percent',max(0,min(100,(float)($_POST['cashback_percent']??0))));
		ovf_update_option('ovf_birthday_bonus_points',max(0,min(100000,absint($_POST['birthday_bonus']??0))));
		$bonus_type=in_array($_POST['referral_bonus_type']??'points',['points','stamps'],true)?$_POST['referral_bonus_type']:'points';$bonus_amount=max(0,absint($_POST['referral_bonus_amount']??0));ovf_update_option('ovf_referral_bonus_type',$bonus_type);ovf_update_option('ovf_referral_bonus_points',$bonus_type==='points'?$bonus_amount:0);ovf_update_option('ovf_referral_bonus_stamps',$bonus_type==='stamps'?min(2,$bonus_amount):0);
		ovf_update_option('ovf_referral_discount_percent',max(0,min(100,(float)($_POST['referral_discount_percent']??0))));
		ovf_update_option('ovf_points_per_peso',max(1,min(100000,absint($_POST['points_per_peso']??10))));
		foreach([1,2,3] as $i){ovf_update_option('ovf_vip'.$i.'_name',sanitize_text_field(wp_unslash($_POST['vip'.$i.'_name']??''))?:['','Bronce','Plata','Oro'][$i]);ovf_update_option('ovf_vip'.$i.'_amount',max(0,min(100000000,(float)($_POST['vip'.$i.'_amount']??0))));}
		ovf_notice(__('Reglas de puntos, cashback, referidos y VIP guardadas.','ov-fidelidad'));
	}
	ovf_admin_header(__('Reglas de acumulación','ov-fidelidad'),__('Configura qué obtiene el cliente por cada ticket.','ov-fidelidad'),false);
	echo '<section class="ovf-panel"><h2>'.esc_html__('¿Cómo funciona?','ov-fidelidad').'</h2><p>'.esc_html__('Cada ticket registra siempre una visita, como una tarjeta de sellos. Si capturas el importe, también se calculan los puntos, cashback y gasto para niveles VIP que tengas activados. Puedes dejar el importe en $0 y seguir usando solo visitas.','ov-fidelidad').'</p><p><b>'.esc_html__('Ejemplo:','ov-fidelidad').'</b> '.esc_html__('con 1 punto por cada $10 y cashback de 2%, un ticket de $150 suma 1 visita, 15 puntos y $3 de saldo.','ov-fidelidad').'</p></section>';
	echo '<section class="ovf-panel"><h2>'.esc_html__('Reglas para compras nuevas','ov-fidelidad').'</h2><p>'.esc_html__('Los cambios aplican a partir de ahora. Las compras anteriores conservan los datos que tenían al registrarse. Pon 0 en cashback o bonos para desactivarlos.','ov-fidelidad').'</p><form method="post" class="ovf-fields">';wp_nonce_field('ovf_loyalty_settings');
	echo '<label><span>'.esc_html__('Pesos para ganar 1 punto','ov-fidelidad').'</span><input type="number" min="1" name="points_per_amount" value="'.(int)ovf_get_option('ovf_points_per_amount',10).'" required><small>'.esc_html__('Ejemplo: 10 significa 1 punto por cada $10 MXN del ticket.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Cashback sobre el ticket (%)','ov-fidelidad').'</span><input type="number" min="0" max="100" step="0.1" name="cashback_percent" value="'.esc_attr(ovf_get_option('ovf_cashback_percent',0)).'"><small>'.esc_html__('Ejemplo: 2% de un ticket de $100 agrega $2 de saldo.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Puntos para convertir en $1 de saldo','ov-fidelidad').'</span><input type="number" min="1" name="points_per_peso" value="'.(int)ovf_get_option('ovf_points_per_peso',10).'" required><small>'.esc_html__('La conversión se realiza desde la ficha del cliente.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Puntos extra por cumpleaños','ov-fidelidad').'</span><input type="number" min="0" name="birthday_bonus" value="'.(int)ovf_get_option('ovf_birthday_bonus_points',0).'"><small>'.esc_html__('Se otorgan una vez al año a quien haya registrado su fecha de nacimiento.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Bono para quien invita: tipo','ov-fidelidad').'</span><select name="referral_bonus_type"><option value="points" '.selected(ovf_get_option('ovf_referral_bonus_type','points'),'points',false).'>'.esc_html__('Puntos','ov-fidelidad').'</option><option value="stamps" '.selected(ovf_get_option('ovf_referral_bonus_type','points'),'stamps',false).'>'.esc_html__('Sellos de compra','ov-fidelidad').'</option></select></label><label><span>'.esc_html__('Cantidad del bono para quien invita','ov-fidelidad').'</span><input type="number" min="0" max="100000" name="referral_bonus_amount" data-referral-bonus-amount value="'.(ovf_get_option('ovf_referral_bonus_type','points')==='stamps'?(int)ovf_get_option('ovf_referral_bonus_stamps',0):(int)ovf_get_option('ovf_referral_bonus_points',0)).'"><small>'.esc_html__('Si eliges sellos, entrega 1 o 2 cuando el invitado realice su primera compra.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Descuento para el invitado en su primera compra (%)','ov-fidelidad').'</span><input type="number" min="0" max="100" step="0.1" name="referral_discount_percent" value="'.esc_attr(ovf_get_option('ovf_referral_discount_percent',0)).'"><small>'.esc_html__('Solo para clientes registrados con un código válido. Se descuenta del primer ticket; usa 0 para desactivarlo.','ov-fidelidad').'</small></label>';
	foreach([1,2,3] as $i) echo '<label><span>'.esc_html(sprintf(__('Nivel VIP %d · nombre','ov-fidelidad'),$i)).'</span><input name="vip'.$i.'_name" value="'.esc_attr(ovf_get_option('ovf_vip'.$i.'_name',['','Bronce','Plata','Oro'][$i])).'"></label><label><span>'.esc_html(sprintf(__('Nivel VIP %d · gasto acumulado MXN','ov-fidelidad'),$i)).'</span><input type="number" min="0" step="100" name="vip'.$i.'_amount" value="'.esc_attr(ovf_get_option('ovf_vip'.$i.'_amount',[0,1000,5000,10000][$i])).'"></label>';
	echo '<div class="wide"><button class="ovf-admin-btn" name="ovf_save_loyalty_settings" value="1">'.esc_html__('Guardar reglas','ov-fidelidad').'</button></div></form></section>';
	ovf_admin_end();
}

function ovf_admin_reports() {
 if(!current_user_can('manage_options')) return;
 global $wpdb; $t=ovf_tables();
 if(isset($_POST['ovf_save_loyalty_settings'])&&check_admin_referer('ovf_loyalty_settings')) {
  ovf_update_option('ovf_points_per_amount',max(1,min(100000,absint($_POST['points_per_amount']??10))));
  ovf_update_option('ovf_cashback_percent',max(0,min(100,(float)($_POST['cashback_percent']??0))));
  ovf_update_option('ovf_birthday_bonus_points',max(0,min(100000,absint($_POST['birthday_bonus']??0))));
  $bonus_type=in_array($_POST['referral_bonus_type']??'points',['points','stamps'],true)?$_POST['referral_bonus_type']:'points';$bonus_amount=max(0,absint($_POST['referral_bonus_amount']??0));ovf_update_option('ovf_referral_bonus_type',$bonus_type);ovf_update_option('ovf_referral_bonus_points',$bonus_type==='points'?$bonus_amount:0);ovf_update_option('ovf_referral_bonus_stamps',$bonus_type==='stamps'?min(2,$bonus_amount):0);
  ovf_update_option('ovf_referral_discount_percent',max(0,min(100,(float)($_POST['referral_discount_percent']??0))));
  ovf_update_option('ovf_points_per_peso',max(1,min(100000,absint($_POST['points_per_peso']??10))));
  foreach([1,2,3] as $i){ovf_update_option('ovf_vip'.$i.'_name',sanitize_text_field(wp_unslash($_POST['vip'.$i.'_name']??''))?:['','Bronce','Plata','Oro'][$i]);ovf_update_option('ovf_vip'.$i.'_amount',max(0,min(100000000,(float)($_POST['vip'.$i.'_amount']??0))));}
  ovf_notice(__('Reglas de puntos, cashback, referidos y VIP guardadas.','ov-fidelidad'));
 }
 $from=sanitize_text_field(wp_unslash($_GET['from']??wp_date('Y-m-01',current_time('timestamp'))));$to=sanitize_text_field(wp_unslash($_GET['to']??current_time('Y-m-d')));
 if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from))$from=wp_date('Y-m-01',current_time('timestamp'));if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))$to=current_time('Y-m-d');
 $search=sanitize_text_field(wp_unslash($_GET['customer']??''));$analytics=ovf_reporting_summary($from,$to,$search,0,1,50);$am=$analytics['metrics'];$top_customers=$analytics['top'];
 $since=wp_date('Y-m-d H:i:s',current_time('timestamp',true)-30*DAY_IN_SECONDS);
 $sales=(int)$am->purchases;$known_sales=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE type='purchase' AND sale_amount>0 AND created_at BETWEEN %s AND %s",$from.' 00:00:00',$to.' 23:59:59'));
 $revenue=(float)$am->revenue;$referral_discounts=(float)$am->discounts;$avg=(float)$am->average_ticket;
 $inactive_cut=wp_date('Y-m-d H:i:s',current_time('timestamp',true)-30*DAY_IN_SECONDS);
 $dormant=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['clients']} c WHERE c.status='active' AND EXISTS(SELECT 1 FROM {$t['moves']} oldm WHERE oldm.client_id=c.id AND oldm.type='purchase') AND NOT EXISTS(SELECT 1 FROM {$t['moves']} recent WHERE recent.client_id=c.id AND recent.type='purchase' AND recent.created_at>=%s)",$inactive_cut));
 $frequency=(float)$wpdb->get_var("SELECT COALESCE(AVG(day_gap),0) FROM (SELECT DATEDIFF(MAX(created_at),MIN(created_at))/(COUNT(*)-1) day_gap FROM {$t['moves']} WHERE type='purchase' GROUP BY client_id HAVING COUNT(*)>1) freq");
 $top=$wpdb->get_results("SELECT title,COUNT(*) redeemed FROM {$t['rewards']} WHERE status='redeemed' GROUP BY title ORDER BY redeemed DESC LIMIT 10");
 $inactive=$wpdb->get_results($wpdb->prepare("SELECT c.id,c.name,c.phone,MAX(m.created_at) last_visit,COUNT(m.id) purchases FROM {$t['clients']} c JOIN {$t['moves']} m ON m.client_id=c.id AND m.type='purchase' WHERE c.status='active' GROUP BY c.id HAVING MAX(m.created_at)<%s ORDER BY last_visit ASC LIMIT 15",$inactive_cut));
 ovf_admin_header(__('Reportes','ov-fidelidad'),__('Recurrencia, abandono, ventas registradas y rendimiento de beneficios.','ov-fidelidad'),false);
 $export=wp_nonce_url(add_query_arg(['action'=>'ovf_export_admin_analytics','from'=>$from,'to'=>$to],admin_url('admin-post.php')),'ovf_analytics_export');
 $export_customers=wp_nonce_url(add_query_arg(['action'=>'ovf_export_admin_analytics','from'=>$from,'to'=>$to,'report'=>'customers','customer'=>$search],admin_url('admin-post.php')),'ovf_analytics_export');
 echo '<section class="ovf-panel"><h2>'.esc_html__('Analítica del negocio','ov-fidelidad').'</h2><p>'.esc_html__('Datos actualizados al abrir el reporte. El historial de escaneos comienza desde esta versión.','ov-fidelidad').'</p><form method="get" class="ovf-fields"><input type="hidden" name="page" value="ov-fidelidad-reports"><label><span>'.esc_html__('Desde','ov-fidelidad').'</span><input type="date" name="from" value="'.esc_attr($from).'" required></label><label><span>'.esc_html__('Hasta','ov-fidelidad').'</span><input type="date" name="to" value="'.esc_attr($to).'" required></label><label><span>'.esc_html__('Buscar cliente frecuente','ov-fidelidad').'</span><input type="search" name="customer" value="'.esc_attr($search).'" placeholder="Nombre, teléfono o correo"></label><div class="wide"><button class="ovf-admin-btn">'.esc_html__('Aplicar filtros','ov-fidelidad').'</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-reports')).'">'.esc_html__('Limpiar','ov-fidelidad').'</a> <a class="button" href="'.esc_url($export).'">'.esc_html__('Descargar movimientos (Excel/CSV)','ov-fidelidad').'</a> <a class="button" href="'.esc_url($export_customers).'">'.esc_html__('Descargar clientes frecuentes','ov-fidelidad').'</a></div></form></section>';
 echo '<div class="ovf-metrics"><div><span>'.esc_html__('Escaneos QR','ov-fidelidad').'</span><strong>'.number_format_i18n((int)$am->scans).'</strong></div><div><span>'.esc_html__('Nuevas tarjetas','ov-fidelidad').'</span><strong>'.number_format_i18n((int)$am->new_clients).'</strong></div><div><span>'.esc_html__('Compras','ov-fidelidad').'</span><strong>'.number_format_i18n($sales).'</strong></div><div><span>'.esc_html__('Venta neta','ov-fidelidad').'</span><strong>$'.number_format_i18n($revenue,2).' MXN</strong></div><div><span>'.esc_html__('Ticket promedio','ov-fidelidad').'</span><strong>$'.number_format_i18n($avg,2).' MXN</strong></div><div><span>'.esc_html__('Clientes compradores','ov-fidelidad').'</span><strong>'.number_format_i18n((int)$am->buyers).'</strong></div></div>';
 echo '<section class="ovf-panel"><h2>'.esc_html__('Clientes más frecuentes','ov-fidelidad').'</h2><p>'.esc_html__('Ordenados por compras en el periodo; usa esta lista para reconocer a tus clientes más leales.','ov-fidelidad').'</p><div class="ovf-table-wrap"><table class="ovf-table"><thead><tr><th>'.esc_html__('Cliente','ov-fidelidad').'</th><th>'.esc_html__('Teléfono','ov-fidelidad').'</th><th>'.esc_html__('Compras','ov-fidelidad').'</th><th>'.esc_html__('Gasto','ov-fidelidad').'</th><th>'.esc_html__('Ticket promedio','ov-fidelidad').'</th><th>'.esc_html__('Última compra','ov-fidelidad').'</th></tr></thead><tbody>';
 if(!$top_customers)echo '<tr><td colspan="6">'.esc_html__('No hay compras de clientes en este periodo o búsqueda.','ov-fidelidad').'</td></tr>';foreach($top_customers as $c)echo '<tr><td>'.esc_html($c->name).'</td><td>'.esc_html($c->phone).'</td><td>'.number_format_i18n((int)$c->purchases).'</td><td>$'.number_format_i18n((float)$c->spent,2).'</td><td>$'.number_format_i18n((float)$c->average_ticket,2).'</td><td>'.esc_html(mysql2date(get_option('date_format'),$c->last_purchase)).'</td></tr>';
 echo '</tbody></table></div></section>';
 echo '<div class="ovf-metrics"><div><span>'.esc_html__('Descuentos aplicados · periodo','ov-fidelidad').'</span><strong>$'.number_format_i18n($referral_discounts,2).' MXN</strong></div><div><span>'.esc_html__('Tickets con importe capturado','ov-fidelidad').'</span><strong>'.number_format_i18n($known_sales).' / '.number_format_i18n($sales).'</strong></div><div><span>'.esc_html__('Clientes sin volver · 30 días','ov-fidelidad').'</span><strong>'.number_format_i18n($dormant).'</strong></div></div>';
 echo '<div class="ovf-admin-grid"><section class="ovf-panel"><h2>'.esc_html__('Frecuencia de visita','ov-fidelidad').'</h2><p>'.($frequency>0?esc_html(sprintf(__('En promedio, los clientes con al menos dos compras regresan cada %s días.','ov-fidelidad'),number_format_i18n($frequency,1))):esc_html__('Aún no hay suficientes clientes con compras repetidas para calcularla.','ov-fidelidad')).'</p><p class="ovf-help">'.esc_html(sprintf(__('En el periodo seleccionado se capturó importe en %1$d de %2$d compras. Las compras anteriores a esta versión pueden no tener importe disponible.','ov-fidelidad'),$known_sales,$sales)).'</p></section><section class="ovf-panel"><h2>'.esc_html__('Beneficios más canjeados','ov-fidelidad').'</h2>';
 if(!$top) echo '<p>'.esc_html__('Todavía no hay canjes para mostrar.','ov-fidelidad').'</p>'; else {echo '<ol>';foreach($top as $rw)echo '<li>'.esc_html($rw->title).' <b>'.number_format_i18n($rw->redeemed).'</b></li>';echo '</ol>';}
 echo '</section></div><section class="ovf-panel"><h2>'.esc_html__('Clientes que podrían estar dejando de volver','ov-fidelidad').'</h2><p>'.esc_html__('Clientes activos con compras previas y sin visita registrada en los últimos 30 días. Puedes incluirlos en una campaña por correo si aceptaron recibir promociones.','ov-fidelidad').'</p><div class="ovf-table-wrap"><table class="ovf-table"><thead><tr><th>'.esc_html__('Cliente','ov-fidelidad').'</th><th>'.esc_html__('Última visita','ov-fidelidad').'</th><th>'.esc_html__('Compras','ov-fidelidad').'</th><th></th></tr></thead><tbody>';
 if(!$inactive)echo '<tr><td colspan="4">'.esc_html__('No hay clientes inactivos en este periodo.','ov-fidelidad').'</td></tr>';foreach($inactive as $c)echo '<tr><td>'.esc_html($c->name).'</td><td>'.esc_html(date_i18n(get_option('date_format'),strtotime($c->last_visit))).'</td><td>'.(int)$c->purchases.'</td><td><a href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-clients&action=edit&id='.$c->id)).'">'.esc_html__('Ver ficha','ov-fidelidad').'</a></td></tr>';

 echo '</tbody></table></div></section><section class="ovf-panel"><h2>'.esc_html__('Configurar recompensas por consumo','ov-fidelidad').'</h2><p>'.esc_html__('Los puntos, cashback y bonos se calculan en nuevas compras. El saldo cashback se muestra como beneficio acumulado y se puede gestionar desde la operación del negocio.','ov-fidelidad').'</p><form method="post" class="ovf-fields">';wp_nonce_field('ovf_loyalty_settings');
 echo '<label><span>'.esc_html__('Puntos por cada $ MXN gastados','ov-fidelidad').'</span><input type="number" min="1" name="points_per_amount" value="'.(int)ovf_get_option('ovf_points_per_amount',10).'"><small>'.esc_html__('Ejemplo: 10 significa 1 punto por cada $10.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Cashback (%)','ov-fidelidad').'</span><input type="number" min="0" max="100" step="0.1" name="cashback_percent" value="'.esc_attr(ovf_get_option('ovf_cashback_percent',0)).'"></label><label><span>'.esc_html__('Puntos por cada $1 de saldo','ov-fidelidad').'</span><input type="number" min="1" name="points_per_peso" value="'.(int)ovf_get_option('ovf_points_per_peso',10).'"><small>'.esc_html__('El equipo puede convertir puntos en saldo cashback para usarlo en una compra.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Puntos extra por cumpleaños','ov-fidelidad').'</span><input type="number" min="0" name="birthday_bonus" value="'.(int)ovf_get_option('ovf_birthday_bonus_points',0).'"><small>'.esc_html__('Se otorgan una vez por año en el cumpleaños; las campañas promocionales por correo requieren consentimiento.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Bono para quien invita: tipo','ov-fidelidad').'</span><select name="referral_bonus_type"><option value="points" '.selected(ovf_get_option('ovf_referral_bonus_type','points'),'points',false).'>'.esc_html__('Puntos','ov-fidelidad').'</option><option value="stamps" '.selected(ovf_get_option('ovf_referral_bonus_type','points'),'stamps',false).'>'.esc_html__('Sellos de compra','ov-fidelidad').'</option></select></label><label><span>'.esc_html__('Cantidad del bono para quien invita','ov-fidelidad').'</span><input type="number" min="0" max="100000" name="referral_bonus_amount" data-referral-bonus-amount value="'.(ovf_get_option('ovf_referral_bonus_type','points')==='stamps'?(int)ovf_get_option('ovf_referral_bonus_stamps',0):(int)ovf_get_option('ovf_referral_bonus_points',0)).'"><small>'.esc_html__('Si eliges sellos, entrega 1 o 2 cuando el invitado realice su primera compra.','ov-fidelidad').'</small></label><label><span>'.esc_html__('Descuento para el invitado en su primera compra (%)','ov-fidelidad').'</span><input type="number" min="0" max="100" step="0.1" name="referral_discount_percent" value="'.esc_attr(ovf_get_option('ovf_referral_discount_percent',0)).'"><small>'.esc_html__('Solo para clientes registrados con un código válido. Se descuenta del primer ticket; usa 0 para desactivarlo.','ov-fidelidad').'</small></label>';
 foreach([1,2,3] as $i)echo '<label><span>'.esc_html(sprintf(__('Nivel VIP %d · nombre','ov-fidelidad'),$i)).'</span><input name="vip'.$i.'_name" value="'.esc_attr(ovf_get_option('ovf_vip'.$i.'_name',['','Bronce','Plata','Oro'][$i])).'"></label><label><span>'.esc_html(sprintf(__('Nivel VIP %d · gasto acumulado MXN','ov-fidelidad'),$i)).'</span><input type="number" min="0" step="100" name="vip'.$i.'_amount" value="'.esc_attr(ovf_get_option('ovf_vip'.$i.'_amount',[0,1000,5000,10000][$i])).'"></label>';
 echo '<div class="wide"><button class="ovf-admin-btn" name="ovf_save_loyalty_settings" value="1">'.esc_html__('Guardar reglas','ov-fidelidad').'</button></div></form></section>';
 ovf_admin_end();
}
