<?php
/** User avatars for OV Fidelidad business staff. Independent of loyalty clients. */
if (!defined('ABSPATH')) exit;

function ovf_staff_avatar_html($user, $class = '') {
    $user = is_object($user) ? $user : get_user_by('id', absint($user));
    if (!$user) return '';
    $id = absint(get_user_meta($user->ID, 'ovf_profile_avatar_id', true));
    $class = trim('ovf-staff-photo ' . sanitize_html_class($class ?: 'ovf-avatar-photo'));
    if ($id && wp_attachment_is_image($id)) {
        $image = wp_get_attachment_image($id, 'thumbnail', false, [
            'class' => $class,
            'alt' => sprintf(__('Foto de %s', 'ov-fidelidad'), $user->display_name),
            'loading' => 'lazy',
            'decoding' => 'async',
        ]);
        if ($image) return $image;
    }
    return '<span class="ovf-avatar-initial">' . esc_html(ovf_initial($user->display_name)) . '</span>';
}

function ovf_avatar_can_edit($target_id) {
    if (!is_user_logged_in() || !function_exists('ovf_v02_staff_cap') || !ovf_v02_staff_cap()) return false;
    $target = get_userdata(absint($target_id));
    if (!$target) return false;
    // Superadministradores pueden cambiar su propia fotografía aun cuando no
    // tengan un negocio fijo en user_meta (gestionan múltiples negocios).
    if ((int) $target->ID === get_current_user_id() && current_user_can('manage_options')) return true;
    $business_id = absint(ovf_business_id());
    $target_business = absint(get_user_meta($target->ID, 'ovf_business_id', true));
    if (!$business_id || $target_business !== $business_id) return false;
    if (!array_intersect(['ovf_owner', 'ovf_staff'], (array) $target->roles) && !user_can($target, 'manage_options')) return false;
    if ((int) $target->ID === get_current_user_id()) return true;
    if (!ovf_v02_owner_cap()) return false;
    // A business owner may manage employee photos, but not another owner or administrator.
    if (current_user_can('manage_options')) return true;
    return in_array('ovf_staff', (array) $target->roles, true) && !user_can($target, 'manage_options');
}

function ovf_avatar_form($target, $compact = false) {
    $target = is_object($target) ? $target : get_userdata(absint($target));
    if (!$target || !ovf_avatar_can_edit($target->ID)) return '';
    $id = absint(get_user_meta($target->ID, 'ovf_profile_avatar_id', true));
    ob_start(); ?>
    <div class="ovf-avatar-editor<?php echo $compact ? ' is-compact' : ''; ?>">
        <div class="ovf-avatar-editor-preview"><?php echo ovf_staff_avatar_html($target, 'ovf-avatar-preview-image'); ?></div>
        <div class="ovf-avatar-editor-details">
            <?php if (!$compact): ?><strong><?php esc_html_e('Fotografía de perfil', 'ov-fidelidad'); ?></strong><?php endif; ?>
            <p><?php esc_html_e('Imagen JPG, PNG o WebP · máximo 2 MB. Se recorta al centro.', 'ov-fidelidad'); ?></p>
            <form class="ovf-avatar-upload-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(ovf_v02_url('ovf_page_portal')); ?>">
                <?php wp_nonce_field('ovf_avatar_' . $target->ID); ?>
                <input type="hidden" name="ovf_avatar_target" value="<?php echo (int) $target->ID; ?>">
                <input type="hidden" name="ovf_avatar_upload" value="1">
                <label class="ovf-avatar-file-label">
                    <span><?php esc_html_e('Elegir fotografía', 'ov-fidelidad'); ?></span>
                    <input name="ovf_avatar_file" type="file" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp" required>
                </label>
                <button type="submit" class="ovf-app-primary ovf-avatar-save"><?php esc_html_e('Guardar foto', 'ov-fidelidad'); ?></button>
            </form>
            <?php if ($id): ?>
                <form method="post" action="<?php echo esc_url(ovf_v02_url('ovf_page_portal')); ?>" class="ovf-avatar-remove-form">
                    <?php wp_nonce_field('ovf_avatar_' . $target->ID); ?>
                    <input type="hidden" name="ovf_avatar_target" value="<?php echo (int) $target->ID; ?>">
                    <button type="submit" name="ovf_avatar_remove" value="1" class="ovf-avatar-remove"><?php esc_html_e('Quitar fotografía', 'ov-fidelidad'); ?></button>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php return ob_get_clean();
}

function ovf_avatar_delete_previous($target_id, $old_id) {
    if (!$old_id) return;
    // Never remove attachments not explicitly created for this user by this feature.
    if ((int) get_post_meta($old_id, '_ovf_avatar_user_id', true) === (int) $target_id) wp_delete_attachment($old_id, true);
}

add_action('template_redirect', 'ovf_avatar_handle_request', 0);
function ovf_avatar_handle_request() {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || (!isset($_POST['ovf_avatar_upload']) && !isset($_POST['ovf_avatar_remove']))) return;
    $target_id = absint($_POST['ovf_avatar_target'] ?? 0);
    $back = ovf_v02_url('ovf_page_portal', ['view' => $target_id === get_current_user_id() ? 'profile' : 'team']);
    if (!ovf_avatar_can_edit($target_id) || !check_admin_referer('ovf_avatar_' . $target_id, '_wpnonce')) {
        ovf_flash_set(__('No tienes permiso para cambiar esta fotografía.', 'ov-fidelidad'), 'error');
        ovf_redirect(ovf_v02_url('ovf_page_portal'));
    }
    $old_id = absint(get_user_meta($target_id, 'ovf_profile_avatar_id', true));
    if (isset($_POST['ovf_avatar_remove'])) {
        delete_user_meta($target_id, 'ovf_profile_avatar_id');
        ovf_avatar_delete_previous($target_id, $old_id);
        ovf_flash_set(__('Fotografía eliminada. Ahora se mostrará la inicial.', 'ov-fidelidad'));
        ovf_redirect($back);
    }
    $file = $_FILES['ovf_avatar_file'] ?? null;
    if (!$file || !is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || (int) ($file['size'] ?? 0) <= 0 || (int) $file['size'] > 2 * 1024 * 1024) {
        ovf_flash_set(__('La foto debe pesar menos de 2 MB.', 'ov-fidelidad'), 'error');
        ovf_redirect($back);
    }
    $tmp = $file['tmp_name'] ?? '';
    if (!is_uploaded_file($tmp)) {
        ovf_flash_set(__('No se recibió una imagen válida.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    $info = @getimagesize($tmp);
    $allowed = [IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_PNG => 'image/png', IMAGETYPE_WEBP => 'image/webp'];
    if (!$info || !isset($allowed[$info[2]]) || $info[0] > 6000 || $info[1] > 6000 || $info[0] < 40 || $info[1] < 40) {
        ovf_flash_set(__('Utiliza una fotografía JPG, PNG o WebP válida.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    $check = wp_check_filetype_and_ext($tmp, sanitize_file_name($file['name']), ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp']);
    if (empty($check['type']) || $check['type'] !== $allowed[$info[2]]) {
        ovf_flash_set(__('El tipo de imagen no coincide con el archivo.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $saved = wp_handle_upload($file, ['test_form' => false, 'mimes' => ['jpg' => 'image/jpeg','jpeg' => 'image/jpeg','png' => 'image/png','webp' => 'image/webp']]);
    if (isset($saved['error']) || empty($saved['file'])) {
        ovf_flash_set(__('No fue posible subir la fotografía.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    $editor = wp_get_image_editor($saved['file']);
    if (is_wp_error($editor)) { @unlink($saved['file']); ovf_flash_set(__('El servidor no pudo procesar la fotografía.', 'ov-fidelidad'), 'error'); ovf_redirect($back); }
    $resized = $editor->resize(512, 512, true);
    if (is_wp_error($resized) || is_wp_error($editor->save($saved['file']))) {
        @unlink($saved['file']); ovf_flash_set(__('No fue posible optimizar la fotografía.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    $attachment_id = wp_insert_attachment([
        'post_mime_type' => $saved['type'],
        'post_title' => 'Foto de perfil OV Fidelidad',
        'post_status' => 'inherit',
        'post_author' => get_current_user_id(),
    ], $saved['file']);
    if (is_wp_error($attachment_id) || !$attachment_id) {
        @unlink($saved['file']); ovf_flash_set(__('No fue posible guardar la fotografía.', 'ov-fidelidad'), 'error'); ovf_redirect($back);
    }
    wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $saved['file']));
    update_post_meta($attachment_id, '_ovf_avatar_user_id', $target_id);
    update_user_meta($target_id, 'ovf_profile_avatar_id', $attachment_id);
    ovf_avatar_delete_previous($target_id, $old_id);
    ovf_flash_set(__('Fotografía de perfil actualizada correctamente.', 'ov-fidelidad'));
    ovf_redirect($back);
}
