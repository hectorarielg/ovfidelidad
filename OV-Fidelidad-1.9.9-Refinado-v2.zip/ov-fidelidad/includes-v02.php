<?php
if (!defined('ABSPATH')) exit;

add_action('init','ovf_v02_i18n');
function ovf_v02_i18n(){ load_plugin_textdomain('ov-fidelidad',false,dirname(plugin_basename(OVF_FILE)).'/languages'); }

add_action('init','ovf_v02_bootstrap',5);
function ovf_v02_bootstrap(){
 if(get_option('ovf_v02_ready')!=='yes' && current_user_can('manage_options')){ovf_v02_pages();update_option('ovf_v02_ready','yes');}
 // Roles y capacidades se registran una vez por versión (antes se reescribían en cada carga de página).
 if(get_option('ovf_caps_version')===OVF_VERSION.'.2' && get_role('ovf_owner') && get_role('ovf_staff')) return;
 update_option('ovf_caps_version',OVF_VERSION.'.2');
 // Nombre visible de los roles (add_role no actualiza roles ya existentes).
 $wpr=wp_roles();foreach(['ovf_owner'=>__('Encargado del negocio','ov-fidelidad'),'ovf_staff'=>__('Empleado del negocio','ov-fidelidad')] as $rk=>$rn){if(isset($wpr->roles[$rk])&&$wpr->roles[$rk]['name']!==$rn){$wpr->roles[$rk]['name']=$rn;$wpr->role_names[$rk]=$rn;if($wpr->use_db)update_option($wpr->role_key,$wpr->roles);}}
 add_role('ovf_owner',__('Encargado del negocio','ov-fidelidad'),['read'=>true,'manage_ov_fidelidad'=>true,'ovf_manage_staff'=>true,'ovf_manage_clients'=>true,'ovf_register_sales'=>true,'ovf_redeem_rewards'=>true,'ovf_view_reports'=>true]);
 add_role('ovf_staff',__('Empleado del negocio','ov-fidelidad'),['read'=>true,'ovf_manage_clients'=>true,'ovf_register_sales'=>true,'ovf_redeem_rewards'=>true]);
 foreach(['administrator','editor'] as $rn){$r=get_role($rn);if($r){foreach(['manage_ov_fidelidad','ovf_manage_staff','ovf_manage_clients','ovf_register_sales','ovf_redeem_rewards','ovf_view_reports'] as $cap)$r->add_cap($cap);}}
}
function ovf_v02_pages(){ ovf_ensure_pages(); }
function ovf_v02_url($key,$args=[]){$url=ovf_page_url($key);return $args?add_query_arg($args,$url):$url;}
function ovf_v02_logo(){return absint(ovf_get_option('ovf_logo_id'));}
function ovf_v02_logo_html($class=''){ $id=ovf_v02_logo(); if($id)return wp_get_attachment_image($id,'medium',false,['class'=>$class,'alt'=>esc_attr(ovf_get_option('ovf_brand_name',get_bloginfo('name')))]); return '<span class="ovf-app-monogram">'.esc_html(ovf_initial(ovf_get_option('ovf_brand_name',get_bloginfo('name')))).'</span>'; }
/** Account menu shared with optional OV Membresías. Uses WordPress identity, not duplicate accounts. */
function ovf_shared_account_menu_html(){
 if(!is_user_logged_in() || !ovf_v02_staff_cap())return '';
 $u=wp_get_current_user();$owner=ovf_v02_owner_cap();
 $role=$owner?'Encargado':'Empleado';
 $avatar=function_exists('ovf_staff_avatar_html')?ovf_staff_avatar_html($u):esc_html(ovf_initial($u->display_name));
 $url=ovf_v02_url('ovf_page_portal');
 $html='<details class="ovf-shared-account"><summary><span class="ovf-shared-avatar">'.$avatar.'</span><span class="ovf-shared-identity"><strong>'.esc_html($u->display_name).'</strong><small>'.esc_html($role).'</small></span><span aria-hidden="true">⌄</span></summary><div class="ovf-shared-account-options">';
 $html.='<div class="ovf-shared-email">'.esc_html($u->user_email).'</div>';
 $html.='<a href="'.esc_url(add_query_arg('view','profile',$url)).'">Mi perfil y fotografía</a>';
 if($owner)$html.='<a href="'.esc_url(add_query_arg('view','team',$url)).'">Gestionar equipo</a>';
 $html.='<a href="'.esc_url($url).'">Ir a OV Fidelidad</a>';
 $html.='<a class="ovf-shared-logout" href="'.esc_url(wp_logout_url($url)).'">Cerrar sesión</a>';
 return $html.'</div></details>';
}
function ovf_v02_staff_cap(){if(!is_user_logged_in())return false;if(current_user_can('manage_options'))return true;if(get_user_meta(get_current_user_id(),'ovf_access_disabled',true)==='1'||!current_user_can('ovf_register_sales'))return false;$business_id=absint(get_user_meta(get_current_user_id(),'ovf_business_id',true));return $business_id>0&&function_exists('ovf_business_row')&&ovf_business_row($business_id)!==null;}
function ovf_v02_owner_cap(){return ovf_v02_staff_cap()&&(current_user_can('ovf_manage_staff')||current_user_can('manage_options'));}

add_action('wp_enqueue_scripts','ovf_v02_assets',20);
function ovf_v02_assets(){
 $ids=array_filter(array_map('intval',[get_option('ovf_page_portal'),get_option('ovf_page_register'),get_option('ovf_page_card')]));
 if(!is_page($ids))return;
 wp_enqueue_script('ovf-ui');
 wp_enqueue_style('ovf-app-v02',OVF_URL.'assets/app-v02.css',[],ovf_asset_version('assets/app-v02.css'));
 wp_enqueue_script('ovf-app-v02',OVF_URL.'assets/app-v02.js',['ovf-ui'],ovf_asset_version('assets/app-v02.js'),true);
 $card_token=sanitize_text_field(wp_unslash($_GET['ovf']??''));$card_scope=wp_make_link_relative(ovf_v02_url('ovf_page_card'));$card_scope=trailingslashit(wp_parse_url($card_scope,PHP_URL_PATH)?:'/');
 wp_localize_script('ovf-app-v02','OVF_APP',['isApp'=>is_page((int)get_option('ovf_page_portal')),'isCard'=>is_page((int)get_option('ovf_page_card'))&&$card_token!=='','swScope'=>trailingslashit(wp_parse_url(ovf_v02_url('ovf_page_portal'),PHP_URL_PATH)?:'/'),'manifest'=>add_query_arg(['ovf_manifest'=>'1','ovf_business'=>ovf_business_slug()],home_url('/')),'sw'=>add_query_arg('ovf_sw','1',home_url('/')),'cardScope'=>$card_scope,'cardManifest'=>add_query_arg(['ovf_card_manifest'=>'1','token'=>$card_token,'ovf_business'=>ovf_business_slug()],home_url('/')),'cardSw'=>add_query_arg('ovf_card_sw','1',home_url('/')),'app'=>ovf_v02_url('ovf_page_portal'),'scanner'=>ovf_v02_url('ovf_page_portal',['view'=>'scanner']),'register'=>ovf_v02_url('ovf_page_register'),'search'=>['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('ovf_client_search')],'i18n'=>['install'=>__('Instalar app','ov-fidelidad')]]);
}
add_action('wp_head','ovf_v02_head',2);
function ovf_v02_head(){
 $ids=array_filter(array_map('intval',[get_option('ovf_page_portal'),get_option('ovf_page_register'),get_option('ovf_page_card')]));if(!is_page($ids))return;
 // Cada interfaz tiene su propio manifest: la tarjeta instala la tarjeta del cliente, nunca la app del equipo.
 if(is_page((int)get_option('ovf_page_portal'))) echo '<link rel="manifest" href="'.esc_url(ovf_global_login_request()?add_query_arg('ovf_global_manifest','1',home_url('/')):add_query_arg(['ovf_manifest'=>'1','ovf_business'=>ovf_business_slug()],home_url('/'))).'">';
 if(is_page((int)get_option('ovf_page_card'))&&!empty($_GET['ovf'])) echo '<link rel="manifest" href="'.esc_url(add_query_arg(['ovf_card_manifest'=>'1','token'=>sanitize_text_field(wp_unslash($_GET['ovf'])),'ovf_business'=>ovf_business_slug()],home_url('/'))).'">';
 echo '<meta name="theme-color" content="'.esc_attr(ovf_login_brand_option('ovf_primary','#315b46')).'">';
 echo '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default">';
}
add_action('template_redirect','ovf_v02_dynamic_assets',0);
function ovf_v02_global_manifest() {
 if (!isset($_GET['ovf_global_manifest'])) return false;
 nocache_headers();header('Content-Type: application/manifest+json; charset=utf-8');
 $icon=ovf_global_login_icon_url('full');
 $icons=$icon?[['src'=>$icon,'sizes'=>'any','type'=>get_post_mime_type(absint(ovf_global_login_option('favicon_id',0)) ?: absint(ovf_global_login_option('logo_id',0))) ?: 'image/png','purpose'=>'any']]:[];
 echo wp_json_encode(['name'=>ovf_global_login_option('name','OV Fidelidad'),'short_name'=>ovf_global_login_option('name','OV Fidelidad'),'start_url'=>ovf_global_login_portal_url(),'scope'=>home_url('/'),'display'=>'standalone','background_color'=>ovf_global_login_option('background','#f4f5f7'),'theme_color'=>ovf_global_login_option('primary','#5554ae'),'icons'=>$icons],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}
function ovf_v02_dynamic_assets(){
 if (function_exists('ovf_v02_global_manifest')) ovf_v02_global_manifest();
	if(isset($_GET['ovf_card_manifest'])){$token=sanitize_text_field(wp_unslash($_GET['token']??''));$c=ovf_client_by_token($token);if(!$c){status_header(404);exit;}nocache_headers();header('Content-Type: application/manifest+json; charset=utf-8');$icons=[];foreach([192,512] as $sz){$u=ovf_icon_url($sz);if($u)$icons[]=['src'=>$u,'sizes'=>$sz.'x'.$sz,'type'=>'image/png','purpose'=>'any'];}$card=ovf_card_url($token);$scope=trailingslashit(wp_parse_url(ovf_v02_url('ovf_page_card'),PHP_URL_PATH)?:'/');echo wp_json_encode(['id'=>$card,'name'=>sprintf(__('Tarjeta de %1$s · %2$s','ov-fidelidad'),$c->name,ovf_get_option('ovf_brand_name',get_bloginfo('name'))),'short_name'=>sprintf(__('Tarjeta de %s','ov-fidelidad'),ovf_get_option('ovf_brand_name',get_bloginfo('name'))),'start_url'=>$card,'scope'=>home_url($scope),'display'=>'standalone','background_color'=>ovf_get_option('ovf_background','#f6f6f1'),'theme_color'=>ovf_get_option('ovf_primary','#315b46'),'icons'=>$icons],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;}
	if(isset($_GET['ovf_card_sw'])){nocache_headers();header('Content-Type: application/javascript; charset=utf-8');$scope=trailingslashit(wp_parse_url(ovf_v02_url('ovf_page_card'),PHP_URL_PATH)?:'/');header('Service-Worker-Allowed: '.$scope);echo "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));";exit;}
 if(isset($_GET['ovf_manifest'])){nocache_headers();header('Content-Type: application/manifest+json; charset=utf-8');$icons=[];foreach([192,512] as $sz){$u=ovf_icon_url($sz);if($u)$icons[]=['src'=>$u,'sizes'=>$sz.'x'.$sz,'type'=>'image/png','purpose'=>'any'];}echo wp_json_encode(['name'=>ovf_get_option('ovf_app_name',ovf_get_option('ovf_brand_name',get_bloginfo('name')).' Fidelidad'),'short_name'=>ovf_get_option('ovf_app_short_name',ovf_get_option('ovf_brand_name',get_bloginfo('name'))),'start_url'=>ovf_v02_url('ovf_page_portal'),'scope'=>home_url('/'),'display'=>'standalone','background_color'=>ovf_get_option('ovf_background','#f6f6f1'),'theme_color'=>ovf_get_option('ovf_primary','#315b46'),'icons'=>$icons],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;}
 if(isset($_GET['ovf_sw'])){nocache_headers();header('Content-Type: application/javascript; charset=utf-8');header('Service-Worker-Allowed: '.wp_make_link_relative(ovf_v02_url('ovf_page_portal')));$offline=wp_json_encode('<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;display:grid;place-items:center;min-height:90vh;text-align:center;color:#172019"><div><h1>'.esc_html__('Sin conexión','ov-fidelidad').'</h1><p>'.esc_html__('Revisa tu conexión a internet y vuelve a intentarlo.','ov-fidelidad').'</p><button onclick="location.reload()">'.esc_html__('Reintentar','ov-fidelidad').'</button></div>');echo "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{if(e.request.mode!=='navigate')return;e.respondWith(fetch(e.request).catch(()=>new Response($offline,{headers:{'Content-Type':'text/html; charset=utf-8'}})));});";exit;}
}

add_action('admin_menu','ovf_v02_admin_menu',20);
function ovf_v02_admin_menu(){
 add_submenu_page('ov-fidelidad',__('Personal','ov-fidelidad'),__('Personal','ov-fidelidad'),'manage_options','ov-fidelidad-staff','ovf_v02_admin_staff');
 add_submenu_page('ov-fidelidad',__('Ajustes','ov-fidelidad'),__('Ajustes','ov-fidelidad'),'manage_options','ov-fidelidad-settings','ovf_v02_admin_brand');
}
add_action('admin_enqueue_scripts',function($hook){
 if(strpos($hook,'ov-fidelidad')===false)return;
 wp_enqueue_media();
 wp_enqueue_style('ovf-admin-v02',OVF_URL.'assets/app-v02.css',[],ovf_asset_version('assets/app-v02.css'));wp_enqueue_script('ovf-qr',OVF_URL.'assets/qrcode.min.js',[],OVF_VERSION,true);wp_enqueue_script('ovf-ui',OVF_URL.'assets/ovf.js',['ovf-qr'],OVF_VERSION,true);
});
function ovf_v02_admin_brand(){
 if(isset($_POST['ovf_brand_save'])&&check_admin_referer('ovf_brand_save')){foreach(['ovf_brand_name','ovf_app_name','ovf_app_short_name'] as $k)ovf_update_option($k,sanitize_text_field(wp_unslash($_POST[$k]??'')));if(function_exists('ovf_businesses_table')){$bname=sanitize_text_field(wp_unslash($_POST['ovf_brand_name']??''));if($bname){global $wpdb;$wpdb->update(ovf_businesses_table(),['name'=>$bname,'updated_at'=>current_time('mysql')],['id'=>ovf_business_id()]);}}foreach(['ovf_primary','ovf_accent','ovf_background'] as $k)ovf_update_option($k,sanitize_hex_color($_POST[$k]??'')?:($k==='ovf_primary'?'#334155':($k==='ovf_accent'?'#0f172a':'#f4f5f7')));ovf_update_option('ovf_logo_id',absint($_POST['ovf_logo_id']??0));ovf_update_option('ovf_icon_bg',sanitize_hex_color($_POST['ovf_icon_bg']??'')?:'#ffffff');ovf_update_option('ovf_app_icon_id',absint($_POST['ovf_app_icon_id']??0));$review_url=esc_url_raw(wp_unslash($_POST['ovf_google_review_url']??''));$review_parts=wp_parse_url($review_url);if($review_url&&(!is_array($review_parts)||empty($review_parts['host'])||!in_array(strtolower($review_parts['scheme']??''),['http','https'],true)))$review_url='';ovf_update_option('ovf_google_review_url',$review_url);$recovery=in_array($_POST['ovf_password_recovery_mode']??'contact',['hidden','contact','wordpress'],true)?$_POST['ovf_password_recovery_mode']:'contact';ovf_update_option('ovf_password_recovery_mode',$recovery);ovf_update_option('ovf_password_recovery_message',sanitize_textarea_field(wp_unslash($_POST['ovf_password_recovery_message']??'')));ovf_update_option('ovf_privacy_mode',in_array($_POST['ovf_privacy_mode']??'page',['page','url','text','none'],true)?$_POST['ovf_privacy_mode']:'page');ovf_update_option('ovf_privacy_custom',wp_kses_post(wp_unslash($_POST['ovf_privacy_custom']??'')));ovf_update_option('ovf_privacy_page',absint($_POST['ovf_privacy_page']??0));ovf_update_option('ovf_privacy_url',esc_url_raw(wp_unslash($_POST['ovf_privacy_url']??'')));ovf_update_option('ovf_privacy_required',empty($_POST['ovf_privacy_required'])?'0':'1');$ovf_old_win=ovf_purchase_window_days();ovf_update_option('ovf_purchase_window_days',min(3650,absint($_POST['ovf_purchase_window_days']??0)));if($ovf_old_win!==ovf_purchase_window_days())ovf_sync_all_rewards();ovf_notice(__('Ajustes actualizados.','ov-fidelidad'));}
 $brand=ovf_get_option('ovf_brand_name',get_bloginfo('name'));$app=ovf_get_option('ovf_app_name',$brand.' Fidelidad');$short=ovf_get_option('ovf_app_short_name',$brand);$primary=ovf_get_option('ovf_primary','#315b46');$accent=ovf_get_option('ovf_accent','#203c2d');$background=ovf_get_option('ovf_background','#f6f6f1');$logo=ovf_v02_logo();$icon=absint(ovf_get_option('ovf_app_icon_id'));$logo_url=$logo?wp_get_attachment_image_url($logo,'medium'):'';$icon_url=$icon?wp_get_attachment_image_url($icon,'medium'):'';$logo_meta=$logo?wp_get_attachment_metadata($logo):[];$icon_meta=$icon?wp_get_attachment_metadata($icon):[];$logo_dims=(!empty($logo_meta['width'])&&!empty($logo_meta['height']))?' · '.(int)$logo_meta['width'].' × '.(int)$logo_meta['height'].' px':'';$icon_dims=(!empty($icon_meta['width'])&&!empty($icon_meta['height']))?' · '.(int)$icon_meta['width'].' × '.(int)$icon_meta['height'].' px':'';$recovery=ovf_get_option('ovf_password_recovery_mode','contact');$recovery_msg=ovf_get_option('ovf_password_recovery_message',__('¿Olvidaste tu contraseña? Solicita el cambio al encargado del negocio.','ov-fidelidad'));
 ovf_admin_header(__('Ajustes','ov-fidelidad'),__('Configura identidad, Web App, acceso y páginas del sistema desde un solo lugar.','ov-fidelidad'),false);?>
 <form method="post" class="ovf-form-card ovf-brand-editor" id="ovf-brand-editor"><?php wp_nonce_field('ovf_brand_save');?>
 <div class="ovf-brand-layout"><div class="ovf-brand-fields">
  <div class="ovf-brand-section"><h2><?php esc_html_e('Identidad del negocio','ov-fidelidad');?></h2><p><?php esc_html_e('Estos datos se mostrarán en la Web App y en la experiencia de tus clientes.','ov-fidelidad');?></p><div class="ovf-fields">
   <label><span><?php esc_html_e('Nombre del negocio','ov-fidelidad');?></span><input id="ovf_brand_name" name="ovf_brand_name" value="<?php echo esc_attr($brand);?>"></label>
   <label><span><?php esc_html_e('Nombre de la Web App','ov-fidelidad');?></span><input id="ovf_app_name" name="ovf_app_name" value="<?php echo esc_attr($app);?>"></label>
   <label><span><?php esc_html_e('Nombre corto','ov-fidelidad');?></span><input id="ovf_app_short_name" name="ovf_app_short_name" maxlength="20" value="<?php echo esc_attr($short);?>"><small><?php esc_html_e('Se utiliza al instalar la app en el teléfono.','ov-fidelidad');?></small></label>
  </div></div>
  <div class="ovf-brand-section"><h2><?php esc_html_e('Reseñas de Google','ov-fidelidad');?></h2><p><?php esc_html_e('Añade un acceso para que tus clientes puedan valorar su experiencia con el negocio.','ov-fidelidad');?></p><div class="ovf-fields"><label><span><?php esc_html_e('Enlace para dejar una reseña','ov-fidelidad');?></span><input type="url" name="ovf_google_review_url" value="<?php echo esc_attr(ovf_get_option('ovf_google_review_url',''));?>" placeholder="https://g.page/r/.../review"><small><?php esc_html_e('Pega el enlace para solicitar reseñas que copiaste desde tu Perfil de Negocio de Google. Déjalo vacío para ocultar el botón en las tarjetas.','ov-fidelidad');?></small></label></div></div>
  <div class="ovf-brand-section"><h2><?php esc_html_e('Colores','ov-fidelidad');?></h2><p><?php esc_html_e('Selecciona un color o escribe directamente su valor hexadecimal.','ov-fidelidad');?></p><div class="ovf-color-grid">
   <?php foreach([['ovf_primary',__('Color principal','ov-fidelidad'),$primary],['ovf_accent',__('Color oscuro','ov-fidelidad'),$accent],['ovf_background',__('Fondo de la app','ov-fidelidad'),$background]] as $color):?><label class="ovf-color-field"><span><?php echo esc_html($color[1]);?></span><div><input type="color" class="ovf-color-picker" data-hex="<?php echo esc_attr($color[0]);?>_hex" value="<?php echo esc_attr($color[2]);?>"><input type="text" class="ovf-color-hex" id="<?php echo esc_attr($color[0]);?>_hex" name="<?php echo esc_attr($color[0]);?>" value="<?php echo esc_attr(strtoupper($color[2]));?>" maxlength="7" spellcheck="false"></div></label><?php endforeach;?>
  </div></div>
  <div class="ovf-brand-section"><h2><?php esc_html_e('Logo e icono','ov-fidelidad');?></h2><p><?php esc_html_e('Verás una previsualización inmediatamente después de seleccionar cada imagen.','ov-fidelidad');?></p>
   <div class="ovf-media-grid">
    <div class="ovf-media-field" data-kind="logo"><span><?php esc_html_e('Logo','ov-fidelidad');?></span><input type="hidden" id="ovf_logo_id" name="ovf_logo_id" value="<?php echo (int)$logo;?>"><div class="ovf-media-preview <?php echo $logo_url?'has-image':'';?>" id="ovf_logo_id_preview"><?php if($logo_url):?><img src="<?php echo esc_url($logo_url);?>" alt=""><?php else:?><div class="ovf-media-empty"><b>LOGO</b><small><?php esc_html_e('Aún no seleccionado','ov-fidelidad');?></small></div><?php endif;?></div><div class="ovf-media-actions"><button type="button" class="button ovf-media" data-target="ovf_logo_id"><?php echo $logo?esc_html__('Reemplazar logo','ov-fidelidad'):esc_html__('Seleccionar logo','ov-fidelidad');?></button><button type="button" class="button-link-delete ovf-media-remove" data-target="ovf_logo_id" <?php echo $logo?'':'hidden';?>><?php esc_html_e('Eliminar','ov-fidelidad');?></button></div><small class="ovf-media-meta" id="ovf_logo_id_meta"><?php echo $logo?esc_html(get_the_title($logo).$logo_dims):esc_html__('PNG, JPG, WEBP o SVG permitido por WordPress.','ov-fidelidad');?></small></div>
    <div class="ovf-media-field" data-kind="icon"><span><?php esc_html_e('Icono de la Web App','ov-fidelidad');?></span><input type="hidden" id="ovf_app_icon_id" name="ovf_app_icon_id" value="<?php echo (int)$icon;?>"><div class="ovf-media-preview ovf-icon-preview <?php echo $icon_url?'has-image':'';?>" id="ovf_app_icon_id_preview"><?php if($icon_url):?><img src="<?php echo esc_url($icon_url);?>" alt=""><?php else:?><div class="ovf-media-empty"><b>APP</b><small><?php esc_html_e('512 × 512 recomendado','ov-fidelidad');?></small></div><?php endif;?></div><div class="ovf-media-actions"><button type="button" class="button ovf-media" data-target="ovf_app_icon_id"><?php echo $icon?esc_html__('Reemplazar icono','ov-fidelidad'):esc_html__('Seleccionar icono','ov-fidelidad');?></button><button type="button" class="button-link-delete ovf-media-remove" data-target="ovf_app_icon_id" <?php echo $icon?'':'hidden';?>><?php esc_html_e('Eliminar','ov-fidelidad');?></button></div><small class="ovf-media-meta" id="ovf_app_icon_id_meta"><?php echo $icon?esc_html(get_the_title($icon).$icon_dims):esc_html__('Usa una imagen cuadrada; 512 × 512 px es lo recomendado.','ov-fidelidad');?></small></div>
   </div>
   <div class="ovf-fields ovf-icon-bg-row"><label class="ovf-color-field"><span><?php esc_html_e('Fondo del icono en el teléfono','ov-fidelidad');?></span><div><input type="color" class="ovf-color-picker" data-hex="ovf_icon_bg_hex" value="<?php echo esc_attr(ovf_get_option('ovf_icon_bg','#ffffff'));?>"><input type="text" class="ovf-color-hex" id="ovf_icon_bg_hex" name="ovf_icon_bg" value="<?php echo esc_attr(strtoupper(ovf_get_option('ovf_icon_bg','#ffffff')));?>" maxlength="7" spellcheck="false"></div><small><?php esc_html_e('Se usa detrás del logo cuando no hay un icono cuadrado propio. Si subes un “Icono de la Web App”, ese se usa tal cual.','ov-fidelidad');?></small></label></div>
  </div>
  <?php $ovf_win=ovf_purchase_window_days();$ovf_opts=[0=>__('Nunca caducan','ov-fidelidad'),30=>__('30 días','ov-fidelidad'),60=>__('60 días','ov-fidelidad'),90=>__('90 días','ov-fidelidad'),180=>__('6 meses','ov-fidelidad'),365=>__('1 año','ov-fidelidad')];if(!isset($ovf_opts[$ovf_win]))$ovf_opts[$ovf_win]=sprintf(__('%d días','ov-fidelidad'),$ovf_win);?>
  <div class="ovf-brand-section" id="ovf-program-rules"><h2><?php esc_html_e('Reglas del programa','ov-fidelidad');?></h2><p><?php esc_html_e('Define cuánto tiempo cuentan las compras para ganar beneficios. El plazo para canjear cada beneficio se configura en Beneficios.','ov-fidelidad');?></p><div class="ovf-fields"><label><span><?php esc_html_e('Vigencia de las compras','ov-fidelidad');?></span><select name="ovf_purchase_window_days"><?php foreach($ovf_opts as $v=>$l):?><option value="<?php echo (int)$v;?>" <?php selected($ovf_win,$v);?>><?php echo esc_html($l);?></option><?php endforeach;?></select><small><?php esc_html_e('Ejemplo con 90 días: solo cuentan las compras de los últimos 3 meses. Las más antiguas dejan de contar una a una, sin reiniciar todo de golpe. Los beneficios ya ganados no se pierden.','ov-fidelidad');?></small></label></div></div>
  <?php $pv_mode=ovf_get_option('ovf_privacy_mode','page');$pv_page=absint(ovf_get_option('ovf_privacy_page',0))?:absint(get_option('wp_page_for_privacy_policy',0));?>
  <div class="ovf-brand-section" id="ovf-privacy"><h2><?php esc_html_e('Privacidad','ov-fidelidad');?></h2><p><?php esc_html_e('Aviso de privacidad que se muestra a los clientes al registrarse. Los empleados ven el teléfono y el correo de los clientes de forma parcial; los encargados, completos.','ov-fidelidad');?></p>
   <?php if($pv_problem=ovf_privacy_problem()):$pv_pid=absint(ovf_get_option('ovf_privacy_page',0))?:absint(get_option('wp_page_for_privacy_policy',0));?><div class="ovf-inline-warn">⚠ <?php echo esc_html($pv_problem);?><?php if($pv_mode==='page'&&$pv_pid&&get_post($pv_pid)):?> <a href="<?php echo esc_url(get_edit_post_link($pv_pid));?>"><?php esc_html_e('Revisar y publicar la página','ov-fidelidad');?> →</a><?php endif;?></div><?php endif;?>
   <div class="ovf-fields">
    <label><span><?php esc_html_e('Aviso de privacidad','ov-fidelidad');?></span><select name="ovf_privacy_mode" id="ovf_privacy_mode"><option value="page" <?php selected($pv_mode,'page');?>><?php esc_html_e('Una página de este sitio','ov-fidelidad');?></option><option value="url" <?php selected($pv_mode,'url');?>><?php esc_html_e('Un enlace externo','ov-fidelidad');?></option><option value="text" <?php selected($pv_mode,'text');?>><?php esc_html_e('Escribirlo aquí','ov-fidelidad');?></option><option value="none" <?php selected($pv_mode,'none');?>><?php esc_html_e('No mostrar','ov-fidelidad');?></option></select></label>
    <label class="ovf-pv-page"><span><?php esc_html_e('Página del aviso','ov-fidelidad');?></span><?php wp_dropdown_pages(['name'=>'ovf_privacy_page','selected'=>$pv_page,'post_status'=>['publish','draft','private'],'show_option_none'=>__('— Elegir página —','ov-fidelidad'),'option_none_value'=>0]);?><small><?php esc_html_e('Por defecto se usa la página de privacidad configurada en WordPress (Ajustes → Privacidad).','ov-fidelidad');?></small></label>
    <label class="ovf-pv-url"><span><?php esc_html_e('Enlace del aviso','ov-fidelidad');?></span><input type="url" name="ovf_privacy_url" value="<?php echo esc_attr(ovf_get_option('ovf_privacy_url',''));?>" placeholder="https://"></label>
    <label class="ovf-pv-text ovf-span-2"><span><?php esc_html_e('Texto del aviso de privacidad','ov-fidelidad');?></span><textarea name="ovf_privacy_custom" rows="7" placeholder="<?php esc_attr_e('Ej.: [Negocio], con domicilio en …, es responsable del tratamiento de tus datos personales (nombre, teléfono y correo), que usaremos únicamente para administrar tu tarjeta de fidelidad…','ov-fidelidad');?>"><?php echo esc_textarea(ovf_get_option('ovf_privacy_custom',''));?></textarea><small><?php esc_html_e('Revisa el contenido con tu asesor legal. El cliente lo leerá en una ventana al registrarse.','ov-fidelidad');?></small></label>
    <label class="ovf-check-row ovf-pv-req"><input type="checkbox" name="ovf_privacy_required" value="1" <?php checked(ovf_get_option('ovf_privacy_required','1'),'1');?>><span><b><?php esc_html_e('Pedir que el cliente acepte el aviso al registrarse','ov-fidelidad');?></b><small><?php esc_html_e('Se guarda la fecha de aceptación en la ficha del cliente.','ov-fidelidad');?></small></span></label>
   </div>
   <script>(function(){var m=document.getElementById('ovf_privacy_mode');if(!m)return;function u(){var v=m.value;document.querySelector('.ovf-pv-page').style.display=v==='page'?'':'none';document.querySelector('.ovf-pv-url').style.display=v==='url'?'':'none';document.querySelector('.ovf-pv-text').style.display=v==='text'?'':'none';document.querySelector('.ovf-pv-req').style.display=v==='none'?'none':'';}m.addEventListener('change',u);u();})();</script>
  </div>
  <div class="ovf-brand-section"><h2><?php esc_html_e('Acceso del equipo','ov-fidelidad');?></h2><p><?php esc_html_e('Decide qué ocurre cuando un miembro del equipo olvida su contraseña.','ov-fidelidad');?></p><div class="ovf-fields"><label><span><?php esc_html_e('Recuperación de contraseña','ov-fidelidad');?></span><select name="ovf_password_recovery_mode"><option value="hidden" <?php selected($recovery,'hidden');?>><?php esc_html_e('No mostrar ninguna opción','ov-fidelidad');?></option><option value="contact" <?php selected($recovery,'contact');?>><?php esc_html_e('Mostrar mensaje de contacto','ov-fidelidad');?></option><option value="wordpress" <?php selected($recovery,'wordpress');?>><?php esc_html_e('Permitir recuperación segura por correo','ov-fidelidad');?></option></select></label><label><span><?php esc_html_e('Mensaje personalizado','ov-fidelidad');?></span><textarea name="ovf_password_recovery_message" rows="3"><?php echo esc_textarea($recovery_msg);?></textarea><small><?php esc_html_e('Se muestra cuando eliges “Mostrar mensaje de contacto”.','ov-fidelidad');?></small></label></div></div>
 </div>
 <aside class="ovf-brand-preview"><div class="ovf-preview-sticky"><span class="ovf-preview-label"><?php esc_html_e('Vista previa','ov-fidelidad');?></span><div class="ovf-phone" id="ovf-phone" style="--preview-primary:<?php echo esc_attr($primary);?>;--preview-accent:<?php echo esc_attr($accent);?>;--preview-bg:<?php echo esc_attr($background);?>"><div class="ovf-phone-screen"><div class="ovf-phone-status"><span>9:41</span><span>● ● ●</span></div><div class="ovf-phone-app"><header><div class="ovf-preview-logo" id="ovf-preview-logo"><?php if($logo_url):?><img src="<?php echo esc_url($logo_url);?>" alt=""><?php else:?><i><?php echo esc_html(ovf_initial($brand));?></i><?php endif;?></div><div><b id="ovf-preview-brand"><?php echo esc_html($brand);?></b><small><?php esc_html_e('Fidelidad','ov-fidelidad');?></small></div><em><?php echo esc_html(ovf_initial(wp_get_current_user()->display_name));?></em></header><main><span><?php esc_html_e('Inicio','ov-fidelidad');?></span><h3 id="ovf-preview-appname"><?php echo esc_html($app);?></h3><p><?php esc_html_e('¿Qué necesitas hacer?','ov-fidelidad');?></p><div class="ovf-preview-scan"><i><?php echo ovf_v02_icon('scan');?></i><div><b><?php esc_html_e('Escanear QR','ov-fidelidad');?></b><small><?php esc_html_e('Registrar una compra','ov-fidelidad');?></small></div><strong>→</strong></div><div class="ovf-preview-actions"><div>＋<b><?php esc_html_e('Nuevo cliente','ov-fidelidad');?></b></div><div>⌕<b><?php esc_html_e('Buscar cliente','ov-fidelidad');?></b></div></div></main></div></div></div><div class="ovf-home-icon"><div id="ovf-preview-icon"><?php if($icon_url):?><img src="<?php echo esc_url($icon_url);?>" alt=""><?php else:?><i><?php echo esc_html(ovf_initial($short));?></i><?php endif;?></div><span id="ovf-preview-short"><?php echo esc_html($short);?></span></div><p><?php esc_html_e('Así se aproximará la identidad de la app y su icono en el teléfono.','ov-fidelidad');?></p></div></aside>
 </div>
 <div class="ovf-form-actions ovf-brand-save"><button class="ovf-admin-btn" name="ovf_brand_save"><?php esc_html_e('Guardar ajustes','ov-fidelidad');?></button><a class="button" target="_blank" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal'));?>"><?php esc_html_e('Abrir Web App','ov-fidelidad');?> ↗</a><span class="ovf-unsaved" id="ovf-unsaved" hidden><?php esc_html_e('Tienes cambios sin guardar','ov-fidelidad');?></span></div></form>
 <script>jQuery(function($){
  var form=$('#ovf-brand-editor'),dirty=$('#ovf-unsaved');function changed(){dirty.prop('hidden',false)}
  function validHex(v){return /^#[0-9A-F]{6}$/i.test(v)}
  $('.ovf-color-picker').on('input change',function(){var hex=$('#'+$(this).data('hex')),v=$(this).val().toUpperCase();hex.val(v).trigger('input');});
  $('.ovf-color-hex').on('input',function(){var v=$(this).val().trim();if(v&&v[0]!=='#')v='#'+v;v=v.toUpperCase();$(this).val(v);if(validHex(v)){var picker=$('.ovf-color-picker[data-hex="'+this.id+'"]');picker.val(v);if(this.name==='ovf_primary')$('#ovf-phone').css('--preview-primary',v);if(this.name==='ovf_accent')$('#ovf-phone').css('--preview-accent',v);if(this.name==='ovf_background')$('#ovf-phone').css('--preview-bg',v);}changed();});
  $('#ovf_brand_name').on('input',function(){var v=$(this).val()||'<?php echo esc_js(__('Negocio','ov-fidelidad'));?>';$('#ovf-preview-brand').text(v);if(!$('#ovf_logo_id').val())$('#ovf-preview-logo i').text(v.charAt(0).toUpperCase());changed();});
  $('#ovf_app_name').on('input',function(){$('#ovf-preview-appname').text($(this).val());changed();});$('#ovf_app_short_name').on('input',function(){var v=$(this).val();$('#ovf-preview-short').text(v);if(!$('#ovf_app_icon_id').val())$('#ovf-preview-icon i').text((v||'A').charAt(0).toUpperCase());changed();});
  $('.ovf-media').on('click',function(){var btn=$(this),id=btn.data('target'),target=$('#'+id),frame=wp.media({title:'<?php echo esc_js(__('Seleccionar imagen','ov-fidelidad'));?>',button:{text:'<?php echo esc_js(__('Usar esta imagen','ov-fidelidad'));?>'},multiple:false,library:{type:'image'}});frame.on('select',function(){var a=frame.state().get('selection').first().toJSON(),url=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);target.val(a.id);$('#'+id+'_preview').addClass('has-image').html($('<img>',{src:url,alt:''}));var meta=(a.filename||'')+(a.width&&a.height?' · '+a.width+' × '+a.height+' px':'');if(id==='ovf_app_icon_id'&&a.width&&a.height){if(a.width!==a.height)meta+=' · <?php echo esc_js(__('Advertencia: el icono debe ser cuadrado.','ov-fidelidad'));?>';else if(a.width<512||a.height<512)meta+=' · <?php echo esc_js(__('Resolución baja: recomendamos 512 × 512 px o superior.','ov-fidelidad'));?>';else meta+=' · <?php echo esc_js(__('Resolución adecuada','ov-fidelidad'));?>';}$('#'+id+'_meta').text(meta);btn.text(id==='ovf_logo_id'?'<?php echo esc_js(__('Reemplazar logo','ov-fidelidad'));?>':'<?php echo esc_js(__('Reemplazar icono','ov-fidelidad'));?>');$('.ovf-media-remove[data-target="'+id+'"]').prop('hidden',false);if(id==='ovf_logo_id')$('#ovf-preview-logo').html($('<img>',{src:url,alt:''}));else $('#ovf-preview-icon').html($('<img>',{src:url,alt:''}));changed();});frame.open();});
  $('.ovf-media-remove').on('click',function(){var id=$(this).data('target');$('#'+id).val('');var isLogo=id==='ovf_logo_id',txt=isLogo?'LOGO':'APP',sub=isLogo?'<?php echo esc_js(__('Aún no seleccionado','ov-fidelidad'));?>':'<?php echo esc_js(__('512 × 512 recomendado','ov-fidelidad'));?>';$('#'+id+'_preview').removeClass('has-image').html('<div class="ovf-media-empty"><b>'+txt+'</b><small>'+sub+'</small></div>');$(this).prop('hidden',true);$('.ovf-media[data-target="'+id+'"]').text(isLogo?'<?php echo esc_js(__('Seleccionar logo','ov-fidelidad'));?>':'<?php echo esc_js(__('Seleccionar icono','ov-fidelidad'));?>');if(isLogo){var v=$('#ovf_brand_name').val()||'N';$('#ovf-preview-logo').html('<i>'+v.charAt(0).toUpperCase()+'</i>')}else{var s=$('#ovf_app_short_name').val()||'A';$('#ovf-preview-icon').html('<i>'+s.charAt(0).toUpperCase()+'</i>')}changed();});
  form.on('input change','input',function(){if(!$(this).hasClass('ovf-color-picker')&&!$(this).hasClass('ovf-color-hex'))changed()});form.on('submit',function(){dirty.prop('hidden',true)});
 });</script>
 <?php $app_url=ovf_v02_url('ovf_page_portal');$reg_url=ovf_v02_url('ovf_page_register');$card_url=ovf_v02_url('ovf_page_card'); ?>
 <section class="ovf-form-card ovf-system-pages"><div class="ovf-brand-section"><h2><?php esc_html_e('Páginas del sistema','ov-fidelidad');?></h2><p><?php esc_html_e('OV Fidelidad administra estas rutas automáticamente. No necesitas crear páginas ni copiar shortcodes.','ov-fidelidad');?></p></div>
 <div class="ovf-ready-links"><a target="_blank" href="<?php echo esc_url($app_url);?>"><b><?php esc_html_e('Web App del equipo','ov-fidelidad');?></b><span><?php echo esc_html($app_url);?></span></a><a target="_blank" href="<?php echo esc_url($reg_url);?>"><b><?php esc_html_e('Registro público','ov-fidelidad');?></b><span><?php echo esc_html($reg_url);?></span></a><a target="_blank" href="<?php echo esc_url($card_url);?>"><b><?php esc_html_e('Tarjeta del cliente','ov-fidelidad');?></b><span><?php echo esc_html($card_url);?></span></a></div>
 <div class="ovf-registration-qr" id="ovf-registration-qr"><div class="ovf-qr" data-qr="<?php echo esc_attr($reg_url);?>"></div><div><h3><?php esc_html_e('QR de registro del negocio','ov-fidelidad');?></h3><p><?php esc_html_e('Imprímelo o colócalo en el mostrador para que los clientes creen su propia tarjeta.','ov-fidelidad');?></p><button type="button" class="button ovf-download-qr" data-filename="qr-registro-<?php echo esc_attr(sanitize_title($brand));?>.png"><?php esc_html_e('Descargar QR','ov-fidelidad');?></button></div></div>
 </section>
 <section class="ovf-form-card" id="ovf-tools"><div class="ovf-brand-section"><h2><?php esc_html_e('Herramientas','ov-fidelidad');?></h2><p><?php esc_html_e('Utilidades para preparar una instalación antes de ponerla en producción.','ov-fidelidad');?></p></div><form method="post" onsubmit="return confirm('<?php echo esc_js(__('Se eliminarán clientes, compras, canjes e historial de prueba. La identidad, beneficios y personal se conservarán. ¿Continuar?','ov-fidelidad'));?>');"><?php wp_nonce_field('ovf_clear_test_data');?><button class="button" name="ovf_clear_test_data" value="1"><?php esc_html_e('Limpiar clientes e historial de prueba','ov-fidelidad');?></button></form>
 <div class="ovf-cache-tool"><div><b><?php esc_html_e('Caché del sitio','ov-fidelidad');?></b><small><?php $ovf_dc=ovf_detected_cache();echo esc_html($ovf_dc?sprintf(__('Detectado: %s. Las páginas del programa se excluyen automáticamente.','ov-fidelidad'),implode(', ',$ovf_dc)):__('No se detectó un plugin de caché. Si tu hosting o CDN tiene caché propia, excluye estas rutas:','ov-fidelidad'));?></small><code><?php echo esc_html(implode('   ',ovf_cache_paths()));?></code></div><form method="post"><?php wp_nonce_field('ovf_purge_cache');?><button class="button" name="ovf_purge_cache" value="1"><?php esc_html_e('Limpiar caché del programa','ov-fidelidad');?></button></form></div>
 <form method="post" class="ovf-uninstall-pref"><?php wp_nonce_field('ovf_uninstall_pref');?><label class="ovf-check-row"><input type="checkbox" name="ovf_delete_data" value="1" <?php checked(get_option('ovf_delete_data'),'1');?> onchange="this.form.submit()"><span><b><?php esc_html_e('Borrar todos los datos al desinstalar','ov-fidelidad');?></b><small><?php esc_html_e('Desactivado (recomendado): si borras el plugin, clientes, compras y ajustes se conservan para reinstalarlo después.','ov-fidelidad');?></small></span></label><input type="hidden" name="ovf_uninstall_pref" value="1"></form></section>
 <?php ovf_admin_end();
}
function ovf_v02_admin_staff(){
 if(!current_user_can('manage_options'))wp_die(esc_html__('No tienes permisos para administrar el personal.','ov-fidelidad'));
 $business_id=ovf_business_id();$team_query=['meta_key'=>'ovf_business_id','meta_value'=>$business_id];$owners=get_users(array_merge(['role'=>'ovf_owner','fields'=>'ID'],$team_query));$owner_count=count($owners);
 if(isset($_POST['ovf_staff_add'])&&check_admin_referer('ovf_staff_add')){$email=sanitize_email($_POST['email']??'');$name=sanitize_text_field(wp_unslash($_POST['name']??''));$role=in_array($_POST['role']??'',['ovf_owner','ovf_staff'],true)?$_POST['role']:'ovf_staff';$pass=(string)($_POST['password']??'');if(strlen($pass)<8){ovf_notice(__('La contraseña debe tener al menos 8 caracteres.','ov-fidelidad'),'error');}elseif($email&&!email_exists($email)){$uid=wp_create_user($email,$pass,$email);if(!is_wp_error($uid)){$u=new WP_User($uid);$u->set_role($role);wp_update_user(['ID'=>$uid,'display_name'=>$name?:$email,'first_name'=>$name]);delete_user_meta($uid,'ovf_access_disabled');delete_user_meta($uid,'ovf_force_password_change');update_user_meta($uid,'ovf_business_id',$business_id);set_transient('ovf_staff_credentials_'.ovf_business_id().'_'.get_current_user_id(),['name'=>$name?:$email,'email'=>$email,'password'=>$pass],5*MINUTE_IN_SECONDS);ovf_notice(__('Acceso creado correctamente. Comparte estas credenciales con la persona.','ov-fidelidad'));}else ovf_notice($uid->get_error_message(),'error');}else ovf_notice(__('Escribe un email válido que no esté registrado.','ov-fidelidad'),'error');}
 if(isset($_POST['ovf_staff_update'])&&check_admin_referer('ovf_staff_update')){$uid=absint($_POST['user_id']??0);$u=get_user_by('id',$uid);if($u&&absint(get_user_meta($uid,'ovf_business_id',true))===$business_id&&array_intersect(['ovf_owner','ovf_staff'],$u->roles)){$newrole=in_array($_POST['role']??'',['ovf_owner','ovf_staff'],true)?$_POST['role']:'ovf_staff';$is_owner=in_array('ovf_owner',$u->roles,true);if($is_owner&&$newrole!=='ovf_owner'&&$owner_count<=1){ovf_notice(__('Debe existir al menos un encargado. Crea otro encargado antes de cambiar este perfil.','ov-fidelidad'),'error');}else{$email=sanitize_email($_POST['email']??'');$name=sanitize_text_field(wp_unslash($_POST['name']??''));$result=wp_update_user(['ID'=>$uid,'display_name'=>$name?:$u->display_name,'first_name'=>$name,'user_email'=>$email?:$u->user_email]);if(!is_wp_error($result)){$u=new WP_User($uid);$u->set_role($newrole);ovf_notice(__('Datos del miembro actualizados.','ov-fidelidad'));}else ovf_notice($result->get_error_message(),'error');}}}
 if(isset($_POST['ovf_staff_toggle'])&&check_admin_referer('ovf_staff_toggle')){$uid=absint($_POST['user_id']??0);$u=get_user_by('id',$uid);if($u&&absint(get_user_meta($uid,'ovf_business_id',true))===$business_id&&array_intersect(['ovf_owner','ovf_staff'],$u->roles)){$disabled=get_user_meta($uid,'ovf_access_disabled',true)==='1';$is_owner=in_array('ovf_owner',$u->roles,true);if(!$disabled&&$is_owner&&$owner_count<=1){ovf_notice(__('No puedes desactivar al último encargado.','ov-fidelidad'),'error');}elseif($uid===get_current_user_id()&&!$disabled){ovf_notice(__('No puedes desactivar tu propio acceso desde esta pantalla.','ov-fidelidad'),'error');}else{update_user_meta($uid,'ovf_access_disabled',$disabled?'0':'1');ovf_notice($disabled?__('Acceso reactivado.','ov-fidelidad'):__('Acceso desactivado.','ov-fidelidad'));}}}
 if(isset($_POST['ovf_staff_password'])&&check_admin_referer('ovf_staff_password')){$uid=absint($_POST['user_id']??0);$u=get_user_by('id',$uid);$pass=(string)($_POST['new_password']??'');if($u&&absint(get_user_meta($uid,'ovf_business_id',true))===$business_id&&array_intersect(['ovf_owner','ovf_staff'],$u->roles)){if(strlen($pass)<8){ovf_notice(__('La nueva contraseña debe tener al menos 8 caracteres.','ov-fidelidad'),'error');}else{wp_set_password($pass,$uid);delete_user_meta($uid,'ovf_force_password_change');set_transient('ovf_staff_credentials_'.ovf_business_id().'_'.get_current_user_id(),['name'=>$u->display_name,'email'=>$u->user_email,'password'=>$pass],5*MINUTE_IN_SECONDS);ovf_notice(__('Contraseña actualizada. Comparte las nuevas credenciales con esta persona.','ov-fidelidad'));}}}
 if(isset($_POST['ovf_staff_delete'])&&check_admin_referer('ovf_staff_delete')){$uid=absint($_POST['user_id']??0);$u=get_user_by('id',$uid);if($u&&absint(get_user_meta($uid,'ovf_business_id',true))===$business_id&&array_intersect(['ovf_owner','ovf_staff'],$u->roles)){$is_owner=in_array('ovf_owner',$u->roles,true);if($uid===get_current_user_id())ovf_notice(__('No puedes eliminar tu propia cuenta desde esta pantalla.','ov-fidelidad'),'error');elseif($is_owner&&$owner_count<=1)ovf_notice(__('No puedes eliminar al último encargado.','ov-fidelidad'),'error');else{require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($uid);ovf_notice(__('Miembro eliminado. Su actividad histórica se conserva en OV Fidelidad.','ov-fidelidad'));}}}
 $users=get_users(array_merge(['role__in'=>['ovf_owner','ovf_staff'],'orderby'=>'display_name'],$team_query));$owners=0;$staff=0;$active=0;foreach($users as $u){if(in_array('ovf_owner',$u->roles,true))$owners++;else $staff++;if(get_user_meta($u->ID,'ovf_access_disabled',true)!=='1')$active++;}
 $edit_id=absint($_GET['edit_staff']??0);$edit=$edit_id?get_user_by('id',$edit_id):false;if($edit&&(!array_intersect(['ovf_owner','ovf_staff'],$edit->roles)||absint(get_user_meta($edit->ID,'ovf_business_id',true))!==$business_id))$edit=false;
 ovf_admin_header(__('Personal','ov-fidelidad'),__('Gestiona quién puede utilizar la Web App sin entrar al escritorio de WordPress.','ov-fidelidad'),false);$ovf_creds=get_transient('ovf_staff_credentials_'.ovf_business_id().'_'.get_current_user_id());if($ovf_creds){delete_transient('ovf_staff_credentials_'.ovf_business_id().'_'.get_current_user_id());echo '<div class="ovf-credentials-card"><div><span>'.esc_html__('DATOS DE ACCESO','ov-fidelidad').'</span><h2>'.esc_html($ovf_creds['name']).'</h2><p>'.esc_html($ovf_creds['email']).'</p></div><div class="ovf-temp-password"><small>'.esc_html__('Contraseña','ov-fidelidad').'</small><code id="ovf-temp-pass">'.esc_html($ovf_creds['password']).'</code><button type="button" class="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById(\'ovf-temp-pass\').textContent)">'.esc_html__('Copiar contraseña','ov-fidelidad').'</button></div><p>'.esc_html__('Comparte estos datos de forma segura. La contraseña seguirá siendo válida hasta que el encargado la cambie desde este panel.','ov-fidelidad').'</p></div>';}
 echo '<div class="ovf-staff-stats"><div><strong>'.count($users).'</strong><span>'.esc_html__('Miembros','ov-fidelidad').'</span></div><div><strong>'.$owners.'</strong><span>'.esc_html__('Encargados','ov-fidelidad').'</span></div><div><strong>'.$staff.'</strong><span>'.esc_html__('Empleados','ov-fidelidad').'</span></div><div><strong>'.$active.'</strong><span>'.esc_html__('Con acceso','ov-fidelidad').'</span></div></div>';
 echo '<div class="ovf-admin-grid ovf-staff-grid"><div class="ovf-panel"><div class="ovf-panel-title ovf-team-title"><h2>'.esc_html__('Equipo','ov-fidelidad').'</h2><div class="ovf-team-title-actions"><span>'.sprintf(esc_html__('%d miembros','ov-fidelidad'),count($users)).'</span></div></div>';
 if(!$users)echo '<div class="ovf-empty-mini">'.esc_html__('Aún no has creado personal.','ov-fidelidad').'</div>';
 foreach($users as $u){$role=in_array('ovf_owner',$u->roles,true)?__('Encargado','ov-fidelidad'):__('Empleado','ov-fidelidad');$disabled=get_user_meta($u->ID,'ovf_access_disabled',true)==='1';echo '<div class="ovf-staff-row'.($edit&&$edit->ID===$u->ID?' is-selected':'').'"><div class="ovf-staff-avatar">'.esc_html(ovf_initial($u->display_name)).'</div><div class="ovf-staff-info"><div><b>'.esc_html($u->display_name).'</b><span class="ovf-role-badge">'.esc_html($role).'</span>'.($disabled?'<span class="ovf-status-badge is-off">'.esc_html__('Sin acceso','ov-fidelidad').'</span>':'<span class="ovf-status-badge">'.esc_html__('Activo','ov-fidelidad').'</span>').'</div><span>'.esc_html($u->user_email).'</span></div><a class="ovf-staff-manage" href="'.esc_url(add_query_arg(['page'=>'ov-fidelidad-staff','edit_staff'=>$u->ID],admin_url('admin.php'))).'">'.esc_html__('Administrar','ov-fidelidad').' →</a></div>';}
 echo '</div>';
 if($edit){$edit_role=in_array('ovf_owner',$edit->roles,true)?'ovf_owner':'ovf_staff';$disabled=get_user_meta($edit->ID,'ovf_access_disabled',true)==='1';echo '<div class="ovf-panel ovf-stack ovf-staff-editor"><div class="ovf-panel-title"><h2>'.esc_html__('Administrar miembro','ov-fidelidad').'</h2><a class="ovf-back-add" data-ovf-leave href="'.esc_url(admin_url('admin.php?page=ov-fidelidad-staff')).'">← '.esc_html__('Cancelar edición','ov-fidelidad').'</a></div><form method="post" class="ovf-stack">';wp_nonce_field('ovf_staff_update');echo '<input type="hidden" name="user_id" value="'.(int)$edit->ID.'"><label><span>'.esc_html__('Nombre','ov-fidelidad').'</span><input name="name" value="'.esc_attr($edit->display_name).'" required></label><label><span>'.esc_html__('Email','ov-fidelidad').'</span><input type="email" name="email" value="'.esc_attr($edit->user_email).'" required></label><label><span>'.esc_html__('Perfil','ov-fidelidad').'</span><select name="role"><option value="ovf_staff" '.selected($edit_role,'ovf_staff',false).'>'.esc_html__('Empleado','ov-fidelidad').'</option><option value="ovf_owner" '.selected($edit_role,'ovf_owner',false).'>'.esc_html__('Encargado (dueño o gerente)','ov-fidelidad').'</option></select></label><button class="ovf-admin-btn" name="ovf_staff_update">'.esc_html__('Guardar cambios','ov-fidelidad').'</button></form><div class="ovf-staff-actions"><form method="post">';wp_nonce_field('ovf_staff_toggle');echo '<input type="hidden" name="user_id" value="'.(int)$edit->ID.'"><button class="ovf-secondary-btn" name="ovf_staff_toggle">'.esc_html($disabled?__('Reactivar acceso','ov-fidelidad'):__('Desactivar acceso','ov-fidelidad')).'</button></form><form method="post" class="ovf-password-reset" onsubmit="return confirm(\''.esc_js(__('La contraseña actual dejará de funcionar y se cerrarán las sesiones de esta persona. ¿Continuar?','ov-fidelidad')).'\')">';wp_nonce_field('ovf_staff_password');echo '<input type="hidden" name="user_id" value="'.(int)$edit->ID.'"><input type="text" name="new_password" minlength="8" required placeholder="'.esc_attr__('Nueva contraseña','ov-fidelidad').'"><button class="ovf-secondary-btn" name="ovf_staff_password">'.esc_html__('Cambiar contraseña','ov-fidelidad').'</button></form><form method="post" onsubmit="return confirm(\''.esc_js(__('¿Eliminar a esta persona del equipo? Su historial de actividad se conservará.','ov-fidelidad')).'\')">';wp_nonce_field('ovf_staff_delete');echo '<input type="hidden" name="user_id" value="'.(int)$edit->ID.'"><button class="ovf-danger-btn" name="ovf_staff_delete">'.esc_html__('Eliminar del equipo','ov-fidelidad').'</button></form></div><p class="ovf-help">'.esc_html__('Desactivar bloquea el acceso sin borrar la cuenta. Eliminar quita la cuenta del equipo, pero OV Fidelidad conserva las referencias históricas de sus operaciones.','ov-fidelidad').'</p></div>';}else{echo '<form method="post" class="ovf-panel ovf-stack">';wp_nonce_field('ovf_staff_add');echo '<h2>'.esc_html__('Agregar persona','ov-fidelidad').'</h2><p class="ovf-help">'.esc_html__('Crea un acceso para un encargado (dueño, gerente o responsable) o para un empleado.','ov-fidelidad').'</p><label><span>'.esc_html__('Nombre','ov-fidelidad').'</span><input name="name" required></label><label><span>'.esc_html__('Email','ov-fidelidad').'</span><input type="email" name="email" required></label><label><span>'.esc_html__('Perfil','ov-fidelidad').'</span><select name="role"><option value="ovf_staff">'.esc_html__('Empleado','ov-fidelidad').'</option><option value="ovf_owner">'.esc_html__('Encargado (dueño o gerente)','ov-fidelidad').'</option></select></label><label><span>'.esc_html__('Contraseña','ov-fidelidad').'</span><input type="text" name="password" minlength="8" required autocomplete="new-password" placeholder="'.esc_attr__('Mínimo 8 caracteres','ov-fidelidad').'"><small class="ovf-field-help">'.esc_html__('El encargado define esta contraseña y se la entrega al miembro del equipo.','ov-fidelidad').'</small></label><button class="ovf-admin-btn" name="ovf_staff_add">'.esc_html__('Crear acceso','ov-fidelidad').'</button></form>';}
 echo '</div>';?><script>jQuery(function($){var dirty=false,form=$('.ovf-staff-editor form').first();if(!form.length)return;form.on('input change','input,select',function(){dirty=true});form.on('submit',function(){dirty=false});$('[data-ovf-leave],.ovf-add-staff,.ovf-staff-manage').on('click',function(e){if(dirty&&!window.confirm(<?php echo wp_json_encode(__('Tienes cambios sin guardar. ¿Quieres salir sin guardarlos?','ov-fidelidad'));?>)){e.preventDefault();}});});</script>
 <?php ovf_admin_end();
}

function ovf_v02_icon($name){$icons=[
'eye'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.8"/></svg>',
'eye-off'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 6.2A10.8 10.8 0 0 1 12 6c6 0 9.5 6 9.5 6a15 15 0 0 1-2.2 2.8M6.3 7.3C3.9 9.1 2.5 12 2.5 12s3.5 6 9.5 6c1.5 0 2.8-.4 4-.9M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>',
'home'=>'<svg viewBox="0 0 24 24"><path d="M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1Z"/></svg>',
'scan'=>'<svg viewBox="0 0 24 24"><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M8 12h8"/></svg>',
'user-plus'=>'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="4"/><path d="M2.5 21a6.5 6.5 0 0 1 13 0M19 8v6M16 11h6"/></svg>',
'users'=>'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M17 5.5a3.5 3.5 0 0 1 0 6.8M18 15a6 6 0 0 1 4 6"/></svg>',
'chevron'=>'<svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>',
'search'=>'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg>',
'qr'=>'<svg viewBox="0 0 24 24"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2v2h-2zM18 14h2M14 18v2M18 18h2v2"/></svg>',
'list'=>'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0M16 8h5M16 12h5M17 16h4"/></svg>',
'back'=>'<svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg>',
'gift'=>'<svg viewBox="0 0 24 24"><rect x="3.5" y="8" width="17" height="4.5" rx="1"/><path d="M5 12.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7.5M12 8v13M12 8S10.8 3.5 8.3 3.5a2.3 2.3 0 0 0 0 4.5H12Zm0 0s1.2-4.5 3.7-4.5a2.3 2.3 0 0 1 0 4.5H12Z"/></svg>',
'mail'=>'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>',
'chart'=>'<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
'star'=>'<svg viewBox="0 0 24 24"><path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/></svg>',
'logout'=>'<svg viewBox="0 0 24 24"><path d="M10 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5M14 8l4 4-4 4M9 12h9"/></svg>',
'chat'=>'<svg viewBox="0 0 24 24"><path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H6l-3 2v-6.5A7.5 7.5 0 1 1 20 11.5Z"/><path d="M8 10h8M8 14h5"/></svg>'
];return $icons[$name]??'';}

function ovf_v02_public_shell($body,$kind='public'){$brand=esc_html(ovf_login_brand_option('ovf_brand_name','OV Fidelidad'));$style='--ovf-primary:'.esc_attr(ovf_login_brand_option('ovf_primary','#315b46')).';--ovf-accent:'.esc_attr(ovf_login_brand_option('ovf_accent','#203c2d')).';--ovf-bg:'.esc_attr(ovf_login_brand_option('ovf_background','#f6f6f1'));ob_start();?>
<div class="ovf-v02 ovf-public-2026 ovf-public-<?php echo esc_attr($kind);?>" style="<?php echo $style;?>"><div class="ovf-public-shell"><header class="ovf-public-brand"><?php echo ovf_login_logo_html();?><span><b><?php echo $brand;?></b><small><?php esc_html_e('Programa de fidelidad','ov-fidelidad');?></small></span></header><main><?php echo $body;?></main><footer><?php echo esc_html($brand);?> · <?php esc_html_e('Fidelidad','ov-fidelidad');?></footer></div></div>
<?php return ob_get_clean();}

/** Enlace "Volver" consistente en todas las vistas internas. */
function ovf_v02_back($url,$label){return '<a class="ovf-app-back" href="'.esc_url($url).'">'.ovf_v02_icon('back').'<span>'.esc_html($label).'</span></a>';}

/** Buscador único de clientes (siempre lleva a la vista Clientes filtrada). */
function ovf_v02_search_form($placeholder='',$value=''){
 $placeholder=$placeholder?:__('Buscar por nombre o teléfono','ov-fidelidad');
 return '<form class="ovf-app-search" role="search" data-ovf-live-search="app" action="'.esc_url(ovf_v02_url('ovf_page_portal')).'"><input type="hidden" name="view" value="clients"><input type="search" name="q" value="'.esc_attr($value).'" placeholder="'.esc_attr($placeholder).'" aria-label="'.esc_attr($placeholder).'" autocomplete="off"><div class="ovf-search-suggestions" data-ovf-search-results hidden></div><button aria-label="'.esc_attr__('Buscar','ov-fidelidad').'">'.ovf_v02_icon('search').'</button></form>';
}

/** Sección activa del menú según la vista actual. */
function ovf_v02_section(){
 $view=sanitize_key($_GET['view']??'');
 if(!empty($_GET['ovf'])) return sanitize_key($_GET['source']??'')==='search'?'clients':'scanner';
 if(in_array($view,['clients','new'],true)) return 'clients';
 if(in_array($view,['profile','scanner','team','signup','rewards','program','activity','reports','messages','settings'],true)) return $view==='signup'?'home':$view;
 return 'home';
}

function ovf_v02_shell($body,$nav=true){
 $brand=esc_html(ovf_get_option('ovf_brand_name',get_bloginfo('name')));
 $style='--ovf-primary:'.esc_attr(ovf_get_option('ovf_primary','#315b46')).';--ovf-accent:'.esc_attr(ovf_get_option('ovf_accent','#203c2d')).';--ovf-bg:'.esc_attr(ovf_get_option('ovf_background','#f6f6f1'));
 $u=is_user_logged_in()?wp_get_current_user():null;
 $role=$u?(in_array('ovf_owner',$u->roles,true)||current_user_can('manage_options')?__('Encargado','ov-fidelidad'):__('Empleado','ov-fidelidad')):'';
 $is_staff=$u&&ovf_v02_staff_cap();$is_owner=$u&&ovf_v02_owner_cap();
 $active=ovf_v02_section();
 $items=[
  'home'=>[ovf_v02_url('ovf_page_portal'),'home',__('Inicio','ov-fidelidad')],
  'scanner'=>[ovf_v02_url('ovf_page_portal',['view'=>'scanner']),'scan',__('Escanear','ov-fidelidad')],
  'clients'=>[ovf_v02_url('ovf_page_portal',['view'=>'clients']),'list',__('Clientes','ov-fidelidad')],
 ];
 $items['messages']=[ovf_v02_url('ovf_page_portal',['view'=>'messages']),'mail',__('Banner y envío de promociones','ov-fidelidad')];
 if($is_owner){$items['program']=[ovf_v02_url('ovf_page_portal',['view'=>'program']),'chart',__('Reglas de acumulación','ov-fidelidad')];$items['rewards']=[ovf_v02_url('ovf_page_portal',['view'=>'rewards']),'gift',__('Beneficios','ov-fidelidad')];$items['activity']=[ovf_v02_url('ovf_page_portal',['view'=>'activity']),'chart',__('Actividad','ov-fidelidad')];$items['reports']=[ovf_v02_url('ovf_page_portal',['view'=>'reports']),'chart',__('Reportes','ov-fidelidad')];$items['settings']=[ovf_v02_url('ovf_page_portal',['view'=>'settings']),'star',__('Reseñas de Google','ov-fidelidad')];}
 $mobile_primary=['home','scanner','clients'];if($is_owner)$mobile_primary[]='rewards';$mobile_more=array_diff_key($items,array_flip($mobile_primary));$mobile_more_active=!in_array($active,$mobile_primary,true);
 ob_start();?>
<div class="ovf-v02 ovf-app-2026<?php echo ($nav&&$is_staff)?' has-nav':'';?>" style="<?php echo $style;?>"><div class="ovf-mobile-shell">
 <header class="ovf-mobile-head">
  <a class="ovf-mobile-brand" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal'));?>"><?php echo ovf_v02_logo_html();?><span><?php echo $brand;?><small><?php esc_html_e('Club de fidelidad','ov-fidelidad');?></small></span></a>
  <?php if($u):?>
  <details class="ovf-account"><summary aria-label="<?php esc_attr_e('Mi cuenta','ov-fidelidad');?>"><span class="ovf-avatar"><?php echo ovf_staff_avatar_html($u); ?></span><span class="ovf-account-who"><b><?php echo esc_html($u->display_name);?></b><small><?php echo esc_html($role);?></small></span><i>⌄</i></summary>
   <div>
    <div class="ovf-session-card"><span class="ovf-online-dot"></span><p><b><?php echo esc_html($u->display_name);?></b><small><?php echo esc_html($role);?></small><em><?php echo esc_html($u->user_email);?></em></p></div>
    <a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'profile']));?>"><?php echo ovf_v02_icon('users');?><?php esc_html_e('Mi perfil y fotografía','ov-fidelidad');?></a>
    <?php if($is_owner):?><a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'team']));?>"><?php echo ovf_v02_icon('users');?><?php esc_html_e('Gestionar equipo','ov-fidelidad');?></a><?php endif;?>
    <?php if(current_user_can('manage_options')):?><a href="<?php echo esc_url(admin_url('admin.php?page=ov-fidelidad'));?>"><?php echo ovf_v02_icon('home');?><?php esc_html_e('Escritorio de WordPress','ov-fidelidad');?></a><?php endif;?>
    <a class="ovf-logout" href="<?php echo esc_url(wp_logout_url(ovf_v02_url('ovf_page_portal')));?>"><?php echo ovf_v02_icon('logout');?><?php esc_html_e('Cerrar sesión','ov-fidelidad');?></a>
   </div>
  </details>
  <?php endif;?>
 </header>
 <?php if($nav&&$is_staff):?>
 <nav class="ovf-bottom-nav<?php echo $is_owner?' has-owner-nav':'';?>" aria-label="<?php esc_attr_e('Navegación principal','ov-fidelidad');?>">
  <?php foreach($items as $key=>$it):?><a class="ovf-nav-desktop <?php echo $active===$key?'is-active':'';?>" href="<?php echo esc_url($it[0]);?>"<?php echo $active===$key?' aria-current="page"':'';?>><?php echo ovf_v02_icon($it[1]);?><span><?php echo esc_html($it[2]);?></span></a><?php endforeach;?>
  <?php foreach($mobile_primary as $key):$it=$items[$key];$mobile_label=['home'=>__('Inicio','ov-fidelidad'),'scanner'=>__('Escanear','ov-fidelidad'),'clients'=>__('Clientes','ov-fidelidad'),'rewards'=>__('Premios','ov-fidelidad')][$key];?><a class="ovf-nav-mobile <?php echo $active===$key?'is-active':'';?>" href="<?php echo esc_url($it[0]);?>"<?php echo $active===$key?' aria-current="page"':'';?>><?php echo ovf_v02_icon($it[1]);?><span><?php echo esc_html($mobile_label);?></span></a><?php endforeach;?>
  <?php if($mobile_more):?><details class="ovf-nav-more"><summary class="ovf-nav-mobile<?php echo $mobile_more_active?' is-active':'';?>" aria-label="<?php esc_attr_e('Más secciones','ov-fidelidad');?>"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg><span><?php esc_html_e('Más','ov-fidelidad');?></span></summary><div class="ovf-nav-more-panel"><?php foreach($mobile_more as $key=>$it):?><a class="<?php echo $active===$key?'is-active':'';?>" href="<?php echo esc_url($it[0]);?>"<?php echo $active===$key?' aria-current="page"':'';?>><?php echo ovf_v02_icon($it[1]);?><span><?php echo esc_html($it[2]);?></span></a><?php endforeach;?></div></details><?php endif;?>
 </nav>
 <?php endif;?>
 <main><?php echo $body;?></main>
</div></div>
<?php return ob_get_clean();}

add_shortcode('ov_fidelidad_login','ovf_v02_login');
/** Formulario de acceso. El POST se procesa en ovf_action_login() (template_redirect). */
function ovf_v02_login(){
 ovf_v02_assets();
 if(is_user_logged_in()&&ovf_v02_staff_cap()&&!is_page((int)get_option('ovf_page_portal')))return '<script>location.replace('.wp_json_encode(ovf_v02_url('ovf_page_portal')).');</script>';
 $errors=['login'=>__('No pudimos iniciar sesión. Revisa tu email/usuario y contraseña.','ov-fidelidad'),'disabled'=>__('Tu acceso está desactivado. Habla con el encargado del negocio.','ov-fidelidad'),'expired'=>__('La página caducó. Vuelve a intentarlo.','ov-fidelidad')];
 $error=$errors[sanitize_key($_GET['ovf_err']??'')]??'';
 $mode=ovf_login_brand_option('ovf_password_recovery_mode',ovf_global_login_request()?'wordpress':'contact');
 $forgot=ovf_login_brand_option('ovf_password_recovery_message',__('¿Olvidaste tu contraseña? Solicita el cambio al encargado del negocio.','ov-fidelidad'));
 $recovery_view=sanitize_key(wp_unslash($_GET['ovf_recovery']??''));
 if(in_array($recovery_view,['request','sent','reset','complete','invalid'],true)){
  $brand=ovf_login_brand_option('ovf_brand_name','OV Fidelidad');$key=sanitize_text_field(wp_unslash($_GET['key']??''));$login=sanitize_text_field(wp_unslash($_GET['login']??''));$reset_user=($recovery_view==='reset'&&$key&&$login)?check_password_reset_key($key,$login):false;
  if($recovery_view==='reset'&&is_wp_error($reset_user))$recovery_view='invalid';
  $portal_args=[];if(!empty($_GET['ovf_business']))$portal_args['ovf_business']=sanitize_title(wp_unslash($_GET['ovf_business']));$is_global_recovery=empty($portal_args)&&function_exists('ovf_global_recovery_url');$portal_url=$is_global_recovery?ovf_global_login_portal_url():ovf_v02_url('ovf_page_portal',$portal_args);$action_url=$is_global_recovery?ovf_global_recovery_url('request'):add_query_arg('ovf_recovery','request',$portal_url);$reset_action_url=add_query_arg(['key'=>$key,'login'=>$login],$is_global_recovery?ovf_global_recovery_url('reset'):add_query_arg('ovf_recovery','reset',$portal_url));
  ob_start();?><section class="ovf-login ovf-recovery-screen"><div class="ovf-login-logo"><?php echo ovf_login_logo_html();?></div><span class="ovf-kicker"><?php echo esc_html($brand);?></span>
  <?php if($recovery_view==='sent'):?><h1><?php esc_html_e('Revisa tu correo','ov-fidelidad');?></h1><p><?php esc_html_e('Si existe una cuenta con esos datos, enviaremos instrucciones para cambiar la contraseña.','ov-fidelidad');?></p><div class="ovf-app-alert"><?php esc_html_e('Revisa también la carpeta de correo no deseado.','ov-fidelidad');?></div><a class="ovf-forgot" href="<?php echo esc_url($portal_url);?>"><?php esc_html_e('Volver al acceso','ov-fidelidad');?></a>
  <?php elseif($recovery_view==='complete'):?><h1><?php esc_html_e('Contraseña actualizada','ov-fidelidad');?></h1><p><?php esc_html_e('Ya puedes entrar a la Web App con tu nueva contraseña.','ov-fidelidad');?></p><a class="ovf-app-primary ovf-recovery-cta" href="<?php echo esc_url($portal_url);?>"><?php esc_html_e('Ir al acceso','ov-fidelidad');?> →</a>
  <?php elseif($recovery_view==='invalid'):?><h1><?php esc_html_e('El enlace ya no es válido','ov-fidelidad');?></h1><p><?php esc_html_e('El enlace pudo haber vencido o ya se utilizó. Solicita uno nuevo para continuar.','ov-fidelidad');?></p><a class="ovf-app-primary ovf-recovery-cta" href="<?php echo esc_url($action_url);?>"><?php esc_html_e('Solicitar otro enlace','ov-fidelidad');?></a>
  <?php elseif($recovery_view==='reset'):?><h1><?php esc_html_e('Crea una contraseña nueva','ov-fidelidad');?></h1><p><?php esc_html_e('Elige una contraseña segura de al menos 12 caracteres.','ov-fidelidad');?></p><?php if(!empty($_GET['ovf_recovery_error'])):?><div class="ovf-app-alert error"><?php esc_html_e('Las contraseñas deben coincidir y tener al menos 12 caracteres.','ov-fidelidad');?></div><?php endif;?><form method="post" action="<?php echo esc_url($reset_action_url);?>"><?php wp_nonce_field('ovf_recovery_reset');?><input type="hidden" name="key" value="<?php echo esc_attr($key);?>"><input type="hidden" name="login" value="<?php echo esc_attr($login);?>"><label><?php esc_html_e('Nueva contraseña','ov-fidelidad');?><input type="password" name="password" minlength="12" autocomplete="new-password" required></label><label><?php esc_html_e('Repite la contraseña','ov-fidelidad');?><input type="password" name="password_confirm" minlength="12" autocomplete="new-password" required></label><button class="ovf-app-primary" name="ovf_recovery_reset" value="1"><?php esc_html_e('Guardar contraseña','ov-fidelidad');?></button></form>
  <?php else:?><h1><?php esc_html_e('Recupera tu acceso','ov-fidelidad');?></h1><p><?php esc_html_e('Escribe el correo de acceso de tu negocio y te enviaremos un enlace para crear una contraseña nueva.','ov-fidelidad');?></p><form method="post" action="<?php echo esc_url($action_url);?>"><?php wp_nonce_field('ovf_recovery_request');?><label><?php esc_html_e('Correo o usuario','ov-fidelidad');?><input type="text" name="user_login" autocomplete="username" required></label><button class="ovf-app-primary" name="ovf_recovery_request" value="1"><?php esc_html_e('Enviar enlace seguro','ov-fidelidad');?></button></form><a class="ovf-forgot" href="<?php echo esc_url($portal_url);?>">← <?php esc_html_e('Volver al acceso','ov-fidelidad');?></a><?php endif;?></section><?php return ovf_v02_public_shell(ob_get_clean(),'login');
 }
 ob_start();?>
<section class="ovf-login"><div class="ovf-login-logo"><?php echo ovf_login_logo_html();?></div><span class="ovf-kicker"><?php echo esc_html(ovf_global_login_request()?ovf_global_login_option('subtitle','Acceso del equipo'):__('Acceso del equipo','ov-fidelidad'));?></span><h1><?php esc_html_e('Iniciar sesión','ov-fidelidad');?></h1><p><?php esc_html_e('Entra para atender clientes y registrar sus compras.','ov-fidelidad');?></p>
<?php if($error):?><div class="ovf-app-alert error"><?php echo esc_html($error);?></div><?php endif;?>
<form method="post" action="<?php echo esc_url(remove_query_arg('ovf_err'));?>"><?php wp_nonce_field('ovf_front_login');?>
 <label><?php esc_html_e('Email o usuario','ov-fidelidad');?><input name="login" autocomplete="username" autocapitalize="none" required></label>
 <label><?php esc_html_e('Contraseña','ov-fidelidad');?><span class="ovf-password-field"><input id="ovf-login-password" type="password" name="password" autocomplete="current-password" required><button type="button" class="ovf-password-toggle" data-target="ovf-login-password" aria-label="<?php esc_attr_e('Mostrar u ocultar contraseña','ov-fidelidad');?>"><span class="ovf-eye-on"><?php echo ovf_v02_icon('eye');?></span><span class="ovf-eye-off"><?php echo ovf_v02_icon('eye-off');?></span></button></span></label>
 <label class="ovf-check"><input type="checkbox" name="remember" value="1" checked><span><?php esc_html_e('Mantener mi sesión','ov-fidelidad');?></span></label>
 <button name="ovf_login" value="1" class="ovf-app-primary"><?php esc_html_e('Entrar','ov-fidelidad');?></button>
</form>
<?php if($mode==='wordpress'):?><a class="ovf-forgot" href="<?php echo esc_url((ovf_global_login_request()&&function_exists('ovf_global_recovery_url')?ovf_global_recovery_url('request'):add_query_arg('ovf_recovery','request',ovf_v02_url('ovf_page_portal'))));?>"><?php esc_html_e('¿Olvidaste tu contraseña?','ov-fidelidad');?></a><?php elseif($mode==='contact'):?><details class="ovf-forgot-help"><summary><?php esc_html_e('¿Olvidaste tu contraseña?','ov-fidelidad');?></summary><p><?php echo nl2br(esc_html($forgot));?></p></details><?php endif;?>
</section>
<?php echo ovf_v02_password_toggle_js(); return ovf_v02_public_shell(ob_get_clean(),'login');}

function ovf_v02_password_toggle_js(){static $done=false;if($done)return '';$done=true;return "<script>document.addEventListener('click',function(e){var b=e.target.closest('.ovf-password-toggle');if(!b)return;var i=document.getElementById(b.dataset.target);if(i){var show=i.type==='password';i.type=show?'text':'password';b.classList.toggle('is-visible',show);b.setAttribute('aria-pressed',show?'true':'false');}});</script>";}

add_shortcode('ov_fidelidad_app','ovf_v02_app');
/**
 * Web App del equipo. Vistas: home · scanner (también ?ovf=token) · clients (?q=) · new · team · signup.
 * Los formularios se procesan en includes/front-actions.php y vuelven aquí con un mensaje flash.
 */
function ovf_v02_app(){
 ovf_v02_assets();
 if(!is_user_logged_in())return ovf_v02_login();
 if(!ovf_v02_staff_cap())return ovf_v02_shell('<div class="ovf-app-section"><div class="ovf-state"><h1>'.esc_html__('Sin acceso','ov-fidelidad').'</h1><p>'.esc_html__('Esta cuenta no pertenece al equipo del programa o su acceso está desactivado.','ov-fidelidad').'</p><a class="ovf-app-primary" href="'.esc_url(wp_logout_url(ovf_v02_url('ovf_page_portal'))).'">'.esc_html__('Entrar con otra cuenta','ov-fidelidad').'</a></div></div>',false);
 global $wpdb;$t=ovf_tables();
 $view=sanitize_key($_GET['view']??'home');
 // Un enlace con ?ovf=TOKEN (QR escaneado, búsqueda o enlace desde el escritorio) abre la ficha del cliente.
 if($view==='scanner'||!empty($_GET['ovf']))return ovf_sc_scanner();
 if(in_array($view,['team','rewards','program','activity','reports','settings'],true)&&!ovf_v02_owner_cap())$view='home';
 $home=ovf_v02_url('ovf_page_portal');
 $q=sanitize_text_field(wp_unslash($_GET['q']??''));
 if($q!==''&&$view==='home')$view='clients'; // compatibilidad con enlaces antiguos ?q=
 ob_start();
 echo ovf_flash_html();

 if($view==='profile'):
  $profile_user=wp_get_current_user(); ?>
  <section class="ovf-app-section ovf-my-profile">
    <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad')); ?>
    <span class="ovf-kicker"><?php esc_html_e('MI CUENTA','ov-fidelidad'); ?></span>
    <h1><?php esc_html_e('Mi perfil','ov-fidelidad'); ?></h1>
    <p><?php esc_html_e('Personaliza tu foto. Se mostrará en tu panel y en la lista del equipo.','ov-fidelidad'); ?></p>
    <div class="ovf-avatar-profile-card">
      <div class="ovf-avatar-profile-name"><strong><?php echo esc_html($profile_user->display_name); ?></strong><small><?php echo esc_html($profile_user->user_email); ?></small></div>
      <?php echo ovf_avatar_form($profile_user); ?>
    </div>
  </section>
  <?php return ovf_v02_shell(ob_get_clean(),true);
 endif;

 if($view==='messages'){
  echo ovf_email_campaign_view();
  return ovf_v02_shell(ob_get_clean(),true);
 }

 if($view==='settings'):
 $review_url=ovf_get_option('ovf_google_review_url','');?>
<section class="ovf-app-section ovf-business-settings">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('PRESENCIA EN GOOGLE','ov-fidelidad');?></span><h1><?php esc_html_e('Reseñas Google','ov-fidelidad');?></h1>
 <p><?php esc_html_e('Configura el enlace para que tus clientes puedan valorar su experiencia.','ov-fidelidad');?></p>
 <div class="ovf-team-create ovf-review-settings-card"><div class="ovf-review-settings-heading"><span class="ovf-review-settings-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/></svg></span><div><h2><?php esc_html_e('Reseñas de Google','ov-fidelidad');?></h2><p><?php esc_html_e('Invita a tus clientes a compartir su experiencia en Google.','ov-fidelidad');?></p></div></div>
 <form method="post" class="ovf-app-form ovf-review-settings-form"><?php wp_nonce_field('ovf_front_reviews');?><label><?php esc_html_e('Enlace directo para dejar una reseña','ov-fidelidad');?><input type="url" name="ovf_google_review_url" value="<?php echo esc_attr($review_url);?>" placeholder="https://g.page/r/.../review"><small class="ovf-hint"><?php esc_html_e('Cópialo desde tu Perfil de Negocio de Google. Al guardarlo, aparecerá un botón en las tarjetas de tus clientes.','ov-fidelidad');?></small></label><div class="ovf-review-actions"><button class="ovf-app-primary" name="ovf_front_reviews" value="save"><?php esc_html_e('Guardar enlace','ov-fidelidad');?></button><?php if($review_url):?><button type="submit" class="ovf-review-delete" name="ovf_front_reviews" value="delete" formnovalidate onclick="return confirm('<?php echo esc_js(__('¿Eliminar el enlace de reseñas? El botón dejará de aparecer en las tarjetas.','ov-fidelidad'));?>')"><?php esc_html_e('Eliminar enlace','ov-fidelidad');?></button><?php endif;?></div></form>
 </div>
</section>
<?php
 elseif($view==='program'):
  $names=['','Bronce','Plata','Oro'];$defaults=[0,1000,5000,10000];?>
<section class="ovf-app-section ovf-program-view">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Configuración del negocio','ov-fidelidad');?></span><h1><?php esc_html_e('Reglas de acumulación','ov-fidelidad');?></h1>
 <p><?php esc_html_e('Configura qué obtiene el cliente por cada ticket. Los cambios aplican a las compras nuevas.','ov-fidelidad');?></p>
 <form method="post" class="ovf-team-create ovf-program-form"><?php wp_nonce_field('ovf_front_program');?><div class="ovf-program-features"><b><?php esc_html_e('Qué acumulan tus clientes','ov-fidelidad');?></b><p><?php esc_html_e('Cada compra registra un sello. Activa los puntos, el cashback o ambos.','ov-fidelidad');?></p><label><input type="checkbox" name="program_features[]" value="points" <?php checked(ovf_program_feature_enabled('points'));?>> <?php esc_html_e('Puntos','ov-fidelidad');?></label><label><input type="checkbox" name="program_features[]" value="cashback" <?php checked(ovf_program_feature_enabled('cashback'));?>> <?php esc_html_e('Cashback','ov-fidelidad');?></label></div><div class="ovf-app-form ovf-two-col">
  <label><?php esc_html_e('Pesos para ganar 1 punto','ov-fidelidad');?><input type="number" min="1" max="100000" name="points_per_amount" value="<?php echo (int)ovf_get_option('ovf_points_per_amount',10);?>" required><small class="ovf-hint"><?php esc_html_e('Ejemplo: 10 significa 1 punto por cada $10 MXN.','ov-fidelidad');?></small></label>
  <label><?php esc_html_e('Cashback sobre el ticket (%)','ov-fidelidad');?><input type="number" min="0" max="100" step="0.1" name="cashback_percent" value="<?php echo esc_attr(ovf_get_option('ovf_cashback_percent',0));?>"><small class="ovf-hint"><?php esc_html_e('Usa 0 para desactivarlo.','ov-fidelidad');?></small></label>
  <label><?php esc_html_e('Puntos para convertir en $1 de saldo','ov-fidelidad');?><input type="number" min="1" max="100000" name="points_per_peso" value="<?php echo (int)ovf_get_option('ovf_points_per_peso',10);?>" required></label>
  <label><?php esc_html_e('Puntos extra por cumpleaños','ov-fidelidad');?><input type="number" min="0" max="100000" name="birthday_bonus" value="<?php echo (int)ovf_get_option('ovf_birthday_bonus_points',0);?>"><small class="ovf-hint"><?php esc_html_e('Se entregan una vez al año. Usa 0 para desactivarlos.','ov-fidelidad');?></small></label>
  <label><?php esc_html_e('Bono para quien invita: tipo','ov-fidelidad');?><select name="referral_bonus_type"><option value="points" <?php selected(ovf_get_option('ovf_referral_bonus_type','points'),'points');?>><?php esc_html_e('Puntos','ov-fidelidad');?></option><option value="stamps" <?php selected(ovf_get_option('ovf_referral_bonus_type','points'),'stamps');?>><?php esc_html_e('Sellos de compra','ov-fidelidad');?></option></select></label><label><?php esc_html_e('Cantidad del bono para quien invita','ov-fidelidad');?><input type="number" min="0" max="100000" name="referral_bonus_amount" data-referral-bonus-amount value="<?php echo ovf_get_option('ovf_referral_bonus_type','points')==='stamps'?(int)ovf_get_option('ovf_referral_bonus_stamps',0):(int)ovf_get_option('ovf_referral_bonus_points',0);?>"><small class="ovf-hint"><?php esc_html_e('Si es un bono en sellos, elige 1 o 2. Se entrega cuando el invitado completa su primera compra.','ov-fidelidad');?></small></label>
  <label><?php esc_html_e('Descuento al invitado en su primera compra (%)','ov-fidelidad');?><input type="number" min="0" max="100" step="0.1" name="referral_discount_percent" value="<?php echo esc_attr(ovf_get_option('ovf_referral_discount_percent',0));?>"></label>
  <?php foreach([1,2,3] as $i):?><label><?php echo esc_html(sprintf(__('Nivel VIP %d · nombre','ov-fidelidad'),$i));?><input name="vip<?php echo $i;?>_name" value="<?php echo esc_attr(ovf_get_option('ovf_vip'.$i.'_name',$names[$i]));?>"></label><label><?php echo esc_html(sprintf(__('Nivel VIP %d · gasto acumulado MXN','ov-fidelidad'),$i));?><input type="number" min="0" step="100" name="vip<?php echo $i;?>_amount" value="<?php echo esc_attr(ovf_get_option('ovf_vip'.$i.'_amount',$defaults[$i]));?>"></label><?php endforeach;?>
  <button class="ovf-app-primary ovf-span" name="ovf_front_program" value="1"><?php esc_html_e('Guardar reglas','ov-fidelidad');?></button>
 </div></form>
</section>
<?php
 elseif($view==='team'):
  $team=get_users(['role__in'=>['ovf_owner','ovf_staff'],'orderby'=>'display_name','meta_key'=>'ovf_business_id','meta_value'=>ovf_business_id()]);$me=get_current_user_id();?>
<section class="ovf-app-section">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Encargado','ov-fidelidad');?></span><h1><?php esc_html_e('Gestionar equipo','ov-fidelidad');?></h1><p><?php esc_html_e('Crea accesos y cambia contraseñas sin entrar a WordPress.','ov-fidelidad');?></p>
 <div class="ovf-team-list">
 <?php foreach($team as $member):
  $is_owner_m=in_array('ovf_owner',$member->roles,true);
  $r=$is_owner_m?__('Encargado','ov-fidelidad'):__('Empleado','ov-fidelidad');
  $can_edit=current_user_can('manage_options')||$member->ID===$me||(!$is_owner_m&&!user_can($member,'manage_options'));?>
  <details class="ovf-team-member"><summary><i class="ovf-team-avatar"><?php echo ovf_staff_avatar_html($member); ?></i><span><b><?php echo esc_html($member->display_name);?><?php if($member->ID===$me):?> <em class="ovf-you"><?php esc_html_e('Tú','ov-fidelidad');?></em><?php endif;?></b><small><?php echo esc_html($r.' · '.$member->user_email);?></small></span><em>⌄</em></summary>
  <?php if($can_edit):?>
   <?php echo ovf_avatar_form($member,true); ?>
   <form method="post" class="ovf-inline-password"><?php wp_nonce_field('ovf_front_staff_password');?><input type="hidden" name="user_id" value="<?php echo (int)$member->ID;?>"><label><?php esc_html_e('Nueva contraseña','ov-fidelidad');?><span class="ovf-password-field"><input id="ovf-p-<?php echo (int)$member->ID;?>" type="password" name="new_password" minlength="8" required autocomplete="new-password"><button type="button" class="ovf-password-toggle" data-target="ovf-p-<?php echo (int)$member->ID;?>" aria-label="<?php esc_attr_e('Mostrar u ocultar contraseña','ov-fidelidad');?>"><span class="ovf-eye-on"><?php echo ovf_v02_icon('eye');?></span><span class="ovf-eye-off"><?php echo ovf_v02_icon('eye-off');?></span></button></span></label><button class="ovf-app-secondary" name="ovf_front_staff_password" value="1"><?php esc_html_e('Cambiar contraseña','ov-fidelidad');?></button></form>
  <?php else:?><p class="ovf-inline-note"><?php esc_html_e('Solo el administrador del sitio puede cambiar la contraseña de otro encargado.','ov-fidelidad');?></p><?php endif;?>
  </details>
 <?php endforeach;?>
 </div>
 <div class="ovf-team-create"><h2><?php esc_html_e('Agregar miembro','ov-fidelidad');?></h2>
  <form method="post" class="ovf-app-form ovf-two-col"><?php wp_nonce_field('ovf_front_staff_add');?>
   <label><?php esc_html_e('Nombre','ov-fidelidad');?><input name="name" required></label>
   <label><?php esc_html_e('Email','ov-fidelidad');?><input name="email" type="email" required autocapitalize="none"></label>
   <label><?php esc_html_e('Rol','ov-fidelidad');?><select name="role"><option value="ovf_staff"><?php esc_html_e('Empleado','ov-fidelidad');?></option><option value="ovf_owner"><?php esc_html_e('Encargado (dueño o gerente)','ov-fidelidad');?></option></select></label>
   <label><?php esc_html_e('Contraseña','ov-fidelidad');?><span class="ovf-password-field"><input id="ovf-new-staff-pass" name="password" type="password" minlength="8" required autocomplete="new-password"><button type="button" class="ovf-password-toggle" data-target="ovf-new-staff-pass" aria-label="<?php esc_attr_e('Mostrar u ocultar contraseña','ov-fidelidad');?>"><span class="ovf-eye-on"><?php echo ovf_v02_icon('eye');?></span><span class="ovf-eye-off"><?php echo ovf_v02_icon('eye-off');?></span></button></span></label>
   <button class="ovf-app-primary ovf-span" name="ovf_front_staff_add" value="1"><?php esc_html_e('Crear acceso','ov-fidelidad');?></button>
  </form>
 </div>
</section>
<?php echo ovf_v02_password_toggle_js();

 elseif($view==='reports'):
  $from=sanitize_text_field(wp_unslash($_GET['from']??wp_date('Y-m-01',current_time('timestamp'))));$to=sanitize_text_field(wp_unslash($_GET['to']??current_time('Y-m-d')));
  if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from))$from=wp_date('Y-m-01',current_time('timestamp'));if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))$to=current_time('Y-m-d');
  $customer_search=sanitize_text_field(wp_unslash($_GET['customer']??''));$selected_client=absint($_GET['client_id']??0);$report_page=max(1,absint($_GET['report_page']??1));$report=ovf_reporting_summary($from,$to,$customer_search,$selected_client,$report_page,10);$m=$report['metrics'];$frequent=$report['top'];
  $download=wp_nonce_url(add_query_arg(['action'=>'ovf_export_owner_analytics','from'=>$from,'to'=>$to],admin_url('admin-post.php')),'ovf_analytics_export');
  $download_customers=wp_nonce_url(add_query_arg(['action'=>'ovf_export_owner_analytics','from'=>$from,'to'=>$to,'report'=>'customers','customer'=>$customer_search,'client_id'=>$selected_client],admin_url('admin-post.php')),'ovf_analytics_export');?>
<section class="ovf-app-section ovf-activity-view ovf-reports-view">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Datos del negocio','ov-fidelidad');?></span><h1><?php esc_html_e('Reportes','ov-fidelidad');?></h1>
 <p><?php esc_html_e('Analítica actualizada desde la actividad registrada. Revisa ventas, clientes y visitas para decidir a quién reconocer.','ov-fidelidad');?></p>
 <form method="get" class="ovf-team-create ovf-report-filters" data-ovf-live-search="reports"><input type="hidden" name="view" value="reports"><input type="hidden" name="client_id" value="<?php echo $selected_client;?>" data-ovf-report-client><label><?php esc_html_e('Desde','ov-fidelidad');?><input type="date" name="from" value="<?php echo esc_attr($from);?>" required></label><label><?php esc_html_e('Hasta','ov-fidelidad');?><input type="date" name="to" value="<?php echo esc_attr($to);?>" required></label><div class="ovf-report-search"><label for="ovf-report-customer"><?php esc_html_e('Buscar cliente','ov-fidelidad');?><input id="ovf-report-customer" type="search" name="customer" value="<?php echo esc_attr($customer_search);?>" placeholder="<?php esc_attr_e('Nombre, teléfono o correo','ov-fidelidad');?>" autocomplete="off"></label><div class="ovf-search-suggestions" data-ovf-search-results hidden></div></div><button class="ovf-app-primary"><?php esc_html_e('Filtrar','ov-fidelidad');?></button></form>
 <div class="ovf-report-downloads"><a class="ovf-app-secondary" href="<?php echo esc_url($download);?>"><?php esc_html_e('Descargar movimientos (Excel/CSV)','ov-fidelidad');?></a><a class="ovf-app-secondary" href="<?php echo esc_url($download_customers);?>"><?php esc_html_e('Descargar clientes frecuentes','ov-fidelidad');?></a></div>
 <div class="ovf-kpis"><div><strong><?php echo number_format_i18n((int)$m->scans);?></strong><span><?php esc_html_e('escaneos QR','ov-fidelidad');?></span></div><div><strong><?php echo number_format_i18n((int)$m->new_clients);?></strong><span><?php esc_html_e('tarjetas activadas','ov-fidelidad');?></span></div><div><strong><?php echo number_format_i18n((int)$m->purchases);?></strong><span><?php esc_html_e('ventas','ov-fidelidad');?></span></div><div><strong>$<?php echo number_format_i18n((float)$m->revenue,2);?></strong><span><?php esc_html_e('venta neta MXN','ov-fidelidad');?></span></div><div><strong>$<?php echo number_format_i18n((float)$m->average_ticket,2);?></strong><span><?php esc_html_e('ticket promedio','ov-fidelidad');?></span></div><div><strong><?php echo number_format_i18n((int)$m->buyers);?></strong><span><?php esc_html_e('clientes compradores','ov-fidelidad');?></span></div><div><strong><?php echo number_format_i18n((int)$m->redemptions);?></strong><span><?php esc_html_e('beneficios canjeados','ov-fidelidad');?></span></div></div>
 <div class="ovf-section-title"><span><?php esc_html_e('Clientes más frecuentes','ov-fidelidad');?></span><b><?php echo number_format_i18n((int)$report['total']);?></b></div>
 <p class="ovf-report-note"><?php esc_html_e('Identifica a tus clientes más leales por número de compras y gasto. Puedes usar esta lista para ofrecerles un premio, descuento o invitación especial.','ov-fidelidad');?></p>
 <div class="ovf-report-table-card"><p class="ovf-report-table-meta"><?php printf(esc_html__('Mostrando %1$d–%2$d de %3$d clientes · 10 por página','ov-fidelidad'),$report['total']?($report['page']-1)*10+1:0,min($report['page']*10,$report['total']),$report['total']);?></p><div class="ovf-table-wrap"><table class="ovf-table"><thead><tr><th><?php esc_html_e('Cliente','ov-fidelidad');?></th><th><?php esc_html_e('Teléfono','ov-fidelidad');?></th><th><?php esc_html_e('Compras','ov-fidelidad');?></th><th><?php esc_html_e('Gasto total','ov-fidelidad');?></th><th><?php esc_html_e('Ticket promedio','ov-fidelidad');?></th><th><?php esc_html_e('Última compra','ov-fidelidad');?></th></tr></thead><tbody><?php if(!$frequent):?><tr><td colspan="6"><?php esc_html_e('No hay compras de clientes en este periodo.','ov-fidelidad');?></td></tr><?php else:foreach($frequent as $c):?><tr><td><?php echo esc_html($c->name);?></td><td><?php echo esc_html($c->phone);?></td><td><?php echo number_format_i18n((int)$c->purchases);?></td><td>$<?php echo number_format_i18n((float)$c->spent,2);?> MXN</td><td>$<?php echo number_format_i18n((float)$c->average_ticket,2);?> MXN</td><td><?php echo esc_html(mysql2date(get_option('date_format'),$c->last_purchase));?></td></tr><?php endforeach;endif;?></tbody></table></div><?php if($report['pages']>1):?><nav class="ovf-report-pagination" aria-label="<?php esc_attr_e('Paginación de clientes frecuentes','ov-fidelidad');?>"><?php if($report['page']>1):?><a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'reports','from'=>$from,'to'=>$to,'customer'=>$customer_search,'client_id'=>$selected_client,'report_page'=>$report['page']-1]));?>">← <?php esc_html_e('Anterior','ov-fidelidad');?></a><?php endif;?><span><?php printf(esc_html__('Página %1$d de %2$d','ov-fidelidad'),$report['page'],$report['pages']);?></span><?php if($report['page']<$report['pages']):?><a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'reports','from'=>$from,'to'=>$to,'customer'=>$customer_search,'client_id'=>$selected_client,'report_page'=>$report['page']+1]));?>"><?php esc_html_e('Siguiente','ov-fidelidad');?> →</a><?php endif;?></nav><?php endif;?></div>
 <p class="ovf-report-note"><?php esc_html_e('Los escaneos se contabilizan desde esta versión. Los importes de compras que no se capturaron al registrarlas aparecen como $0 y no se pueden recuperar retroactivamente.','ov-fidelidad');?></p>
</section>
<?php
 elseif($view==='activity'):
  $ranges=['today'=>__('Hoy','ov-fidelidad'),'7'=>__('7 días','ov-fidelidad'),'30'=>__('30 días','ov-fidelidad')];
  $range=sanitize_key($_GET['range']??'today');if(!isset($ranges[$range]))$range='today';
  $since=$range==='today'?current_time('Y-m-d').' 00:00:00':wp_date('Y-m-d 00:00:00',current_time('timestamp',true)-((int)$range-1)*DAY_IN_SECONDS);
  $sum=function($type)use($wpdb,$t,$since){return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE type=%s AND created_at>=%s",$type,$since));};
  $purchases=$sum('purchase');$redeems=$sum('redeem');
  $newc=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['clients']} WHERE created_at>=%s",$since));
  $unique=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT client_id) FROM {$t['moves']} WHERE type='purchase' AND created_at>=%s",$since));
  $by_staff=$wpdb->get_results($wpdb->prepare("SELECT m.user_id, u.display_name, SUM(m.type='purchase') p, SUM(m.type='redeem') r FROM {$t['moves']} m LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.created_at>=%s AND m.type IN ('purchase','redeem') GROUP BY m.user_id, u.display_name ORDER BY p DESC",$since));
  $rows=$wpdb->get_results($wpdb->prepare("SELECT m.*, c.name, c.token, u.display_name staff FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id LEFT JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.created_at>=%s ORDER BY m.id DESC LIMIT 150",$since));
  $labels=['purchase'=>[__('Compra registrada','ov-fidelidad'),'+1'],'redeem'=>[__('Beneficio canjeado','ov-fidelidad'),'★'],'registration'=>[__('Nuevo cliente','ov-fidelidad'),'＋']];?>
<section class="ovf-app-section ovf-activity-view">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Encargado','ov-fidelidad');?></span><h1><?php esc_html_e('Actividad','ov-fidelidad');?></h1>
 <p><?php esc_html_e('Qué pasó en tu negocio: compras, canjes y clientes nuevos, y quién del equipo los registró.','ov-fidelidad');?></p>
 <nav class="ovf-segment" aria-label="<?php esc_attr_e('Periodo','ov-fidelidad');?>"><?php foreach($ranges as $k=>$l):?><a class="<?php echo $range===(string)$k?'is-active':'';?>" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'activity','range'=>$k]));?>"><?php echo esc_html($l);?></a><?php endforeach;?></nav>
 <div class="ovf-kpis">
  <div><strong><?php echo $purchases;?></strong><span><?php echo esc_html(_n('compra','compras',$purchases,'ov-fidelidad'));?></span></div>
  <div><strong><?php echo $unique;?></strong><span><?php echo esc_html(_n('cliente atendido','clientes atendidos',$unique,'ov-fidelidad'));?></span></div>
  <div><strong><?php echo $redeems;?></strong><span><?php echo esc_html(_n('canje','canjes',$redeems,'ov-fidelidad'));?></span></div>
  <div><strong><?php echo $newc;?></strong><span><?php echo esc_html(_n('cliente nuevo','clientes nuevos',$newc,'ov-fidelidad'));?></span></div>
 </div>
 <?php if($by_staff):?>
 <div class="ovf-staff-board"><div class="ovf-section-title"><span><?php esc_html_e('Por persona del equipo','ov-fidelidad');?></span></div>
  <?php $max=max(1,max(array_map(function($x){return (int)$x->p;},$by_staff)));foreach($by_staff as $s):?>
  <div class="ovf-staff-line"><b><?php echo esc_html($s->display_name?:__('Sin usuario del equipo','ov-fidelidad'));?></b><div class="ovf-bar"><i style="width:<?php echo (int)round((int)$s->p/$max*100);?>%"></i></div><span><?php echo esc_html(sprintf(_n('%d compra','%d compras',(int)$s->p,'ov-fidelidad'),(int)$s->p).' · '.sprintf(_n('%d canje','%d canjes',(int)$s->r,'ov-fidelidad'),(int)$s->r));?></span></div>
  <?php endforeach;?>
 </div>
 <?php endif;?>
 <div class="ovf-section-title ovf-feed-title"><span><?php esc_html_e('Movimientos','ov-fidelidad');?></span><b><?php echo count($rows);?></b></div>
 <div class="ovf-feed">
 <?php if(!$rows):?><div class="ovf-state compact"><?php esc_html_e('No hay movimientos en este periodo.','ov-fidelidad');?></div><?php endif;
  $day='';foreach($rows as $m):$d=date_i18n(get_option('date_format'),strtotime($m->created_at));if($range!=='today'&&$d!==$day){$day=$d;echo '<h3 class="ovf-feed-day">'.esc_html($d).'</h3>';}
  $lb=$labels[$m->type]??[__('Ajuste','ov-fidelidad'),'·'];$link=$m->token?add_query_arg('source','search',ovf_scan_url($m->token)):'';?>
  <<?php echo $link?'a href="'.esc_url($link).'"':'div';?> class="ovf-feed-row is-<?php echo esc_attr($m->type);?>"><i><?php echo esc_html($lb[1]);?></i><div><b><?php echo esc_html($m->name?:__('Cliente eliminado','ov-fidelidad'));?></b><span><?php echo esc_html($lb[0].(!empty($m->receipt_number)?' · '.__('Ticket','ov-fidelidad').': '.$m->receipt_number:'').($m->type==='redeem'&&$m->note?': '.$m->note:'').($m->staff?' · '.$m->staff:($m->type==='registration'&&$m->method==='self'?' · '.__('se registró solo','ov-fidelidad'):'')));?></span></div><time><?php echo esc_html(date_i18n(get_option('time_format'),strtotime($m->created_at)));?></time></<?php echo $link?'a':'div';?>>
 <?php endforeach;?>
 </div>
</section>
<?php
 elseif($view==='rewards'):
  $rules=ovf_all_rules();$win=ovf_purchase_window_days();
  $freq=function($name,$rep){return '<select name="'.esc_attr($name).'"><option value="0" '.selected($rep,0,false).'>'.esc_html__('Una sola vez','ov-fidelidad').'</option><option value="1" '.selected($rep,1,false).'>'.esc_html__('Se repite (cíclico)','ov-fidelidad').'</option></select>';};?>
<section class="ovf-app-section ovf-rewards-view">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Encargado','ov-fidelidad');?></span><h1><?php esc_html_e('Beneficios','ov-fidelidad');?></h1>
 <p><?php esc_html_e('Lo que tus clientes ganan al acumular compras. Los cambios se aplican también a quienes ya cumplen el requisito.','ov-fidelidad');?> <?php echo $win?esc_html(sprintf(__('Cuentan las compras de los últimos %d días.','ov-fidelidad'),$win)):esc_html__('Las compras no caducan.','ov-fidelidad');?></p>
 <div class="ovf-rule-list">
 <?php if(!$rules):?><div class="ovf-state compact"><?php esc_html_e('Aún no hay beneficios. Crea el primero abajo.','ov-fidelidad');?></div><?php endif;?>
 <?php foreach($rules as $r):$rep=ovf_rule_repeats($r)?1:0;$on=(int)$r->enabled===1;?>
  <details class="ovf-rule-item<?php echo $on?'':' is-paused';?>">
   <summary><span class="ovf-rule-num"><b><?php echo (int)$r->milestone;?></b><small><?php echo $rep?esc_html__('cada','ov-fidelidad'):esc_html__('compras','ov-fidelidad');?></small></span><span class="ovf-rule-txt"><b><?php echo esc_html($r->title);?></b><small><?php echo esc_html(ovf_rule_label($r));?></small></span><em class="<?php echo $on?'on':'off';?>"><?php echo $on?esc_html__('Activo','ov-fidelidad'):esc_html__('Pausado','ov-fidelidad');?></em><i>⌄</i></summary>
   <form method="post" class="ovf-app-form ovf-two-col"><?php wp_nonce_field('ovf_front_rule');?><input type="hidden" name="rule_id" value="<?php echo (int)$r->id;?>">
    <label class="ovf-span"><?php esc_html_e('Nombre del beneficio','ov-fidelidad');?><input name="title" value="<?php echo esc_attr($r->title);?>" required></label>
    <label><?php esc_html_e('Número de compras','ov-fidelidad');?><input type="number" min="1" name="milestone" value="<?php echo (int)$r->milestone;?>" required></label>
    <label><?php esc_html_e('Frecuencia','ov-fidelidad');?><?php echo $freq('repeats',$rep);?></label>
    <label><?php esc_html_e('Días para canjear','ov-fidelidad');?><input type="number" min="0" name="expires_days" value="<?php echo (int)ovf_rule_expires_days($r);?>"><small class="ovf-hint"><?php esc_html_e('0 = sin vencimiento','ov-fidelidad');?></small></label>
    <label class="ovf-span"><?php esc_html_e('Descripción (opcional)','ov-fidelidad');?><input name="description" value="<?php echo esc_attr($r->description);?>"></label>
    <div class="ovf-form-foot ovf-span"><button class="ovf-app-primary" name="ovf_front_rule" value="update"><?php esc_html_e('Guardar cambios','ov-fidelidad');?></button></div>
   </form>
   <div class="ovf-rule-actions">
    <form method="post"><?php wp_nonce_field('ovf_front_rule');?><input type="hidden" name="rule_id" value="<?php echo (int)$r->id;?>"><button class="ovf-app-secondary" name="ovf_front_rule" value="toggle"><?php echo $on?esc_html__('Pausar','ov-fidelidad'):esc_html__('Activar','ov-fidelidad');?></button></form>
    <form method="post" onsubmit="return confirm(<?php echo esc_attr(wp_json_encode(sprintf(__('¿Eliminar “%s”? Los beneficios ya otorgados a clientes se conservan.','ov-fidelidad'),$r->title)));?>)"><?php wp_nonce_field('ovf_front_rule');?><input type="hidden" name="rule_id" value="<?php echo (int)$r->id;?>"><button class="ovf-link-danger" name="ovf_front_rule" value="delete"><?php esc_html_e('Eliminar','ov-fidelidad');?></button></form>
   </div>
  </details>
 <?php endforeach;?>
 </div>
 <div class="ovf-team-create"><h2><?php esc_html_e('Nuevo beneficio','ov-fidelidad');?></h2>
  <form method="post" class="ovf-app-form ovf-two-col ovf-new-rule"><?php wp_nonce_field('ovf_front_rule');?>
   <label class="ovf-span"><?php esc_html_e('Nombre del beneficio','ov-fidelidad');?><input name="title" placeholder="<?php esc_attr_e('Ej. Café americano gratis','ov-fidelidad');?>" required></label>
   <label><?php esc_html_e('Número de compras','ov-fidelidad');?><input type="number" min="1" name="milestone" value="5" required></label>
   <label><?php esc_html_e('Días para canjear','ov-fidelidad');?><input type="number" min="0" name="expires_days" value="0"><small class="ovf-hint"><?php esc_html_e('0 = sin vencimiento','ov-fidelidad');?></small></label>
   <fieldset class="ovf-choice ovf-span"><legend><?php esc_html_e('¿Cada cuánto se gana?','ov-fidelidad');?></legend>
    <label><input type="radio" name="repeats" value="0" checked><span><b><?php esc_html_e('Una sola vez','ov-fidelidad');?></b><small><?php esc_html_e('Ideal para premios grandes.','ov-fidelidad');?></small></span></label>
    <label><input type="radio" name="repeats" value="1"><span><b><?php esc_html_e('Se repite (cíclico)','ov-fidelidad');?></b><small><?php esc_html_e('Como una tarjeta de sellos.','ov-fidelidad');?></small></span></label>
   </fieldset>
   <p class="ovf-rule-preview ovf-span" data-once="<?php esc_attr_e('El cliente lo gana una vez, en la compra %d.','ov-fidelidad');?>" data-cyclic="<?php esc_attr_e('El cliente lo gana en las compras %1$d, %2$d, %3$d…','ov-fidelidad');?>"></p>
   <label class="ovf-span"><?php esc_html_e('Descripción (opcional)','ov-fidelidad');?><input name="description"></label>
   <div class="ovf-form-foot ovf-span"><button class="ovf-app-primary" name="ovf_front_rule" value="add">＋ <?php esc_html_e('Crear beneficio','ov-fidelidad');?></button></div>
  </form>
 </div>
</section>
<?php
 elseif($view==='new'):?>
<section class="ovf-app-section">
 <?php echo ovf_v02_back(ovf_v02_url('ovf_page_portal',['view'=>'clients']),__('Clientes','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Nuevo cliente','ov-fidelidad');?></span><h1><?php esc_html_e('Registrar cliente','ov-fidelidad');?></h1><p><?php esc_html_e('Solo toma unos segundos. Al guardar abrimos su ficha para registrar la primera compra.','ov-fidelidad');?></p>
 <form method="post" class="ovf-app-form ovf-two-col"><?php wp_nonce_field('ovf_front_new');?>
  <label class="ovf-register-field ovf-span"><span class="ovf-sr-only"><?php esc_html_e('Nombre','ov-fidelidad');?></span><input name="name" placeholder="<?php esc_attr_e('Nombre','ov-fidelidad');?>" required autofocus autocomplete="name"></label>
  <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Teléfono','ov-fidelidad');?></span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="<?php esc_attr_e('Teléfono','ov-fidelidad');?>"></label>
  <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Email','ov-fidelidad');?></span><input name="email" type="email" autocapitalize="none" autocomplete="email" placeholder="<?php esc_attr_e('Correo electrónico','ov-fidelidad');?>"></label>
  <label class="ovf-register-field"><span class="ovf-register-label"><?php esc_html_e('Fecha de nacimiento (opcional)','ov-fidelidad');?></span><input name="birthday" type="date" aria-label="<?php esc_attr_e('Fecha de nacimiento (opcional)','ov-fidelidad');?>"></label>
  <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Código de invitación (opcional)','ov-fidelidad');?></span><input name="referral_code" maxlength="24" autocapitalize="characters" placeholder="<?php esc_attr_e('Código de invitación (opcional)','ov-fidelidad');?>"></label>
  <?php echo ovf_email_consent_field();?>
  <div class="ovf-form-foot ovf-span"><a class="ovf-app-secondary" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'clients']));?>"><?php esc_html_e('Cancelar','ov-fidelidad');?></a><button class="ovf-app-primary" name="ovf_front_new" value="1"><?php esc_html_e('Guardar cliente','ov-fidelidad');?></button></div>
 </form>
</section>
<?php
 elseif($view==='signup'):$reg=ovf_v02_url('ovf_page_register');?>
<section class="ovf-app-section ovf-signup-view">
 <?php echo ovf_v02_back($home,__('Inicio','ov-fidelidad'));?>
 <span class="ovf-kicker"><?php esc_html_e('Registro público','ov-fidelidad');?></span><h1><?php esc_html_e('Que el cliente escanee este código','ov-fidelidad');?></h1><p><?php esc_html_e('Gira la pantalla hacia el cliente. Con la cámara de su teléfono creará su propia tarjeta en segundos.','ov-fidelidad');?></p>
 <div class="ovf-signup-qr"><div class="ovf-qr" data-qr="<?php echo esc_attr($reg);?>" data-size="260"></div><small><?php echo esc_html(preg_replace('#^https?://#','',$reg));?></small></div>
 <div class="ovf-form-foot"><button type="button" class="ovf-app-secondary ovf-download-qr" data-filename="qr-registro.png"><?php esc_html_e('Descargar QR para imprimir','ov-fidelidad');?></button><a class="ovf-app-secondary" href="<?php echo esc_url($reg);?>" target="_blank" rel="noopener"><?php esc_html_e('Abrir formulario','ov-fidelidad');?> ↗</a></div>
</section>
<?php
 elseif($view==='clients'):
  if($q!==''){if(stripos($q,'OVF:')===0)$q=substr($q,4);$like='%'.$wpdb->esc_like($q).'%';$digits=preg_replace('/\D+/','',$q);$dlike=$digits!==''?'%'.$wpdb->esc_like($digits).'%':$like;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['clients']} WHERE status='active' AND (name LIKE %s OR email LIKE %s OR phone LIKE %s OR phone LIKE %s OR token=%s) ORDER BY name ASC LIMIT 50",$like,$like,$like,$dlike,$q));}
  else $rows=$wpdb->get_results("SELECT * FROM {$t['clients']} WHERE status='active' ORDER BY updated_at DESC LIMIT 50");?>
<section class="ovf-app-section">
 <div class="ovf-section-head"><div><span class="ovf-kicker"><?php esc_html_e('Clientes','ov-fidelidad');?></span><h1><?php esc_html_e('Tus clientes','ov-fidelidad');?></h1></div><a class="ovf-app-primary" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'new']));?>"><?php echo ovf_v02_icon('user-plus');?><span><?php esc_html_e('Nuevo','ov-fidelidad');?></span></a></div>
 <?php echo ovf_v02_search_form(__('Nombre, teléfono o email','ov-fidelidad'),$q);?>
 <p class="ovf-results-meta"><?php if($q!==''):printf(esc_html(_n('%1$d resultado para “%2$s”','%1$d resultados para “%2$s”',count($rows),'ov-fidelidad')),count($rows),esc_html($q));?> · <a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'clients']));?>"><?php esc_html_e('Ver todos','ov-fidelidad');?></a><?php else:esc_html_e('Actividad más reciente primero','ov-fidelidad');endif;?></p>
 <div class="ovf-app-results">
 <?php foreach($rows as $r):?><a href="<?php echo esc_url(add_query_arg('source','search',ovf_scan_url($r->token)));?>"><i><?php echo esc_html(ovf_initial($r->name));?></i><div><b><?php echo esc_html($r->name);?></b><span><?php echo esc_html(ovf_contact_display($r,false)?:__('Sin contacto','ov-fidelidad'));?></span></div><strong><?php echo (int)$r->visits;?><small><?php echo esc_html(_n('compra','compras',(int)$r->visits,'ov-fidelidad'));?></small></strong></a><?php endforeach;?>
 <?php if(!$rows):?><div class="ovf-state compact"><?php echo $q!==''?esc_html__('No encontramos coincidencias.','ov-fidelidad'):esc_html__('Aún no hay clientes registrados.','ov-fidelidad');?> <a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'new']));?>"><?php esc_html_e('Registrar uno','ov-fidelidad');?> →</a></div><?php endif;?>
 </div>
</section>
<?php
 else:
  $today=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t['moves']} WHERE type='purchase' AND created_at >= %s",current_time('Y-m-d').' 00:00:00'));
  $new=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['clients']} WHERE created_at >= %s",current_time('Y-m-d').' 00:00:00'));
  $redeemed=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['moves']} WHERE type='redeem' AND created_at >= %s",current_time('Y-m-d').' 00:00:00'));?>
<section class="ovf-home">
 <span class="ovf-kicker"><?php echo esc_html(wp_date(_x('l, j \d\e F','fecha de la portada','ov-fidelidad')));?></span>
 <h1><?php printf(esc_html__('Hola, %s','ov-fidelidad'),esc_html(wp_get_current_user()->display_name));?></h1>
 <p><?php esc_html_e('¿Qué necesitas hacer?','ov-fidelidad');?></p>
 <a class="ovf-scan-cta" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'scanner']));?>"><i><?php echo ovf_v02_icon('scan');?></i><div><b><?php esc_html_e('Escanear QR','ov-fidelidad');?></b><span><?php esc_html_e('Registrar una compra o canjear','ov-fidelidad');?></span></div><em>→</em></a>
 <div class="ovf-app-actions">
  <a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'new']));?>"><i><?php echo ovf_v02_icon('user-plus');?></i><b><?php esc_html_e('Nuevo cliente','ov-fidelidad');?></b><span><?php esc_html_e('Registro rápido en mostrador','ov-fidelidad');?></span></a>
  <a href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'signup']));?>"><i><?php echo ovf_v02_icon('qr');?></i><b><?php esc_html_e('Registro público','ov-fidelidad');?></b><span><?php esc_html_e('Mostrar QR de alta al cliente','ov-fidelidad');?></span></a>
 </div>
 <?php echo ovf_v02_search_form();?>
 <?php if(ovf_v02_owner_cap()):?><a class="ovf-today ovf-today-link" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'activity']));?>" aria-label="<?php esc_attr_e('Ver actividad','ov-fidelidad');?>"><?php else:?><div class="ovf-today"><?php endif;?><span><?php esc_html_e('Hoy','ov-fidelidad');?></span>
  <div><strong><?php echo $today;?></strong><small><?php echo esc_html(_n('compra','compras',$today,'ov-fidelidad'));?></small></div>
  <div><strong><?php echo $new;?></strong><small><?php echo esc_html(_n('cliente nuevo','clientes nuevos',$new,'ov-fidelidad'));?></small></div>
  <div><strong><?php echo $redeemed;?></strong><small><?php echo esc_html(_n('canje','canjes',$redeemed,'ov-fidelidad'));?></small></div>
 <?php if(ovf_v02_owner_cap()):?><em class="ovf-today-more"><?php esc_html_e('Ver actividad','ov-fidelidad');?> →</em></a><?php else:?></div><?php endif;?>
 <?php if(ovf_v02_owner_cap()):?><a class="ovf-owner-card" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'rewards']));?>"><span><?php echo ovf_v02_icon('gift');?></span><div><small><?php esc_html_e('ADMINISTRACIÓN','ov-fidelidad');?></small><b><?php esc_html_e('Beneficios','ov-fidelidad');?></b><em><?php esc_html_e('Crear, editar o pausar recompensas','ov-fidelidad');?></em></div><?php echo ovf_v02_icon('chevron');?></a><a class="ovf-owner-card" href="<?php echo esc_url(ovf_v02_url('ovf_page_portal',['view'=>'team']));?>"><span><?php echo ovf_v02_icon('users');?></span><div><small><?php esc_html_e('ADMINISTRACIÓN','ov-fidelidad');?></small><b><?php esc_html_e('Gestionar equipo','ov-fidelidad');?></b><em><?php esc_html_e('Empleados, encargados y contraseñas','ov-fidelidad');?></em></div><?php echo ovf_v02_icon('chevron');?></a><?php endif;?>
 <button type="button" id="ovf-install-app" class="ovf-install" hidden><?php esc_html_e('Instalar esta Web App','ov-fidelidad');?></button>
</section>
<?php endif;
 return ovf_v02_shell(ob_get_clean());
}

add_shortcode('ov_fidelidad_registro','ovf_v02_public_register');
/** Registro público. El POST se procesa en ovf_action_public_register(); al terminar se abre la tarjeta. */
function ovf_v02_public_register(){
 ovf_v02_assets();
 $msgs=['missing'=>__('Completa tu nombre, WhatsApp y correo electrónico.','ov-fidelidad'),'invalid_email'=>__('Escribe un correo electrónico válido. Revisa que esté bien escrito.','ov-fidelidad'),'invalid_phone'=>__('Escribe un número de WhatsApp válido de 10 dígitos.','ov-fidelidad'),'exists'=>__('Ya hay una tarjeta con ese teléfono o email. Pide tu enlace en el mostrador y te lo compartimos.','ov-fidelidad'),'error'=>__('No pudimos crear tu tarjeta. Inténtalo nuevamente.','ov-fidelidad'),'expired'=>__('La página caducó. Vuelve a intentarlo.','ov-fidelidad'),'limit'=>__('Demasiados registros desde esta conexión. Inténtalo en unos minutos o pide ayuda en el mostrador.','ov-fidelidad'),'privacy'=>__('Para crear tu tarjeta necesitas aceptar el aviso de privacidad.','ov-fidelidad'),'referral'=>__('El código de invitación no es válido. Revísalo o borra el campo para continuar sin invitación.','ov-fidelidad')];
 $err=$msgs[sanitize_key($_GET['ovf_reg']??'')]??'';
 ob_start();?>
<section class="ovf-join"><div class="ovf-login-logo"><?php echo ovf_v02_logo_html();?></div><span class="ovf-kicker"><?php esc_html_e('Programa de beneficios','ov-fidelidad');?></span><h1><?php esc_html_e('Consulta tus beneficios','ov-fidelidad');?></h1><p><?php esc_html_e('Crea tu tarjeta para consultar el progreso y los beneficios del negocio.','ov-fidelidad');?></p>
<?php if($err):?><div class="ovf-app-alert error"><?php echo esc_html($err);?></div><?php endif;?>
<form method="post" class="ovf-app-form" action="<?php echo esc_url(remove_query_arg('ovf_reg'));?>"><?php wp_nonce_field('ovf_public_register');?>
 <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Código de invitación (opcional)','ov-fidelidad');?></span><input name="referral_code" maxlength="24" autocapitalize="characters" value="<?php echo esc_attr(sanitize_text_field(wp_unslash($_GET['ref']??'')));?>" placeholder="<?php esc_attr_e('Código de invitación (opcional)','ov-fidelidad');?>"><small class="ovf-referral-copy"><?php esc_html_e('Si tienes un código de invitación, recibirás un descuento en tu primera compra.','ov-fidelidad');?></small></label>
 <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Tu nombre','ov-fidelidad');?></span><input name="name" placeholder="<?php esc_attr_e('Tu nombre','ov-fidelidad');?>" required autocomplete="name"></label>
 <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('WhatsApp','ov-fidelidad');?></span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="<?php esc_attr_e('WhatsApp','ov-fidelidad');?>" aria-label="WhatsApp" required minlength="10" maxlength="20"></label>
 <label class="ovf-register-field"><span class="ovf-sr-only"><?php esc_html_e('Email','ov-fidelidad');?></span><input name="email" type="email" autocomplete="email" autocapitalize="none" placeholder="<?php esc_attr_e('Correo electrónico','ov-fidelidad');?>" required></label>
 <label class="ovf-register-field"><span class="ovf-register-label"><?php esc_html_e('Fecha de nacimiento (opcional)','ov-fidelidad');?></span><input name="birthday" type="date" aria-label="<?php esc_attr_e('Fecha de nacimiento (opcional)','ov-fidelidad');?>"></label>
 <?php echo ovf_email_consent_field();?>
 <?php $pv=ovf_privacy_notice();if($pv):$pv_text=!empty($pv['text'])?$pv['text']:($pv['page']?ovf_privacy_text($pv['page']):'');$pv_req=ovf_get_option('ovf_privacy_required','1')==='1';?>
 <label class="ovf-check ovf-privacy-check"><input type="checkbox" name="ovf_privacy" value="1" <?php echo $pv_req?'required':'';?>><span><?php printf(esc_html__('He leído y acepto el %s.','ov-fidelidad'),'<a href="'.esc_url($pv['url']).'" target="_blank" rel="noopener" class="ovf-privacy-link"'.($pv_text?' data-ovf-privacy="1"':'').'>'.esc_html__('aviso de privacidad','ov-fidelidad').'</a>');?></span></label>
 <?php if($pv_text):?><template id="ovf-privacy-text"><h3><?php echo esc_html($pv['page']?get_the_title($pv['page']):__('Aviso de privacidad','ov-fidelidad'));?></h3><div class="ovf-privacy-body"><?php echo $pv_text;?></div></template><?php endif;endif;?>
 <div class="ovf-hp" aria-hidden="true"><label><?php esc_html_e('Website','ov-fidelidad');?><input name="ovf_website" tabindex="-1" autocomplete="off"></label></div>
 <button class="ovf-app-primary" name="ovf_public_register" value="1"><?php esc_html_e('Crear mi tarjeta','ov-fidelidad');?></button>
</form>
<small><?php esc_html_e('Al registrarte aceptas formar parte del programa de fidelidad del establecimiento.','ov-fidelidad');?></small></section>
<script>document.addEventListener('click',function(e){var a=e.target.closest('[data-ovf-privacy]');var t=document.getElementById('ovf-privacy-text');if(!a||!t)return;e.preventDefault();
var root=document.createElement('div');root.className='ovf-sheet ovf-privacy-sheet';root.innerHTML='<div class="ovf-sheet-back"></div><div class="ovf-sheet-card" role="dialog" aria-modal="true"></div>';
var card=root.querySelector('.ovf-sheet-card');card.appendChild(t.content.cloneNode(true));var b=document.createElement('div');b.className='ovf-sheet-actions one';b.innerHTML='<button type="button" class="ovf-app-primary"><?php echo esc_js(__('Entendido','ov-fidelidad'));?></button>';card.appendChild(b);
(document.querySelector('.ovf-v02')||document.body).appendChild(root);function close(){root.classList.remove('is-open');setTimeout(function(){root.remove();},250);}
root.querySelector('.ovf-sheet-back').onclick=close;b.querySelector('button').onclick=function(){var c=document.querySelector('input[name=ovf_privacy]');if(c)c.checked=true;close();};requestAnimationFrame(function(){root.classList.add('is-open');});});</script>
<?php return ovf_v02_public_shell(ob_get_clean(),'register');}

// Búsqueda predictiva compartida por el panel y la Web App.
add_action('wp_ajax_ovf_client_suggest','ovf_ajax_client_suggest');
function ovf_ajax_client_suggest(){
 if(!is_user_logged_in()||!ovf_v02_staff_cap())wp_send_json_error(['message'=>__('No tienes permiso para buscar clientes.','ov-fidelidad')],403);
 check_ajax_referer('ovf_client_search','nonce');
 $q=sanitize_text_field(wp_unslash($_POST['q']??''));$context=sanitize_key($_POST['context']??'app');
 if(strlen($q)<2)wp_send_json_success([]);
 global $wpdb;$t=ovf_tables();$like='%'.$wpdb->esc_like($q).'%';$digits=preg_replace('/\D+/','',$q);$items=[];
 if($context==='reports'){
  if(!ovf_v02_owner_cap())wp_send_json_error(['message'=>__('No tienes permiso para consultar reportes.','ov-fidelidad')],403);
  $from_raw=isset($_POST['from'])&&is_string($_POST['from'])?sanitize_text_field(wp_unslash($_POST['from'])):'';$to_raw=isset($_POST['to'])&&is_string($_POST['to'])?sanitize_text_field(wp_unslash($_POST['to'])):'';
  $from=preg_match('/^\d{4}-\d{2}-\d{2}$/',$from_raw)?$from_raw:wp_date('Y-m-01',current_time('timestamp'));
  $to=preg_match('/^\d{4}-\d{2}-\d{2}$/',$to_raw)?$to_raw:current_time('Y-m-d');
  $sql="SELECT c.id,c.name,c.email,c.phone,COUNT(m.id) purchases FROM {$t['clients']} c INNER JOIN {$t['moves']} m ON m.client_id=c.id AND m.type='purchase' AND m.created_at BETWEEN %s AND %s WHERE (c.name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s".($digits!==''?' OR c.phone LIKE %s':'').") GROUP BY c.id,c.name,c.email,c.phone ORDER BY purchases DESC,c.name ASC LIMIT 10";
  $args=[$from.' 00:00:00',$to.' 23:59:59',$like,$like,$like];if($digits!=='')$args[]='%'.$wpdb->esc_like($digits).'%';
  $rows=$wpdb->get_results($wpdb->prepare($sql,$args));
  foreach($rows as $r){$url=ovf_v02_url('ovf_page_portal',['view'=>'reports','from'=>$from,'to'=>$to,'customer'=>$r->name,'client_id'=>(int)$r->id]);$items[]=['name'=>$r->name,'contact'=>$r->phone?:$r->email?:'','detail'=>$r->email?:'','visits'=>(int)$r->purchases,'url'=>$url];}
 }elseif($context==='history'){
  ovf_ensure_moves_schema();
  if(!current_user_can('manage_options'))wp_send_json_error(['message'=>__('No tienes permiso para consultar el historial.','ov-fidelidad')],403);
  $sql="SELECT m.client_id,m.type,m.note,m.receipt_number,m.created_at,c.name,c.email,c.phone FROM {$t['moves']} m LEFT JOIN {$t['clients']} c ON c.id=m.client_id WHERE (c.name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s OR m.note LIKE %s OR m.receipt_number LIKE %s".($digits!==''?' OR c.phone LIKE %s':'').") ORDER BY m.id DESC LIMIT 40";
  $args=[$like,$like,$like,$like,$like];if($digits!=='')$args[]='%'.$wpdb->esc_like($digits).'%';
  $rows=$wpdb->get_results($wpdb->prepare($sql,$args));$seen=[];
  foreach($rows as $r){$id=(int)$r->client_id;if(!$id||isset($seen[$id]))continue;$seen[$id]=true;$detail=trim(($r->phone?:$r->email?:'').' · '.wp_strip_all_tags($r->note??''),' ·');
   $items[]=['name'=>$r->name?:__('Cliente eliminado','ov-fidelidad'),'contact'=>$r->phone?:$r->email?:'','detail'=>$detail?:$r->created_at,'visits'=>0,'url'=>add_query_arg(['page'=>'ov-fidelidad-history','client'=>$id,'q'=>$q],admin_url('admin.php'))];
  }
 }else{
  $sql="SELECT id,name,email,phone,token,visits,status FROM {$t['clients']} WHERE (name LIKE %s OR email LIKE %s OR phone LIKE %s".($digits!==''?' OR phone LIKE %s':'')." OR token LIKE %s)";
  $args=[$like,$like,$like];if($digits!=='')$args[]='%'.$wpdb->esc_like($digits).'%';$args[]=$like;
  if(!current_user_can('manage_options'))$sql.=" AND status='active'";
  $sql.=' ORDER BY name ASC LIMIT 10';$rows=$wpdb->get_results($wpdb->prepare($sql,$args));
  foreach($rows as $r){$url=current_user_can('manage_options')?admin_url('admin.php?page=ov-fidelidad-clients&action=edit&id='.(int)$r->id):add_query_arg('source','search',ovf_scan_url($r->token));$items[]=['name'=>$r->name,'contact'=>$r->phone?:$r->email?:'','detail'=>$r->email?:'','visits'=>(int)$r->visits,'url'=>$url];}
 }
 wp_send_json_success($items);
}
