OV Fidelidad 1.8.11.2: enlaces cortos seguros
- URL de tarjeta: /t/{slug-negocio}/{codigo-aleatorio-16}/.
- Nuevo código aleatorio de 96 bits, separado del token del QR.
- Los códigos QR actuales y los enlaces antiguos siguen funcionando.
- Enlaces de compartir, descarga de tarjeta y acceso al cliente usan la URL corta automáticamente.
- Nuevas columnas short_code con índice único por tabla de clientes, sin eliminar datos.
- Las rutas se registran automáticamente; si el hosting devuelve 404, guardar Ajustes > Enlaces permanentes.
- La URL es un acceso de tipo portador: compartir solo con el titular y mantener autorizaciones para acciones sensibles.

=== OV Fidelidad ===
Contributors: ovdivi
Tags: fidelidad, loyalty, qr, recompensas, pwa
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.8.11
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plataforma multinegocio de fidelidad con datos, tarjetas, personal y configuración separados por negocio, en una sola instalación WordPress.

== Description ==

OV Fidelidad convierte cualquier sitio WordPress en un club de fidelidad:

* **Tarjeta digital del cliente** con QR único, progreso, beneficios y actividad.
* **Escaneo con confirmación**: escanear → confirmar → compra registrada, sin salir del escáner.
* **Marca personalizable** por negocio: nombre, logo, icono de la app y colores.
* **Web App para el equipo** (instalable en el teléfono): escanear QR, registrar compras, canjear beneficios y dar de alta clientes.
* **Panel del encargado** dentro de la Web App: beneficios, equipo y actividad del negocio.
* **Beneficios** de una sola vez o cíclicos (cada N compras), con días para canjear.
* **Vigencia de compras** opcional (solo cuentan las de los últimos X días).
* **Registro público** con QR para el mostrador.
* **Campañas por correo**: promociones y novedades a clientes con consentimiento, con segmentos para todas las tarjetas, cumpleaños del mes o una tarjeta específica.
* **Multinegocio**: administra negocios desde una sola instalación. Cada negocio tiene clientes, compras, beneficios, campañas, personal, imágenes y ajustes aislados; una persona puede tener tarjeta en varios negocios.
* **Portal privado móvil para el superadministrador**: acceso con PIN de seis dígitos independiente de WordPress, administración de todos los negocios, búsqueda instantánea y paginación.
* Desde el portal móvil puedes editar por negocio identidad, colores, logotipo e icono, privacidad, recuperación de acceso, puntos, cashback, referidos, cumpleaños, niveles VIP, beneficios, imágenes promocionales y QR de registro.
* Colores administrativos independientes: personaliza el panel de OV Fidelidad y el portal privado sin modificar la paleta de cada negocio.
* **Ventas y recompensas por consumo**: captura del importe MXN por compra, puntos por gasto, conversión de puntos a saldo cashback, saldo utilizable en compras posteriores, bonos por cumpleaños y referidos, y tres niveles VIP configurables por gasto acumulado.
* **Reportes** de clientes sin volver en 30 días, frecuencia promedio de visita, beneficios más canjeados, ventas e importe capturado.
* **Referidos configurables**: el negocio puede ofrecer un descuento porcentual al cliente invitado en su primera compra y entregar a quien invita puntos o de 1 a 2 sellos al registrarse esa compra.
* Escáner con cámara compatible con Android, iPhone y escritorio (requiere HTTPS).
* Listo para traducir con Loco Translate (dominio `ov-fidelidad`, plantilla en `/languages`).

== Installation ==

1. Sube el plugin y actívalo. Se crean automáticamente las páginas de la Web App, el registro, la tarjeta y el portal privado de alta móvil.
2. Sigue el asistente inicial (nombre, logo, colores, encargado y primeros beneficios).
3. En **OV Fidelidad → Negocios** registra cada negocio desde el panel; se crea una cuenta de encargado y un espacio de datos independiente.
4. Entra al negocio desde el selector de negocio activo para configurar su programa.
5. En **OV Fidelidad → Ajustes** descarga el QR de registro para el mostrador.
6. Comparte con el equipo la URL de la Web App; en el teléfono se puede “Agregar a la pantalla de inicio”.
7. Para administrar desde celular sin iniciar sesión en WordPress, configura tu PIN en **OV Fidelidad → Alta móvil** y abre el portal privado. La sesión del portal dura 12 horas; el PIN se guarda como hash y puedes eliminarlo o reemplazarlo desde ese menú.
8. Configura **OV Fidelidad → Correo SMTP** con los datos de tu proveedor, una dirección remitente verificada y sus registros SPF/DKIM.


== Frequently Asked Questions ==

= ¿Dónde configuro puntos, cashback y referidos? =
En Reglas de acumulación, dentro de la Web App del encargado. Cada compra suma un sello; el encargado puede activar puntos, cashback o ambos, y definir las reglas de referidos y niveles VIP para su negocio.

= ¿Cómo funciona una invitación? =
Cada cliente puede compartir su enlace desde su tarjeta. La persona invitada también puede escribir el código manualmente al registrarse. En Reglas de acumulación puedes configurar el descuento porcentual para la primera compra del invitado (0 lo desactiva) y el bono de quien invita: puntos o 1–2 sellos. Al registrar la primera compra, la Web App pregunta si el empleado aplicó el descuento manualmente en caja. Si confirma, el descuento se registra y se consume una sola vez; si registra la compra sin descuento, el beneficio de primera compra vence. En ambos casos, al guardar la compra se completa la invitación y el bono configurado para quien invitó se acredita automáticamente. Si el bono está en sellos, se suman a sus compras y pueden ayudarle a desbloquear beneficios.

= ¿Cómo comparto nuevamente la tarjeta de un cliente? =
En la Web App, busca al cliente y abre su ficha. Usa “Compartir tarjeta con el cliente”: en un teléfono abre las opciones para compartir y en una computadora copia el enlace para pegarlo en un mensaje.

= ¿Puede el cliente guardar su tarjeta en el teléfono? =
Sí. Desde su tarjeta puede tocar “Agregar tarjeta al teléfono”. Android puede ofrecer instalarla; en iPhone se muestran los pasos para usar Compartir → Agregar a pantalla de inicio en Safari.

= ¿Qué ve el encargado del negocio y qué ve el administrador? =
El encargado (dueño, gerente o responsable) trabaja en la Web App (clientes, reglas del programa, beneficios, equipo, actividad y reportes). El superadministrador administra negocios y la identidad inicial desde WordPress o desde el portal privado de alta móvil.

= ¿Puedo dar de alta negocios desde el teléfono? =
Sí. Configura un PIN de seis dígitos en OV Fidelidad → Alta móvil desde el escritorio y abre el enlace del portal en tu teléfono. El portal no usa las credenciales de WordPress. Desde ahí puedes buscar y administrar cualquier negocio registrado, editar sus ajustes y beneficios, cambiar promociones, compartir accesos y descargar su QR de registro. También puedes dar de alta negocios nuevos.

= ¿Funciona con WooCommerce? =
Sí. El acceso de la Web App lleva siempre a la Web App y el inicio de sesión de la tienda sigue llevando a "Mi cuenta", sin interferir.

= Tengo un plugin de caché, ¿afecta? =
No. OV Fidelidad excluye sus páginas de la caché automáticamente. Si tu hosting o CDN tiene una caché propia que no respeta las cabeceras estándar, excluye las rutas que se muestran en Ajustes → Herramientas.

= ¿Cómo se maneja el aviso de privacidad? =
En Ajustes → Privacidad eliges la página del aviso (por defecto, la de privacidad de WordPress) o un enlace externo. El registro público pide aceptarlo y guarda la fecha de aceptación.

= ¿Puedo cambiar el nombre de los roles? =
Sí, con Loco Translate puedes cambiar "Encargado" por "Gerente", "Administrador", etc. en cada sitio.

= ¿Por qué no abre la cámara? =
Los navegadores solo permiten la cámara en sitios con HTTPS.

= ¿Se pierden los datos si borro el plugin? =
No. Se conservan, salvo que actives “Borrar todos los datos al desinstalar” en Ajustes → Herramientas.

= ¿Cómo traduzco el plugin? =
Con Loco Translate: Plugins → OV Fidelidad → Nuevo idioma. La plantilla está en `languages/ov-fidelidad.pot`.

== Changelog ==

= 1.8.11 =
* Oculta los accesos compactos y el menú “Más” en escritorio; conserva ahí la navegación lateral completa sin duplicados.
* Ajusta la superposición del menú de cuenta en escritorio.

= 1.8.10 =
* Centra los iconos y etiquetas de cada acceso de la barra inferior en móvil.

= 1.8.9 =
* Ordena la barra móvil de la Web App con accesos principales compactos y un menú “Más” para las demás secciones.

= 1.8.8 =
* Mejora el restablecimiento del acceso: el correo de recuperación solo puede solicitarse para cuentas ligadas al negocio correspondiente y mantiene mensajes genéricos.
* Aclara el cambio de contraseña del encargado y avisa cuando la contraseña se actualizó.

= 1.8.7 =
* Agrega el restablecimiento manual de la contraseña del encargado al editar un negocio desde Alta móvil.
* Cambia la recuperación del equipo a un flujo propio con marca del negocio, mensajes genéricos y enlaces seguros sin mostrar la pantalla de acceso de WordPress.

= 1.8.6 =
* Permite cambiar desde Alta móvil la contraseña del encargado de un negocio existente; el campo vacío conserva la contraseña actual.
* Sustituye el enlace de recuperación genérico por una pantalla de marca y un enlace de restablecimiento propio de OV Fidelidad.

= 1.8.5 =
* La descarga del QR genera una imagen PNG de 1080 × 1080 px para impresión.

= 1.8.4 =
* Mejora el espaciado entre secciones y refina los encabezados del portal privado en móviles.
* Añade controles para personalizar los colores del panel administrativo y del portal móvil, separados de la identidad de cada negocio.

= 1.8.3 =
* Rediseña el acceso móvil con seis casillas de PIN, pegado automático del código y navegación de teclado.
* Añade la opción de eliminar el PIN y cierra las sesiones existentes al cambiarlo o quitarlo.
* Completa el formulario de alta móvil con identidad de la Web App, reseñas Google, colores, logo e icono, puntos, cashback, cumpleaños, referidos, niveles VIP, vigencia, privacidad y recuperación de acceso.

= 1.8.2 =
* Cambia el acceso al portal privado móvil para usar un PIN de seis dígitos configurado desde WordPress, con límite de intentos y sesión independiente de las cuentas de WordPress.
* Añade búsqueda AJAX y paginación para administrar todos los negocios existentes desde el portal móvil.
* Permite editar por negocio la identidad, colores, logo, icono, reseñas Google, privacidad, acceso del equipo, reglas de puntos/cashback, cumpleaños, referidos y niveles VIP.
* Permite agregar, editar y eliminar reglas de beneficios, además de subir, reemplazar y quitar imágenes promocionales.
* Muestra los enlaces del sistema y QR de registro descargable para cada negocio.

= 1.8.1 =
* Portal frontal privado, adaptable a celular y tablet, para que el superadministrador cree negocios sin abrir el escritorio de WordPress.
* El alta móvil captura negocio, encargado, correo, contraseña inicial, teléfono, color, logotipo, acumulación por sellos, puntos o cashback, referidos y primer beneficio opcional.
* El encargado puede editar después las reglas de puntos y cashback desde su Web App; una compra siempre suma el sello del programa.
* Al terminar se muestran los accesos para compartir con el dueño y se puede descargar el QR único de registro del negocio para imprimirlo.
* Contraseña segura generada automáticamente si se deja vacío el campo; el valor temporal solo queda disponible brevemente para compartirlo.

= 1.8.0 =
* Requires a positive purchase amount when registering a purchase from the QR scanner; the AJAX handler also validates the amount.
* Asks whether to add a receipt number before saving the scanned purchase; choosing yes requires a receipt number, choosing no saves without it.
* Makes the employee confirm whether the referral welcome discount was applied manually before the scanned purchase is saved.
* Applies the referrer's configured points or 1–2 stamp bonus after the referred customer's first purchase.
* Adds a share action for a customer's digital card from the customer detail in the Web App.
* Updates owner access messages for WhatsApp Web with simple, separated sections.

= 1.7.9 =
* Adds AJAX customer suggestions to owner reports, filter selection by exact customer, and clear display of 10 customers per page with a contained, scrollable table.
* Adds an optional receipt number to QR purchase registration and includes it in customer activity, admin history, search, and CSV exports.
* Adds a receipt-number column to the movement table with automatic migration for existing businesses.

= 1.7.8 =
* Added live business analytics reports with date filters, sales, ticket averages, scans, card activations, redemptions, and frequent-customer rankings.
* Added Excel-compatible CSV exports for admin and business-owner reports.
* Recorded successful QR card lookups as scan events for future analytics.

= 1.7.7 =
* Indica claramente el campo opcional de fecha de nacimiento en los formularios.
* El slider de promociones se desplaza hacia la izquierda con una transición más suave y un ciclo continuo.
* La lista de negocios muestra 10 por página, con búsqueda AJAX, filtros por estado y orden por clientes o actividad de compras de los últimos 30 días.
* Aclara las reglas iniciales al crear un negocio.
* Permite entregar el bono por referido como puntos o 1–2 sellos; los sellos también pueden desbloquear beneficios.

= 1.7.6 =
* Reduce el ancho del banner promocional en la tarjeta del cliente y lo alinea con el margen del contenido.
* Añade configuración SMTP global con servidor, puerto, cifrado, autenticación, remitente autorizado y correo de prueba.
* Las campañas usan el nombre del negocio como remitente visible, una dirección autorizada y el correo del negocio como respuesta.
* La contraseña SMTP no se vuelve a mostrar en pantalla y solo los administradores pueden modificarla.

= 1.7.2 =
* El slider promocional avanza automáticamente, conserva puntos interactivos y ya no muestra flechas. Pausa durante interacción y respeta la preferencia de movimiento reducido.
* Las campañas muestran el nombre del negocio como remitente y el resultado de envío ya no muestra el nombre de la plataforma.
* Añade una nota para configurar SPF y DKIM y mejorar la entrega de campañas.

= 1.7.1 =
* Corrige el submenú duplicado del Resumen y deja una sola entrada clara en el panel.
* Muestra siempre el negocio activo en el escritorio y permite cambiarlo desde la cabecera.
* Mejora el estilo responsive de tarjetas, formularios, tablas, botones y navegación administrativa.
* Mantiene las secciones operativas y sus datos asociados al negocio seleccionado.

= 1.7.0 =
* Añade administración multinegocio y alta de cuentas de encargado desde WordPress.
* Separa las tablas de clientes, compras, beneficios e historial y las opciones de cada negocio.
* Añade selector de negocio en el panel, enlaces y QR de registro por negocio, y segmenta la gestión del personal.
* Conserva los datos y configuración existentes como el negocio principal al actualizar desde 1.6.4.

= 1.6.4 =
* Agrega sugerencias de búsqueda AJAX para clientes en la Web App y el panel, y para clientes/notas en el historial.
* Retira la cola y los estilos sin uso de WhatsApp; conserva el consentimiento y las campañas por correo.


= 1.5.2 =
* Campañas de email con consentimiento y segmentación por cliente individual, cumpleaños o lista completa.
* Alineación y estilos consistentes para botones, formularios, tablas, paneles, QR y avisos en todas las pantallas de administración de WordPress.

= 1.5.1 =
* Rediseño visual de la tarjeta del cliente con sellos de estrella por compra y progreso hacia el siguiente beneficio.
* Mejor jerarquía para puntos, saldo cashback y nivel VIP.
* Estilos renovados para dashboard, métricas, paneles, tablas y formularios del escritorio.

= 1.5.0 =
* Porcentaje configurable de descuento de invitación para la primera compra del cliente referido.
* La tarjeta muestra el descuento pendiente y el equipo ve el cálculo al registrar el ticket.
* El historial de compras conserva importe original, descuento e importe final; los reportes suman los descuentos por invitación.
* El descuento se reclama de forma atómica y solo se aplica una vez, junto con el bono de referido posterior a la compra.

= 1.4.0 =
* La tarjeta muestra invitaciones registradas, pendientes de primera compra y puntos ganados por referidos.
* La persona invitada ve confirmación cuando su código queda aplicado al crear la tarjeta.
* El bono continúa entregándose tras la primera compra del invitado para reducir registros fraudulentos o duplicados.

= 1.3.0 =
* Nueva sección visible “Reglas de acumulación” con explicación de visitas, importes, puntos, cashback, cumpleaños, referidos y niveles VIP.
* El escáner captura el importe dentro de la confirmación y muestra las reglas activas del negocio.
* La tarjeta del cliente permite compartir su enlace/código de invitación y explica cuándo se genera el bono; el registro acepta código manual y avisa si no es válido.
* Cada tarjeta tiene manifest y opción para agregarla a la pantalla de inicio del teléfono, independiente de la app del equipo.

= 1.2.0 =
* Captura de importe MXN y acumulación de puntos/cashback en compras nuevas.
* Conversión de puntos a saldo cashback y uso del saldo en compras posteriores.
* Cumpleaños con bono anual opcional, referido con código personal y bono al completar la primera compra, y niveles VIP por gasto acumulado.
* Segmento VIP para campañas manuales de correo.
* Reportes de ventas capturadas, ticket promedio, frecuencia, clientes inactivos, canjes y actividad posterior a campañas.
* Las ventas de versiones anteriores permanecen como importe desconocido y no se inventan importes retroactivos.

= 1.0.0 =
* Primera versión de producción.
* Web App del equipo con navegación completa, escáner con respaldo para iPhone, ficha del cliente, alta rápida y registro público.
* Panel del encargado en la Web App: Beneficios, Equipo y Actividad.
* Motor de beneficios: una sola vez o cíclicos, días para canjear, vigencia de compras y sincronización automática con clientes existentes.
* Verificación y reparación automática de la base de datos en instalaciones antiguas; diagnóstico de beneficios por cliente.
* Seguridad: formularios con patrón POST → redirección, protección de privilegios del administrador, registro público con anti-spam y límite por conexión.
* Traducción completa con Loco Translate.
* Opción para borrar o conservar los datos al desinstalar.
* Escaneo rápido: al leer el QR desde la Web App aparece una ventana para confirmar la compra (y canjear beneficios) sin salir del escáner; la cámara se abre sola.
* El QR de la tarjeta contiene un código que solo entiende la Web App: la cámara normal del teléfono ya no abre ninguna página.
* Icono de la pantalla de inicio, favicon y manifest generados a partir del icono o el logo configurados, con fondo ajustable.
* Indicador de carga al navegar entre secciones.
* Privacidad: los empleados ven el teléfono y el correo de los clientes de forma parcial (los encargados, completos); la búsqueda sigue funcionando con el dato completo.
* Aviso de privacidad configurable en Ajustes (página del sitio, enlace externo o texto escrito en Ajustes), con alerta si la página elegida no está publicada, con casilla de aceptación en el registro público, lectura en ventana y fecha de aceptación guardada en la ficha del cliente.
* Compatibilidad con caché: las páginas del programa nunca se guardan en caché (WP Rocket, LiteSpeed, W3 Total Cache, WP Super Cache, WP Fastest Cache, SiteGround, Breeze, Hummingbird, Cache Enabler, Nginx Helper, Cloudflare/Varnish por cabeceras), purga automática al actualizar y botón "Limpiar caché del programa" en Herramientas.
* Confirmación antes de registrar una compra o canjear un beneficio desde la ficha del cliente (evita registros por un toque accidental).
* El formulario de acceso de la Web App siempre lleva a la Web App; los demás inicios de sesión del sitio (WooCommerce, wp-login.php) funcionan como siempre.
* Redirecciones robustas detrás de proxies, CDN o dominios alternos (www/sin www).
* Historial de actividad completo en la ficha del cliente (compras, canjes y alta, con quién lo registró), en una sección colapsable.
* Roles: "Encargado" (dueño, gerente o responsable) y "Empleado".
* Historial del escritorio con filtros (cliente o nota, persona del equipo, acción, identificación y rango de fechas), atajos de fecha, paginación y exportación a CSV.
* Colores de marca configurables en todo el plugin (escritorio, Web App y tarjeta); valores iniciales neutros para cualquier giro de negocio.

= 1.1.0 =
* Carrusel de imágenes promocionales cargadas por el encargado y visible en las tarjetas digitales.
* Consentimiento independiente para avisos de cuenta/beneficios y para promociones, con fecha y opción de baja.
* Avisos pendientes de bienvenida, beneficio desbloqueado y beneficio próximo a vencer.

* Registro de mensajes enviados u omitidos.

1.8.11.1 — Registro con WhatsApp: pestañas QR/WhatsApp en la pantalla del empleado; búsqueda exacta por número dentro del negocio activo y confirmación compartida de compras/canjes. No se alteran tablas ni registros existentes.

OV Fidelidad 1.8.11.3 - Fotografías del equipo
- Cada encargado o empleado puede subir o quitar su foto desde Mi cuenta > Mi perfil y fotografía.
- El encargado puede gestionar las fotos de empleados de su mismo negocio desde Gestionar equipo.
- Formatos JPG, PNG, WebP; máximo 2 MB; optimización cuadrada 512x512; inicial como respaldo.
- Los archivos se almacenan como adjuntos WordPress con referencia por user_meta (ovf_profile_avatar_id).
- No se modifican tarjetas, movimientos ni reglas de acumulación existentes.


1.8.11.4: Corrige el formulario de foto en cuentas administradoras sin negocio fijo y mueve el menu de cuenta en escritorio para que no cubra la barra lateral.

OV Fidelidad 1.9.0 - Administración de plataforma
---------------------------------------------------
- El menú principal abre el Dashboard global, independiente del negocio seleccionado.
- Dashboard general de negocios y clientes por tablas existentes; solo consulta datos.
- Módulos globales: Usuarios y accesos, Configuración global, Páginas del sistema, Acceso general y SMTP.
- Búsqueda de empleados AJAX, desactivación de cuentas con invalidación de sesiones y enlaces de restablecimiento por correo.
- El menú identifica claramente las secciones de la plataforma y de cada negocio.
- Negocios conservan identificadores, tablas, opciones, QR, movimientos, contraseñas y ajustes anteriores.
- Los enlaces antiguos de /wp-admin/admin.php?page=ov-fidelidad&ovf_business_id=N continúan abriendo el resumen de N.
- El apartado de clientes, beneficios, reportes y reglas sigue trabajando con el negocio seleccionado (compatibilidad).
- No se crea una nueva estructura de tablas ni se migra el negocio con ID 1.
- Antes de actualizar: respaldo de la base de datos y ambos plugins. Probar en staging los recorridos de negocio 1 y negocio adicional.


OV Fidelidad 1.9.4 - Administrador independiente
- Menú nativo de WordPress: solo la entrada OV Fidelidad es visible; rutas internas se conservan y siguen registradas.
- Navegación propia de plataforma con grupos desplegables mediante details/summary.
- Contexto de negocio visible y enlace para cambiarlo.
- Buscadores de negocios y usuarios sin manipular los submenús de WordPress.
- No se eliminan tablas, negocios, usuarios, configuraciones ni conexiones con OV Membresías.
