<?php
/**
 * OV Fidelidad — plantilla de pantalla completa para la Web App, el registro y la tarjeta.
 * Evita la cabecera, el pie y los anchos de contenido del tema (Divi, Twenty*, etc.),
 * que antes encogían la app y le quitaban espacio.
 */
if (!defined('ABSPATH')) exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class('ovf-fullscreen'); ?>>
<?php wp_body_open(); ?>
<?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
<?php wp_footer(); ?>
</body>
</html>
